# test_final_state.py
#
# Pytest suite that validates the **FINAL** state of the filesystem
# after the “storage administrator” exercise has been completed.
#
# These tests MUST pass only when the student has carried out every
# step exactly as required.  Any deviation will be reported with a
# clear, actionable error message.
#
# Only the Python standard library and pytest are used.

import os
from pathlib import Path

import pytest

ROOT = Path("/home/user")
ARCHIVE_DIR = ROOT / "archive"
ARCHIVE_APP2 = ARCHIVE_DIR / "app2_logs"
OLD_LOGS_ROOT = ROOT / "logs"
APP2_LINK_PATH = OLD_LOGS_ROOT / "app2"
APP1_DIR = OLD_LOGS_ROOT / "app1"
OLD_LATEST_LINK = APP1_DIR / "old_latest"
AUDIT_FILE = ROOT / "symlink_audit.log"

EXPECTED_APP2_TARGET = "/home/user/archive/app2_logs"          # stored target string
EXPECTED_OLD_LATEST_STORED_TARGET = "log2.txt"                 # stored (relative) target
EXPECTED_OLD_LATEST_RESOLVED = "/home/user/logs/app1/log2.txt" # resolved absolute target
EXPECTED_AUDIT_LINES = {
    f"{APP2_LINK_PATH} -> {EXPECTED_APP2_TARGET}",
    f"{OLD_LATEST_LINK} -> {EXPECTED_OLD_LATEST_RESOLVED}",
}


def _read_file(p: Path) -> str:
    """Return full contents of a text file, asserting it exists and is readable."""
    assert p.is_file(), f"Expected regular file missing: {p}"
    try:
        return p.read_text()
    except Exception as exc:  # pragma: no cover
        raise AssertionError(f"Could not read {p}: {exc}") from exc


def test_archive_directory_structure():
    """A. & B.  Verify /home/user/archive and /home/user/archive/app2_logs with logA.txt."""
    assert ARCHIVE_DIR.is_dir(), f"Missing archive directory: {ARCHIVE_DIR}"
    assert ARCHIVE_APP2.is_dir(), f"Missing directory: {ARCHIVE_APP2}"

    logA = ARCHIVE_APP2 / "logA.txt"
    assert logA.is_file(), f"'logA.txt' not found at expected location: {logA}"

    expected_contents = "Debug 123\n"
    actual_contents = _read_file(logA)
    assert (
        actual_contents == expected_contents
    ), f"Unexpected contents for {logA}: {actual_contents!r} (expected {expected_contents!r})"


def test_app2_symlink_points_to_archive():
    """C.  /home/user/logs/app2 must be a symlink with the correct *absolute* target."""
    assert APP2_LINK_PATH.exists(), f"Path missing: {APP2_LINK_PATH}"
    assert APP2_LINK_PATH.is_symlink(), f"{APP2_LINK_PATH} should be a symbolic link, not a directory."

    stored_target = os.readlink(APP2_LINK_PATH)
    assert stored_target == EXPECTED_APP2_TARGET, (
        f"Symlink {APP2_LINK_PATH} has incorrect target string: {stored_target!r} "
        f"(expected {EXPECTED_APP2_TARGET!r}). Ensure it is an *absolute* path."
    )

    # Confirm the link resolves to the same target (guards against broken links).
    resolved = str(APP2_LINK_PATH.resolve(strict=True))
    assert (
        resolved == EXPECTED_APP2_TARGET
    ), f"Symlink {APP2_LINK_PATH} resolves to {resolved!r}, expected {EXPECTED_APP2_TARGET!r}."


def test_old_latest_relative_symlink_inside_app1():
    """D.  Validate the relative symlink /home/user/logs/app1/old_latest."""
    assert OLD_LATEST_LINK.exists(), f"Symlink missing: {OLD_LATEST_LINK}"
    assert OLD_LATEST_LINK.is_symlink(), f"{OLD_LATEST_LINK} should be a symbolic link."

    stored_target = os.readlink(OLD_LATEST_LINK)
    assert not stored_target.startswith(
        "/"
    ), f"old_latest symlink target must be *relative*, but got absolute path {stored_target!r}."
    assert (
        stored_target == EXPECTED_OLD_LATEST_STORED_TARGET
    ), f"old_latest symlink has incorrect stored target: {stored_target!r} (expected {EXPECTED_OLD_LATEST_STORED_TARGET!r})."

    resolved_target = str(OLD_LATEST_LINK.resolve(strict=True))
    assert (
        resolved_target == EXPECTED_OLD_LATEST_RESOLVED
    ), f"old_latest resolves to {resolved_target!r}, expected {EXPECTED_OLD_LATEST_RESOLVED!r}."


def test_symlink_audit_file_contents():
    """E.  /home/user/symlink_audit.log must list both symlinks exactly once, with proper formatting."""
    assert AUDIT_FILE.is_file(), f"Audit file missing: {AUDIT_FILE}"

    text = _read_file(AUDIT_FILE)
    assert text.endswith(
        "\n"
    ), "Audit file must end with exactly one trailing newline (no extra blank lines)."

    # Collect the lines without their terminating newlines.
    lines = text.rstrip("\n").split("\n")
    assert len(lines) == 2, (
        f"Audit file must contain exactly 2 non-blank lines, found {len(lines)} line(s):\n{text}"
    )

    lines_set = set(lines)
    missing = EXPECTED_AUDIT_LINES - lines_set
    extras = lines_set - EXPECTED_AUDIT_LINES

    assert not missing, (
        "Audit file is missing the following required line(s):\n"
        + "\n".join(missing)
    )
    assert not extras, (
        "Audit file contains unexpected extra line(s):\n"
        + "\n".join(extras)
    )