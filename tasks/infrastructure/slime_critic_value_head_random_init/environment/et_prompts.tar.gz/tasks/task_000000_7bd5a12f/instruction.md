You are working as a storage administrator and need to reclaim space under 
/home/user/logs while ensuring applications that depend on the original 
paths keep functioning.

### INITIAL STATE VISIBLE TO YOU
--------------------------------
```
/home/user/logs/
    ├── app1/
    │   ├── log1.txt   (a small text file)
    │   └── log2.txt   (a small text file)
    └── app2/
        └── logA.txt   (a small text file)
```

### GOAL
----
1.  Create an archive area under /home/user called `archive`.
2.  Relocate the whole `app2` directory into that archive area **without** 
    changing its name, but place it under a new directory called `app2_logs`.  
    (The resulting path on disk must be `/home/user/archive/app2_logs/…`).
3.  Replace the original `/home/user/logs/app2` directory with a **symbolic 
    link** (not a hard-link) named “app2” that points to the *new* location.
    *   The link itself must live in `/home/user/logs/`  
    *   The link target must be an **absolute path**.
4.  Inside the still-existing `/home/user/logs/app1` directory, create a 
    **relative** symbolic link called `old_latest` that points to `log2.txt`.
    (Use a *relative* target string such that the link remains valid if 
    `/home/user/logs/app1` is moved as a whole.)
5.  Produce an audit file at `/home/user/symlink_audit.log` describing every 
    symbolic link you created in *exactly* the format below:

    `<full_link_path> -> <absolute_resolved_target_path>`

    *   One link per line.  
    *   `<full_link_path>` must be the absolute path of the link itself  
    *   `<absolute_resolved_target_path>` must be the absolute path the link 
        ultimately resolves to after the filesystem follows the link.  
    *   No extra whitespace before or after the arrow (`->`).  
    *   End the file with a single trailing newline.

    Example of the required formatting **ONLY FOR ILLUSTRATION**
    `/path/to/link -> /real/target/path`

### SUCCESS CRITERIA (what the automated tests will verify)
-------------------------------------------------------
A. Directory `/home/user/archive` exists.  
B. Directory `/home/user/archive/app2_logs` contains `logA.txt`.  
C. The path `/home/user/logs/app2` is a *symbolic link* whose target string 
   is an absolute path equal to `/home/user/archive/app2_logs`.  
D. The path `/home/user/logs/app1/old_latest` is a *symbolic link* whose 
   resolved target is `/home/user/logs/app1/log2.txt` and whose stored 
   target string is relative (does not start with “/”).  
E. `/home/user/symlink_audit.log` exists and contains exactly two lines:
   ` /home/user/logs/app2 -> /home/user/archive/app2_logs`
   ` /home/user/logs/app1/old_latest -> /home/user/logs/app1/log2.txt`
   (with a single trailing newline, no blank lines, and lines in any order).

### IMPORTANT:
*   Do not delete any log files.  
*   Do not compress the files.  
*   Only symbolic links should be used—no hard links.  
*   Absolute vs. relative link requirements are strict.  
*   Follow the exact audit-file format so automated grading succeeds.