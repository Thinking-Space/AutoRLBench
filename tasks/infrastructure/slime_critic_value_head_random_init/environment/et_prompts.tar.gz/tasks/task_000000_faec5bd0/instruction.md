A colleague left a small data-cleaning chore for you.

1.  A CSV file already exists at  
    `/home/user/webdev/data/products.csv`

2.  Your job is to:
    a. Read that CSV and keep only the rows whose `status` column equals the literal string “active”.  
    b. Convert the remaining rows to a JSON array (pretty-printed with an indentation of two spaces).  
    c. Save that JSON to  
       `/home/user/webdev/output/active_products.json`

3.  The JSON *must* satisfy all of the following so the automated test can find it:
    *   The file must contain one top-level JSON array.  
    *   Inside the array, each element is an object with **exactly** four keys in this order: `id`, `name`, `price`, `status`.  
    *   `id` is an integer, `name` is a string, `price` is a number, `status` is the string “active”.  
    *   Objects must appear in ascending `id` order.  
    *   The file must end with a single newline (Unix LF).

4.  After generating the JSON, create a plain-text log file at  
    `/home/user/webdev/output/task.log`  
    The file must contain **exactly** these two lines (each terminated with a single LF newline):

    ```
    Total products: <N>
    Active products: <M>
    ```

    where `<N>` is the total row count in `products.csv` (including discontinued ones) and `<M>` is the number of active rows you kept.  
    No extra spaces, blank lines, or additional text.

5.  Keep everything inside `/home/user/webdev`.  
    You do not need root privileges.

The automatic checker will:
*   Verify that `/home/user/webdev/output/active_products.json` exists and is byte-for-byte identical to the expected content.  
*   Verify that `/home/user/webdev/output/task.log` exists and has the two exact lines described above.  
*   Check that both files are world-readable.

Proceed using the terminal to accomplish the task.