# test_final_state.py
#
# Pytest suite to validate the *final* filesystem state after the student
# has completed the data-cleaning task.
#
# It asserts that:
#   • /home/user/webdev/output/active_products.json exists,
#     is world-readable, and its content is *exactly* as expected.
#   • /home/user/webdev/output/task.log exists,
#     is world-readable, and its content is *exactly* as expected.
#
# Only stdlib + pytest are used.  Failure messages point out precisely
# what is still wrong so the student can fix it.

import os
import stat
import json
import pytest

HOME = "/home/user"
WEBDEV_DIR = os.path.join(HOME, "webdev")
OUTPUT_DIR = os.path.join(WEBDEV_DIR, "output")

ACTIVE_JSON = os.path.join(OUTPUT_DIR, "active_products.json")
TASK_LOG = os.path.join(OUTPUT_DIR, "task.log")

# --------------------------------------------------------------------------- #
# Expected byte-for-byte content (LF newlines, pretty-printed, 2-space indent)
# --------------------------------------------------------------------------- #
EXPECTED_JSON_STR = (
    '[\n'
    '  {\n'
    '    "id": 1,\n'
    '    "name": "Widget",\n'
    '    "price": 19.99,\n'
    '    "status": "active"\n'
    '  },\n'
    '  {\n'
    '    "id": 3,\n'
    '    "name": "Doohickey",\n'
    '    "price": 9.95,\n'
    '    "status": "active"\n'
    '  },\n'
    '  {\n'
    '    "id": 5,\n'
    '    "name": "Whatsit",\n'
    '    "price": 14.0,\n'
    '    "status": "active"\n'
    '  }\n'
    ']\n'
)
EXPECTED_JSON_BYTES = EXPECTED_JSON_STR.encode()

EXPECTED_LOG_STR = "Total products: 5\nActive products: 3\n"
EXPECTED_LOG_BYTES = EXPECTED_LOG_STR.encode()


# ---------------------------- Helper utilities ----------------------------- #
def _require_world_readable(path: str) -> None:
    """
    Assert that *others* have read permission on `path`.
    Group/owner permissions may be anything;
    write permission for others is allowed but not required.
    """
    mode = os.stat(path).st_mode
    if not (mode & stat.S_IROTH):
        pytest.fail(
            f"{path} exists but is not world-readable (others need read bit). "
            f"Fix with: chmod o+r {path}"
        )


def _read_bytes(path: str) -> bytes:
    """Read a file in binary mode, raising pytest-friendly errors."""
    if not os.path.exists(path):
        pytest.fail(f"Required file missing: {path}")
    if not os.path.isfile(path):
        pytest.fail(f"Expected a regular file at {path}, found something else.")
    try:
        with open(path, "rb") as fp:
            return fp.read()
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"Unable to read {path}: {exc}")


# --------------------------------- Tests ----------------------------------- #
def test_output_directory_exists():
    """The /home/user/webdev/output directory must still exist."""
    assert os.path.isdir(OUTPUT_DIR), f"Directory missing: {OUTPUT_DIR}"


@pytest.mark.parametrize(
    "path,expected_bytes,description",
    [
        (ACTIVE_JSON, EXPECTED_JSON_BYTES, "JSON output"),
        (TASK_LOG, EXPECTED_LOG_BYTES, "task log"),
    ],
)
def test_files_exist_and_world_readable(path, expected_bytes, description):
    """Common checks for required files."""
    if not os.path.isfile(path):
        pytest.fail(f"{description} file missing at: {path}")

    # World readable?
    _require_world_readable(path)

    # Content check handled in dedicated tests below.


def test_active_products_json_exact_content_and_parseable():
    """
    The JSON output must match the expected pretty printed form byte-for-byte
    *and* be valid JSON with the required structure.
    """
    actual = _read_bytes(ACTIVE_JSON)

    # First, strict byte-for-byte comparison.
    if actual != EXPECTED_JSON_BYTES:
        # Provide a short diff-style hint without spamming entire files.
        msg_lines = ["active_products.json is not exactly as expected."]
        msg_lines.append("First byte position where they differ (0-based):")
        for i, (a_byte, e_byte) in enumerate(zip(actual, EXPECTED_JSON_BYTES)):
            if a_byte != e_byte:
                msg_lines.append(f"  offset {i}: actual 0x{a_byte:02x}, expected 0x{e_byte:02x}")
                break
        msg_lines.append(
            "Make sure indent spacing, key order, numeric formatting, and "
            "the trailing newline are all exactly correct."
        )
        pytest.fail("\n".join(msg_lines))

    # Second, semantic sanity check: it parses and contains the right data.
    try:
        data = json.loads(actual.decode())
    except json.JSONDecodeError as exc:
        pytest.fail(f"active_products.json is not valid JSON: {exc}")

    # Structural assertions (these will not usually fail if byte-comparison passed,
    # but they give clearer error messages in edge cases).
    assert isinstance(data, list), "Top-level JSON must be an array."
    expected_ids = [1, 3, 5]
    assert [row.get("id") for row in data] == expected_ids, "IDs or order incorrect."
    for row in data:
        assert list(row.keys()) == ["id", "name", "price", "status"], (
            "Each object must contain EXACTLY the keys "
            "id, name, price, status in that order."
        )
        assert row["status"] == "active", "Non-active product found in JSON output."


def test_task_log_exact_content():
    """task.log must contain exactly the two specified lines."""
    actual = _read_bytes(TASK_LOG)
    if actual != EXPECTED_LOG_BYTES:
        pytest.fail(
            "task.log content is incorrect.\n"
            "Expected exactly:\n"
            + EXPECTED_LOG_STR
        )