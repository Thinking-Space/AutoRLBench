#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


export LC_ALL=C.UTF-8

export LANG=C.UTF-8

export PATH=/usr/local/bin:/usr/bin:/bin:$PATH

set -e && \
    apt-get update -qq && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3-pip \
        jq \
        gawk \
        ca-certificates && \
    pip3 install --no-cache-dir pytest

mkdir -p /home/user/webdev/data && \
    mkdir -p /home/user/webdev/output

cat > /home/user/webdev/data/products.csv <<'EOF'
id,name,price,status
1,Widget,19.99,active
2,Gadget,29.49,discontinued
3,Doohickey,9.95,active
4,Thingamajig,4.50,discontinued
5,Whatsit,14.00,active
EOF

chmod 0755 /home/user && \
    chmod 0755 /home/user/webdev && \
    chmod 0755 /home/user/webdev/data && \
    chmod 0777 /home/user/webdev/output && \
    chmod 0644 /home/user/webdev/data/products.csv

apt-get clean && true

chmod 755 /home/user
