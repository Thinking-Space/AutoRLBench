You are a DevSecOps engineer who must prove—using “policy-as-code”—that every hostname listed in the corporate allow-list can actually be resolved on the running system.

**Initial state:**
1.  An allow-list file already exists at `/home/user/policy/dns_allowlist.txt`.
2.  Its exact, line-delimited contents are:
    ```
    localhost
    invalid.local
    ```

**Objective:**
Create a new CSV compliance report at `/home/user/policy/dns_audit.csv`.

**Output requirements for `/home/user/policy/dns_audit.csv`:**
*   One line per hostname, in the same order that the hostnames appear in `dns_allowlist.txt`.
*   Three comma-separated fields **without any surrounding spaces**:
    1.  `hostname` (verbatim)
    2.  `status` – the literal string `RESOLVED` or `UNRESOLVED` (uppercase)
    3.  `result` – if status is `RESOLVED`, the first IPv4 address returned by the system resolver; if `UNRESOLVED`, the literal string `N/A`
*   No header line, no trailing commas, and each line must end with a single UNIX newline (LF).

*Note: The output file will be checked by an automated process and must be created in exactly the format described. Extra whitespace, incorrect case, or missing newlines will result in failure.*

**Concrete example:**
The contents of the final `/home/user/policy/dns_audit.csv` file should be:
```
localhost,RESOLVED,127.0.0.1
invalid.local,UNRESOLVED,N/A
```

**Deliverable:**
The only file you need to create or modify is `/home/user/policy/dns_audit.csv`. No additional output is required in the terminal once the file has been created correctly.