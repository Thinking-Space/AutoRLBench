# test_final_state.py
#
# Pytest suite that validates the **final** operating-system / filesystem
# state for the “DNS allow-list audit” exercise.
#
# What we verify _after_ the student’s solution has run:
#
# 1. /home/user/policy/dns_allowlist.txt is still present, world-readable
#    (0644), and its **contents are unchanged**.
# 2. /home/user/policy/dns_audit.csv now exists, is a regular file with mode
#    0644, and its contents match the exercise’s *truth* bytes-for-bytes:
#
#       localhost,RESOLVED,127.0.0.1\n
#       invalid.local,UNRESOLVED,N/A\n
#
#    - Exactly two lines, in that order.
#    - UNIX LF line endings only (no CR, no CRLF).
#    - No header, no trailing blank lines, no extra whitespace.
# 3. The information in dns_audit.csv is *semantically* correct, i.e. it
#    reflects real resolver behaviour on the host at test time.
#
# Any deviation from the specification must result in a clear, actionable
# test failure message.
#
# Only the Python standard library and pytest are used.

import os
import stat
import socket
from pathlib import Path

import pytest

POLICY_DIR = Path("/home/user/policy")
ALLOWLIST_FILE = POLICY_DIR / "dns_allowlist.txt"
AUDIT_CSV_FILE  = POLICY_DIR / "dns_audit.csv"

# ---------- Ground-truth data -------------------------------------------------

ALLOWLIST_EXPECTED_LINES = ["localhost", "invalid.local"]

AUDIT_CSV_EXPECTED_TEXT = (
    "localhost,RESOLVED,127.0.0.1\n"
    "invalid.local,UNRESOLVED,N/A\n"
)
AUDIT_CSV_EXPECTED_LINES = AUDIT_CSV_EXPECTED_TEXT.splitlines()


# ---------- Helper utilities --------------------------------------------------

def assert_permissions(path: Path, expected_mode: int):
    """
    Assert that a file has exactly expected_mode (e.g. 0o644).
    """
    actual_mode = stat.S_IMODE(path.stat().st_mode)
    assert actual_mode == expected_mode, (
        f"{path} permissions are {oct(actual_mode)}, expected {oct(expected_mode)}."
    )


def read_text_exact(path: Path) -> str:
    """
    Read a text file strictly as UTF-8 without altering newlines.
    """
    with path.open("r", encoding="utf-8", newline="") as fh:
        return fh.read()


# ---------- Tests -------------------------------------------------------------

def test_policy_directory_still_exists():
    assert POLICY_DIR.is_dir(), f"Directory {POLICY_DIR} disappeared."


# --------------------------------------------------------------------------- #
#                       Allow-list integrity checks                           #
# --------------------------------------------------------------------------- #

def test_allowlist_file_still_intact():
    """
    The exercise explicitly says dns_allowlist.txt must remain unmodified.
    We therefore re-assert existence, permissions and **exact** contents.
    """
    assert ALLOWLIST_FILE.is_file(), (
        f"Required allow-list file {ALLOWLIST_FILE} is missing."
    )
    assert_permissions(ALLOWLIST_FILE, 0o644)

    actual_text = read_text_exact(ALLOWLIST_FILE)
    actual_lines = actual_text.splitlines()
    assert actual_lines == ALLOWLIST_EXPECTED_LINES, (
        f"{ALLOWLIST_FILE} contents have changed.\n"
        f"Expected lines: {ALLOWLIST_EXPECTED_LINES!r}\n"
        f"Actual lines  : {actual_lines!r}"
    )


# --------------------------------------------------------------------------- #
#                       Audit CSV existence / perms                           #
# --------------------------------------------------------------------------- #

def test_audit_csv_exists_and_has_correct_mode():
    assert AUDIT_CSV_FILE.is_file(), (
        f"Compliance report {AUDIT_CSV_FILE} is missing."
    )
    assert_permissions(AUDIT_CSV_FILE, 0o644)


# --------------------------------------------------------------------------- #
#                      Audit CSV ‑ exact byte comparison                      #
# --------------------------------------------------------------------------- #

def test_audit_csv_contents_exact():
    """
    The specification requires an *exact* byte-for-byte match to the truth
    string in AUDIT_CSV_EXPECTED_TEXT, including the final newline.
    """
    with AUDIT_CSV_FILE.open("rb") as fh:
        actual_bytes = fh.read()

    expected_bytes = AUDIT_CSV_EXPECTED_TEXT.encode("utf-8")
    assert actual_bytes == expected_bytes, (
        "Contents of dns_audit.csv differ from the expected truth value.\n"
        f"Expected bytes:\n{expected_bytes!r}\n"
        f"Actual bytes  :\n{actual_bytes!r}"
    )


# --------------------------------------------------------------------------- #
#         Audit CSV ‑ semantic validation against live DNS results            #
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize(
    "hostname,status_field,result_field",
    [
        ("localhost",     "RESOLVED",   "127.0.0.1"),
        ("invalid.local", "UNRESOLVED", "N/A"),
    ],
)
def test_audit_csv_semantics_match_resolver(hostname, status_field, result_field):
    """
    Beyond the byte-for-byte check, we also verify that each line in the CSV
    accurately reflects *current* resolver behaviour on this host.
    """
    # --- Fetch the CSV line for the given hostname
    csv_lines = AUDIT_CSV_EXPECTED_LINES  # we already know actual == expected
    matching = [ln for ln in csv_lines if ln.split(",", 1)[0] == hostname]
    assert matching, f"No CSV line found for hostname {hostname!r}"
    csv_line = matching[0]

    # --- Parse fields
    fields = csv_line.split(",")
    assert len(fields) == 3, f"CSV line {csv_line!r} does not have 3 fields."
    host_field, status_field_actual, result_field_actual = fields

    # --- Status & result logic checks
    if status_field_actual == "RESOLVED":
        # It must resolve, and first IPv4 must match result_field_actual
        try:
            ips = socket.gethostbyname_ex(hostname)[2]
        except socket.gaierror as exc:  # pragma: no cover
            pytest.fail(f"CSV says {hostname!r} is RESOLVED, but resolver fails: {exc}")
        assert ips, f"Resolver returned no IPv4 addresses for {hostname!r}."
        assert ips[0] == result_field_actual, (
            f"CSV lists first IPv4 {result_field_actual!r} for {hostname!r}, "
            f"but resolver returned {ips[0]!r}."
        )
    elif status_field_actual == "UNRESOLVED":
        # It must NOT resolve; result must be literally 'N/A'
        assert result_field_actual == "N/A", (
            f"CSV result field for unresolved host {hostname!r} must be 'N/A', "
            f"found {result_field_actual!r}."
        )
        with pytest.raises(socket.gaierror):
            socket.gethostbyname(hostname)
    else:  # pragma: no cover
        pytest.fail(
            f"Invalid status {status_field_actual!r} for host {hostname!r} "
            "— expected 'RESOLVED' or 'UNRESOLVED'."
        )