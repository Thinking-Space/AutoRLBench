# test_final_state.py
"""
Pytest suite that validates the **final** filesystem state after the student
ran the “quick security-hygiene scan on PostgreSQL backups” task.

The tests assert, with great precision, that:
1.  /home/user/security_scan exists (correct type & perms).
2.  The two required log files exist, have sane permissions, end with '\n',
    and conform EXACTLY to the required, machine-parsable format.
3.  The offending-file and password-leak findings listings are *exactly*
    those dictated by the known “truth” data for the three pre-existing
    backup files and nothing else (no extra / missing lines).
4.  The student echoed the absolute paths to both log files to STDOUT.

Only the Python standard library and pytest are used.
"""
from __future__ import annotations

import os
import re
import stat
from pathlib import Path
from typing import List, Optional

import pytest


# --------------------------------------------------------------------------- #
# CONSTANTS                                                                   #
# --------------------------------------------------------------------------- #
HOME = Path("/home/user")
BACKUP_DIR = HOME / "db_backups"
SEC_DIR = HOME / "security_scan"

BACKUP_REPORT = SEC_DIR / "backup_permissions_report.log"
PASSWORD_REPORT = SEC_DIR / "password_leak_report.log"

# Expected log body lines (after the 2-line header) ------------------------- #
EXPECTED_BACKUP_REPORT_LINES = [
    "/home/user/db_backups/dev_2023-05-01.sql | 0600 | UNENCRYPTED_SQL",
    "/home/user/db_backups/hr_2023-05-01.sql | 0644 | UNENCRYPTED_SQL",
    "/home/user/db_backups/hr_2023-05-01.sql | 0644 | WORLD_READABLE",
]

EXPECTED_PASSWORD_REPORT_LINES = [
    (
        "/home/user/db_backups/hr_2023-05-01.sql | 3 | "
        "CREATE ROLE hr_user WITH LOGIN PASSWORD 'secret123';"
    )
]

# Regex for strict ISO-8601 UTC timestamp “YYYY-MM-DDThh:mm:ssZ”
ISO_TS_RE = re.compile(
    r"# (?:Backup Permission Scan Report|Plain-text Credential Scan Report) "
    r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$"
)

# Acceptable dir permissions: 0700 or 0755 (strictly these two)
ACCEPTABLE_DIR_PERMS = {0o700, 0o755}

# --------------------------------------------------------------------------- #
# HELPERS                                                                     #
# --------------------------------------------------------------------------- #
def octal_perm(path: Path) -> str:
    """Return permission bits as zero-padded octal string, e.g. '0644'."""
    return format(stat.S_IMODE(path.stat().st_mode), "04o")


def file_lines(path: Path) -> List[str]:
    """Return *stripped* lines from a text file (rstrip only the newline)."""
    with path.open("r", encoding="utf-8") as fh:
        return [ln.rstrip("\n") for ln in fh.readlines()]


def file_ends_with_newline(path: Path) -> bool:
    """True iff the file’s last byte is `\n`."""
    with path.open("rb") as fh:
        if fh.seek(0, os.SEEK_END) == 0:  # empty file
            return False
        fh.seek(-1, os.SEEK_END)
        return fh.read(1) == b"\n"


def read_student_stdout() -> Optional[str]:
    """
    Best-effort attempt to retrieve what the student printed to STDOUT.
    The exact capture location is environment/harness specific, so we probe
    a handful of common locations and env vars.  If none are found we return
    None so that the corresponding test can be skipped (not failed).
    """
    # 1. Direct env variable with content
    for env_var in ("STUDENT_STDOUT", "STDOUT"):
        if env_var in os.environ and os.environ[env_var].strip():
            return os.environ[env_var]

    # 2. Path to a file containing the captured stdout
    candidate_paths = [
        os.environ.get("STUDENT_STDOUT_PATH"),
        "/tmp/student_stdout.txt",
        "/tmp/stdout",
        "/home/user/stdout",
        "/home/user/.stdout",
    ]
    for p in candidate_paths:
        if p and Path(p).exists():
            return Path(p).read_text(encoding="utf-8", errors="replace")

    return None


# --------------------------------------------------------------------------- #
# TESTS                                                                       #
# --------------------------------------------------------------------------- #
def test_security_scan_directory_exists_and_perms():
    assert SEC_DIR.exists(), "Directory /home/user/security_scan does not exist."
    assert SEC_DIR.is_dir(), "/home/user/security_scan exists but is not a directory."
    dir_perm = stat.S_IMODE(SEC_DIR.stat().st_mode)
    assert (
        dir_perm in ACCEPTABLE_DIR_PERMS
    ), f"/home/user/security_scan has permissions {octal_perm(SEC_DIR)}, expected 0700 or 0755."


@pytest.mark.parametrize("path", [BACKUP_REPORT, PASSWORD_REPORT])
def test_log_files_exist_and_have_sane_perms(path: Path):
    assert path.exists(), f"Required log file {path} is missing."
    assert path.is_file(), f"{path} exists but is not a regular file."
    assert (
        octal_perm(path) == "0644"
    ), f"{path} should have permission 0644 but is {octal_perm(path)}."
    assert file_ends_with_newline(
        path
    ), f"{path} must end with exactly one newline ('\\n')."


def test_backup_permissions_report_format_and_contents():
    lines = file_lines(BACKUP_REPORT)

    # ── Header checks ──────────────────────────────────────────────────────
    assert lines, f"{BACKUP_REPORT} appears to be empty."
    assert ISO_TS_RE.match(
        lines[0]
    ), "First line must match '# Backup Permission Scan Report <ISO-8601-timestamp>'."
    assert (
        lines[1] == "FILENAME | PERMISSIONS | ISSUE"
    ), "Second line of backup report must be the literal header 'FILENAME | PERMISSIONS | ISSUE'."

    # ── Body lines (after header) ──────────────────────────────────────────
    body = lines[2:]
    assert (
        body == EXPECTED_BACKUP_REPORT_LINES
    ), (
        f"{BACKUP_REPORT} body lines do not match expected.\n"
        f"Expected:\n  " + "\n  ".join(EXPECTED_BACKUP_REPORT_LINES) +
        f"\nFound:\n  " + "\n  ".join(body)
    )


def test_password_leak_report_format_and_contents():
    lines = file_lines(PASSWORD_REPORT)

    # ── Header checks ──────────────────────────────────────────────────────
    assert lines, f"{PASSWORD_REPORT} appears to be empty."
    assert ISO_TS_RE.match(
        lines[0]
    ), "First line must match '# Plain-text Credential Scan Report <ISO-8601-timestamp>'."
    assert (
        lines[1] == "FILENAME | LINE_NUMBER | MATCH"
    ), "Second line of password leak report must be the literal header 'FILENAME | LINE_NUMBER | MATCH'."

    # ── Body lines ─────────────────────────────────────────────────────────
    body = lines[2:]
    assert (
        body == EXPECTED_PASSWORD_REPORT_LINES
    ), (
        f"{PASSWORD_REPORT} body lines do not match expected.\n"
        f"Expected:\n  " + "\n  ".join(EXPECTED_PASSWORD_REPORT_LINES) +
        f"\nFound:\n  " + "\n  ".join(body)
    )


def test_student_echoed_paths_to_stdout():
    stdout = read_student_stdout()
    if stdout is None:
        pytest.skip("Could not locate captured STDOUT for the student's session.")
    for required_path in (str(BACKUP_REPORT), str(PASSWORD_REPORT)):
        assert (
            required_path in stdout
        ), f"Expected '{required_path}' to be printed to STDOUT but it was not found."