You are a database reliability engineer who has been asked to run a quick security-hygiene scan on yesterday’s PostgreSQL backups that live in “/home/user/db_backups”.

    BACKGROUND
    ──────────
    1. Every night a cron-driven dump script places *.sql* or compressed *.sql.gz* files in /home/user/db_backups.  
    2. The security team is worried that:
       a. Some of the uncompressed .sql files may have been left world-readable (permission **0644** or more permissive).  
       b. Uncompressed .sql files should really be shipped encrypted (or at least gzip-compressed) before being copied off-box.  
       c. Some dumps may accidentally contain plain-text credentials (the string “PASSWORD” followed by a quoted literal).  

    WHAT YOU MUST DELIVER
    ─────────────────────
    Create ONE new directory and TWO plain-text log files that summarise the scan results in a highly specific, machine-parsable format.

    1. Directory to create  
       • /home/user/security_scan  
       (Make no assumption that it already exists—create it with default user permissions.)

    2. File #1: Backup permission findings  
       • Path  : /home/user/security_scan/backup_permissions_report.log  
       • Format :  
         Line 1: “# Backup Permission Scan Report <ISO-8601-timestamp>”  
                 (Example: “# Backup Permission Scan Report 2027-11-23T14:35:08Z”)  
         Line 2: literal header → “FILENAME | PERMISSIONS | ISSUE”  
         Subsequent lines (one per offending backup) must be ordered alphabetically by **full path** and follow this pattern exactly:  

             <absolute-path> | <octal-perm> | <ISSUE_CODE>

         Recognised ISSUE_CODE values  
             WORLD_READABLE   → file permissions are **0644** or looser  
             UNENCRYPTED_SQL  → file is a plain “*.sql” (not .gz) regardless of perms  

         A single file may trigger both conditions. If so, generate two separate lines (same filename; different ISSUE_CODE).

    3. File #2: Plain-text credential findings  
       • Path  : /home/user/security_scan/password_leak_report.log  
       • Format :  
         Line 1: “# Plain-text Credential Scan Report <ISO-8601-timestamp>”  
         Line 2: literal header → “FILENAME | LINE_NUMBER | MATCH”  
         Subsequent lines (alphabetically by path) following exactly:  

             <absolute-path> | <1-based-line-number> | <the full text of the matching line>

       A match is a line that (case-insensitive) contains the substring “password”.  
       Include the line verbatim as it appears in the file (leading/trailing spaces preserved).

    4. Console feedback  
       After both log files are written, print their absolute paths to STDOUT—one path per line—so a human (or CI step) sees where the reports live.

    CONSTRAINTS
    • Do NOT move, rename, delete, edit, compress or otherwise change the existing backup files.  
    • You do not have root; stay in /home/user.  
    • The timestamp in both logs must be generated dynamically at runtime in strict ISO-8601 “YYYY-MM-DDThh:mm:ssZ” form (UTC).  
    • End every line (including the final one) with a single newline “\n”.  

    SUCCESS CRITERIA (checked by automated tests)
    1. Directory /home/user/security_scan exists.  
    2. File /home/user/security_scan/backup_permissions_report.log exists and conforms exactly to the format above.  
    3. File /home/user/security_scan/password_leak_report.log exists and conforms exactly to the format above.  
    4. The paths of both log files are echoed to STDOUT (order unimportant).