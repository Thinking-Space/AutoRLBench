A customer suspects that the firmware image you supplied them last month became corrupted during transfer.
*   You are in the role of a support-desk engineer who must collect quick diagnostics for the development team.
*   The developer workstation already contains the original image at
    /home/user/support/firmware_v2.1.0.bin and a reference checksum file called
    /home/user/support/reference.sha256.

Your assignment (no sudo needed):

You must verify the integrity of `/home/user/support/firmware_v2.1.0.bin`. This involves calculating its SHA-256 digest and comparing it to the reference digest in `/home/user/support/reference.sha256`.

The results of this process should be recorded in the following way:

*   The file `/home/user/support/checksums.log` must be created or appended to, containing a line with the computed SHA-256 digest. The line must use the following exact two-column format:

        firmware_v2.1.0.bin  <computed-sha256>

    *   Two consecutive spaces separate the filename and the digest.
    *   A single trailing newline must follow the digest.
*   The file `/home/user/support/verification.log` must be created containing the result of the comparison. It must contain ONE of these exact single-line messages (no extra whitespace, uppercase as shown):

        VERIFIED OK
        VERIFIED FAILED

    *   Choose “VERIFIED OK” only when the digests are an exact match.
*   The same single-line status (either `VERIFIED OK` or `VERIFIED FAILED`) must also be displayed on the terminal so that an on-call technician sees the result immediately.

The automated grader will check all of the following:

*   /home/user/support/checksums.log exists and contains exactly one well-formatted line for firmware_v2.1.0.bin (duplicates or extra text will fail the test).
*   /home/user/support/verification.log exists and holds **only** one of the two strings specified above, matching the console output.
*   If the verification log says VERIFIED OK, the digest inside checksums.log must be identical to the digest in reference.sha256.
    If it says VERIFIED FAILED, the two values must differ.

Only the three files mentioned should be modified or created; everything else on the filesystem must remain untouched.