# test_final_state.py
#
# Pytest suite that validates the **FINAL** operating-system / file-system
# state for the “firmware checksum” exercise.
#
# What is verified after the student’s solution has run:
#
#   1. The original artefacts (/home/user/support/firmware_v2.1.0.bin and
#      /home/user/support/reference.sha256) are **unchanged**.
#   2. /home/user/support/checksums.log
#        • exists as a regular file
#        • contains exactly ONE line
#        • the line is strictly:  "firmware_v2.1.0.bin␠␠<64-hex-digest>\n"
#          (two spaces, 64 lowercase hex digits, single trailing newline)
#   3. /home/user/support/verification.log
#        • exists as a regular file
#        • contains exactly ONE of the two allowed strings followed by '\n':
#            "VERIFIED OK\n"  or  "VERIFIED FAILED\n"
#   4. Consistency between the files:
#        • If verification.log says VERIFIED OK   ⇒ digest in checksums.log
#          must match the reference digest.
#        • If it says VERIFIED FAILED             ⇒ digest must differ.
#   5. No *other* files were created inside /home/user/support.
#
# Any failure message pinpoints precisely what is still wrong.

import hashlib
import os
import re
import stat
import pytest

SUPPORT_DIR        = "/home/user/support"
FIRMWARE_PATH      = os.path.join(SUPPORT_DIR, "firmware_v2.1.0.bin")
REFERENCE_PATH     = os.path.join(SUPPORT_DIR, "reference.sha256")
CHECKSUM_LOG_PATH  = os.path.join(SUPPORT_DIR, "checksums.log")
VERIFICATION_PATH  = os.path.join(SUPPORT_DIR, "verification.log")

# The SHA-256 digest of an empty file (the expected reference digest)
EMPTY_FILE_SHA256 = (
    "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
)

# --------------------------------------------------------------------------- #
# Helper functions
# --------------------------------------------------------------------------- #
def sha256_of_file(path: str) -> str:
    hasher = hashlib.sha256()
    with open(path, "rb") as fp:
        for chunk in iter(lambda: fp.read(8192), b""):
            hasher.update(chunk)
    return hasher.hexdigest()

def read_single_line(path: str) -> str:
    with open(path, "r", encoding="utf-8") as fp:
        data = fp.read()
    # Ensure exactly ONE trailing newline
    assert data.endswith("\n"), f"{path} must end with a single newline."
    assert data[:-1].find("\n") == -1, (
        f"{path} must contain exactly one line (found additional newline)."
    )
    return data

# --------------------------------------------------------------------------- #
# 1. Validate original, immutable artefacts are still intact
# --------------------------------------------------------------------------- #
def test_firmware_still_empty_and_unchanged():
    assert os.path.isfile(FIRMWARE_PATH), (
        f"Firmware file {FIRMWARE_PATH} is missing."
    )
    # Size must still be 0
    size = os.path.getsize(FIRMWARE_PATH)
    assert size == 0, (
        f"Firmware file should remain 0 bytes but is {size} bytes."
    )
    # Digest must still be the empty-file digest
    digest = sha256_of_file(FIRMWARE_PATH)
    assert digest == EMPTY_FILE_SHA256, (
        "Firmware file contents have changed — SHA-256 digest differs."
    )

def test_reference_sha256_unchanged():
    assert os.path.isfile(REFERENCE_PATH), (
        f"Reference file {REFERENCE_PATH} is missing."
    )
    expected_line = f"{EMPTY_FILE_SHA256}  firmware_v2.1.0.bin\n"
    content = read_single_line(REFERENCE_PATH)
    assert content == expected_line, (
        "reference.sha256 contents were modified.\n"
        f"Expected exactly:\n{expected_line!r}\nGot:\n{content!r}"
    )

# --------------------------------------------------------------------------- #
# 2. Verify /home/user/support/checksums.log
# --------------------------------------------------------------------------- #
def test_checksums_log_format_and_contents():
    assert os.path.isfile(CHECKSUM_LOG_PATH), (
        f"{CHECKSUM_LOG_PATH} must exist after running the solution."
    )

    line = read_single_line(CHECKSUM_LOG_PATH)
    # Regex: filename, two spaces, 64 lowercase hex digits, newline already stripped
    pattern = r"^firmware_v2.1.0\.bin  ([0-9a-f]{64})$"
    m = re.match(pattern, line.rstrip("\n"))
    assert m, (
        "checksums.log must contain exactly:\n"
        "'firmware_v2.1.0.bin␠␠<64-hex-digest>\\n'\n"
        f"Got: {line!r}"
    )
    digest = m.group(1)
    # Store digest on the object for later tests
    pytest.checksum_digest_in_log = digest.lower()

# --------------------------------------------------------------------------- #
# 3. Verify /home/user/support/verification.log and consistency with checksum
# --------------------------------------------------------------------------- #
def test_verification_log_and_consistency():
    assert os.path.isfile(VERIFICATION_PATH), (
        f"{VERIFICATION_PATH} must exist after running the solution."
    )

    status_line = read_single_line(VERIFICATION_PATH)
    allowed = {"VERIFIED OK\n", "VERIFIED FAILED\n"}
    assert status_line in allowed, (
        f"{VERIFICATION_PATH} must contain exactly "
        "'VERIFIED OK\\n' or 'VERIFIED FAILED\\n'.\n"
        f"Got: {status_line!r}"
    )

    status = status_line.rstrip("\n")
    digest_in_log = getattr(pytest, "checksum_digest_in_log", None)
    assert digest_in_log is not None, (
        "Internal test error: checksum digest not captured."
    )

    # Obtain reference digest from reference.sha256 (it was validated earlier)
    reference_digest = EMPTY_FILE_SHA256

    if status == "VERIFIED OK":
        assert digest_in_log == reference_digest, (
            "verification.log says VERIFIED OK but the digest in checksums.log "
            "does NOT match reference.sha256."
        )
    else:  # VERIFIED FAILED
        assert digest_in_log != reference_digest, (
            "verification.log says VERIFIED FAILED but the digest in "
            "checksums.log actually matches the reference."
        )

# --------------------------------------------------------------------------- #
# 4. Ensure no extra files were created inside /home/user/support
# --------------------------------------------------------------------------- #
def test_no_unexpected_files_created():
    expected_files = {
        "firmware_v2.1.0.bin",
        "reference.sha256",
        "checksums.log",
        "verification.log",
    }
    actual = set(os.listdir(SUPPORT_DIR))
    unexpected = actual - expected_files
    assert not unexpected, (
        "The following unexpected files/directories were found in "
        f"{SUPPORT_DIR}: {', '.join(sorted(unexpected))}"
    )