# test_final_state.py
#
# Pytest suite that validates the final operating-system state
# *after* the student has completed the “frequency report” task
# for the nightly archive dated 2024-06-10.
#
# These tests assert that:
#   • /home/user/backup_reports/ exists
#   • 2024-06-10_frequency_report.txt exists and its contents are
#     byte-for-byte correct, sorted, and complete
#   • operator_audit.log exists and its LAST line matches the
#     required ISO-8601 timestamp + literal text
#
# Only the Python standard library and pytest are used.

import os
import re
import datetime as _dt
from pathlib import Path
from collections import Counter

import pytest

# --------------------------------------------------------------------------- #
# Constants                                                                   #
# --------------------------------------------------------------------------- #

RESTORE_LOG = Path("/home/user/restores/2024-06-10/daily_filelist.log")
BACKUP_DIR = Path("/home/user/backup_reports")
REPORT_FILE = BACKUP_DIR / "2024-06-10_frequency_report.txt"
AUDIT_LOG = BACKUP_DIR / "operator_audit.log"

# Regex for the audit-log last-line check
AUDIT_REGEX = re.compile(
    r"^(?P<ts>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})Z generated 2024-06-10_frequency_report\.txt\n$"
)

# --------------------------------------------------------------------------- #
# Helper functions                                                            #
# --------------------------------------------------------------------------- #


def _read_bytes(path: Path) -> bytes:
    """Read a file as raw bytes (strict UTF-8 decode happens elsewhere)."""
    with path.open("rb") as fh:
        return fh.read()


def _read_text(path: Path) -> str:
    """Read a file and return decoded UTF-8 text (strict)."""
    return _read_bytes(path).decode("utf-8", errors="strict")


def _expected_report_content() -> str:
    """
    Generate, from the *source log*, the exact text that **must** appear
    in 2024-06-10_frequency_report.txt.  This keeps the test resilient if
    the source fixture ever changes.
    """
    source_lines = _read_text(RESTORE_LOG).splitlines()

    # Count how many times each pathname occurs.
    counter = Counter(source_lines)

    # Sort: 1) descending count, 2) ascending pathname (case-sensitive).
    ordered_items = sorted(counter.items(), key=lambda kv: (-kv[1], kv[0]))

    # Build the expected lines with required formatting and trailing \n.
    lines = [f"{count} {path}\n" for path, count in ordered_items]

    return "".join(lines)


# --------------------------------------------------------------------------- #
# Tests                                                                       #
# --------------------------------------------------------------------------- #


def test_backup_reports_directory_created():
    """/home/user/backup_reports/ must now exist and be a directory."""
    assert BACKUP_DIR.exists(), "Directory /home/user/backup_reports/ does not exist."
    assert BACKUP_DIR.is_dir(), "/home/user/backup_reports/ exists but is not a directory."


def test_frequency_report_exists_and_is_regular_file():
    """The frequency report must exist and be a regular file."""
    assert REPORT_FILE.exists(), f"Expected report file {REPORT_FILE} to exist."
    assert REPORT_FILE.is_file(), f"{REPORT_FILE} exists but is not a regular file."


def test_frequency_report_content_is_exact_and_sorted():
    """
    Validate byte-for-byte content of the frequency report.

    The test recomputes the expected result from the source log to ensure
    correctness and to enforce the required ordering & formatting rules.
    """
    expected = _expected_report_content()
    actual = _read_text(REPORT_FILE)

    # Quick length check for clearer assertion messages.
    assert len(actual) == len(expected), (
        "Frequency report size mismatch: "
        f"expected {len(expected)} bytes, got {len(actual)} bytes."
    )

    assert actual == expected, (
        "Frequency report content is incorrect.\n\n"
        "=== Expected ===\n"
        f"{expected}"
        "=== Actual ===\n"
        f"{actual}"
    )


def test_frequency_report_final_line_has_trailing_newline():
    """
    Every line, *including the last one*, must end with a Unix newline (0x0A).
    """
    raw_bytes = _read_bytes(REPORT_FILE)
    assert raw_bytes.endswith(b"\n"), (
        f"{REPORT_FILE} must end with a single newline character (0x0A)."
    )


def test_operator_audit_log_last_line_format_and_timestamp():
    """
    The audit log must exist and its LAST line must:
      • match the required regex
      • contain a timestamp that is not earlier than the restore log’s mtime
        (a conservative approximation of “container start time”).
    """
    assert AUDIT_LOG.exists(), f"Expected audit log {AUDIT_LOG} to exist."
    assert AUDIT_LOG.is_file(), f"{AUDIT_LOG} exists but is not a regular file."

    lines = _read_text(AUDIT_LOG).splitlines(keepends=True)
    assert lines, f"{AUDIT_LOG} is empty; expected at least one audit entry."

    last_line = lines[-1]
    match = AUDIT_REGEX.match(last_line)
    assert match, (
        "The last line of operator_audit.log does not match the required format.\n"
        f"Last line: {last_line!r}"
    )

    # Timestamp sanity check: ≥ the source restore log's modification time.
    ts_str = match.group("ts")
    ts = _dt.datetime.strptime(ts_str, "%Y-%m-%dT%H:%M:%S")
    ts = ts.replace(tzinfo=_dt.timezone.utc)

    restore_log_mtime = _dt.datetime.utcfromtimestamp(RESTORE_LOG.stat().st_mtime).replace(
        tzinfo=_dt.timezone.utc
    )

    assert ts >= restore_log_mtime, (
        "Timestamp in the last audit log line appears to be earlier than the restore "
        "log modification time, which is unlikely:\n"
        f"  audit timestamp : {ts_str}Z\n"
        f"  restore log mtime (UTC): {restore_log_mtime.isoformat(timespec='seconds')}Z"
    )


@pytest.mark.skipif(
    not os.getenv("CI_STDOUT_CAPTURE"),  # Environment variable set by harness if needed
    reason="Live STDOUT comparison only executed when the harness captures output",
)
def test_stdout_matches_report(capsys):
    """
    Optional: if the test harness is capturing the student's STDOUT (via
    CI_STDOUT_CAPTURE env-var), assert it is identical to the frequency
    report content.

    The harness should run the student’s script *before* pytest and export
    the captured stdout in the CI_STDOUT_CAPTURE environment variable.
    """
    captured_stdout = os.environ["CI_STDOUT_CAPTURE"]
    expected = _expected_report_content()
    assert captured_stdout == expected, (
        "STDOUT emitted by the student's script does not match the frequency report "
        "written to disk.\n\n"
        "=== Expected ===\n"
        f"{expected}"
        "=== STDOUT ===\n"
        f"{captured_stdout}"
    )