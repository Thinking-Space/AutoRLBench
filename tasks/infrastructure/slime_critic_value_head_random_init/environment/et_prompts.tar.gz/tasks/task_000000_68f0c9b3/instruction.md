You are a backup-operator who has just finished restoring the nightly archive dated 2024-06-10 into `/home/user/restores/2024-06-10/`.

Your task is to generate a *frequency report* that shows how many times each pathname appears in the restore log.

The restore software already produced a plain-text list of every object it tried to restore; that list is stored in

    /home/user/restores/2024-06-10/daily_filelist.log

From that file, count how many times each **full pathname** occurs, and create the report. The final, sorted result should be saved in a brand-new directory called `/home/user/backup_reports/` using the exact filename

    2024-06-10_frequency_report.txt

The report must be sorted so that:
*   the lines are ordered by the numeric count in *descending* order
*   if two or more items have the same count, those items are ordered alphabetically by the pathname (ascending, case-sensitive).

The report’s *exact* line format is:

    <count><single-space><pathname><newline>

Example for clarity (do **not** hard-code these numbers—they come from the log):

    42 /some/path/example.txt⏎

*   `<count>` must contain no leading zeroes.
*   There is **exactly one** ASCII space (0x20) between the integer and the path.
*   Every line, including the last one, **must** end with a Unix newline (0x0A).

After creating the report, emit the report’s content to STDOUT so a supervising engineer who is tail-ing the job log can see the same information that is written to the file.

For traceability purposes, append a one-line audit record to

    /home/user/backup_reports/operator_audit.log

The audit line must contain the UTC timestamp in ISO-8601 format, one space, the literal string “generated 2024-06-10_frequency_report.txt”.
Example layout (again, do not copy the timestamp verbatim):

    2024-06-12T14:07:33Z generated 2024-06-10_frequency_report.txt⏎

The automated checker will verify:
*   That `/home/user/backup_reports/2024-06-10_frequency_report.txt` exists.
*   That its contents follow the format and ordering rules above.
*   That the file exactly reflects the counts derived from the supplied `daily_filelist.log`.
*   That `/home/user/backup_reports/operator_audit.log` exists and the most recent line matches the formatting rule.

Remember you do **not** have root privileges. Work entirely under `/home/user`.