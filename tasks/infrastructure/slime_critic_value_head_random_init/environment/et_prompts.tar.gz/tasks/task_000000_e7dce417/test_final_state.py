# test_final_state.py
#
# Pytest suite that validates the **FINAL** state of the workstation
# after the “Synchronise a release bundle…” task has been completed.
#
# What is checked:
#   • The deployment workspace and its log-directory exist.
#   • Each “remote” application directory contains EXACTLY the three
#     expected files and their byte-for-byte contents match the source
#     bundle in /home/user/project.
#   • /home/user/deploy/logs/sync_report.log exists and its textual
#     contents obey the mandatory format (correct section ordering,
#     required blank lines, valid timestamp, “OK” tags, etc.).
#
# Only the Python standard library and pytest are used.

import re
from datetime import datetime
from pathlib import Path
import pytest


HOME = Path("/home/user")
PROJECT_DIR = HOME / "project"
DEPLOY_DIR = HOME / "deploy"
LOG_DIR = DEPLOY_DIR / "logs"
LOG_FILE = LOG_DIR / "sync_report.log"

REMOTE_DIRS = {
    "web01": HOME / "remote_servers" / "web01" / "var" / "www" / "app",
    "web02": HOME / "remote_servers" / "web02" / "var" / "www" / "app",
}

EXPECTED_FILES = {
    "index.html": b"<h1>Welcome</h1>\n",
    "app.js": b'console.log("version 1.0.0");\n',
    "config.yaml": b"version: 1.0.0\n",
}

# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def _assert_is_dir(path: Path, msg: str | None = None) -> None:
    assert path.exists(), msg or f"Expected directory {path!s} does not exist."
    assert path.is_dir(), msg or f"{path!s} exists but is not a directory."

def _assert_file_content(path: Path, expected_bytes: bytes) -> None:
    assert path.exists(), f"Expected file {path!s} is missing."
    assert path.is_file(), f"Path {path!s} exists but is not a regular file."
    actual_bytes = path.read_bytes()
    assert actual_bytes == expected_bytes, (
        f"Content mismatch in {path!s}.\n"
        f"Expected bytes:\n{expected_bytes!r}\n\nActual bytes:\n{actual_bytes!r}"
    )

def _strip_trailing_newline(data: str) -> str:
    """
    Remove a single trailing newline if present.
    (Helpful when reading files with pathlib's read_text().)
    """
    return data[:-1] if data.endswith("\n") else data

# ---------------------------------------------------------------------------
# Tests for workspace structure
# ---------------------------------------------------------------------------

def test_deploy_workspace_exists():
    """
    /home/user/deploy and /home/user/deploy/logs must exist and be directories.
    """
    _assert_is_dir(DEPLOY_DIR)
    _assert_is_dir(LOG_DIR)

# ---------------------------------------------------------------------------
# Tests for file synchronisation on the “remote” servers
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("host", ["web01", "web02"])
def test_remote_directories_have_exact_files(host):
    """
    Each remote directory must contain ONLY the three expected files and their
    contents must match the source bundle byte-for-byte.
    """
    remote_dir = REMOTE_DIRS[host]
    _assert_is_dir(remote_dir, f"Remote directory for {host} is missing.")

    # 1. Directory listing must exactly equal the expected filenames
    found_files = sorted(p.name for p in remote_dir.iterdir() if p.is_file())
    expected_filenames = sorted(EXPECTED_FILES)
    assert found_files == expected_filenames, (
        f"{remote_dir!s} must contain exactly the files "
        f"{expected_filenames}, but currently contains {found_files}."
    )

    # 2. Contents of every file must equal the source bundle
    for filename, expected_bytes in EXPECTED_FILES.items():
        _assert_file_content(remote_dir / filename, expected_bytes)

# ---------------------------------------------------------------------------
# Tests for the synchronisation report
# ---------------------------------------------------------------------------

def test_sync_report_exists():
    """
    The log file /home/user/deploy/logs/sync_report.log must exist.
    """
    assert LOG_FILE.exists(), "sync_report.log is missing."
    assert LOG_FILE.is_file(), "sync_report.log exists but is not a regular file."


def test_sync_report_format_and_content():
    """
    Validate the exact required format of the synchronisation report.
    Only the TIMESTAMP value may vary (it must match YYYY-MM-DD HH:MM:SS).
    """
    raw_text = LOG_FILE.read_text(encoding="utf-8")
    # Preserve trailing newline information for better error reporting
    # but easier line-by-line checks with splitlines(keepends=False)
    lines = raw_text.splitlines()

    # ---------------------------------------------------------------------
    # Expected fixed text blocks (blank lines are empty strings in `lines`)
    # ---------------------------------------------------------------------
    expected_sequence = [
        "RELEASE_SYNC_REPORT",
        r"TIMESTAMP: \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}",  # regex
        "",  # blank line
        "START: web01",
        "FILES:",
        r"index\.html\s*: OK",     # regex allows extra spaces before colon
        r"app\.js\s*: OK",
        r"config\.yaml\s*: OK",
        "END: web01",
        "",  # blank line
        "START: web02",
        "FILES:",
        r"index\.html\s*: OK",
        r"app\.js\s*: OK",
        r"config\.yaml\s*: OK",
        "END: web02",
        "",  # blank line
        "STATUS: SUCCESS",
    ]

    assert len(lines) == len(expected_sequence), (
        "sync_report.log has an unexpected number of lines.\n"
        f"Expected {len(expected_sequence)} lines, found {len(lines)}."
    )

    # Walk through each expected line / regex
    for idx, (actual, expected_pattern) in enumerate(zip(lines, expected_sequence), start=1):
        if expected_pattern == "":
            # Blank line required
            assert actual.strip() == "", (
                f"Line {idx} must be completely blank, but found: {actual!r}"
            )
            continue

        # For regex-based checks
        is_regex = "\\" in expected_pattern or "(" in expected_pattern or ".*" in expected_pattern
        if is_regex:
            assert re.fullmatch(expected_pattern, actual), (
                f"Line {idx} does not match the required pattern.\n"
                f"Expected pattern: {expected_pattern!r}\n"
                f"Actual line    : {actual!r}"
            )
            if expected_pattern.startswith("TIMESTAMP"):
                # Additional check: timestamp should not be in the future
                timestamp_str = actual.split("TIMESTAMP:")[1].strip()
                try:
                    ts = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S")
                    assert ts <= datetime.now(), (
                        f"Timestamp in line {idx} is in the future: {timestamp_str}"
                    )
                except ValueError:
                    pytest.fail(
                        f"Timestamp in line {idx} is not a valid datetime: {timestamp_str!r}"
                    )
        else:
            assert actual == expected_pattern, (
                f"Line {idx} is incorrect.\n"
                f"Expected: {expected_pattern!r}\n"
                f"Actual  : {actual!r}"
            )