<title>Synchronise a release bundle to two “remote” servers and write a verification log</title>

<scenario>
    You are the release-manager of a small web application.  
    A fresh release bundle already exists locally in  

        /home/user/project

    containing exactly three files:

        index.html
        app.js
        config.yaml

    Two “remote” servers are represented on this workstation by the
    following **local** paths (no real networking is involved):

        /home/user/remote_servers/web01/var/www/app
        /home/user/remote_servers/web02/var/www/app
</scenario>

<objective>
    A deployment workspace must be created at  

           /home/user/deploy  

       with a sub-directory  

           /home/user/deploy/logs

    The contents of /home/user/project must be synchronised **in parallel**
    to BOTH “remote” locations so that, at the end, each
    `<remote>/var/www/app` directory holds the **byte-for-byte
    identical** copies of the three files.

    A plain-text log file must be generated, named

           /home/user/deploy/logs/sync_report.log

    which confirms that every file reached every destination
    correctly.

    The automated test will read this log, so its format MUST be
    **exactly** as follows (including blank lines, capitals,
    colons and indentation):

           RELEASE_SYNC_REPORT
           TIMESTAMP: YYYY-MM-DD HH:MM:SS

           START: web01
           FILES:
           index.html : OK
           app.js     : OK
           config.yaml: OK
           END: web01

           START: web02
           FILES:
           index.html : OK
           app.js     : OK
           config.yaml: OK
           END: web02

           STATUS: SUCCESS

       a) The “TIMESTAMP” value must be the current system time in
          24-hour format, *single space* between date and time.  
       b) Every section and line must be present exactly as shown.  
       c) Each “OK” must be upper-case.  
       d) Column alignment of the three file names is optional; the
          test ignores additional spaces immediately before “: OK”.
</objective>

<constraints>
    • Do not delete or modify the source bundle in /home/user/project.  
    • No root privileges are available; stay inside /home/user.  
    • The copy operations for web01 and web02 must run simultaneously (i.e.,
      issued by the shell so both are active at the same time).  
    • After completion, the log is the single source of truth that the
      automated test will parse.  Make sure it passes the exactness
      checks described above.  
</constraints>