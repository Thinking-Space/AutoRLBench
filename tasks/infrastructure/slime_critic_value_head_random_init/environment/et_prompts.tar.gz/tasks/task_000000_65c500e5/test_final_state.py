# test_final_state.py
#
# This pytest suite validates the *final* state of the container *after*
# the student has completed the task.  It focuses on the artefact that
# must be produced:  /home/user/audit/cert_scan.log
#
# If any test here fails, the student’s solution is incomplete or wrong
# and the automated grading should award **zero** points for the task.
#
# IMPORTANT:
# * All absolute paths are hard-coded exactly as required.
# * Tests are intentionally strict – even a single extra space, a
#   misplaced newline, or incorrect file mode will fail with a clear
#   explanation so that issues can be fixed quickly.
#
# Only the Python standard library and pytest are used.

import os
import stat
import pytest

HOME = "/home/user"
AUDIT_DIR = os.path.join(HOME, "audit")
LOG_FILE = os.path.join(AUDIT_DIR, "cert_scan.log")

# The canonical, byte-exact contents (must end with a single \n)
EXPECTED_LOG_CONTENT = (
    "target,subject,issuer,notBefore,notAfter,expired,self_signed\n"
    "old_server,CN=Old Vulnerable Server,CN=Old Vulnerable Server,"
    "2022-04-01T00:00:00Z,2023-04-01T00:00:00Z,TRUE,TRUE\n"
)


@pytest.fixture(scope="module")
def log_stat():
    """
    Return an os.stat_result for /home/user/audit/cert_scan.log
    Tests that need basic metadata can use this fixture without
    re-stat'ing the file repeatedly.
    """
    if not os.path.exists(LOG_FILE):
        pytest.skip(f"{LOG_FILE} does not exist – task not completed.")
    return os.stat(LOG_FILE)


def test_audit_directory_still_exists_and_is_dir():
    assert os.path.exists(AUDIT_DIR), (
        f"Directory {AUDIT_DIR} is missing – it must not be deleted or renamed."
    )
    assert os.path.isdir(AUDIT_DIR), f"{AUDIT_DIR} exists but is not a directory."


def test_log_file_exists_and_is_regular(log_stat):
    assert os.path.isfile(LOG_FILE), (
        f"{LOG_FILE} should be a regular file but is not (maybe a symlink?)."
    )


def test_log_file_permissions_are_0644(log_stat):
    mode = stat.S_IMODE(log_stat.st_mode)
    expected_mode = 0o644
    assert (
        mode == expected_mode
    ), f"{LOG_FILE} must have mode 0644, but has {oct(mode)}."


def test_log_file_content_exact_match():
    assert os.path.exists(LOG_FILE), (
        f"{LOG_FILE} is missing – the compliance pipeline cannot ingest results."
    )

    with open(LOG_FILE, "r", encoding="utf-8", newline="") as fh:
        content = fh.read()

    # 1. Exact byte-for-byte comparison (includes trailing newline)
    assert (
        content == EXPECTED_LOG_CONTENT
    ), (
        "The contents of {0} do not match the expected output.\n"
        "Differences could be due to:\n"
        "  • Extra/missing spaces or commas\n"
        "  • Wrong TRUE/FALSE capitalisation\n"
        "  • Incorrect date formatting\n"
        "  • Missing trailing newline\n\n"
        "Expected:\n"
        "--------------------\n"
        "{1}--------------------\n"
        "Actual:\n"
        "--------------------\n"
        "{2}--------------------".format(LOG_FILE, EXPECTED_LOG_CONTENT, content)
    )

    # 2. Sanity-check: there should be exactly two non-empty lines
    logical_lines = content.rstrip("\n").split("\n")
    assert len(logical_lines) == 2, (
        f"{LOG_FILE} should contain exactly two lines (header + data), "
        f"but contains {len(logical_lines)}."
    )

    header_expected = "target,subject,issuer,notBefore,notAfter,expired,self_signed"
    assert logical_lines[0] == header_expected, (
        f"Header row is incorrect. Expected:\n{header_expected}\nGot:\n{logical_lines[0]}"
    )

    data_expected = (
        "old_server,CN=Old Vulnerable Server,CN=Old Vulnerable Server,"
        "2022-04-01T00:00:00Z,2023-04-01T00:00:00Z,TRUE,TRUE"
    )
    assert logical_lines[1] == data_expected, (
        f"Data row is incorrect. Expected:\n{data_expected}\nGot:\n{logical_lines[1]}"
    )