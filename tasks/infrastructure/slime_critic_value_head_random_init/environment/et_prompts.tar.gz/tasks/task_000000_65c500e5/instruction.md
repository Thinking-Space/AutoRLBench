A client has provided you with the raw *text* output of an `openssl x509 -text` command that was run against one of their legacy services.
Your job, acting as a penetration-tester, is to extract the most important certificate-lifetime data, decide whether the certificate is self-signed and/or expired, and then record your findings in a single CSV log file so that the client’s automated compliance pipeline can ingest it.

### Files/directories already present
1.  `/home/user/targets/old_server_certificate.txt`  
    – The file holds the verbatim human-readable certificate dump that the client sent you (see “exact contents” in the truth section).
2.  `/home/user/audit/`      (empty directory with write permission for the current user)

### What you must do
1.  Read `/home/user/targets/old_server_certificate.txt` and extract **exactly** the following fields (do not include leading or trailing spaces):
    *   Subject CN (everything after `Subject:`)
    *   Issuer CN (everything after `Issuer:`)
    *   Not Before date/time (everything after `Not Before:`)
    *   Not After  date/time (everything after `Not After :`)

2.  Convert the two date/time values from the “Apr 1 00:00:00 2022 GMT” style to strict ISO-8601 UTC format **YYYY-MM-DDTHH:MM:SSZ**
    Example:
    `Apr  1 00:00:00 2022 GMT`  →  `2022-04-01T00:00:00Z`

3.  Decide the following booleans:
    *   `expired` – TRUE if the *current* system date is later than the converted **Not After** value, otherwise FALSE.
    *   `self_signed` – TRUE if Subject CN and Issuer CN are identical, otherwise FALSE.

4.  Create the log file `/home/user/audit/cert_scan.log` with **exactly** these two lines (including the header) and **no additional whitespace**:
    ```
    target,subject,issuer,notBefore,notAfter,expired,self_signed
    old_server,<Subject CN>,<Issuer CN>,<ISO_NotBefore>,<ISO_NotAfter>,<TRUE/FALSE>,<TRUE/FALSE>
    ```

    For this dataset the correct finished line (after your substitutions) is expected to be:
    `old_server,CN=Old Vulnerable Server,CN=Old Vulnerable Server,2022-04-01T00:00:00Z,2023-04-01T00:00:00Z,TRUE,TRUE`

    Ensure the file ends with a single trailing newline.

5.  Display the contents of `/home/user/audit/cert_scan.log` to the console (so the client sees the summary immediately).

### Verification notes for you
*   The CSV must use commas only (**,**) as separators – no tabs or extra spaces.
*   Case matters: use TRUE / FALSE in all-caps.
*   Date strings must contain the literal **T** between the date and time and end with **Z**.

No root privileges are required.