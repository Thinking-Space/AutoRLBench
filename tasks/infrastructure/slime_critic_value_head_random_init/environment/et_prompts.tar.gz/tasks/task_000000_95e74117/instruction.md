<title>Audit & Correct YAML/TOML Configuration, Then Log Results</title>

    <background>
        You are playing the role of a compliance-officer bot that has just received two
        existing configuration files that are not up-to-date with corporate policy.
        Your job is to
        1) create safe backups of the originals,
        2) modify both files so they meet the new requirements, and
        3) produce a strictly-formatted, two-line audit log proving what you changed.

        All paths are under the normal user’s home directory, so no elevated
        privileges are needed or allowed.
        • YAML file:  /home/user/compliance/service_a/config.yaml  
        • TOML file:  /home/user/compliance/service_b/settings.toml  

        A brand-new directory must also be created to contain the audit report:
        /home/user/compliance/audit
    </background>

    <required_changes>
        1. Back up each file **in the same directory** before touching it.  
           • Name the backups <original_filename>.pre_audit  
           • These backup files must be byte-for-byte identical to the originals.  

        2. Edit /home/user/compliance/service_a/config.yaml so its final
           content is **exactly** (including indentation):
            apiVersion: v1
            service:
              enabled: true
              port: 8080
              allowedOrigins:
                - https://corp.example.com
                - https://partners.example.com
            logging:
              level: WARN

        3. Edit /home/user/compliance/service_b/settings.toml so its final
           content is **exactly**:
            [server]
            active = true
            listen_ip = "0.0.0.0"
            listen_port = 9443
            allowed_hosts = ["corp.example.com", "partners.example.com"]

            [security]
            ciphers = ["TLS_AES_128_GCM_SHA256"]

            [compliance]
            version = "23.4"
            audited_by = "ISO27001"

        4. Create a file /home/user/compliance/audit/compliance_report.log
           containing **exactly two lines** in the following fixed format  
           (the timestamp is predetermined so the test harness can check it):

             2025-01-01T00:00:00Z - /home/user/compliance/service_a/config.yaml - UPDATED - service.enabled -> true; service.allowedOrigins added; logging.level -> WARN
             2025-01-01T00:00:00Z - /home/user/compliance/service_b/settings.toml - UPDATED - server.active -> true; server.listen_port -> 9443; server.allowed_hosts added; compliance section added

           Rules for the log:
           • No extra blank lines before or after.  
           • Each line ends with a single newline character (line-feed).  
           • The timestamp **must remain exactly** 2025-01-01T00:00:00Z.  
           • Field separator is “space-hyphen-space” (` - `).  
           • The wording in the <details> section (everything after the third
             hyphen) must match exactly what is shown above.

        5. File & directory permissions:
           • Newly created directory /home/user/compliance/audit must allow read
             & execute for everyone and write for the owner (octal 755).  
           • The log file itself and the two edited configuration files should be
             world-readable but only owner-writable (octal 644).  
              (The test harness will not insist on this, but setting correct
               permissions is considered best practice.)
    </required_changes>

    <verification>
        An automated test will affirm ALL of the following:

        • Backups named *.pre_audit exist in the same directories as the originals
          and are binary-identical to the original pre-task content.  
        • The edited YAML and TOML files match the “Required Changes” sections
          exactly, including whitespace, order and case.  
        • /home/user/compliance/audit/compliance_report.log exists and contains
          precisely the two required lines, nothing more, nothing less, in the
          correct order and with the fixed timestamp.  
        • The audit directory exists and the log file is located inside it.  
    </verification>