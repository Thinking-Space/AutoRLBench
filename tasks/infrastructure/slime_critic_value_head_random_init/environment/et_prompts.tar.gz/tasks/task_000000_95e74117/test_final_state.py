# test_final_state.py
#
# Pytest suite that validates the FINAL state of the filesystem after the
# student has completed the “Audit & Correct YAML/TOML Configuration, Then
# Log Results” task.  We verify 1) the existence and byte-perfect contents
# of the backup files, 2) the exact new contents of the edited YAML and
# TOML configuration files, and 3) the presence, placement, and precise
# formatting of the two-line audit log.

import pathlib
import stat
import pytest

HOME = pathlib.Path("/home/user")

# ---------------------------------------------------------------------------
# Absolute paths used throughout the tests
# ---------------------------------------------------------------------------
CFG_YAML_ORIG = HOME / "compliance/service_a/config.yaml"
CFG_TOML_ORIG = HOME / "compliance/service_b/settings.toml"

BKP_YAML = CFG_YAML_ORIG.with_suffix(CFG_YAML_ORIG.suffix + ".pre_audit")
BKP_TOML = CFG_TOML_ORIG.with_suffix(CFG_TOML_ORIG.suffix + ".pre_audit")

AUDIT_DIR = HOME / "compliance/audit"
AUDIT_LOG = AUDIT_DIR / "compliance_report.log"

# ---------------------------------------------------------------------------
# Expected – original (pre-task) contents for backup comparison
# ---------------------------------------------------------------------------
ORIGINAL_YAML_CONTENT = (
    "apiVersion: v1\n"
    "service:\n"
    "  enabled: false\n"
    "  port: 8080\n"
    "logging:\n"
    "  level: INFO\n"
)

ORIGINAL_TOML_CONTENT = (
    "[server]\n"
    "active = false\n"
    "listen_ip = \"0.0.0.0\"\n"
    "listen_port = 9000\n"
    "\n"
    "[security]\n"
    "ciphers = [\"TLS_AES_128_GCM_SHA256\"]\n"
)

# ---------------------------------------------------------------------------
# Expected – final (post-task) contents
# ---------------------------------------------------------------------------
FINAL_YAML_CONTENT = (
    "apiVersion: v1\n"
    "service:\n"
    "  enabled: true\n"
    "  port: 8080\n"
    "  allowedOrigins:\n"
    "    - https://corp.example.com\n"
    "    - https://partners.example.com\n"
    "logging:\n"
    "  level: WARN\n"
)

FINAL_TOML_CONTENT = (
    "[server]\n"
    "active = true\n"
    "listen_ip = \"0.0.0.0\"\n"
    "listen_port = 9443\n"
    "allowed_hosts = [\"corp.example.com\", \"partners.example.com\"]\n"
    "\n"
    "[security]\n"
    "ciphers = [\"TLS_AES_128_GCM_SHA256\"]\n"
    "\n"
    "[compliance]\n"
    "version = \"23.4\"\n"
    "audited_by = \"ISO27001\"\n"
)

# ---------------------------------------------------------------------------
# Expected audit log – note the mandatory trailing newline on BOTH lines
# ---------------------------------------------------------------------------
LOG_LINE_1 = (
    "2025-01-01T00:00:00Z - /home/user/compliance/service_a/config.yaml - "
    "UPDATED - service.enabled -> true; service.allowedOrigins added; "
    "logging.level -> WARN\n"
)
LOG_LINE_2 = (
    "2025-01-01T00:00:00Z - /home/user/compliance/service_b/settings.toml - "
    "UPDATED - server.active -> true; server.listen_port -> 9443; "
    "server.allowed_hosts added; compliance section added\n"
)

EXPECTED_LOG_CONTENT = LOG_LINE_1 + LOG_LINE_2


# ---------------------------------------------------------------------------
# Helper fixtures
# ---------------------------------------------------------------------------
@pytest.fixture(scope="module")
def backup_expectations():
    """
    Mapping of backup file paths to their required byte-for-byte contents.
    """
    return {
        BKP_YAML: ORIGINAL_YAML_CONTENT,
        BKP_TOML: ORIGINAL_TOML_CONTENT,
    }


@pytest.fixture(scope="module")
def final_expectations():
    """
    Mapping of edited configuration file paths to their required final
    contents.
    """
    return {
        CFG_YAML_ORIG: FINAL_YAML_CONTENT,
        CFG_TOML_ORIG: FINAL_TOML_CONTENT,
    }


# ---------------------------------------------------------------------------
# Tests for backup files
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("bkp_path", [BKP_YAML, BKP_TOML])
def test_backups_exist(bkp_path):
    assert bkp_path.is_file(), (
        f"Expected backup file {bkp_path} to exist but it does not. "
        "Ensure you created a '.pre_audit' backup in the SAME directory "
        "before modifying the original file."
    )


@pytest.mark.parametrize("bkp_path", [BKP_YAML, BKP_TOML])
def test_backups_content_exact(bkp_path, backup_expectations):
    actual = bkp_path.read_text(encoding="utf-8")
    expected = backup_expectations[bkp_path]
    assert (
        actual == expected
    ), (
        f"Backup file {bkp_path} does not match the original pre-task content.\n\n"
        f"--- Expected (byte-for-byte) ---\n{expected!r}\n"
        f"---   Actual on disk         ---\n{actual!r}\n"
        "Backups must be IDENTICAL to the original file before changes."
    )


# ---------------------------------------------------------------------------
# Tests for edited (final) configuration files
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("cfg_path", [CFG_YAML_ORIG, CFG_TOML_ORIG])
def test_edited_files_exist(cfg_path):
    assert cfg_path.is_file(), (
        f"Edited configuration file {cfg_path} is missing."
    )


@pytest.mark.parametrize("cfg_path", [CFG_YAML_ORIG, CFG_TOML_ORIG])
def test_edited_files_content_exact(cfg_path, final_expectations):
    actual = cfg_path.read_text(encoding="utf-8")
    expected = final_expectations[cfg_path]
    assert (
        actual == expected
    ), (
        f"Content mismatch in {cfg_path}.\n\n"
        f"--- Expected FINAL content ---\n{expected!r}\n"
        f"---     Actual on disk      ---\n{actual!r}\n"
        "The file has not been updated exactly as required."
    )


# ---------------------------------------------------------------------------
# Tests for audit directory and log file
# ---------------------------------------------------------------------------
def test_audit_directory_exists():
    assert AUDIT_DIR.is_dir(), (
        f"Audit directory {AUDIT_DIR} does not exist. "
        "You must create it to hold the compliance report."
    )


def test_audit_log_exists():
    assert AUDIT_LOG.is_file(), (
        f"Audit log file {AUDIT_LOG} is missing."
    )


def test_audit_log_content_exact():
    actual = AUDIT_LOG.read_text(encoding="utf-8")
    assert (
        actual == EXPECTED_LOG_CONTENT
    ), (
        "Audit log content is incorrect.\n\n"
        f"--- Expected log (exactly two lines) ---\n{EXPECTED_LOG_CONTENT!r}\n"
        f"---        Actual log on disk         ---\n{actual!r}\n"
        "Ensure the log has EXACTLY the two required lines, in order, with the "
        "fixed timestamp and a trailing newline on each line."
    )


def test_audit_log_only_two_lines():
    lines = AUDIT_LOG.read_text(encoding="utf-8").splitlines(keepends=False)
    assert len(lines) == 2, (
        f"Audit log should contain exactly 2 lines, found {len(lines)}."
    )


# ---------------------------------------------------------------------------
# Optional (informational) permission checks
# These will WARN rather than FAIL if permissions are not as recommended,
# because the grading rubric does not mandate them.  We still report to
# guide best practice.
# ---------------------------------------------------------------------------
def _octal_permissions(path: pathlib.Path) -> str:
    """Return a string like '644' or '755' for the file/directory."""
    return oct(path.stat().st_mode & 0o777)[2:]


@pytest.mark.parametrize(
    "path, expected_octal",
    [
        (AUDIT_DIR, "755"),
        (AUDIT_LOG, "644"),
        (CFG_YAML_ORIG, "644"),
        (CFG_TOML_ORIG, "644"),
    ],
)
def test_recommended_permissions(path, expected_octal):
    """
    Non-blocking, best-practice permission check.  Fails softly with xfail so
    the assignment grade is not impacted, but students still see guidance.
    """
    actual = _octal_permissions(path)
    if actual != expected_octal:
        pytest.xfail(
            f"{path} permissions are {actual}, recommended {expected_octal}.  "
            "This is not graded but is considered best practice."
        )