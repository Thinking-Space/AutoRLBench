# test_final_state.py
#
# This pytest suite validates the **final** state of the operating system /
# container after the student has completed the task.  Every requirement
# listed in “What the automated test will check” (section 6 of the prompt)
# is asserted below.
#
# If any assertion fails, the accompanying error message will describe
# exactly what is still wrong so the student can fix it.
#
# Only the Python standard library and pytest are used.

import difflib
import os
import stat
from pathlib import Path

import pytest

# --------------------------------------------------------------------------- #
# Constants
# --------------------------------------------------------------------------- #
HARDENING_DIR = Path("/home/user/hardening")
TUNED_CONF = HARDENING_DIR / "tuned.conf"
LOG_FILE = HARDENING_DIR / "optimization.log"

EXPECTED_TUNED_CONF_LINES = [
    "# Kernel scheduler settings",
    "sched_migration_cost_ns = 500000",
    "sched_latency_ns = 4000000",
    "sched_min_granularity_ns = 750000",
    "# end",
]
# The log file must contain exactly the following single line + trailing '\n'
EXPECTED_LOG_CONTENT = (
    "sched_latency_ns changed from 6000000 to 4000000\n"
)


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def _read_text(path: Path) -> str:
    """Read a text file using UTF-8, raising a helpful error if it fails."""
    try:
        return path.read_text(encoding="utf-8")
    except Exception as exc:  # pragma: no cover
        raise AssertionError(f"Unable to read {path}: {exc}") from exc


def _file_mode_bits(path: Path) -> int:
    """Return the permission bits for *path* (e.g. 0o644)."""
    return stat.S_IMODE(path.stat().st_mode)


def _pretty_diff(expected: str, actual: str) -> str:
    """Return a unified diff between *expected* and *actual* for error msgs."""
    diff = "\n".join(
        difflib.unified_diff(
            expected.splitlines(),
            actual.splitlines(),
            fromfile="expected",
            tofile="actual",
            lineterm="",
        )
    )
    return diff if diff else "<no differences>"


# --------------------------------------------------------------------------- #
# Tests verifying final state
# --------------------------------------------------------------------------- #
def test_tuned_conf_final_contents_are_exact():
    # 1. File existence and type
    assert TUNED_CONF.exists(), f"Expected file {TUNED_CONF} does not exist."
    assert TUNED_CONF.is_file(), f"{TUNED_CONF} exists but is not a regular file."

    # 2. Read content & ensure it ends with a single newline
    actual_content = _read_text(TUNED_CONF)
    assert actual_content.endswith(
        "\n"
    ), f"{TUNED_CONF} must end with a single trailing newline."

    # 3. Split into logical lines (strip final '\n', then split)
    actual_lines = actual_content.rstrip("\n").split("\n")

    # 4. Line-count must be exactly what we expect (no extra/missing lines)
    expected_lines = EXPECTED_TUNED_CONF_LINES
    assert (
        actual_lines == expected_lines
    ), (
        "The contents of {file} do not match the required final state.\n"
        "Unified diff:\n{diff}".format(
            file=TUNED_CONF, diff=_pretty_diff("\n".join(expected_lines), "\n".join(actual_lines))
        )
    )

    # 5. Sanity check: exactly one line contains the token “sched_latency_ns”
    latency_lines = [ln for ln in actual_lines if "sched_latency_ns" in ln]
    assert len(latency_lines) == 1, (
        f"{TUNED_CONF} should contain exactly one line with "
        f"'sched_latency_ns', found {len(latency_lines)}."
    )
    assert latency_lines[0].strip() == "sched_latency_ns = 4000000", (
        "The sched_latency_ns line must read exactly:\n"
        "sched_latency_ns = 4000000"
    )


def test_optimization_log_exists_and_has_correct_single_line():
    # 1. Existence & type
    assert LOG_FILE.exists(), f"Required log file {LOG_FILE} does not exist."
    assert LOG_FILE.is_file(), f"{LOG_FILE} exists but is not a regular file."

    # 2. Content must be exactly the single required line + newline
    actual_log_content = _read_text(LOG_FILE)
    assert (
        actual_log_content == EXPECTED_LOG_CONTENT
    ), (
        "The contents of {file} are incorrect.\nExpected:\n{exp!r}\nGot:\n{act!r}"
    ).format(file=LOG_FILE, exp=EXPECTED_LOG_CONTENT, act=actual_log_content)