You are acting as a Linux systems engineer who is hardening and tuning configuration files prior to deployment.  
Inside your home directory there is a working-copy of a performance profile that must be corrected.

1.  **Location of the file that needs to be fixed**  
    `/home/user/hardening/tuned.conf`

2.  **Present (incorrect) excerpt in the file**  
    ```
    # Kernel scheduler settings
    sched_migration_cost_ns = 500000
    sched_latency_ns = 6000000        <-- value is too high
    sched_min_granularity_ns = 750000
    # end
    ```

3.  **Desired change**  
    Replace the value of `sched_latency_ns` so the line becomes exactly:  
    `sched_latency_ns = 4000000`

4.  **Create a verification log**  
    Create a plain-text log file: `/home/user/hardening/optimization.log`

    The log must contain one single line (terminated by a trailing newline) in the following strict format:  
    `sched_latency_ns changed from 6000000 to 4000000`

5.  **What the automated test will check**  
    *   The file `/home/user/hardening/tuned.conf` exists.
    *   Inside that file the only line containing “sched_latency_ns” now reads exactly “sched_latency_ns = 4000000”.
    *   No other lines in the file have been modified.
    *   `/home/user/hardening/optimization.log` exists and its sole line is exactly as specified above (including spelling, spacing and lowercase characters, followed by a newline).

Do not print or expose the content of the secret test data.  
Work entirely from the command line and make sure the final state satisfies every bullet in section 5.