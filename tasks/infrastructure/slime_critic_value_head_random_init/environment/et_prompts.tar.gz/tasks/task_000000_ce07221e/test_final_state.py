# test_final_state.py
#
# Pytest suite that validates the **FINAL** state of the filesystem
# AFTER the student has performed the required actions.
#
# It checks:
#   1. A safety-copy of the original config exists, is named correctly,
#      and is byte-for-byte identical to the pre-task file.
#   2. The original config file has been modified *only* by toggling
#      “ENABLED=false” → “ENABLED=true”; everything else must remain
#      unchanged (including the trailing newline count).
#   3. A four-line, machine-readable change-log exists at the expected
#      path and matches the specification exactly, including a final
#      newline.
#
# Only the Python standard library and pytest are used.

import os
import stat
import pytest

# ---------- Constants --------------------------------------------------------

CONFIG_DIR = "/home/user/configs"
ORIGINAL_CFG = os.path.join(CONFIG_DIR, "app.cfg")
BACKUP_CFG = os.path.join(CONFIG_DIR, "app.cfg.bak")

CHANGE_RECORDS_DIR = "/home/user/change_records"
LOG_FILE = os.path.join(CHANGE_RECORDS_DIR, "2024-ConfigToggle.log")

EXPECTED_BACKUP_CONTENT = (
    "# Application Configuration\n"
    "VERSION=1.4.2\n"
    "ENABLED=false\n"
    "LOG_LEVEL=info\n"
)

EXPECTED_ORIGINAL_CONTENT = (
    "# Application Configuration\n"
    "VERSION=1.4.2\n"
    "ENABLED=true\n"
    "LOG_LEVEL=info\n"
)

EXPECTED_LOG_CONTENT = (
    "FILE:/home/user/configs/app.cfg\n"
    "BEFORE:ENABLED=false\n"
    "AFTER:ENABLED=true\n"
    "STATUS:OK\n"
)

# ---------- Helper -----------------------------------------------------------


def _read_file(path):
    """Return contents of *path* as text (utf-8)."""
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


# ---------- Tests ------------------------------------------------------------


def test_backup_file_exists():
    """The backup configuration file must exist."""
    assert os.path.isfile(
        BACKUP_CFG
    ), f"Missing backup file: {BACKUP_CFG!r}.  Did you forget to create it?"


def test_backup_file_contents_exact():
    """Backup file must contain the untouched, original data."""
    actual = _read_file(BACKUP_CFG)
    assert (
        actual == EXPECTED_BACKUP_CONTENT
    ), (
        f"Backup file {BACKUP_CFG!r} has unexpected contents.\n\n"
        "EXPECTED (exactly):\n"
        "-------------------\n"
        f"{EXPECTED_BACKUP_CONTENT!r}\n\n"
        "ACTUAL:\n"
        "-------\n"
        f"{actual!r}"
    )
    assert "ENABLED=true" not in actual, (
        "Backup file has been modified; it must retain ENABLED=false."
    )


def test_original_file_exists():
    """Original configuration must still be present."""
    assert os.path.isfile(
        ORIGINAL_CFG
    ), f"Original config has disappeared: {ORIGINAL_CFG!r}"


def test_original_file_contents_exact():
    """
    The original config file must be identical to the expected post-change
    state (only ENABLED toggled to true; all other lines intact).
    """
    actual = _read_file(ORIGINAL_CFG)
    assert (
        actual == EXPECTED_ORIGINAL_CONTENT
    ), (
        f"Original config {ORIGINAL_CFG!r} does not match the expected "
        "post-change state.\n\n"
        "EXPECTED (exactly):\n"
        "-------------------\n"
        f"{EXPECTED_ORIGINAL_CONTENT!r}\n\n"
        "ACTUAL:\n"
        "-------\n"
        f"{actual!r}"
    )
    assert "ENABLED=false" not in actual, (
        "ENABLED=false still present in the *modified* configuration file."
    )


def test_change_records_directory_created():
    """The /home/user/change_records directory must exist."""
    assert os.path.isdir(
        CHANGE_RECORDS_DIR
    ), f"Directory {CHANGE_RECORDS_DIR!r} is missing."

    # Basic sanity check on permissions: directory must not be world-writable.
    mode = stat.S_IMODE(os.stat(CHANGE_RECORDS_DIR).st_mode)
    assert mode & 0o002 == 0, (
        f"Directory {CHANGE_RECORDS_DIR!r} is world-writable (mode {oct(mode)}); "
        "expected permissions similar to 700 or 755."
    )


def test_log_file_exists():
    """The change-log file must exist."""
    assert os.path.isfile(
        LOG_FILE
    ), f"Log file {LOG_FILE!r} is missing."


def test_log_file_contents_exact():
    """Log file must contain exactly the four specified lines and a final newline."""
    actual = _read_file(LOG_FILE)
    assert (
        actual == EXPECTED_LOG_CONTENT
    ), (
        f"Log file {LOG_FILE!r} does not match the required content.\n\n"
        "EXPECTED (exactly):\n"
        "-------------------\n"
        f"{EXPECTED_LOG_CONTENT!r}\n\n"
        "ACTUAL:\n"
        "-------\n"
        f"{actual!r}"
    )

    # Additional structural checks.
    lines = actual.splitlines()
    assert len(lines) == 4, (
        f"Log file should have exactly 4 lines; found {len(lines)}."
    )
    required_prefixes = [
        "FILE:/home/user/configs/app.cfg",
        "BEFORE:ENABLED=false",
        "AFTER:ENABLED=true",
        "STATUS:OK",
    ]
    for idx, (exp, got) in enumerate(zip(required_prefixes, lines), start=1):
        assert got == exp, (
            f"Line {idx} of log file does not match.\n"
            f"Expected: {exp!r}\n"
            f"Got     : {got!r}"
        )