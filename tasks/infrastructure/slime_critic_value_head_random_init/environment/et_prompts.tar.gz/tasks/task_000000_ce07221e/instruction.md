A configuration–management audit needs you to record and implement a single parameter change inside a text-based configuration file.

Initial state:
*   One file already exists at
    `/home/user/configs/app.cfg`
*   Its exact initial contents are:
    ```
    # Application Configuration
    VERSION=1.4.2
    ENABLED=false
    LOG_LEVEL=info
    ```

What you must do:
1.  Make a safety copy of `/home/user/configs/app.cfg` in the same directory; the copy MUST be named `/home/user/configs/app.cfg.bak`.
2.  In the original file (`/home/user/configs/app.cfg`), switch the single parameter “ENABLED” from “false” to “true”, leaving everything else untouched.
3.  Append a small, machine-readable log of the change. Create the directory `/home/user/change_records` (if it does not yet exist) and add a new file called `2024-ConfigToggle.log` inside that directory whose contents are EXACTLY four lines, in this order:
    ```
    FILE:/home/user/configs/app.cfg
    BEFORE:ENABLED=false
    AFTER:ENABLED=true
    STATUS:OK
    ```
    *   No leading or trailing spaces on any line.
    *   A trailing newline after the final “STATUS:OK” line **is** required.

Verification notes the automated grader will use:
*   `/home/user/configs/app.cfg.bak` must exist and still contain “ENABLED=false”.
*   `/home/user/configs/app.cfg` must now contain “ENABLED=true”.
*   `/home/user/change_records/2024-ConfigToggle.log` must exist and match the four-line format above exactly (including the final newline).

When you are done, the three artefacts (the updated config file, the backup, and the change log) should be in place with the precise contents stated here.