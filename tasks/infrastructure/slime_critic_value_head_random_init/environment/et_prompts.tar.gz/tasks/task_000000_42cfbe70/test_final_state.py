# test_final_state.py
#
# This test-suite validates the **FINAL** state of the operating system
# AFTER the student has completed the task.  It asserts that the
# /home/user/scan/latest_tag_findings.log file exists with exactly the
# expected content and that no collateral changes were made elsewhere in
# the repo.
#
# Only the Python standard library and pytest are used.

import os
from pathlib import Path

import pytest

PROJECT_ROOT = Path("/home/user/microservices").resolve()
SCAN_DIR = Path("/home/user/scan").resolve()
OUTPUT_FILE = SCAN_DIR / "latest_tag_findings.log"

# --------------------------------------------------------------------------- #
# Ground-truth for the Dockerfiles – they must remain unaltered.
# --------------------------------------------------------------------------- #
EXPECTED_DOCKERFILES = {
    PROJECT_ROOT / "service-a" / "Dockerfile": [
        "FROM python:3.9-slim",
        "# Simple API service",
    ],
    PROJECT_ROOT / "service-b" / "Dockerfile": [
        "FROM ubuntu:latest",
        "RUN apt-get update && apt-get install -y curl",
    ],
    PROJECT_ROOT / "service-c" / "Dockerfile": [
        "FROM node:14",
        "WORKDIR /usr/src/app",
    ],
}

# Ground-truth for the scan result
EXPECTED_LOG_CONTENT = "service-b/Dockerfile:1:FROM ubuntu:latest\n"


def _read_file_lines(path: Path):
    """Return the file's lines *without* their trailing newline characters."""
    with path.open("r", encoding="utf-8") as fh:
        return [ln.rstrip("\n") for ln in fh.readlines()]


# --------------------------------------------------------------------------- #
# 1. Verify the output file exists and is exactly correct
# --------------------------------------------------------------------------- #
def test_output_file_exists():
    assert OUTPUT_FILE.is_file(), (
        f"Expected result file {OUTPUT_FILE} does not exist."
    )


def test_output_file_content_exact():
    """
    The result file must contain exactly one line that precisely matches the
    required format, including spacing and a single trailing newline.
    """
    content = OUTPUT_FILE.read_bytes()  # use bytes to detect stray CR characters
    try:
        decoded = content.decode("utf-8")
    except UnicodeDecodeError as exc:
        pytest.fail(
            f"{OUTPUT_FILE} is not valid UTF-8: {exc}"
        )

    # Reject Windows line endings outright
    assert "\r" not in decoded, (
        f"{OUTPUT_FILE} must use UNIX line endings (LF) only, "
        "but carriage-return characters were detected."
    )

    assert decoded == EXPECTED_LOG_CONTENT, (
        f"Content of {OUTPUT_FILE} is incorrect.\n"
        f"--- Expected (repr) ---\n{repr(EXPECTED_LOG_CONTENT)}\n"
        f"--- Got (repr) ---\n{repr(decoded)}"
    )


# --------------------------------------------------------------------------- #
# 2. Ensure no surplus artefacts were created in /home/user/scan
# --------------------------------------------------------------------------- #
def test_scan_directory_contains_only_output_file():
    scan_contents = sorted(p.name for p in SCAN_DIR.iterdir() if p.exists())
    assert scan_contents == [OUTPUT_FILE.name], (
        f"{SCAN_DIR} should contain only {OUTPUT_FILE.name} but contains: "
        f"{scan_contents}"
    )


# --------------------------------------------------------------------------- #
# 3. Ensure the original Dockerfiles are still present and unmodified
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("dockerfile_path, expected_lines", EXPECTED_DOCKERFILES.items())
def test_dockerfiles_unchanged(dockerfile_path: Path, expected_lines):
    assert dockerfile_path.is_file(), f"Missing Dockerfile: {dockerfile_path}"
    actual_lines = _read_file_lines(dockerfile_path)
    assert actual_lines == expected_lines, (
        f"{dockerfile_path} has been modified.\n"
        f"Expected lines:\n{expected_lines}\n"
        f"Actual lines:\n{actual_lines}"
    )


def test_no_additional_dockerfiles_present():
    """
    Guard against accidental creation of extra Dockerfiles during the task.
    """
    found = set(PROJECT_ROOT.rglob("Dockerfile"))
    expected = set(EXPECTED_DOCKERFILES.keys())

    unexpected = found - expected
    missing = expected - found

    assert not unexpected, (
        f"Unexpected Dockerfile(s) present: {sorted(map(str, unexpected))}"
    )
    assert not missing, (
        f"Expected Dockerfile(s) missing: {sorted(map(str, missing))}"
    )