You are a container-platform specialist performing a quick security check of the in-repo Dockerfiles used by three micro-services.

**PRE-EXISTING SET-UP**
*   The project root is `/home/user/microservices`
    *   `service-a/Dockerfile`
    *   `service-b/Dockerfile`
    *   `service-c/Dockerfile`

**TASK**
Perform a case-insensitive, recursive search within `/home/user/microservices` to locate every line in every Dockerfile that pulls an image tagged exactly “latest”.

Write the result to the file `/home/user/scan/latest_tag_findings.log`.
*   The directory `/home/user/scan` already exists and is writable.
*   The output file should be overwritten if it already exists.

**REQUIRED LOG FORMAT**
Each finding must be on its own line with the format:
`<relative-path-from-/home/user/microservices>:<line-number>:<entire-matching-line>`

Examples (DO NOT hard-code):
```
service-x/Dockerfile:3:FROM ubuntu:latest
service-y/Dockerfile:1:FROM nginx:latest
```

Notes:
*   “relative-path-from-/home/user/microservices” means do not include the leading `/home/user/microservices/`.
*   Use UNIX line endings.
*   Preserve all spacing in the matched line exactly as it appears in the Dockerfile.

**VERIFICATION**
*   Exactly one line is expected in the final log for the current repo state.
*   The process should finish without interactive prompts.