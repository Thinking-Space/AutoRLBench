You are a mobile build engineer doing a quick data-massage job on a CI pipeline host.
Inside the directory `/home/user/build_reports` you will find one semicolon-separated log file named `build_full_2023-09-15.log` whose exact contents are shown below:

```
ID;Platform;Start;End;Status;Duration(s)
B1021;android;2023-09-15T01:02:03Z;2023-09-15T01:07:10Z;Success;307
B1022;ios;2023-09-15T02:10:00Z;2023-09-15T02:24:45Z;Failed;885
B1023;android;2023-09-15T03:05:30Z;2023-09-15T03:11:01Z;Success;331
B1024;ios;2023-09-15T04:20:10Z;2023-09-15T04:25:35Z;Success;325
```

Your goal is to create a concise CSV summary that is easier for downstream tooling to ingest.

**Required end-state:**

1.  Create a new file `/home/user/build_reports/build_summary_2023-09-15.csv`
2.  The file must be exactly 5 lines long and must contain only three comma-separated columns in the following order and spelling:

    ```
    Build_ID,Platform,Status
    B1021,android,Success
    B1022,ios,Failed
    B1023,android,Success
    B1024,ios,Success
    ```

3.  Do NOT leave any trailing whitespace, extra blank lines, or additional columns.
4.  Do not manually re-type the data; derive all output from the supplied `build_full_2023-09-15.log` file.

Because automated grading will byte-compare the resulting `/home/user/build_reports/build_summary_2023-09-15.csv` against the reference shown above, make sure the format matches exactly (including case, commas, newlines, and header text).

When you are done, you can `cat` the file to the console so that a human observer sees the final result, but the test harness will rely solely on the file’s on-disk contents.