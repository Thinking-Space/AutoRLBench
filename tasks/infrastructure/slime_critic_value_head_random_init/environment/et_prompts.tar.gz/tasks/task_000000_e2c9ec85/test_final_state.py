# test_final_state.py
#
# Pytest suite that validates the *final* state of the filesystem
# after the student has completed the task described in the prompt.
#
# Only the Python standard library and pytest are used.

from pathlib import Path
import pytest

HOME = Path("/home/user")
REPORT_DIR = HOME / "build_reports"
LOG_FILE = REPORT_DIR / "build_full_2023-09-15.log"
SUMMARY_FILE = REPORT_DIR / "build_summary_2023-09-15.csv"

EXPECTED_LOG_CONTENT = (
    "ID;Platform;Start;End;Status;Duration(s)\n"
    "B1021;android;2023-09-15T01:02:03Z;2023-09-15T01:07:10Z;Success;307\n"
    "B1022;ios;2023-09-15T02:10:00Z;2023-09-15T02:24:45Z;Failed;885\n"
    "B1023;android;2023-09-15T03:05:30Z;2023-09-15T03:11:01Z;Success;331\n"
    "B1024;ios;2023-09-15T04:20:10Z;2023-09-15T04:25:35Z;Success;325\n"
)

EXPECTED_SUMMARY_CONTENT = (
    "Build_ID,Platform,Status\n"
    "B1021,android,Success\n"
    "B1022,ios,Failed\n"
    "B1023,android,Success\n"
    "B1024,ios,Success\n"
)


def _read_text_exact(path: Path) -> str:
    """
    Read a file in binary mode and decode as UTF-8 so that we don’t
    silently normalise line endings or ignore trailing newlines.
    """
    try:
        data = path.read_bytes()
    except FileNotFoundError:
        pytest.fail(f"Expected file {path} is missing.")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError as exc:
        pytest.fail(f"Could not decode {path} as UTF-8: {exc}")


# ----------------------------------------------------------------------
# Existence / type checks
# ----------------------------------------------------------------------

def test_summary_file_exists_and_is_regular_file():
    """The concise CSV summary must exist and be a regular file."""
    assert SUMMARY_FILE.exists(), (
        f"Summary file {SUMMARY_FILE} is missing. "
        "Create the file using cut/paste as instructed."
    )
    assert SUMMARY_FILE.is_file(), (
        f"{SUMMARY_FILE} exists but is not a regular file."
    )


# ----------------------------------------------------------------------
# Content checks
# ----------------------------------------------------------------------

def test_summary_file_exact_contents():
    """
    The summary file must match the required 5-line, comma-separated CSV
    exactly—byte-for-byte—including a single LF at the end of *every*
    line and no extraneous whitespace or columns.
    """
    actual = _read_text_exact(SUMMARY_FILE)
    assert actual == EXPECTED_SUMMARY_CONTENT, (
        "The contents of the summary CSV do not match the required "
        "format.\n\n"
        "Expected:\n"
        f"{EXPECTED_SUMMARY_CONTENT!r}\n\n"
        "Found:\n"
        f"{actual!r}\n\n"
        "Ensure you:\n"
        "  • Output exactly the three columns Build_ID,Platform,Status.\n"
        "  • Preserve the order and spelling shown.\n"
        "  • Use commas as delimiters and LF (\\n) line endings.\n"
        "  • Include a final newline after the last line.\n"
        "  • Do not add extra whitespace, blank lines, or columns."
    )


def test_summary_has_correct_number_of_lines():
    """Guard-rail: the file must be exactly 5 non-empty lines long."""
    lines = _read_text_exact(SUMMARY_FILE).splitlines()
    assert len(lines) == 5, (
        f"Expected exactly 5 lines in {SUMMARY_FILE}, found {len(lines)}. "
        "Check for missing/extra lines."
    )


def test_each_summary_line_has_exactly_three_columns():
    """Every line—including the header—must contain exactly 3 columns."""
    for idx, line in enumerate(_read_text_exact(SUMMARY_FILE).splitlines(), start=1):
        cols = line.split(",")
        assert len(cols) == 3, (
            f"Line {idx} of {SUMMARY_FILE} should have exactly 3 comma-"
            f"separated fields, but has {len(cols)}: {line!r}"
        )


def test_header_is_spelled_correctly():
    """Validate that the header matches exactly 'Build_ID,Platform,Status'."""
    header = _read_text_exact(SUMMARY_FILE).splitlines()[0]
    assert header == "Build_ID,Platform,Status", (
        f"Header line is incorrect: {header!r}. "
        "It must be exactly 'Build_ID,Platform,Status'."
    )


# ----------------------------------------------------------------------
# Regression: original log file must remain untouched
# ----------------------------------------------------------------------

def test_original_log_file_unchanged():
    """
    The original semicolon-separated log file should *not* be modified
    during processing.  Compare against the known initial content.
    """
    actual = _read_text_exact(LOG_FILE)
    assert actual == EXPECTED_LOG_CONTENT, (
        f"The original log file {LOG_FILE} appears to have been modified. "
        "Do not edit or delete the source file; create the summary CSV "
        "from it instead.\n\n"
        "Expected:\n"
        f"{EXPECTED_LOG_CONTENT!r}\n\n"
        "Found:\n"
        f"{actual!r}"
    )