# test_final_state.py
#
# Pytest suite that validates the operating-system / filesystem state
# AFTER the student’s solution has run.
#
# What we assert:
#   1. The original directories (/home/user/build/logs/ and
#      /home/user/build/reports/) still exist with the correct modes.
#   2. The original log file still exists, still has the same permissions,
#      and its 23 lines are unchanged (the task was read-only on that file).
#   3. A new report file
#      /home/user/build/reports/warning_frequency.txt exists
#      with mode 0644 and *exactly* the four expected lines –
#      correctly ordered, no extra / missing / malformed lines.
#
# If any assertion fails, the test explains precisely what is wrong so the
# student can quickly fix the issue.

import os
import stat
import pytest

HOME = "/home/user"
LOGS_DIR = os.path.join(HOME, "build", "logs")
REPORTS_DIR = os.path.join(HOME, "build", "reports")
LOG_FILE = os.path.join(LOGS_DIR, "mobile_build.log")
REPORT_FILE = os.path.join(REPORTS_DIR, "warning_frequency.txt")

# Expected permissions in octal form
DIR_MODE = 0o755
LOG_MODE = 0o644
REPORT_MODE = 0o644

# Truth-data: the log file must remain unchanged
EXPECTED_LOG_LINES = [
    "INFO: Build started\n",
    "WARNING: Unused resource\n",
    "INFO: Checking dependencies\n",
    "WARNING: Deprecated API usage\n",
    "INFO: Running Lint\n",
    "WARNING: Unused resource\n",
    "ERROR: Missing keystore\n",
    "WARNING: Missing translation\n",
    "INFO: Compiling sources\n",
    "WARNING: Deprecated API usage\n",
    "INFO: Packaging APK\n",
    "WARNING: Unused resource\n",
    "ERROR: Build failed\n",
    "WARNING: Large APK size\n",
    "INFO: Build environment: Android-30\n",
    "WARNING: Missing translation\n",
    "INFO: Retrying build steps\n",
    "WARNING: Deprecated API usage\n",
    "INFO: Re-running unit tests\n",
    "INFO: Build completed with warnings\n",
    "WARNING: Unused resource\n",
    "INFO: Archiving artifacts\n",
    "INFO: Pipeline finished\n",
]

# Truth-data: the desired contents of the final report
EXPECTED_REPORT_LINES = [
    "4 WARNING: Unused resource",
    "3 WARNING: Deprecated API usage",
    "2 WARNING: Missing translation",
    "1 WARNING: Large APK size",
]


# --------------------------------------------------------------------------
# Helper utilities
# --------------------------------------------------------------------------
def _assert_mode(path: str, expected_octal: int):
    """
    Assert that `path` has the permission bits `expected_octal`.
    Produce a clear, actionable failure message on mismatch.
    """
    actual_mode = stat.S_IMODE(os.stat(path).st_mode)
    assert actual_mode == expected_octal, (
        f"Permissions for {path!r} are {oct(actual_mode)}, "
        f"but should be {oct(expected_octal)}."
    )


def _read_lines(path: str):
    """
    Read a file returning a list of lines including the terminating '\n'.
    """
    with open(path, encoding="utf-8") as fh:
        return fh.readlines()


# --------------------------------------------------------------------------
# Tests
# --------------------------------------------------------------------------
def test_directories_still_exist_with_correct_permissions():
    # Logs directory
    assert os.path.isdir(LOGS_DIR), (
        f"Directory {LOGS_DIR!r} is missing – it must still exist."
    )
    _assert_mode(LOGS_DIR, DIR_MODE)

    # Reports directory
    assert os.path.isdir(REPORTS_DIR), (
        f"Directory {REPORTS_DIR!r} is missing – it must still exist."
    )
    _assert_mode(REPORTS_DIR, DIR_MODE)


def test_original_log_file_untouched():
    # Presence & mode
    assert os.path.isfile(LOG_FILE), (
        f"Log file {LOG_FILE!r} is missing – it must not be deleted or moved."
    )
    _assert_mode(LOG_FILE, LOG_MODE)

    # Content unchanged
    actual_lines = _read_lines(LOG_FILE)
    assert actual_lines == EXPECTED_LOG_LINES, (
        "The contents of the original log file have changed.\n"
        "Your solution must read from it but not modify it."
    )


def test_report_file_exists_with_correct_permissions():
    assert os.path.isfile(REPORT_FILE), (
        f"Required report file {REPORT_FILE!r} was not created."
    )
    _assert_mode(REPORT_FILE, REPORT_MODE)


def test_report_file_contents_exact():
    raw = _read_lines(REPORT_FILE)

    # Allow (optional) final trailing newline but no blank lines
    if raw and raw[-1].endswith("\n"):
        # Keep newline but strip for comparison later
        pass  # already has newline char, fine
    # Convert to "stripped newline" list for easy comparison
    stripped = [line.rstrip("\n") for line in raw]

    # 1. Correct number of lines
    expected_count = len(EXPECTED_REPORT_LINES)
    actual_count = len(stripped)
    assert actual_count == expected_count, (
        f"{REPORT_FILE!r} should contain exactly {expected_count} lines "
        f"but contains {actual_count}."
    )

    # 2. Exact line-for-line match
    mismatches = [
        (idx + 1, exp, got)
        for idx, (exp, got) in enumerate(zip(EXPECTED_REPORT_LINES, stripped))
        if exp != got
    ]
    assert not mismatches, (
        f"Content mismatch in {REPORT_FILE!r}:\n" +
        "\n".join(
            f"Line {lineno}: expected {exp!r}, got {got!r}"
            for lineno, exp, got in mismatches
        )
    )

    # 3. No extra whitespace (leading/trailing)
    for idx, line in enumerate(raw, 1):
        # raw still contains '\n' at the end unless it's the last line without it
        core = line.rstrip("\n")
        assert core == core.strip(), (
            f"Line {idx} in {REPORT_FILE!r} has unexpected leading/trailing "
            f"spaces: {repr(core)}"
        )


def test_report_file_sorted_descending_by_count():
    """
    Additional sanity check: verify the integer counts are in descending order.
    This catches cases where counts are correct but ordering is wrong.
    """
    counts = [int(line.split(" ", 1)[0]) for line in EXPECTED_REPORT_LINES]
    assert counts == sorted(counts, reverse=True), (
        "Counts in the report must be sorted in numeric descending order."
    )