You are a mobile build engineer reviewing yesterday’s CI run.  
A log file already exists at  

/home/user/build/logs/mobile_build.log  

Inside that file, every build message occupies exactly one line and warning lines always begin with the literal string  

WARNING: (including the colon and the space).

Your job is to produce a frequency report that counts how many times each *distinct* WARNING line appears in the log. The report must be sorted so the most frequent warning appears first, then the next most frequent, and so on (in numeric descending order). Save the report to

/home/user/build/reports/warning_frequency.txt  

Report format (must match **exactly**; automated tests are whitespace- and case-sensitive):

• One warning per line.  
• Each line starts with the integer count, followed by a single space, then the full warning text exactly as it appears in the log.  
• No leading or trailing spaces.  
• Lines separated by Unix newline “\n” (a trailing newline after the last line is fine).

Example of the required format (counts and messages here are illustrative only):

    12 WARNING: Unused resource  
    7 WARNING: Deprecated API usage  
    3 WARNING: Missing translation  

When you are finished, /home/user/build/reports/warning_frequency.txt should exist and contain the correctly formatted, sorted counts described above.