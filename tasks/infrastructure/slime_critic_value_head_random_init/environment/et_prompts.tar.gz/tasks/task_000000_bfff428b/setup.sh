#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    apt-get install -y --no-install-recommends python3 python3-pip && \
    pip3 install --no-cache-dir pytest && \
    mkdir -p /home/user/raw_scans

cat >/home/user/raw_scans/nmap_scan1.xml <<'EOF'
<?xml version="1.0"?>
<!DOCTYPE nmaprun>
<nmaprun scanner="nmap" args="nmap -oX -" start="1234567890">
<host>
  <status state="up" reason="syn-ack"/>
  <address addr="192.168.1.10" addrtype="ipv4"/>
  <ports>
    <port protocol="tcp" portid="22">
      <state state="open" reason="syn-ack" />
      <service name="ssh" />
    </port>
    <port protocol="tcp" portid="80">
      <state state="open" reason="syn-ack" />
      <service name="http" />
    </port>
    <port protocol="tcp" portid="3306">
      <state state="closed" />
      <service name="mysql" />
    </port>
  </ports>
</host>
<host>
  <status state="up" reason="syn-ack"/>
  <address addr="192.168.1.11" addrtype="ipv4"/>
  <ports>
    <port protocol="tcp" portid="21">
      <state state="open" reason="syn-ack" />
      <service name="ftp" />
    </port>
    <port protocol="tcp" portid="139">
      <state state="open" reason="syn-ack" />
      <service name="netbios-ssn" />
    </port>
    <port protocol="tcp" portid="445">
      <state state="open" reason="syn-ack" />
      <service name="microsoft-ds" />
    </port>
  </ports>
</host>
</nmaprun>
EOF

chmod 0644 /home/user/raw_scans/nmap_scan1.xml && \
    chmod 755 /home/user

export PATH="/usr/local/bin:${PATH}"
