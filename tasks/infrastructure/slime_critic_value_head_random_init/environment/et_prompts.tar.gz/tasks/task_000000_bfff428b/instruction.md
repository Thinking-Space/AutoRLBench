You are acting as a penetration tester who has just been handed an **offline** XML-formatted Nmap scan.
Your goal is to stage a mini “reporting environment”, configure a very small
helper “config” file, parse the XML, and finally generate a clean,
machine-checkable vulnerability summary log.

- Create a new directory `/home/user/reports`.

- Inside that directory create a plain-text file called `/home/user/reports/report_config.cfg` whose exact contents must be:

      # Minimal reporting configuration
      target_scan=/home/user/raw_scans/nmap_scan1.xml
      report_output=/home/user/reports/vuln_report.log

  - No extra spaces before or after the three lines.
  - Ensure the file ends with a single trailing newline.

- Process the XML scan that already exists at `/home/user/raw_scans/nmap_scan1.xml`.

- From that XML extract **every port element** that meets **all** of the following criteria:
    - Its &lt;state&gt; child has attribute state="open"
    - The parent &lt;port&gt; element has attribute protocol="tcp"
    - The host is “up” (state="up" in the enclosing &lt;status&gt; element)

- For every open TCP port that matches, write one line to the log file `/home/user/reports/vuln_report.log` using this **EXACT** format (case sensitive, single spaces only, no extra punctuation):

      HOST <ip-address> PORT <port-number>/tcp SERVICE <service-name>

  - &lt;ip-address&gt; = value of the host’s &lt;address addr="..."&gt; field
  - &lt;port-number&gt; = the portid attribute of the &lt;port&gt; element
  - &lt;service-name&gt; = the name attribute of the &lt;service&gt; child element

- The lines in the log file must be sorted first by the IP address in ascending numerical order and then by the port number in ascending numerical order.

- Ensure `/home/user/reports/vuln_report.log` is world-readable (octal permission 0644). Do **not** modify permissions on any other file.

OUTPUT FORMAT THAT WILL BE TESTED
---------------------------------
The automated checker will verify **BOTH** of these files:

A) /home/user/reports/report_config.cfg
- Must contain exactly the three lines described above, plus a trailing newline.

B) /home/user/reports/vuln_report.log
- Must contain exactly five lines, each of which must match **precisely** one of the following (in this exact order):

      HOST 192.168.1.10 PORT 22/tcp SERVICE ssh
      HOST 192.168.1.10 PORT 80/tcp SERVICE http
      HOST 192.168.1.11 PORT 21/tcp SERVICE ftp
      HOST 192.168.1.11 PORT 139/tcp SERVICE netbios-ssn
      HOST 192.168.1.11 PORT 445/tcp SERVICE microsoft-ds

- A single trailing newline after the last line is allowed.

If both files exist with the exact content and the log file has mode 0644,
the task is considered complete. You do not need to display anything else
besides the normal shell output produced while you work.