# test_final_state.py
"""
Robust pytest suite that validates the *final* operating-system / filesystem
state **after** the student has completed the “mini reporting environment”
task.

The tests explicitly verify:

1.  The reports directory exists.
2.  The configuration file exists, has *exact* required content and ends with
    a single trailing newline, and its permissions are 0644.
3.  The vulnerability report exists, has exactly the five required lines in
    the correct order (optionally followed by one trailing newline), and its
    permissions are 0644.

Only the Python standard library plus pytest is used.
"""

import os
import stat
import pytest

# --------------------------------------------------------------------------- #
# Constants                                                                   #
# --------------------------------------------------------------------------- #
REPORTS_DIR = "/home/user/reports"

CFG_PATH = os.path.join(REPORTS_DIR, "report_config.cfg")
CFG_EXPECTED_LINES = [
    "# Minimal reporting configuration",
    "target_scan=/home/user/raw_scans/nmap_scan1.xml",
    "report_output=/home/user/reports/vuln_report.log",
]

LOG_PATH = os.path.join(REPORTS_DIR, "vuln_report.log")
LOG_EXPECTED_LINES = [
    "HOST 192.168.1.10 PORT 22/tcp SERVICE ssh",
    "HOST 192.168.1.10 PORT 80/tcp SERVICE http",
    "HOST 192.168.1.11 PORT 21/tcp SERVICE ftp",
    "HOST 192.168.1.11 PORT 139/tcp SERVICE netbios-ssn",
    "HOST 192.168.1.11 PORT 445/tcp SERVICE microsoft-ds",
]

REQUIRED_MODE = 0o644  # world-readable, no execute bits


# --------------------------------------------------------------------------- #
# Helper functions                                                            #
# --------------------------------------------------------------------------- #
def read_file(path):
    """
    Read *binary* to make absolutely sure we do not silently translate
    line-endings.  Decode as UTF-8 afterwards.
    """
    with open(path, "rb") as fp:
        raw = fp.read()
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        pytest.fail(f"File '{path}' is not valid UTF-8: {exc}")


def assert_mode(path, expected_mode):
    """Fail with a helpful message if the mode is not exactly expected_mode."""
    actual_mode = os.stat(path).st_mode & 0o777
    assert actual_mode == expected_mode, (
        f"File '{path}' should have permissions {oct(expected_mode)} "
        f"but currently has {oct(actual_mode)}."
    )


def split_lines_allow_single_trailing_newline(text):
    """
    Return a list of lines without their trailing newline.
    A *single* trailing newline at end-of-file is ignored (it is allowed).
    Any additional newline characters beyond that cause failure.
    """
    if text.endswith("\n"):
        text_without_last_nl = text[:-1]
        assert not text_without_last_nl.endswith(
            "\n"
        ), "File has more than one trailing newline."
        return text_without_last_nl.split("\n")
    # No trailing newline – allowed for the LOG file, *not* for the config file
    return text.split("\n")


# --------------------------------------------------------------------------- #
# Tests                                                                       #
# --------------------------------------------------------------------------- #
def test_reports_directory_exists():
    """The /home/user/reports directory must exist."""
    assert os.path.isdir(
        REPORTS_DIR
    ), f"Required directory '{REPORTS_DIR}' is missing."


# ---------------------------- #
# Configuration file checks    #
# ---------------------------- #
def test_config_file_exists():
    assert os.path.isfile(
        CFG_PATH
    ), f"Configuration file '{CFG_PATH}' is missing."


def test_config_file_permissions():
    assert_mode(CFG_PATH, REQUIRED_MODE)


def test_config_file_contents_exact():
    content = read_file(CFG_PATH)

    # Config MUST end with exactly one trailing newline
    assert content.endswith(
        "\n"
    ), "Configuration file must end with a single trailing newline."
    cfg_lines = split_lines_allow_single_trailing_newline(content)

    assert cfg_lines == CFG_EXPECTED_LINES, (
        "Configuration file contents are incorrect.\n\n"
        "EXPECTED LINES:\n  " + "\n  ".join(CFG_EXPECTED_LINES) + "\n\n"
        "FOUND LINES:\n  " + ("\n  ".join(cfg_lines) if cfg_lines else "(none)")
    )


# ---------------------------- #
# Vulnerability log checks     #
# ---------------------------- #
def test_log_file_exists():
    assert os.path.isfile(
        LOG_PATH
    ), f"Vulnerability log '{LOG_PATH}' is missing."


def test_log_file_permissions():
    assert_mode(LOG_PATH, REQUIRED_MODE)


def test_log_file_contents_exact_and_sorted():
    content = read_file(LOG_PATH)
    log_lines = split_lines_allow_single_trailing_newline(content)

    # The spec allows *at most* one trailing newline, so len(log_lines)
    # must be exactly the expected number of lines.
    assert len(log_lines) == len(
        LOG_EXPECTED_LINES
    ), (
        f"Vulnerability log should contain exactly {len(LOG_EXPECTED_LINES)} "
        f"lines but has {len(log_lines)}."
    )

    # Equality check also guarantees sort order and exact spacing.
    assert log_lines == LOG_EXPECTED_LINES, (
        "Vulnerability log contents are incorrect or not properly sorted.\n\n"
        "EXPECTED:\n  " + "\n  ".join(LOG_EXPECTED_LINES) + "\n\n"
        "FOUND:\n  " + "\n  ".join(log_lines)
    )