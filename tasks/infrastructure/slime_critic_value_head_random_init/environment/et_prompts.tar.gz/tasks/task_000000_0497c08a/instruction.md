You are a build-pipeline engineer who needs to investigate a failed nightly build.  
Three raw build logs have already been copied to

    /home/user/build_logs/

1. appserver_build.log  
2. db_build.log  
3. ui_build.log  

Your goal is to create two artefacts inside

    /home/user/artifact_reports/

(create the directory if it does not already exist):

A. /home/user/artifact_reports/filtered_build_issues.log  
B. /home/user/artifact_reports/issue_summary.json  

---------------  REQUIRED FILTERING RULES  ---------------  
Scan every *.log file that is present in /home/user/build_logs and extract only the
lines that match **ANY** of the following two REGEX tests.

  1. /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\s+\[(ERROR|WARN)\]/  
     (lines that start with a timestamp followed by “[ERROR]” or “[WARN ]”).  
  2. /E\d{4}/  (anywhere in the line; denotes an error code such as “E5678”).  

If *either* regex is satisfied the line is kept, otherwise it is ignored.

---------------  OUTPUT FILE #1  (filtered_build_issues.log)  ---------------  
• Each kept line must be rewritten into the following single-line format

      <source_file>:<line_number>:<log_level>:<message>

    where  
      <source_file> = basename of the log file (e.g. “db_build.log”)  
      <line_number> = 1-based line index within that source file  
      <log_level>   = “ERROR” or “WARN”  
                     (lines that matched only because of “E\d{4}” are treated as ERROR)  
      <message>     = the *original* log line stripped of the leading timestamp and
                      leading severity tag (and any following whitespace).

    Example transformation  
        raw:  2023-07-19 14:20:58 [ERROR] Failed to copy artifact artifact-xyz.jar  
        out:  appserver_build.log:42:ERROR:Failed to copy artifact artifact-xyz.jar

• Order matters!  After all conversions, sort the whole file first by
  <source_file> (alphabetically) and then by <line_number> (ascending).  
• End the file with a single trailing newline (POSIX style).

---------------  OUTPUT FILE #2  (issue_summary.json)  ---------------  
Generate a compact JSON document summarising how many WARN and ERROR lines were
written to filtered_build_issues.log:

    {
      "<fileA>": { "ERROR": x, "WARN": y },
      "<fileB>": { "ERROR": x, "WARN": y },
      "<fileC>": { "ERROR": x, "WARN": y },
      "total":   { "ERROR": X, "WARN": Y }
    }

• The keys for individual files must exactly match the basenames that appear in the
  build_logs directory.  
• “total” is the cross-file sum of each level.  
• Write the JSON completely minified (no extra spaces or line breaks except a final
  newline). The automated test will parse it with a JSON parser, so pay strict
  attention to the key names, capitalisation of “ERROR”/“WARN”, and integer values.

• You do not need elevated permissions; everything must be done as the current user.  
• The task is considered successful only if both files exist, follow the exact
  formats described above, and the counts in issue_summary.json match the lines
  in filtered_build_issues.log.
• Do not hard-code the expected numbers; all values must be derived from the log content.