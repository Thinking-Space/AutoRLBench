# test_final_state.py
#
# Pytest suite that validates the **final** state of the operating-system /
# container once the student has completed the assignment.
#
# It asserts that:
#   • /home/user/artifact_reports/ exists and is a directory.
#   • filtered_build_issues.log exists, is properly sorted, has exactly the
#     expected transformed lines, and finishes with a single trailing newline.
#   • issue_summary.json exists, is minified, contains the correct per-file and
#     total ERROR/WARN counts, and has no superfluous keys.
#
# Only the Python stdlib and pytest are used.

import json
import os
from pathlib import Path
from typing import List, Tuple

import pytest

ARTIFACT_DIR = Path("/home/user/artifact_reports")
FILTERED_LOG = ARTIFACT_DIR / "filtered_build_issues.log"
SUMMARY_JSON = ARTIFACT_DIR / "issue_summary.json"

# --------------------------------------------------------------------------- #
# “Truth” data that *must* be present after the student’s code has run.
# --------------------------------------------------------------------------- #
_EXPECTED_LINES: List[str] = [
    "appserver_build.log:2:WARN:Deprecated API usage detected",
    "appserver_build.log:4:ERROR:Failed to copy artifact artifact-xyz.jar",
    "appserver_build.log:7:ERROR:Test suite failed for module security",
    "appserver_build.log:9:ERROR:Build step failed with code E5678",
    "db_build.log:2:WARN:Outdated driver version detected",
    "db_build.log:5:ERROR:Migration 20230719_add_index.sql failed",
    "db_build.log:6:ERROR:Error code E3141 encountered during migration",
    "ui_build.log:3:WARN:Package \"left-pad\" is deprecated",
    "ui_build.log:5:ERROR:Lint failed at component Navbar with E0987",
    "ui_build.log:7:ERROR:12 tests failed",
]
# Ensure we always compare with the exact newline conventions later.
_EXPECTED_FILE_CONTENT = "\n".join(_EXPECTED_LINES) + "\n"

_EXPECTED_COUNTS = {
    "appserver_build.log": {"ERROR": 3, "WARN": 1},
    "db_build.log":       {"ERROR": 2, "WARN": 1},
    "ui_build.log":       {"ERROR": 2, "WARN": 1},
    "total":              {"ERROR": 7, "WARN": 3},
}

# --------------------------------------------------------------------------- #
# Helper functions
# --------------------------------------------------------------------------- #
def _split_filtered_line(line: str) -> Tuple[str, int, str, str]:
    """
    Split a single transformed log line into its 4 components and perform
    minimal sanity checking.

    Returns:
        (source_file, line_number, level, message)
    """
    parts = line.split(":", 3)
    if len(parts) != 4:
        pytest.fail(
            f"Line '{line}' in {FILTERED_LOG} does not contain the expected "
            "'<source_file>:<line_number>:<log_level>:<message>' structure."
        )
    source_file, ln_str, level, message = parts
    # Validate numeric line number
    try:
        ln = int(ln_str)
    except ValueError:
        pytest.fail(
            f"Line '{line}' in {FILTERED_LOG}: line_number '{ln_str}' is not an integer."
        )

    # Validate level
    if level not in {"ERROR", "WARN"}:
        pytest.fail(
            f"Line '{line}' in {FILTERED_LOG}: log_level '{level}' "
            "is neither 'ERROR' nor 'WARN'."
        )
    return source_file, ln, level, message


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #
def test_artifact_directory_exists():
    assert ARTIFACT_DIR.is_dir(), (
        f"Directory {ARTIFACT_DIR} is missing. "
        "Create it to store the required artefacts."
    )


def test_required_files_exist():
    missing = [str(p) for p in (FILTERED_LOG, SUMMARY_JSON) if not p.is_file()]
    assert not missing, (
        "The following required artefact files are missing:\n  " +
        "\n  ".join(missing)
    )


def test_filtered_build_issues_log_content_matches_exactly():
    content = FILTERED_LOG.read_text(encoding="utf-8")

    # 1. Ensure single trailing newline
    assert content.endswith("\n"), (
        f"{FILTERED_LOG} must end with exactly one trailing newline."
    )

    # 2. Ensure no extra blank lines at end
    assert not content.endswith("\n\n"), (
        f"{FILTERED_LOG} contains extra blank lines at the end."
    )

    # 3. Exact content comparison
    assert content == _EXPECTED_FILE_CONTENT, (
        f"{FILTERED_LOG} content differs from the expected output.\n"
        "To help debug, here are the expected vs actual lines:\n"
        "EXPECTED:\n"
        + _EXPECTED_FILE_CONTENT +
        "ACTUAL:\n"
        + content
    )


def test_filtered_build_issues_log_line_format_and_sorting():
    """
    Beyond an exact match, check that each line individually respects the
    required structure and that global ordering is correct.
    """
    lines = [ln for ln in FILTERED_LOG.read_text(encoding="utf-8").splitlines()]

    # Sanity: already guaranteed equal to _EXPECTED_LINES, but check structure anyway
    for line in lines:
        _split_filtered_line(line)  # raises pytest.fail on error

    # Verify sorting: by source_file then by numeric line_number
    tuples = [_split_filtered_line(l) for l in lines]
    for i in range(1, len(tuples)):
        prev = tuples[i - 1]
        curr = tuples[i]
        prev_key = (prev[0], prev[1])
        curr_key = (curr[0], curr[1])
        assert prev_key <= curr_key, (
            f"{FILTERED_LOG} is not globally sorted as required. "
            f"Line '{lines[i - 1]}' should not come before '{lines[i]}'."
        )


def test_issue_summary_json_counts_and_format():
    raw = SUMMARY_JSON.read_text(encoding="utf-8")

    # 1. Must be minified: allow only the single trailing newline
    assert raw.endswith("\n"), (
        f"{SUMMARY_JSON} must end with exactly one newline."
    )
    assert "\n" not in raw[:-1], (
        f"{SUMMARY_JSON} must be a single-line minified JSON (plus trailing newline)."
    )
    parsed = json.loads(raw)

    # 2. Keys and counts must match exactly
    assert parsed == _EXPECTED_COUNTS, (
        f"{SUMMARY_JSON} contents are incorrect.\n"
        f"EXPECTED: {_EXPECTED_COUNTS}\n"
        f"ACTUAL:   {parsed}"
    )

    # 3. Additional sanity: recompute counts from filtered log
    computed_counts = {}
    for line in _EXPECTED_LINES:
        src, _, lvl, _ = _split_filtered_line(line)
        computed_counts.setdefault(src, {"ERROR": 0, "WARN": 0})
        computed_counts[src][lvl] += 1

    total_error = sum(v["ERROR"] for v in computed_counts.values())
    total_warn  = sum(v["WARN"]  for v in computed_counts.values())
    computed_counts["total"] = {"ERROR": total_error, "WARN": total_warn}

    assert parsed == computed_counts, (
        f"{SUMMARY_JSON} counts do not correspond to the data in "
        f"{FILTERED_LOG}.\nEXPECTED (re-derived): {computed_counts}\n"
        f"ACTUAL: {parsed}"
    )