As the backup administrator, you are preparing yesterday’s inventory CSV for long-term storage.

1.  **Source data**
    *   File: `/home/user/backups/servers_2023-10-15.csv`
    *   The CSV file is UTF-8, uses “,” as the field separator, and contains exactly three lines (a header line plus two data lines).

2.  **What you must do**
    a) Create the directory `/home/user/backups/archive` if it does not yet exist.
    b) Convert the CSV file to JSON and save it at `/home/user/backups/archive/servers_2023-10-15.json`

       Required JSON format:
       *   One physical line only (i.e. no embedded line-breaks or indentation).
       *   An array of objects, with the header names as keys in the same order as they appear in the CSV (id, hostname, ip).
       *   Every field value must be enclosed in double quotes, so the numbers remain strings.
       *   Example shape (values differ):
         `[{"id":"…","hostname":"…","ip":"…"}, {...}]`

    c) Write (or append) a one-line status entry to `/home/user/backups/archive/archive.log`

       *   The line must be the literal text `OK:` followed immediately by the current UTC timestamp in strict ISO-8601 “YYYY-MM-DDTHH:MM:SSZ” format that you obtain at runtime, e.g.
         `OK:2023-10-16T09:41:07Z`
       *   If `archive.log` already exists, add the new line to the end; do not overwrite the previous content.

3.  **Constraints**
    *   Do not introduce any extra whitespace or newlines into the JSON output.
    *   You are working as the regular user “user”; no `sudo` is available.

4.  **Automated tests will verify:**
    *   The directory `/home/user/backups/archive` exists.
    *   `/home/user/backups/archive/servers_2023-10-15.json` exists and its entire contents match exactly the required single-line JSON string.
    *   `/home/user/backups/archive/archive.log` exists and its last line matches the regex
        `^OK:\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$`
        (the timestamp must be in UTC).

Produce no additional files other than those described above.