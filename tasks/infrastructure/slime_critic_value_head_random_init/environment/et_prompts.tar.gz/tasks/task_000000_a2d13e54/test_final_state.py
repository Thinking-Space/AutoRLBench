# test_final_state.py
#
# Functional tests that verify the operating-system / container **after**
# the student has completed the “CSV → JSON archive” task.
#
# These tests purposefully mirror the specification and the authoritative
# truth data.  They will fail with explicit, actionable messages whenever
# the end-state still deviates from the requirements.
#
# Only the Python standard library and pytest are used.

import os
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import pytest

# ---------------------------------------------------------------------
# Constants – absolute paths exactly as mandated by the task
# ---------------------------------------------------------------------
ARCHIVE_DIR = Path("/home/user/backups/archive")
CSV_PATH = Path("/home/user/backups/servers_2023-10-15.csv")
JSON_PATH = ARCHIVE_DIR / "servers_2023-10-15.json"
LOG_PATH = ARCHIVE_DIR / "archive.log"

# Ground-truth JSON string (single physical line, no trailing newline)
EXPECTED_JSON = (
    '[{"id":"1","hostname":"web01","ip":"192.168.1.10"},'
    '{"id":"2","hostname":"db01","ip":"192.168.1.20"}]'
)

# Regex for a valid ISO-8601 UTC timestamp line inside archive.log
LOG_LINE_REGEX = re.compile(r"^OK:\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")

# ---------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------


def read_file_bytes(path: Path) -> bytes:
    """Read a file as raw bytes (no encoding errors possible)."""
    return path.read_bytes()


def read_file_text(path: Path) -> str:
    """Read entire file as UTF-8 string."""
    return path.read_text(encoding="utf-8")


# ---------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------


def test_archive_directory_exists_and_is_directory():
    assert ARCHIVE_DIR.exists(), (
        f"Required directory {ARCHIVE_DIR} is missing."
    )
    assert ARCHIVE_DIR.is_dir(), (
        f"{ARCHIVE_DIR} exists but is not a directory."
    )


def test_json_file_exists_with_exact_content_and_single_line():
    # ----- existence -----
    assert JSON_PATH.is_file(), (
        f"Converted JSON file {JSON_PATH} does not exist."
    )

    # ----- single physical line -----
    raw = read_file_text(JSON_PATH)
    assert "\n" not in raw and "\r" not in raw, (
        f"{JSON_PATH} must contain exactly one physical line "
        f"(no embedded newlines), but newline characters were found."
    )

    # ----- exact content -----
    assert raw == EXPECTED_JSON, (
        f"Contents of {JSON_PATH} do not match the expected JSON.\n"
        f"Expected: {EXPECTED_JSON!r}\n"
        f"Got     : {raw!r}"
    )

    # ----- additional sanity: valid JSON -----
    try:
        obj = json.loads(raw)
    except json.JSONDecodeError as exc:
        pytest.fail(f"{JSON_PATH} does not contain valid JSON: {exc}")


def test_archive_log_exists_and_last_line_matches_regex():
    # ----- existence -----
    assert LOG_PATH.is_file(), (
        f"Log file {LOG_PATH} is missing – the status entry was not written."
    )

    # ----- non-empty -----
    content = read_file_text(LOG_PATH)
    assert content.strip() != "", (
        f"{LOG_PATH} exists but is empty. Expected at least one OK: timestamp line."
    )

    # ----- determine last logical line -----
    # splitlines() discards all newline characters and works for any platform
    lines = content.splitlines()
    last_line = lines[-1]

    # ----- regex match -----
    assert LOG_LINE_REGEX.fullmatch(last_line), (
        f"The last line in {LOG_PATH} must match "
        f"'OK:YYYY-MM-DDTHH:MM:SSZ' (UTC ISO-8601).\n"
        f"Found: {last_line!r}"
    )

    # ----- optional sanity: timestamp is not in the future -----
    timestamp_str = last_line[3:]  # strip the leading 'OK:'
    try:
        ts = datetime.strptime(timestamp_str, "%Y-%m-%dT%H:%M:%SZ")
        ts = ts.replace(tzinfo=timezone.utc)
    except ValueError as exc:
        pytest.fail(
            f"Timestamp parsing error for {last_line!r} in {LOG_PATH}: {exc}"
        )

    now_utc = datetime.now(timezone.utc)
    assert ts <= now_utc, (
        f"Timestamp {timestamp_str} in {LOG_PATH} is in the future "
        f"(current UTC time is {now_utc.strftime('%Y-%m-%dT%H:%M:%SZ')})."
    )


def test_source_csv_still_intact_for_reference():
    """
    Sanity-check that the original CSV file has *not* been modified or removed
    by accident while solving the task.
    """
    assert CSV_PATH.is_file(), "The original CSV file has gone missing."