#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    echo "Updating package lists and installing required packages..." && \
    apt-get update -y && \
    apt-get install -y --no-install-recommends python3-pip && \
    pip3 install --no-cache-dir pytest && \
    echo "Creating base directory layout under /home/user ..." && \
    mkdir -p /home/user && \
    chmod 0777 /home/user && \
    mkdir -p /home/user/releases

set -e && \
    echo "Populating release directories with exact-sized files..." && \
    mkdir -p /home/user/releases/app_v1.0 /home/user/releases/app_v1.0/bin && \
    truncate -s 512 /home/user/releases/app_v1.0/README.txt && chmod 0644 /home/user/releases/app_v1.0/README.txt && \
    truncate -s 1536 /home/user/releases/app_v1.0/bin/app.bin && chmod 0644 /home/user/releases/app_v1.0/bin/app.bin && \
    mkdir -p /home/user/releases/app_v1.1 /home/user/releases/app_v1.1/bin /home/user/releases/app_v1.1/docs && \
    truncate -s 1024 /home/user/releases/app_v1.1/README.txt && chmod 0644 /home/user/releases/app_v1.1/README.txt && \
    truncate -s 2048 /home/user/releases/app_v1.1/bin/app.bin && chmod 0644 /home/user/releases/app_v1.1/bin/app.bin && \
    truncate -s 3072 /home/user/releases/app_v1.1/docs/CHANGELOG.md && chmod 0644 /home/user/releases/app_v1.1/docs/CHANGELOG.md && \
    mkdir -p /home/user/releases/app_v2.0 /home/user/releases/app_v2.0/bin /home/user/releases/app_v2.0/scripts && \
    truncate -s 2048 /home/user/releases/app_v2.0/README.txt && chmod 0644 /home/user/releases/app_v2.0/README.txt && \
    truncate -s 3072 /home/user/releases/app_v2.0/bin/app.bin && chmod 0644 /home/user/releases/app_v2.0/bin/app.bin && \
    truncate -s 2048 /home/user/releases/app_v2.0/scripts/migrate.sh && chmod 0644 /home/user/releases/app_v2.0/scripts/migrate.sh && \
    find /home/user/releases -type d -exec chmod 0755 {} \; && \
    echo "Initial state successfully prepared."

export PATH="/usr/local/bin:/usr/bin:/bin:${PATH}"

chmod 755 /home/user
