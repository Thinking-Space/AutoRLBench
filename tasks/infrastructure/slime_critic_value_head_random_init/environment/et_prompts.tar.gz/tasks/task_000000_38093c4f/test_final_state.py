# test_final_state.py
#
# Pytest suite that validates the **final** OS / filesystem state
# after the student has completed the “release-audit” task.
#
# What we verify:
#   1.  /home/user/release_audit/            exists and is a directory.
#   2.  /home/user/release_audit/disk_usage_report.csv
#         • exists and is a regular, user-writable file.
#         • contains **exactly** the five required lines.
#         • lines are in strict ASCII alphabetical order for the
#           three releases, followed by ALL_RELEASES.
#         • byte-counts match the truth data given to the exercise.
#         • file ends with a single trailing newline, no extra
#           whitespace.
#         • the SHA-256 hash of the file matches the expected hash
#           for the mandated content.
#
# Only the Python standard library and pytest are used.
import hashlib
import os
import stat
import pytest

HOME = "/home/user"
AUDIT_DIR = os.path.join(HOME, "release_audit")
CSV_PATH = os.path.join(AUDIT_DIR, "disk_usage_report.csv")

# --------  Truth data from the exercise description  -----------------
EXPECTED_RELEASE_SIZES = {
    "app_v1.0": 2048,
    "app_v1.1": 6144,
    "app_v2.0": 7168,
}
EXPECTED_TOTAL = 15360

# Construct the canonical CSV content *including* the trailing <LF>.
EXPECTED_CSV_LINES = [
    "Release_Name,Size_Bytes",
    "app_v1.0,2048",
    "app_v1.1,6144",
    "app_v2.0,7168",
    "ALL_RELEASES,15360",
]
EXPECTED_CSV_CONTENT = "\n".join(EXPECTED_CSV_LINES) + "\n"
EXPECTED_CSV_SHA256 = hashlib.sha256(EXPECTED_CSV_CONTENT.encode()).hexdigest()
# ---------------------------------------------------------------------


def _is_user_writable(path: str) -> bool:
    """Return True if the current user has write permission to *path*."""
    mode = os.stat(path).st_mode
    return bool(mode & stat.S_IWUSR)


def test_audit_directory_exists_and_user_writable():
    assert os.path.exists(AUDIT_DIR), (
        f"Directory '{AUDIT_DIR}' does not exist. "
        "It should have been created to store the audit report."
    )
    assert os.path.isdir(AUDIT_DIR), (
        f"'{AUDIT_DIR}' exists but is not a directory."
    )
    assert _is_user_writable(AUDIT_DIR), (
        f"Directory '{AUDIT_DIR}' is not writable by the user."
    )


def test_csv_file_exists_and_user_writable():
    assert os.path.exists(CSV_PATH), (
        f"CSV report '{CSV_PATH}' is missing."
    )
    assert os.path.isfile(CSV_PATH), (
        f"'{CSV_PATH}' exists but is not a regular file."
    )
    assert _is_user_writable(CSV_PATH), (
        f"CSV report '{CSV_PATH}' is not writable by the user."
    )


def test_csv_content_is_exact():
    with open(CSV_PATH, "r", encoding="utf-8", newline="") as fp:
        content = fp.read()

    # 1. Trailing newline must exist but no extra blank lines afterwards.
    assert content.endswith("\n"), (
        "CSV file must end with exactly one newline character."
    )
    assert not content.endswith("\n\n"), (
        "CSV file has more than one trailing newline."
    )

    # 2. Line-by-line comparison.
    actual_lines = content.splitlines()
    assert actual_lines == EXPECTED_CSV_LINES, (
        "CSV contents do not match the expected lines.\n"
        f"Expected lines:\n{EXPECTED_CSV_LINES}\n\n"
        f"Actual lines:\n{actual_lines}"
    )

    # 3. Verify aggregate sizes programmatically to guard against
    #    accidental hard-coding of the ALL_RELEASES value.
    #    (If the previous assertion passes the lines are parseable.)
    parsed_sizes = {
        line.split(",")[0]: int(line.split(",")[1])
        for line in actual_lines[1:-1]  # skip header and ALL_RELEASES
    }
    total_reported = int(actual_lines[-1].split(",")[1])

    assert parsed_sizes == EXPECTED_RELEASE_SIZES, (
        "Per-release byte counts in the CSV are incorrect.\n"
        f"Expected: {EXPECTED_RELEASE_SIZES}\n"
        f"Found   : {parsed_sizes}"
    )
    assert total_reported == EXPECTED_TOTAL, (
        f"ALL_RELEASES total is {total_reported} but should be "
        f"{EXPECTED_TOTAL} bytes."
    )
    assert sum(parsed_sizes.values()) == total_reported, (
        "ALL_RELEASES total does not equal the sum of individual "
        "release sizes."
    )


def test_csv_sha256_matches_expected():
    with open(CSV_PATH, "rb") as fp:
        file_bytes = fp.read()
    actual_sha256 = hashlib.sha256(file_bytes).hexdigest()
    assert actual_sha256 == EXPECTED_CSV_SHA256, (
        "CSV file SHA-256 checksum is incorrect.\n"
        f"Expected: {EXPECTED_CSV_SHA256}\n"
        f"Found   : {actual_sha256}"
    )