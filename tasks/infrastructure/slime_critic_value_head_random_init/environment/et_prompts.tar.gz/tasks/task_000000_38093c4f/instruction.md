You are the release manager who must verify that upcoming application releases fit within the disk-space budget of the deployment servers.

    Current project layout (already present in the system):
      /home/user/releases/
          ├── app_v1.0/
          │     ├── README.txt
          │     └── bin/app.bin
          ├── app_v1.1/
          │     ├── README.txt
          │     ├── bin/app.bin
          │     └── docs/CHANGELOG.md
          └── app_v2.0/
                ├── README.txt
                ├── bin/app.bin
                └── scripts/migrate.sh

    Task Requirements:

    * Create the directory `/home/user/release_audit` if it does not yet exist.
      * The directory must end up with default user-writable permissions (e.g. 755 or 700).

    * Compute the *exact* aggregate size, in bytes, of every **first-level** sub-directory located in `/home/user/releases`.
      * “Exact” means the sum of the byte-sizes of all regular files inside a release (do **not** include the size of the directories themselves).
      * Ignore hidden files (none exist now, but the rule must be followed).

    * Write those numbers to a comma-separated values (CSV) log located at:
          `/home/user/release_audit/disk_usage_report.csv`

      The CSV **must contain exactly five lines**, formatted precisely like this (including capitalisation, commas and line breaks <LF>, **no extra spaces**):

          Release_Name,Size_Bytes
          app_v1.0,<bytes_for_app_v1.0>
          app_v1.1,<bytes_for_app_v1.1>
          app_v2.0,<bytes_for_app_v2.0>
          ALL_RELEASES,<total_bytes_all_releases>

      * Replace the `<bytes_for…>` placeholders with the computed integer byte counts.
      * The release rows must appear in strict ASCII alphabetical order.
      * The final `ALL_RELEASES` line must equal the sum of the three individual sizes.
      * Ensure the file ends with a single trailing newline character.

    * After creating `disk_usage_report.csv`, display its contents to the terminal so that a reviewer can immediately see the results.

    * Do **not** hard-code the numbers—they must be derived programmatically before assembling the CSV file.

    Verification expectations:
       * The CSV file exists at `/home/user/release_audit/disk_usage_report.csv`.
       * Its permission bits are user-writable.
       * Its contents exactly match the required five-line format and the precalculated byte totals.
       * The terminal output printed by the agent displays those same five lines.