# test_final_state.py
#
# Pytest suite that validates the **FINAL** state of the operating-system /
# container after the student has carried out the checksum-verification task.
#
# The tests assert that:
#   1. The original *.conf files are still present and unmodified.
#   2. /home/user/checksum_verification.log exists, is well-formed and contains
#      the correct information derived from the authoritative CSV.
#
# Only the Python standard library and pytest are used.

import hashlib
from pathlib import Path
import os
import stat
import pytest

# ---------------------------------------------------------------------------
# Constants & helpers
# ---------------------------------------------------------------------------

BASE_DIR = Path("/home/user/config_backups")
LOG_PATH = Path("/home/user/checksum_verification.log")
REFERENCE_CSV = BASE_DIR / "reference_checksums.csv"

CONF_FILES = {
    "fw01.conf": {
        "expected_content": b"abc",
        "sha256": "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
    },
    "sw02.conf": {
        "expected_content": b"hello world",
        "sha256": "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9",
    },
    "rtr03.conf": {
        "expected_content": b"",
        "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    },
}


def sha256_of_bytes(data: bytes) -> str:
    """Return the hex-encoded SHA-256 digest of *data*."""
    return hashlib.sha256(data).hexdigest()


# ---------------------------------------------------------------------------
# Tests that ensure the original files are still intact
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("filename,meta", CONF_FILES.items())
def test_conf_files_not_tampered(filename, meta):
    """
    The original *.conf files must still exist, contain the same bytes, and
    therefore hash to their authoritative SHA-256 values.
    """
    path = BASE_DIR / filename
    assert path.exists(), f"Required file {path} is missing after the task ran."
    assert path.is_file(), f"{path} exists but is not a regular file."

    data = path.read_bytes()
    assert (
        data == meta["expected_content"]
    ), f"The content of {path} has been modified."

    actual_sha = sha256_of_bytes(data)
    assert (
        actual_sha == meta["sha256"]
    ), f"SHA-256 of {path} has changed: expected {meta['sha256']}, got {actual_sha}."


# ---------------------------------------------------------------------------
# Tests that validate /home/user/checksum_verification.log
# ---------------------------------------------------------------------------


def test_log_file_exists_and_readable():
    """The verification log must exist and be world-readable (0600..0644)."""
    assert LOG_PATH.exists(), f"Expected log file {LOG_PATH} is missing."
    assert LOG_PATH.is_file(), f"{LOG_PATH} exists but is not a regular file."

    st_mode = LOG_PATH.stat().st_mode
    # Owner must have read permission; others may or may not.
    assert (
        st_mode & stat.S_IRUSR
    ), f"{LOG_PATH} is not readable by the current user (mode {oct(st_mode)})."


def test_log_file_format_and_content():
    """
    The log must:
      • Contain exactly 4 LF-terminated lines (header + 3 data rows)
      • Use Unix newlines, no carriage returns
      • Have the exact header
      • List the three files in the prescribed order
      • Contain no spaces before/after commas
      • Provide correct hashes and STATUS=OK
    """
    raw = LOG_PATH.read_bytes()

    # 1. Must end with a single Unix newline
    assert raw.endswith(
        b"\n"
    ), f"{LOG_PATH} must be terminated by exactly one newline (LF)."

    # 2. Must not contain Windows CR characters
    assert b"\r" not in raw, f"{LOG_PATH} must use Unix newlines only (found CR)."

    # 3. Split lines (keeping newline for later exactness checks)
    lines = raw.decode("utf-8").splitlines(keepends=True)
    assert (
        len(lines) == 4
    ), f"{LOG_PATH} must contain exactly 4 lines; found {len(lines)}."

    header_expected = "FILE,EXPECTED_SHA256,ACTUAL_SHA256,STATUS\n"
    header_actual = lines[0]
    assert (
        header_actual == header_expected
    ), f"Header line incorrect.\nExpected: {header_expected!r}\nActual:   {header_actual!r}"

    # Build data mapping for ease of checks
    for idx, (filename, meta) in enumerate(CONF_FILES.items(), start=1):
        line = lines[idx]

        # 4. No spaces allowed anywhere in the line
        assert (
            " " not in line
        ), f"Line {idx+1} contains space characters, which are disallowed: {line!r}"

        # 5. Exactly 4 comma-separated columns
        parts = line.rstrip("\n").split(",")
        assert (
            len(parts) == 4
        ), f"Line {idx+1} must have exactly 4 comma-separated fields; found {len(parts)}."

        file_field, expected_sha_field, actual_sha_field, status_field = parts

        # 6. Correct filename and order
        assert (
            file_field == filename
        ), f"Line {idx+1} expected filename '{filename}', found '{file_field}'."

        # 7. EXPECTED_SHA256 must match authoritative value
        authoritative = meta["sha256"]
        assert (
            expected_sha_field == authoritative
        ), f"Line {idx+1}: EXPECTED_SHA256 incorrect for {filename}. Expected {authoritative}, got {expected_sha_field}."

        # 8. ACTUAL_SHA256 must match hash computed now
        conf_path = BASE_DIR / filename
        current_sha = sha256_of_bytes(conf_path.read_bytes())
        assert (
            actual_sha_field == current_sha
        ), f"Line {idx+1}: ACTUAL_SHA256 mismatch for {filename}. Expected {current_sha}, got {actual_sha_field}."

        # 9. STATUS must be OK
        assert (
            status_field == "OK"
        ), f"Line {idx+1}: STATUS must be 'OK' when hashes match; found '{status_field}'."

    # 10. Ensure there are no additional blank lines (already covered by length check)
    #     but be explicit for readability.
    assert lines[-1].endswith(
        "\n"
    ), "The final line must be newline-terminated (already verified via raw check)."


# ---------------------------------------------------------------------------
# End of test_final_state.py
# ---------------------------------------------------------------------------