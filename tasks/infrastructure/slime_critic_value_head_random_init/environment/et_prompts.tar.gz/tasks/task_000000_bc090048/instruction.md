A network-engineering audit has revealed that three critical configuration backups stored in the directory `/home/user/config_backups` might have been tampered with.
Your job is to verify their SHA-256 checksums against the official reference list and to produce a single machine-readable log file that clearly records the results of your investigation.

Files already present on disk:
*   `/home/user/config_backups/fw01.conf`
*   `/home/user/config_backups/sw02.conf`
*   `/home/user/config_backups/rtr03.conf`
*   `/home/user/config_backups/reference_checksums.csv`

You must read `/home/user/config_backups/reference_checksums.csv` to get the *authoritative* hash values. Do not hard-code the expected values. The file is a simple header-plus-data CSV:

```
FILENAME,SHA256
fw01.conf,ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad
sw02.conf,b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9
rtr03.conf,e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
```

(No extra whitespace, exactly one newline at the end.)

Compute the current SHA-256 checksum of each of the three `*.conf` files.

Generate a verification log named `/home/user/checksum_verification.log` following this *exact* format so that automated grading scripts can parse it without ambiguity:

```
FILE,EXPECTED_SHA256,ACTUAL_SHA256,STATUS
fw01.conf,ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad,<calc1>,OK
sw02.conf,b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9,<calc2>,OK
rtr03.conf,e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855,<calc3>,OK
```

*   Replace `<calc1>`, `<calc2>` and `<calc3>` with the actual hashes you computed.
*   The STATUS field must be the literal word “OK” when the computed hash matches the expected value, otherwise the literal word “MISMATCH”.
*   Every line, including the header, must be terminated by a single Unix newline (LF). No extra blank lines are allowed.
*   There must be *exactly* four comma-separated columns per line and *absolutely no* spaces before or after commas.

When the log is finished, print its contents to STDOUT so a human reviewer can see it immediately.

Acceptance criteria checked by the automatic grader:
*   `/home/user/checksum_verification.log` exists.
*   The header row is exactly:  
    `FILE,EXPECTED_SHA256,ACTUAL_SHA256,STATUS`
*   There are three data rows, in the same order as in the reference CSV.
*   The EXPECTED_SHA256 column matches what is listed in `reference_checksums.csv`.
*   The ACTUAL_SHA256 column contains the correct hashes of the current files.
*   STATUS is “OK” for all three rows (no mismatches).
*   The file is newline-terminated and contains no superfluous whitespace.