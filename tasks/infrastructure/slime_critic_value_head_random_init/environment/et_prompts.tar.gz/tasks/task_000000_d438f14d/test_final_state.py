# test_final_state.py
#
# Pytest suite that validates the *final* operating-system / filesystem state
# after the learner has completed the FinOps scraping task.
#
# Expectations verified:
#   1. /home/user/finops directory exists and has sane permissions (755 or 775).
#   2. /home/user/finops/latest_costs.csv exists and its contents match the
#      required CSV EXACTLY (byte-for-byte, including the trailing newline).
#   3. /home/user/finops/scrape.log exists, is non-empty, has ≥2 lines, and
#      every line conforms to the required timestamp+command format.
#
# If any assertion fails, the error message pinpoints precisely what is wrong
# so that the learner can fix it quickly.

from pathlib import Path
import re
import stat
import pytest

FINOPS_DIR = Path("/home/user/finops")
CSV_PATH = FINOPS_DIR / "latest_costs.csv"
LOG_PATH = FINOPS_DIR / "scrape.log"

# Expected CSV content (exact, including trailing LF)
EXPECTED_CSV = (
    "Service,MonthlyCostUSD\n"
    "EC2,45.32\n"
    "S3,12.05\n"
    "RDS,33.10\n"
)

TIMESTAMP_CMD_REGEX = re.compile(r"^\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\] .+$")


def _human_perm(oct_mode: int) -> str:
    """Return a human-readable string of the lower 3 octal permission bits."""
    return oct(oct_mode & 0o777)


# --------------------------------------------------------------------------- #
# 1. Directory tests
# --------------------------------------------------------------------------- #
def test_finops_directory_exists_and_permissions():
    assert FINOPS_DIR.exists(), (
        "Directory /home/user/finops is missing. "
        "Create it to store the CSV and log files."
    )
    assert FINOPS_DIR.is_dir(), "/home/user/finops exists but is not a directory."

    mode = stat.S_IMODE(FINOPS_DIR.stat().st_mode)
    assert mode in (0o755, 0o775), (
        f"/home/user/finops has permissions {_human_perm(mode)}; "
        "expected 0o755 or 0o775."
    )


# --------------------------------------------------------------------------- #
# 2. CSV file tests
# --------------------------------------------------------------------------- #
def test_latest_costs_csv_exists():
    assert CSV_PATH.exists(), "Required CSV file /home/user/finops/latest_costs.csv is missing."
    assert CSV_PATH.is_file(), "/home/user/finops/latest_costs.csv exists but is not a regular file."


def test_latest_costs_csv_content_exact_match():
    actual = CSV_PATH.read_text(encoding="utf-8")
    if actual != EXPECTED_CSV:
        # Produce a helpful diff-style message limited to the first differing line
        exp_lines = EXPECTED_CSV.splitlines(keepends=True)
        act_lines = actual.splitlines(keepends=True)
        for idx, (e_line, a_line) in enumerate(zip(exp_lines, act_lines), start=1):
            if e_line != a_line:
                raise AssertionError(
                    f"CSV content mismatch at line {idx} of {CSV_PATH}.\n"
                    f"Expected: {e_line!r}\n"
                    f"Actual:   {a_line!r}"
                )
        # If we get here, lengths differ
        raise AssertionError(
            f"CSV file length mismatch. Expected {len(EXPECTED_CSV)} bytes, "
            f"got {len(actual)} bytes."
        )


# --------------------------------------------------------------------------- #
# 3. scrape.log tests
# --------------------------------------------------------------------------- #
def test_scrape_log_exists_and_non_empty():
    assert LOG_PATH.exists(), "scrape.log is missing at /home/user/finops/scrape.log."
    assert LOG_PATH.is_file(), "/home/user/finops/scrape.log exists but is not a file."
    assert LOG_PATH.stat().st_size > 0, "scrape.log is empty; at least one line is required."


def test_scrape_log_format_and_line_count():
    lines = LOG_PATH.read_text(encoding="utf-8").splitlines()

    assert len(lines) >= 2, (
        f"scrape.log should contain at least 2 lines (found {len(lines)})."
    )

    for idx, line in enumerate(lines, start=1):
        assert TIMESTAMP_CMD_REGEX.fullmatch(line), (
            f"Line {idx} of scrape.log does not match the required format:\n"
            f"  {line!r}\n"
            "Expected format:\n"
            "  [YYYY-MM-DD HH:MM:SS] COMMAND_GOES_HERE"
        )