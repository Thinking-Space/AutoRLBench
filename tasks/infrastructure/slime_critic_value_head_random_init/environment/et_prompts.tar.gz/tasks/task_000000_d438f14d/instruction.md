You are a FinOps analyst who needs to pull the current month’s line-item cloud-cost data from a simple “billing portal” and convert it to a CSV that downstream reports can ingest.

    Preconditions for the exercise:
    •  A static HTML file that represents the billing portal already exists at  
       /home/user/data/cloudbilling.html  
    •  No network access is required; treat the HTML file as if it had been downloaded by a headless browser.

    Goal:
    *   Inspect /home/user/data/cloudbilling.html and locate the table with id="cost-table".  
    *   Extract every row under that table’s &lt;tbody&gt; element.  
        Each row has exactly two cells in the following order:  
            – Service name (e.g. “EC2”)  
            – Cost with a leading “$” sign (e.g. “$45.32”)  
    *   Produce a CSV file at /home/user/finops/latest_costs.csv with **exactly** this format (including letter case, comma placement, and newline characters):  

            Service,MonthlyCostUSD
            EC2,45.32
            S3,12.05
            RDS,33.10

        •  There must be **one newline character (ASCII 0x0A)** after every line, including the last line.  
        •  Do not include the dollar sign in the numbers; keep exactly two digits after the decimal point.  
        •  The file must not contain any extra whitespace, quotation marks, or blank lines.

    *   For auditability, create a plain-text command log at /home/user/finops/scrape.log.  
        •  Append one line to scrape.log **immediately after each command is executed**.  
        •  Each line must be in this exact format (24-hour clock, seconds included):  

            [YYYY-MM-DD HH:MM:SS] COMMAND_GOES_HERE
 
        •  Only the command itself should appear after the timestamp; do not log the resulting output.

    Verification notes the grader will follow:
    •  It will read /home/user/finops/latest_costs.csv and compare it byte-for-byte with the reference content above.  
    •  It will ensure that scrape.log exists, is non-empty, and that every line matches the timestamp pattern.

    Constraints:
    •  You do NOT have root; stay inside /home/user.  
    •  Do NOT hard-code the costs; they must be parsed from the HTML.