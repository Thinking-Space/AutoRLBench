# test_final_state.py
#
# Pytest suite that verifies the **FINAL** state of the operating-system /
# container **after** the learner has completed the FinOps filtering task.
#
# Only the Python standard library and pytest are used.
# Any failure message should help the learner understand what is still wrong.

import json
import csv
from pathlib import Path

import pytest

# --------------------------------------------------------------------------- #
# CONSTANTS – absolute paths that MUST exist after the task is completed
# --------------------------------------------------------------------------- #

BASE_DIR              = Path("/home/user/cloud_costs")
RAW_FILE              = BASE_DIR / "raw"       / "weekly_costs.json"
SCHEMA_FILE           = BASE_DIR / "schema"    / "cloud_cost_report.schema.json"

PROCESSED_DIR         = BASE_DIR / "processed"
HIGH_SPEND_JSON_FILE  = PROCESSED_DIR / "high_spend_weekly_costs.json"
HIGH_SPEND_CSV_FILE   = PROCESSED_DIR / "high_spend_weekly_costs_summary.csv"

LOGS_DIR              = BASE_DIR / "logs"
VALIDATION_LOG_FILE   = LOGS_DIR / "high_spend_validation.log"


# --------------------------------------------------------------------------- #
# Helper functions
# --------------------------------------------------------------------------- #

def _load_raw_cost_data():
    """Return the list loaded from the raw weekly_costs.json file."""
    try:
        return json.loads(RAW_FILE.read_text(encoding="utf-8"))
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"Could not read initial raw file {RAW_FILE}: {exc}")


def _expected_filtered_records():
    """Return the list of dicts that MUST be inside the high-spend JSON file."""
    return [
        item for item in _load_raw_cost_data()
        if isinstance(item.get("cost"), (int, float))
        and item["cost"] > 1000
        and item["currency"] == "USD"
    ]


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #

def test_processed_directories_exist():
    assert PROCESSED_DIR.is_dir(), (
        f"Missing directory {PROCESSED_DIR}. "
        "Create it before writing the filtered JSON & CSV files."
    )
    assert LOGS_DIR.is_dir(), (
        f"Missing directory {LOGS_DIR}. "
        "Create it before writing the validation log file."
    )


# ----------------------------  JSON artefact  ------------------------------ #

def test_high_spend_json_file_exists():
    assert HIGH_SPEND_JSON_FILE.is_file(), (
        f"Expected filtered JSON file {HIGH_SPEND_JSON_FILE} is missing."
    )


def test_high_spend_json_content_and_ordering():
    # 1. Load learner-produced file
    try:
        learner_data = json.loads(HIGH_SPEND_JSON_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        pytest.fail(f"{HIGH_SPEND_JSON_FILE} is not valid JSON: {exc}")

    # 2. Compute the ground-truth filtered records
    expected_data = _expected_filtered_records()

    # 3. Comparison
    assert learner_data == expected_data, (
        f"{HIGH_SPEND_JSON_FILE} does not contain the correct filtered data.\n"
        f"Expected (order preserved) {len(expected_data)} record(s) that match the "
        f"criteria cost>1000 & currency=='USD', but found {len(learner_data)}.\n"
        "Ensure you keep the original ordering from the raw file."
    )


def test_high_spend_json_pretty_printing():
    """
    The JSON must be pretty-printed with 2-space indentation and end with exactly
    one newline.  Tabs are NOT allowed.  Each indented line must start with a
    multiple of 2 spaces.
    """
    text = HIGH_SPEND_JSON_FILE.read_text(encoding="utf-8")

    # Trailing newline
    assert text.endswith("\n"), (
        f"{HIGH_SPEND_JSON_FILE} must end with a single trailing newline."
    )

    # No trailing blank lines
    assert text[:-1].rstrip("\n\r") == text[:-1], (
        f"{HIGH_SPEND_JSON_FILE} contains extra blank lines at the end."
    )

    # No TAB characters
    assert "\t" not in text, (
        f"{HIGH_SPEND_JSON_FILE} contains TAB characters; use spaces only."
    )

    # Indentation must be multiples of 2 spaces
    for line_no, line in enumerate(text.splitlines(), start=1):
        if not line.strip():
            continue  # skip empty or all-whitespace lines
        leading_spaces = len(line) - len(line.lstrip(" "))
        assert leading_spaces % 2 == 0, (
            f"Line {line_no} in {HIGH_SPEND_JSON_FILE} is indented with "
            f"{leading_spaces} space(s); indentation must be a multiple of 2."
        )


# -------------------------------  CSV artefact  ---------------------------- #

def test_high_spend_csv_exists():
    assert HIGH_SPEND_CSV_FILE.is_file(), (
        f"Expected CSV summary file {HIGH_SPEND_CSV_FILE} is missing."
    )


def test_high_spend_csv_header_and_rows():
    """
    1. Header line must be exactly: account_id,service,cost,week
    2. Number and order of data rows must match the JSON file.
    3. Each row value must correspond to its JSON record.
    4. All lines must end with a single newline, no extra whitespace.
    """
    raw_text = HIGH_SPEND_CSV_FILE.read_text(encoding="utf-8")
    assert raw_text.endswith("\n"), (
        f"{HIGH_SPEND_CSV_FILE} must end with a single trailing newline."
    )

    # Split while keeping order; drop the last empty element if file ends with \n
    lines = raw_text.splitlines()
    assert lines, f"{HIGH_SPEND_CSV_FILE} is empty."

    expected_header = "account_id,service,cost,week"
    assert lines[0] == expected_header, (
        f"CSV header is incorrect.\nExpected: {expected_header!r}\n"
        f"Found   : {lines[0]!r}"
    )

    learner_rows = lines[1:]
    json_records = json.loads(HIGH_SPEND_JSON_FILE.read_text(encoding="utf-8"))

    assert len(learner_rows) == len(json_records), (
        f"{HIGH_SPEND_CSV_FILE} should contain {len(json_records)} data row(s) "
        f"but has {len(learner_rows)}."
    )

    # Validate each CSV row against its JSON counterpart
    for idx, (csv_line, record) in enumerate(zip(learner_rows, json_records), start=1):
        expected_csv_line = (
            f"{record['account_id']},{record['service']},{record['cost']},{record['week']}"
        )
        assert csv_line == expected_csv_line, (
            f"CSV row {idx} does not match the corresponding JSON record.\n"
            f"Expected: {expected_csv_line!r}\nFound   : {csv_line!r}"
        )


# ------------------------------  LOG artefact  ----------------------------- #

def test_validation_log_exists_and_content():
    assert VALIDATION_LOG_FILE.is_file(), (
        f"Validation log file {VALIDATION_LOG_FILE} is missing."
    )

    content = VALIDATION_LOG_FILE.read_text(encoding="utf-8")
    # Accept either with or without the final newline, but no extra lines
    stripped = content.strip("\n\r")
    assert stripped == "Validation successful", (
        f"{VALIDATION_LOG_FILE} must contain exactly the line "
        f"'Validation successful' and nothing else (found: {content!r})."
    )

    # Ensure it's only one line (after stripping trailing newline)
    assert "\n" not in stripped, (
        f"{VALIDATION_LOG_FILE} contains multiple lines; it must contain exactly one."
    )