You are a FinOps analyst investigating unusually high weekly cloud expenses.
A colleague has already exported the raw cost data as well as the JSON-Schema that
all downstream tooling relies on.

File & directory layout that already exists
  /home/user/cloud_costs/raw/weekly_costs.json
  /home/user/cloud_costs/schema/cloud_cost_report.schema.json
  (The directories above already exist and are readable.)

You must create the following artefacts *exactly* (automated tests are strict):

1.  /home/user/cloud_costs/processed/high_spend_weekly_costs.json
    *   JSON array, pretty-printed with **2-space** indentation and a single trailing
        newline.
    *   It must only contain the objects whose “cost” value is **> 1000** and
        “currency” exactly **"USD"**.
    *   The ordering of objects must be preserved from the original file.

2.  /home/user/cloud_costs/processed/high_spend_weekly_costs_summary.csv
    *   Plain text UTF-8.
    *   The very first line (header) must be literally:
        account_id,service,cost,week
    *   Followed by one line per high-spend record, in the same order as in
        the JSON file.
    *   No extra whitespace; each line ends with a single newline (`\n`).

3.  /home/user/cloud_costs/logs/high_spend_validation.log
    *   Must contain exactly one line:
        Validation successful
    *   Create the parent directory (`/home/user/cloud_costs/logs`) if it does not
        exist.
    *   Only write that line after the filtered JSON successfully validates
        against the schema.

The automated grader will check:
  *   Existence of the three files at the exact locations specified above.
  *   The content of the filtered JSON: it must only contain the expected objects,
      with 2-space indentation and a trailing newline.
  *   The CSV header and row ordering/content exactly matching the filtered JSON.
  *   The validation log contains precisely the text “Validation successful”.

Work entirely from the Linux terminal; do not edit this description.