#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y \
        python3 \
        python3-pip \
        jq \
        curl \
        ca-certificates && \
    pip3 install --no-cache-dir pytest && \
    mkdir -p /home/user/cloud_costs/raw && \
    mkdir -p /home/user/cloud_costs/schema

cat > /home/user/cloud_costs/raw/weekly_costs.json <<'EOF'
[
  {
    "account_id": "acc-001",
    "service": "EC2",
    "cost": 800,
    "currency": "USD",
    "week": "2023-W25"
  },
  {
    "account_id": "acc-002",
    "service": "S3",
    "cost": 1200,
    "currency": "USD",
    "week": "2023-W25"
  },
  {
    "account_id": "acc-003",
    "service": "RDS",
    "cost": 1500,
    "currency": "USD",
    "week": "2023-W25"
  },
  {
    "account_id": "acc-004",
    "service": "Lambda",
    "cost": 400,
    "currency": "USD",
    "week": "2023-W25"
  }
]
EOF

cat > /home/user/cloud_costs/schema/cloud_cost_report.schema.json <<'EOF'
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "array",
  "items": {
    "type": "object",
    "additionalProperties": false,
    "required": ["account_id", "service", "cost", "currency", "week"],
    "properties": {
      "account_id": { "type": "string" },
      "service":     { "type": "string" },
      "cost":        { "type": "number" },
      "currency":    { "type": "string" },
      "week":        { "type": "string" }
    }
  }
}
EOF

chmod -R a+rX /home/user

export PATH=/usr/local/bin:/usr/local/sbin:/usr/bin:/usr/sbin:/bin:/sbin:$PATH

mkdir -p /home/user && cd /home/user
