# test_final_state.py
#
# Pytest suite that validates the **FINAL** operating-system / file-system
# state after the “migration plan” task has been completed.  The tests
# assert that the two required output files have been created in
# /home/user/migration and that their byte-level contents exactly match
# what the specification demands.

from pathlib import Path
import pytest


HOME = Path("/home/user")
MIGRATION_DIR = HOME / "migration"

# ---- Input files (must still be present) ------------------------------------

PROD_FILE = MIGRATION_DIR / "prod_services.csv"
STAGING_FILE = MIGRATION_DIR / "staging_services.csv"
IPS_FILE = MIGRATION_DIR / "new_cluster_ips.txt"

# ---- Output files to be tested ---------------------------------------------

PLAN_FILE = MIGRATION_DIR / "deployment_plan.tsv"
LOG_FILE = MIGRATION_DIR / "plan_generation.log"


# --------------------------------------------------------------------------- #
# Helper functions
# --------------------------------------------------------------------------- #
def _read_file_lines(path: Path):
    """
    Read a text file using UTF-8 and return the list of lines WITHOUT
    trailing newline characters.  Any single trailing newline at EOF is
    ignored so that comparisons are not affected by its presence or
    absence, but embedded newlines are preserved.
    """
    return path.read_text(encoding="utf-8").rstrip("\n").splitlines()


# --------------------------------------------------------------------------- #
# Expected “truth” data (taken from the exercise description)
# --------------------------------------------------------------------------- #

# 1) Expected content for deployment_plan.tsv  (tab-delimited)
EXPECTED_PLAN_LINES = [
    # Header
    "service_id\tservice_name\ttarget_ip\tenvironment",
    # Data rows
    "svc-101\tauth-service\t10.240.0.10\tproduction",
    "svc-102\tbilling-service\t10.240.0.11\tproduction",
    "svc-103\tsearch-service\t10.240.0.12\tproduction",
    "svc-201\tauth-service\t10.240.0.13\tstaging",
    "svc-202\tbilling-service\t10.240.0.14\tstaging",
]

# 2) Expected content for plan_generation.log
EXPECTED_LOG_LINES = [
    "Total_prod_services=3",
    "Total_staging_services=2",
    "Total_services=5",
    "IPs_available=5",
    "IPs_assigned=5",
]


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #

def test_output_files_exist():
    """
    Both output artefacts must exist and be regular files.
    """
    for path in (PLAN_FILE, LOG_FILE):
        assert path.is_file(), (
            f"Required output file {path} is missing. "
            "Have you run the correct shell pipeline that generates it?"
        )


def test_deployment_plan_exact_content():
    """
    deployment_plan.tsv must match the reference content exactly
    (header + 5 data rows, tab-delimited, in the correct order).
    """
    actual = _read_file_lines(PLAN_FILE)
    assert actual == EXPECTED_PLAN_LINES, (
        f"{PLAN_FILE} does not match the expected contents.\n\n"
        "Expected:\n"
        + "\n".join(EXPECTED_PLAN_LINES)
        + "\n\nActual:\n"
        + "\n".join(actual)
    )


def test_deployment_plan_tab_integrity():
    """
    Every line in deployment_plan.tsv must contain exactly three TAB
    characters (=> 4 columns) and zero space characters; this guarantees
    that the student used a tab-delimited format.
    """
    lines = _read_file_lines(PLAN_FILE)
    for idx, line in enumerate(lines, start=1):
        tab_count = line.count("\t")
        assert tab_count == 3, (
            f"Line {idx} of {PLAN_FILE} should contain exactly 3 TAB "
            f"characters (4 columns); found {tab_count}."
        )
        assert " " not in line, (
            f"Line {idx} of {PLAN_FILE} contains spaces.  The file must be "
            "strictly TAB-delimited without any spaces."
        )


def test_plan_generation_log_exact_content():
    """
    plan_generation.log must consist of exactly the five verification
    keys in the required order with the correct numeric values.
    """
    actual = _read_file_lines(LOG_FILE)
    assert actual == EXPECTED_LOG_LINES, (
        f"{LOG_FILE} does not match the expected contents.\n\n"
        "Expected:\n"
        + "\n".join(EXPECTED_LOG_LINES)
        + "\n\nActual:\n"
        + "\n".join(actual)
    )


def test_log_values_are_consistent_with_input_files():
    """
    In addition to matching the literal 'truth' values, the numeric
    figures reported in plan_generation.log must _also_ make sense when
    recomputed dynamically from the still-present input files.  This
    guards against situations where the student hard-coded the expected
    numbers instead of calculating them.
    """
    # --- Compute counts on the fly -----------------------------------------
    prod_rows = len(_read_file_lines(PROD_FILE)) - 1  # subtract header
    staging_rows = len(_read_file_lines(STAGING_FILE)) - 1
    total_services = prod_rows + staging_rows
    ips_available = len(_read_file_lines(IPS_FILE))
    ips_assigned = total_services

    expected_dynamic = [
        f"Total_prod_services={prod_rows}",
        f"Total_staging_services={staging_rows}",
        f"Total_services={total_services}",
        f"IPs_available={ips_available}",
        f"IPs_assigned={ips_assigned}",
    ]

    actual = _read_file_lines(LOG_FILE)
    assert actual == expected_dynamic, (
        "The numbers in plan_generation.log are not consistent with the "
        "current input files.  Make sure you calculate the values "
        "programmatically rather than hard-coding them.\n\n"
        "Expected (dynamic recomputation):\n"
        + "\n".join(expected_dynamic)
        + "\n\nActual:\n"
        + "\n".join(actual)
    )