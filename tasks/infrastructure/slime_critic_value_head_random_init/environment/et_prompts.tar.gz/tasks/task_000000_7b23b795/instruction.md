You are acting as a cloud-solutions architect who is preparing a
migration plan for a set of micro-services that will be moved to a
brand-new Kubernetes cluster.

The directory `/home/user/migration` already contains three data files
that were exported from the company’s CMDB:

1.  `/home/user/migration/prod_services.csv`
    *   Comma-separated.
    *   Header row is:  
        `service_id,service_name,current_env,replicas,owner`

2.  `/home/user/migration/staging_services.csv`  
    *   Same structure and header as the production file.

3.  `/home/user/migration/new_cluster_ips.txt`  
    *   Plain text, one IPv4 address per line, no header.

### TASK

1.  Read both `*.csv` files, extract only the first and second columns
    (`service_id` and `service_name`).  
    *   The production file must be processed first, followed immediately
        by the staging file; do NOT sort the rows – keep the original
        order found in each file.
2.  Consume IP addresses from `new_cluster_ips.txt` sequentially, starting
    with the first line of that file, pairing them 1-for-1 with the
    extracted services.
3.  Add a final column called `environment` that must contain the literal
    string “production” for rows that originated in `prod_services.csv`
    and “staging” for rows that originated in `staging_services.csv`.
4.  Assemble everything into a **tab-delimited** output file named
    `/home/user/migration/deployment_plan.tsv` whose exact first five
    lines must be:

        service_id<TAB>service_name<TAB>target_ip<TAB>environment
        svc-101<TAB>auth-service<TAB>10.240.0.10<TAB>production
        svc-102<TAB>billing-service<TAB>10.240.0.11<TAB>production
        svc-103<TAB>search-service<TAB>10.240.0.12<TAB>production
        svc-201<TAB>auth-service<TAB>10.240.0.13<TAB>staging

    (Where `<TAB>` represents a real horizontal tab character; **do not
    insert spaces**).  
    The file must continue with any remaining rows produced by the same
    algorithm, following the exact tab layout.

5.  Create a plain-text log named `/home/user/migration/plan_generation.log`
    with the following verification keys, **in exactly this order**,
    one per line, no extra spaces, no quotes:

        Total_prod_services=<NUMBER>
        Total_staging_services=<NUMBER>
        Total_services=<NUMBER>
        IPs_available=<NUMBER>
        IPs_assigned=<NUMBER>

    The values must be computed dynamically from the input files:
     * `Total_prod_services`  — data rows (excluding header) in prod file  
     * `Total_staging_services` — data rows in staging file  
     * `Total_services`       — sum of the above two counts  
     * `IPs_available`        — total lines in `new_cluster_ips.txt`  
     * `IPs_assigned`         — must equal `Total_services`

Your work must be executed inside the `/home/user/migration` directory.

When finished, both `deployment_plan.tsv` and `plan_generation.log` must
exist in `/home/user/migration` with the exact formats described above
so that an automated test can verify them byte-for-byte.