#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get -y install --no-install-recommends \
        python3 \
        python3-pip \
        locales && \
    pip3 install --no-cache-dir pytest

mkdir -p /home/user/migration

cat > /home/user/migration/prod_services.csv <<'EOF'
service_id,service_name,current_env,replicas,owner
svc-101,auth-service,production,3,team-login
svc-102,billing-service,production,2,team-payment
svc-103,search-service,production,4,team-search
EOF

cat > /home/user/migration/staging_services.csv <<'EOF'
service_id,service_name,current_env,replicas,owner
svc-201,auth-service,staging,1,team-login
svc-202,billing-service,staging,1,team-payment
EOF

cat > /home/user/migration/new_cluster_ips.txt <<'EOF'
10.240.0.10
10.240.0.11
10.240.0.12
10.240.0.13
10.240.0.14
EOF

chmod -R 0777 /home/user

mkdir -p /home/user && cd /home/user
