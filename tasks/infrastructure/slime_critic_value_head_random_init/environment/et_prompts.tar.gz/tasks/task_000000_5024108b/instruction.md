Your role is that of an artifact-repository engineer who needs to isolate problem download requests and create a compact report for management.

Resources already on disk
-------------------------
1.  A raw HTTP access log is located at
    /home/user/logs/artifact_audit.log
    Its lines follow this exact pattern  
       `YYYY-MM-DDThh:mm:ssZ SP repo-NAME/PATH/TO/FILE SP STATUS SP Human-text`  
    *   `repo-NAME` never contains slashes.
    *   `PATH/TO/FILE` can contain any byte except space.
    *   `STATUS` is the 3-digit HTTP status code.  
    Example line (already present in the file):
       `2024-07-20T10:15:43Z repo-core/org/example/libbar-2.0.0.jar 404 Not Found`

Required output
---------------
A.  Create a new directory  
    `/home/user/reports`  
    and inside it create the **exactly‐named** file  
    `/home/user/reports/bad_requests.log`

    `bad_requests.log` must contain **only** the requests whose status is either 404 or 500, in **the same order** they originally appeared. Each line of `bad_requests.log` must be rewritten into this four-column, tab-separated layout (no double spaces, use TABs only):

    `TIMESTAMP<TAB>REPO_NAME<TAB>STATUS<TAB>RELATIVE_PATH`

    where
    *   TIMESTAMP …… the timestamp copied unchanged from the source line
    *   REPO_NAME …… the text between the first space and the first slash
    *   STATUS …… the numeric status (404 or 500)
    *   RELATIVE_PATH … everything after “REPO_NAME/” up to the status code, i.e. the artifact’s path inside the repo.
    
    A newline must follow the final record.

    Example of the desired format (actual data will match the log):
    `2024-07-20T10:15:43Z<TAB>repo-core<TAB>404<TAB>org/example/libbar-2.0.0.jar`

B.  Also inside `/home/user/reports` create  
    `/home/user/reports/bad_request_summary.txt`  
    Each line of this summary must aggregate how many 404 and 500 events occurred per repository, sorted alphabetically by repository name. The exact required line format is:

    `REPO_NAME 404:<count> 500:<count>`

    Again, terminate the file with a trailing newline.

C.  While your solution is running, feel free to print intermediary console output, but the two files above will be the only artefacts verified by the automated tests.

Technical constraints
---------------------
*   Your solution should not be hard-coded to the example data; it will be tested against a log file with additional lines.
*   Do *not* modify the original `artifact_audit.log`.
*   Ensure that `/home/user/reports/bad_requests.log` and `/home/user/reports/bad_request_summary.txt` are readable by a regular user.

Deliverables
------------
1.  /home/user/reports/bad_requests.log
2.  /home/user/reports/bad_request_summary.txt

The automated grader will check:
*   that `/home/user/reports` exists,
*   that both files exist,
*   that `bad_requests.log` matches the required 4-column, tab-separated layout and contains only 404/500 lines,
*   that `bad_request_summary.txt` has correct per-repo counts and is sorted alphabetically.

Take your time—the task is complete once both files contain the right data in the right format.