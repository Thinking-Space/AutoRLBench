# test_final_state.py
#
# Robust pytest suite that validates the FINAL state of the filesystem
# after the student has finished the “artifact-repository” task.
#
# It asserts that
#   • /home/user/reports           exists and is a directory
#   • /home/user/reports/bad_requests.log          exists, 0644, correct data
#   • /home/user/reports/bad_request_summary.txt   exists, 0644, correct data
#   • /home/user/logs/artifact_audit.log          is STILL present & unchanged
#
# Only stdlib + pytest are used; failures explain exactly what is wrong.

import os
import stat
import pytest

# --------------------------------------------------------------------------- #
# Paths & expected contents                                                   #
# --------------------------------------------------------------------------- #
LOG_DIR             = "/home/user/logs"
LOG_FILE            = "/home/user/logs/artifact_audit.log"

REPORTS_DIR         = "/home/user/reports"
BAD_REQ_LOG         = "/home/user/reports/bad_requests.log"
BAD_REQ_SUMMARY     = "/home/user/reports/bad_request_summary.txt"

# Exact reference data for the ORIGINAL log file (must still be intact)
EXPECTED_ORIGINAL_LOG_LINES = [
    "2024-07-20T10:15:42Z repo-core/org/example/libfoo-1.2.3.jar 200 -\n",
    "2024-07-20T10:15:43Z repo-core/org/example/libbar-2.0.0.jar 404 Not Found\n",
    "2024-07-20T10:16:01Z repo-proprietary/com/acme/widget-5.1.0.bin 500 Internal Server Error\n",
    "2024-07-20T10:16:05Z repo-proprietary/com/acme/widget-5.1.0.sig 200 -\n",
    "2024-07-20T10:17:22Z repo-dev/io/experiment/test-0.0.1-alpha.jar 404 Not Found\n",
    "2024-07-20T10:18:55Z repo-core/org/example/libbaz-3.1.4.jar 200 -\n",
    "2024-07-20T10:19:04Z repo-core/org/example/libbar-2.0.0-sources.jar 404 Not Found\n",
]

# Expected artefacts -------------------------------------------------------- #
EXPECTED_BAD_REQ_LOG_LINES = [
    "2024-07-20T10:15:43Z\trepo-core\t404\torg/example/libbar-2.0.0.jar\n",
    "2024-07-20T10:16:01Z\trepo-proprietary\t500\tcom/acme/widget-5.1.0.bin\n",
    "2024-07-20T10:17:22Z\trepo-dev\t404\tio/experiment/test-0.0.1-alpha.jar\n",
    "2024-07-20T10:19:04Z\trepo-core\t404\torg/example/libbar-2.0.0-sources.jar\n",
]

EXPECTED_SUMMARY_LINES = [
    "repo-core 404:2 500:0\n",
    "repo-dev 404:1 500:0\n",
    "repo-proprietary 404:0 500:1\n",
]

# Convenience constants ----------------------------------------------------- #
PERMISSIONS_0644 = 0o644


# --------------------------------------------------------------------------- #
# Helper utilities                                                            #
# --------------------------------------------------------------------------- #
def _check_mode(path, expected, kind_desc):
    perms = stat.S_IMODE(os.stat(path).st_mode)
    assert perms == expected, (
        f"{kind_desc} {path} must have permissions {oct(expected)}, "
        f"but has {oct(perms)}."
    )


def _read_lines(path):
    """
    Return list(str) using readlines() with universal newlines so we do
    not accidentally drop the trailing LF information (retained in each item).
    """
    with open(path, "r", newline="") as fh:
        return fh.readlines()


# --------------------------------------------------------------------------- #
# Tests verifying the original log is still intact                            #
# --------------------------------------------------------------------------- #
def test_original_log_still_exists_and_is_regular():
    assert os.path.isfile(LOG_FILE), (
        f"Original log file {LOG_FILE} vanished – it must remain untouched."
    )
    mode = os.stat(LOG_FILE).st_mode
    assert stat.S_ISREG(mode), f"{LOG_FILE} exists but is not a regular file."


def test_original_log_permissions_0644():
    _check_mode(LOG_FILE, PERMISSIONS_0644, "Original log file")


def test_original_log_content_unchanged():
    current = _read_lines(LOG_FILE)
    assert current == EXPECTED_ORIGINAL_LOG_LINES, (
        f"{LOG_FILE} content was modified. It must remain exactly as it was "
        "before the task was started.\n"
        "Differences:\n"
        f"EXPECTED ({len(EXPECTED_ORIGINAL_LOG_LINES)} lines):\n"
        f"{''.join(EXPECTED_ORIGINAL_LOG_LINES)}\n"
        f"FOUND    ({len(current)} lines):\n"
        f"{''.join(current)}"
    )


# --------------------------------------------------------------------------- #
# Tests for /home/user/reports directory                                      #
# --------------------------------------------------------------------------- #
def test_reports_directory_exists_and_is_dir():
    assert os.path.isdir(REPORTS_DIR), (
        f"Required directory {REPORTS_DIR} is missing."
    )


# --------------------------------------------------------------------------- #
# Tests for bad_requests.log                                                  #
# --------------------------------------------------------------------------- #
def test_bad_requests_log_exists_and_is_regular():
    assert os.path.isfile(BAD_REQ_LOG), (
        f"Expected file {BAD_REQ_LOG} is missing."
    )
    mode = os.stat(BAD_REQ_LOG).st_mode
    assert stat.S_ISREG(mode), f"{BAD_REQ_LOG} exists but is not a regular file."


def test_bad_requests_log_permissions_0644():
    _check_mode(BAD_REQ_LOG, PERMISSIONS_0644, "Bad-request log")


def test_bad_requests_log_content_exact_and_format():
    lines = _read_lines(BAD_REQ_LOG)

    # 1) trailing newline
    with open(BAD_REQ_LOG, "rb") as fh:
        content_bytes = fh.read()
        assert content_bytes.endswith(b"\n"), (
            f"{BAD_REQ_LOG} must end with a single newline character."
        )

    # 2) exact expected lines & order
    assert lines == EXPECTED_BAD_REQ_LOG_LINES, (
        f"{BAD_REQ_LOG} content differs from expected.\n"
        "EXPECTED:\n" + "".join(EXPECTED_BAD_REQ_LOG_LINES) +
        "\nFOUND:\n" + "".join(lines)
    )

    # 3) validate 4-column TAB-separated structure for every line
    for idx, line in enumerate(lines, start=1):
        cols = line.rstrip("\n").split("\t")
        assert len(cols) == 4, (
            f"Line {idx} in {BAD_REQ_LOG} should have 4 TAB-separated columns, "
            f"found {len(cols)} columns."
        )
        timestamp, repo_name, status, rel_path = cols
        # status must be 404 or 500
        assert status in ("404", "500"), (
            f"Line {idx} in {BAD_REQ_LOG} has illegal status '{status}'; "
            "only 404 or 500 are permitted."
        )
        # rel_path must not be empty
        assert rel_path, (
            f"Line {idx} in {BAD_REQ_LOG} has an empty RELATIVE_PATH column."
        )


# --------------------------------------------------------------------------- #
# Tests for bad_request_summary.txt                                           #
# --------------------------------------------------------------------------- #
def test_bad_request_summary_exists_and_is_regular():
    assert os.path.isfile(BAD_REQ_SUMMARY), (
        f"Expected file {BAD_REQ_SUMMARY} is missing."
    )
    mode = os.stat(BAD_REQ_SUMMARY).st_mode
    assert stat.S_ISREG(mode), (
        f"{BAD_REQ_SUMMARY} exists but is not a regular file."
    )


def test_bad_request_summary_permissions_0644():
    _check_mode(BAD_REQ_SUMMARY, PERMISSIONS_0644, "Summary file")


def test_bad_request_summary_content_exact_and_format():
    lines = _read_lines(BAD_REQ_SUMMARY)

    # 1) trailing newline
    with open(BAD_REQ_SUMMARY, "rb") as fh:
        content_bytes = fh.read()
        assert content_bytes.endswith(b"\n"), (
            f"{BAD_REQ_SUMMARY} must end with a single newline."
        )

    # 2) exact expected lines & alphabetical order
    assert lines == EXPECTED_SUMMARY_LINES, (
        f"{BAD_REQ_SUMMARY} content differs from expected.\n"
        "EXPECTED:\n" + "".join(EXPECTED_SUMMARY_LINES) +
        "\nFOUND:\n" + "".join(lines)
    )

    # 3) validate per-line structure “REPO_NAME 404:<n> 500:<n>”
    for idx, line in enumerate(lines, start=1):
        parts = line.rstrip("\n").split()
        assert len(parts) == 3, (
            f"Line {idx} in {BAD_REQ_SUMMARY} must contain exactly three "
            f"space-separated fields, found {len(parts)}."
        )
        repo, c404, c500 = parts
        assert c404.startswith("404:") and c404[4:].isdigit(), (
            f"Line {idx} in {BAD_REQ_SUMMARY} has malformed 404 count '{c404}'."
        )
        assert c500.startswith("500:") and c500[4:].isdigit(), (
            f"Line {idx} in {BAD_REQ_SUMMARY} has malformed 500 count '{c500}'."
        )