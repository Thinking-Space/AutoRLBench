#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3-pip \
        ca-certificates && \
    pip3 install --no-cache-dir pytest && \
    mkdir -p /home/user/rotation && \
    chmod 0777 /home/user && \
    chmod 0777 /home/user/rotation

cat > /home/user/rotation/credential_rotation.log <<'EOF'
[2024-05-03 09:14:02] user=alice action=update password_old=2c1743a password_new=10ac5bd
[2024-05-03 09:15:45] user=alice action=confirm rotation_status=success
[2024-05-03 10:01:11] user=bob action=update password_old=ffab23a password_new=946adfe
[2024-05-03 10:03:02] user=bob action=confirm rotation_status=success
[2024-05-03 11:20:55] user=charlie action=update password_old=ab41dfe password_new=dfee551
[2024-05-03 11:22:11] user=charlie action=confirm rotation_status=success
[2024-05-03 12:10:13] user=david action=confirm rotation_status=success
EOF

chmod 0666 /home/user/rotation/credential_rotation.log

export LANG=C.UTF-8

export LC_ALL=C.UTF-8

chmod 755 /home/user
