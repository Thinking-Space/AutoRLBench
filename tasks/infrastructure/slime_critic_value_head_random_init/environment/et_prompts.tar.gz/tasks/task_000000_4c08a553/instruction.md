You are a security engineer who has just completed a round of credential rotation.
A colleague has asked for a quick, one-off report that lists every log entry where an **old password hash** was still present in the rotation logs, so they can double-check that no secrets were accidentally written to disk.

### Environment
1. A directory already exists at  
   `/home/user/rotation`
2. Inside that directory there is a text file called  
   `/home/user/rotation/credential_rotation.log`  
   The file is UTF-8 encoded, contains fewer than 100 lines and uses the following fixed log format (one line per event):  
        `[YYYY-MM-DD HH:MM:SS] user=<username> action=<verb> …`
   * Lines that contain an old password have the token  
        `password_old=<hex-hash>`  
     somewhere after the action field.  
   * Other lines (e.g. “confirm” events) never contain the string “password_old=”.

### Task
1. Filter `credential_rotation.log` so that only the lines containing the literal text “password_old=” remain.
2. From those lines extract exactly two fields in the following order and write them to a new file:  
   a. The timestamp in the form `YYYY-MM-DD HH:MM:SS` (no brackets)  
   b. The username (the value that follows “user=”)  
3. Separate the two fields with a single horizontal tab character (`\t`).  
4. Preserve the chronological order in which the matching lines appear in the original log.  
5. Save the resulting three-line* report to  
   `/home/user/rotation/leaked_old_passwords.tsv`  
6. After creating the file, print its entire contents to STDOUT so that a human reviewer can immediately see the result.

### Output format example
If the source log contained a line:
```
[2024-01-02 03:04:05] user=jane action=update password_old=deadbeef …
```
then the corresponding line in `leaked_old_passwords.tsv` must be:
```
2024-01-02 03:04:05	jane
```

### Grading notes
* The automated tests will verify that `leaked_old_passwords.tsv` exists at the specified path.  
* The file must contain exactly three lines, each ending with a UNIX newline (`\n`).  
* Each line must consist of a timestamp, a single `\t` character, and a username—nothing more.  
* Ordering must match the chronological order of the original log entries.

\*The current log happens to contain exactly three “password_old=” events, so your output file will also contain exactly three lines.