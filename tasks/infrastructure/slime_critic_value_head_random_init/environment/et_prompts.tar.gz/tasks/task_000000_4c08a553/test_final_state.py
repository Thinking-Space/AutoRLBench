# test_final_state.py
#
# Pytest suite that validates the *final* state of the container after the
# student has completed the “credential-rotation report” task.
#
# What we check:
#   1. The original log file is still present and *unchanged*.
#   2. The report file /home/user/rotation/leaked_old_passwords.tsv
#        • exists and is a regular file
#        • contains exactly three lines (one per password_old event)
#        • each line ends with a UNIX newline
#        • each line is exactly  “<timestamp>\t<username>\n”
#        • the ordering matches the chronological order of the log
#
# Only the Python standard library and pytest are used.

import os
import re
import stat
import pytest

ROTATION_DIR = "/home/user/rotation"
LOG_PATH = os.path.join(ROTATION_DIR, "credential_rotation.log")
REPORT_PATH = os.path.join(ROTATION_DIR, "leaked_old_passwords.tsv")

# Canonical content of the rotation log from the task description
CANONICAL_LOG_LINES = [
    "[2024-05-03 09:14:02] user=alice action=update password_old=2c1743a password_new=10ac5bd\n",
    "[2024-05-03 09:15:45] user=alice action=confirm rotation_status=success\n",
    "[2024-05-03 10:01:11] user=bob action=update password_old=ffab23a password_new=946adfe\n",
    "[2024-05-03 10:03:02] user=bob action=confirm rotation_status=success\n",
    "[2024-05-03 11:20:55] user=charlie action=update password_old=ab41dfe password_new=dfee551\n",
    "[2024-05-03 11:22:11] user=charlie action=confirm rotation_status=success\n",
    "[2024-05-03 12:10:13] user=david action=confirm rotation_status=success\n",
]

@pytest.fixture(scope="module")
def log_contents():
    """Read and return the contents of the original log file."""
    if not os.path.isfile(LOG_PATH):
        pytest.fail(f"Required log file is missing at {LOG_PATH!r}.")
    with open(LOG_PATH, encoding="utf-8") as fp:
        return fp.readlines()

@pytest.fixture(scope="module")
def report_contents():
    """Read and return the contents (as lines) of the generated TSV report."""
    if not os.path.isfile(REPORT_PATH):
        pytest.fail(
            f"Report file {REPORT_PATH!r} not found. "
            "Did you create it at the correct path?"
        )
    with open(REPORT_PATH, encoding="utf-8") as fp:
        return fp.readlines()

# ---------------------------------------------------------------------------
# Tests for the original log file (must still be intact)
# ---------------------------------------------------------------------------

def test_log_file_unchanged(log_contents):
    assert log_contents == CANONICAL_LOG_LINES, (
        "The original credential_rotation.log has been modified.\n\n"
        "---------- Expected ----------\n"
        + "".join(CANONICAL_LOG_LINES)
        + "\n---------- Found ----------\n"
        + "".join(log_contents)
    )

# ---------------------------------------------------------------------------
# Tests for the generated report
# ---------------------------------------------------------------------------

def test_report_file_exists_and_is_regular():
    assert os.path.isfile(REPORT_PATH), (
        f"Expected report file not found at {REPORT_PATH!r}."
    )
    # Make sure it is a regular file, not a directory or symlink etc.
    st_mode = os.stat(REPORT_PATH).st_mode
    assert stat.S_ISREG(st_mode), (
        f"{REPORT_PATH!r} exists but is not a regular file."
    )

def test_report_has_exactly_three_lines(report_contents):
    assert len(report_contents) == 3, (
        f"Report should contain exactly 3 lines (one for each 'password_old=' "
        f"event) but contains {len(report_contents)} lines."
    )

def test_each_report_line_ends_with_newline(report_contents):
    for idx, line in enumerate(report_contents, start=1):
        assert line.endswith("\n"), (
            f"Line {idx} of the report file is missing a terminating newline."
        )

def extract_expected_report_lines(log_lines):
    """
    From the canonical log lines pick out the lines that contain 'password_old='
    and convert them to the expected <timestamp>\t<username>\n format.
    """
    expected = []
    ts_regex = r"^\[(?P<ts>[\d-]+\s[\d:]+)]"
    user_regex = r"user=(?P<user>\w+)"
    for line in log_lines:
        if "password_old=" not in line:
            continue
        # Timestamp – remove the surrounding brackets.
        ts_match = re.search(ts_regex, line)
        user_match = re.search(user_regex, line)
        assert ts_match and user_match, (
            "Failed to parse canonical log line for timestamp/username."
        )
        expected_line = f"{ts_match.group('ts')}\t{user_match.group('user')}\n"
        expected.append(expected_line)
    return expected

_EXPECTED_REPORT_LINES = extract_expected_report_lines(CANONICAL_LOG_LINES)

def test_report_lines_exact_content(report_contents):
    """
    The content of the generated TSV must match the exact expected values:
        2024-05-03 09:14:02\talice
        2024-05-03 10:01:11\tbob
        2024-05-03 11:20:55\tcharlie
    (Each followed by '\n')
    """
    assert report_contents == _EXPECTED_REPORT_LINES, (
        "Report contents are incorrect.\n\n"
        "---------- Expected ----------\n"
        + "".join(_EXPECTED_REPORT_LINES)
        + "\n---------- Found ----------\n"
        + "".join(report_contents)
    )

def test_report_line_format(report_contents):
    """
    Defensive check: every line must match the format
        YYYY-MM-DD HH:MM:SS <TAB> username
    with nothing before/after, except the terminating '\n'.
    """
    pattern = re.compile(
        r"^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}\t[a-zA-Z0-9_]+\n$"
    )
    for idx, line in enumerate(report_contents, start=1):
        assert pattern.match(line), (
            f"Line {idx} of the report does not match the required "
            f"'timestamp<TAB>username' format:\n{line!r}"
        )