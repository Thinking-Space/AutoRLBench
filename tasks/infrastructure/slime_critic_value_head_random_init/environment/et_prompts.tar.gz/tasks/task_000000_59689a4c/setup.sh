#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update -y && \
    apt-get install -y --no-install-recommends \
        python3 \
        python3-pip \
        ca-certificates \
        locales && \
    pip3 install --no-cache-dir pytest && \
    mkdir -p /home/user/data

cat > /home/user/data/logs.csv <<'EOF'
timestamp,node_id,level,message
2023-01-01T00:00:00Z,node-1,INFO,Service started
2023-01-01T00:01:00Z,node-2,ERROR,Unable to reach DB
2023-01-01T00:02:00Z,node-1,ERROR,Timeout
2023-01-01T00:03:00Z,node-2,WARN,High memory
2023-01-01T00:04:00Z,node-3,ERROR,Disk full
2023-01-01T00:05:00Z,node-1,INFO,Service heartbeat
2023-01-01T00:06:00Z,node-2,ERROR,Connection reset
2023-01-01T00:07:00Z,node-3,INFO,Service started
2023-01-01T00:08:00Z,node-1,ERROR,Out of memory
2023-01-01T00:09:00Z,node-1,ERROR,Service crashed
EOF

mkdir -p /home/user/output && \
    chmod -R 0755 /home/user && \
    apt-get clean && \
    true

export LC_ALL=C.UTF-8

export LANG=C.UTF-8

export PATH=/usr/local/bin:/usr/bin:/bin
