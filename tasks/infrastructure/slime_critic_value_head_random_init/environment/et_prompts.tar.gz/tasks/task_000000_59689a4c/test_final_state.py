# test_final_state.py
#
# Pytest suite that validates the **FINAL** operating-system / container
# state after the student has produced the required “error summary”.
#
# The checks below assert that
#   • the output directory exists,
#   • the CSV artefact exists and is a regular file,
#   • the artefact’s *exact* textual content (lines, ordering, counts,
#     whitespace, newline discipline) matches the specification,
#   • the data in the file are consistent with the source dataset.
#
# If any test fails it will explain precisely what is still wrong.

import csv
import difflib
import os
from pathlib import Path

# ---------- Constants --------------------------------------------------------

SRC_DATA_FILE = Path("/home/user/data/logs.csv")
OUT_DIR = Path("/home/user/output")
OUT_FILE = OUT_DIR / "error_summary.csv"

EXPECTED_LINES = [
    "node_id,error_count",
    "node-1,3",
    "node-2,2",
    "node-3,1",
]

# ---------- Helper Functions -------------------------------------------------


def _read_text(path: Path) -> str:
    """
    Read the entire file *exactly* as UTF-8 text.
    """
    with path.open("r", encoding="utf-8", newline="") as fh:
        return fh.read()


def _read_csv_rows(path: Path):
    """
    Convenience wrapper around csv.DictReader → list[dict].
    """
    with path.open("r", encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def _make_unified_diff(a: list[str], b: list[str], fromfile: str, tofile: str) -> str:
    """
    Return a human-readable unified diff between two lists of strings.
    """
    return "".join(
        difflib.unified_diff(a, b, fromfile=fromfile, tofile=tofile, lineterm="")
    )


# ---------- Tests ------------------------------------------------------------


def test_output_directory_exists_and_is_dir():
    assert OUT_DIR.exists(), (
        f"Required output directory not found: {OUT_DIR!s}\n"
        "Create it with `mkdir -p /home/user/output` (or similar)."
    )
    assert OUT_DIR.is_dir(), f"{OUT_DIR!s} exists but is not a directory."


def test_error_summary_file_exists_and_is_file():
    assert OUT_FILE.exists(), (
        f"Required output file not found: {OUT_FILE!s}\n"
        "Make sure you redirected/created the file at the correct path."
    )
    assert OUT_FILE.is_file(), f"{OUT_FILE!s} exists but is not a regular file."


def test_error_summary_file_ends_with_single_newline_only():
    data = OUT_FILE.read_bytes()
    assert data.endswith(b"\n"), (
        "The output file must end with *exactly one* newline character."
    )
    # Guard against a double-newline (blank line) at EOF
    assert not data.endswith(b"\n\n"), (
        "The output file ends with a blank line (double newline). "
        "Remove the extra newline after the last data row."
    )


def test_error_summary_content_exact_lines_and_no_extra_whitespace_or_tabs():
    content = _read_text(OUT_FILE)
    lines = content.splitlines()

    # --- exact line content --------------------------------------------------
    if lines != EXPECTED_LINES:
        diff = _make_unified_diff(
            EXPECTED_LINES,
            lines,
            fromfile="EXPECTED",
            tofile=str(OUT_FILE),
        )
        raise AssertionError(
            "The textual content of error_summary.csv does not match the "
            "specification:\n" + diff
        )

    # --- whitespace / tab discipline ----------------------------------------
    for idx, line in enumerate(lines, start=1):
        assert line == line.strip(" "), (
            f"Line {idx} contains leading/trailing space characters:\n{line!r}"
        )
        assert "\t" not in line, (
            f"Line {idx} contains a TAB character which is not allowed:\n{line!r}"
        )


def test_error_summary_csv_structure_and_semantics():
    """
    Parse the file with csv.DictReader and cross-check:
      • header columns and order
      • exactly three data rows
      • rows are sorted lexicographically by node_id
      • error_count values are integers and match the *actual* ERROR counts
        found in the source dataset.
    """
    rows = _read_csv_rows(OUT_FILE)

    # --- header validation ---------------------------------------------------
    fieldnames = rows[0].keys() if rows else {}
    assert list(fieldnames) == ["node_id", "error_count"], (
        "CSV header must be exactly: node_id,error_count"
    )

    # --- row count -----------------------------------------------------------
    assert len(rows) == 3, (
        f"CSV must contain exactly three data rows (one per node), "
        f"found {len(rows)}."
    )

    # --- lexical sort order --------------------------------------------------
    node_ids = [row["node_id"] for row in rows]
    sorted_node_ids = sorted(node_ids)
    assert node_ids == sorted_node_ids, (
        "Data rows are not in lexicographical order by node_id.\n"
        f"Expected order: {sorted_node_ids}\n"
        f"Found order   : {node_ids}"
    )

    # --- numeric & semantic correctness --------------------------------------
    # Calculate true ERROR counts from the source dataset
    true_counts: dict[str, int] = {}
    for row in _read_csv_rows(SRC_DATA_FILE):
        if row["level"] == "ERROR":
            node = row["node_id"]
            true_counts[node] = true_counts.get(node, 0) + 1

    # Compare with artefact values
    artefact_counts = {
        row["node_id"]: int(row["error_count"]) for row in rows
    }

    assert artefact_counts == true_counts, (
        "error_count values do not match the source data.\n"
        f"Expected counts: {true_counts}\n"
        f"Found counts   : {artefact_counts}"
    )


def test_error_summary_file_has_only_four_lines():
    """
    Guard against extra hidden/blank lines that the previous content test may
    not catch if the *content* coincidentally still matches.
    """
    num_lines = sum(1 for _ in OUT_FILE.open("r", encoding="utf-8"))
    assert num_lines == 4, (
        f"CSV file must have exactly 4 lines (header + 3 data rows), "
        f"found {num_lines}."
    )