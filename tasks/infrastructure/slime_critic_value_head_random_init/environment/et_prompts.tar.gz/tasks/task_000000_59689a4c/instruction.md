A distributed-systems incident review has begun and you, the data analyst on duty, have
been asked to produce a *very small* diagnostic summary from an existing cluster
event-stream.

1.  Source data
    *   Location: /home/user/data/logs.csv
    *   Format: standard UTF-8 CSV, comma-separated, UNIX line-feeds.
    *   The first row is a header.
    *   Columns (in order): timestamp,node_id,level,message.
    *   The field “level” may hold INFO, WARN or ERROR.

2.  Required output
    *   Create a **new** file at /home/user/output/error_summary.csv.
    *   The file must contain exactly **four** lines:
        1.  a header
        2.  one line per unique node_id that appears in level=ERROR rows.
    *   Exact layout, including the header, must be:

          ```
          node_id,error_count
          node-1,3
          node-2,2
          node-3,1
          ```

        (Each line must end with a single newline character; there must be *no*
        blank lines, leading/trailing whitespace, tab characters, or extra
        columns.)

    *   Lines after the header must be sorted in plain ASCII/lexicographical
        order by node_id (node-1 before node-2 before node-3).
    *   The output directory /home/user/output must exist when you finish; create
        it if it is not already there.
    *   If /home/user/output/error_summary.csv already exists, overwrite it.

3.  Constraints
    *   Do not open an interactive editor.
    *   You do not need elevated privileges; everything should run as the
        ordinary “user” account.

Once the file is written, display its contents in the terminal so that the
incident commander can immediately see the result.