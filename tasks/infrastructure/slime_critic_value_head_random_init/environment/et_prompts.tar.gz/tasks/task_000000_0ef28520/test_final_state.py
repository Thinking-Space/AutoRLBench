# test_final_state.py
#
# This pytest suite validates the **FINAL** operating-system / container state
# after the student has completed the credential-rotation drill.
#
# The checks are STRICT:
#   • The three *.cfg files under /home/user/infra/ must now contain the
#     2025-based passwords (and still only two lines each).
#   • /home/user/infra/credentials.json must exist and match the required text
#     **byte-for-byte**, including whitespace and the single trailing LF.
#   • /home/user/rotation.log must exist and have the three new CSV lines as
#     its final three lines, in the correct order, each newline-terminated, and
#     with no blank line afterward.
#
# If any test fails the assertion message explains exactly what is missing or
# malformed so the learner can quickly fix the issue.

import pathlib
import pytest

HOME = pathlib.Path("/home/user")
INFRA_DIR = HOME / "infra"

# ---------------------------------------------------------------------------
# Expectations
# ---------------------------------------------------------------------------

CFG_EXPECTATIONS_FINAL = {
    "db.cfg": {
        "username": "db_user",
        "password": "db_pass_2025",
    },
    "redis.cfg": {
        "username": "redis_user",
        "password": "redis_pass_2025",
    },
    "api.cfg": {
        "username": "api_user",
        "password": "api_pass_2025",
    },
}

CREDENTIALS_JSON_PATH = INFRA_DIR / "credentials.json"

EXPECTED_CREDENTIALS_JSON = (
    '{\n'
    '  "db":    { "username": "db_user",    "password": "db_pass_2025" },\n'
    '  "redis": { "username": "redis_user", "password": "redis_pass_2025" },\n'
    '  "api":   { "username": "api_user",   "password": "api_pass_2025" }\n'
    '}\n'
)

ROTATION_LOG_PATH = HOME / "rotation.log"

EXPECTED_LOG_LINES = [
    "db.cfg,db_pass_2022,db_pass_2025\n",
    "redis.cfg,redis_pass_2022,redis_pass_2025\n",
    "api.cfg,api_pass_2022,api_pass_2025\n",
]

# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def _read_file_lines(path: pathlib.Path):
    """Read a file and return a list of its lines (each still newline-terminated)."""
    with path.open("r", encoding="utf-8") as f:
        return f.readlines()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_infra_directory_still_present():
    assert INFRA_DIR.exists(), f"Required directory {INFRA_DIR} has disappeared."
    assert INFRA_DIR.is_dir(), f"{INFRA_DIR} exists but is no longer a directory."


@pytest.mark.parametrize("cfg_name,expected", CFG_EXPECTATIONS_FINAL.items())
def test_cfg_files_rotated(cfg_name, expected):
    """
    Each *.cfg file must:
      • still exist
      • still have exactly two newline-terminated lines
      • have the untouched username line
      • have the password line with “2025” (and *not* “2022”)
    """
    cfg_path = INFRA_DIR / cfg_name
    assert cfg_path.exists(), f"Expected file {cfg_path} is missing after rotation."
    assert cfg_path.is_file(), f"{cfg_path} exists but is not a regular file."

    lines = _read_file_lines(cfg_path)
    assert len(lines) == 2, (
        f"{cfg_path} should contain exactly two lines (username/password) "
        f"after rotation but contains {len(lines)} line(s): {lines!r}"
    )

    username_line, password_line = lines

    expected_username_line = f"username={expected['username']}\n"
    expected_password_line = f"password={expected['password']}\n"

    assert username_line == expected_username_line, (
        f"{cfg_path} username line was modified unexpectedly:\n"
        f"  expected: {expected_username_line!r}\n"
        f"  found:    {username_line!r}"
    )
    assert password_line == expected_password_line, (
        f"{cfg_path} password line incorrect after rotation:\n"
        f"  expected: {expected_password_line!r}\n"
        f"  found:    {password_line!r}"
    )
    assert "2022" not in password_line, (
        f"{cfg_path} password line still contains '2022'; rotation incomplete."
    )


def test_credentials_json_exact_match():
    assert CREDENTIALS_JSON_PATH.exists(), (
        f"Consolidated credentials file {CREDENTIALS_JSON_PATH} was not created."
    )
    assert CREDENTIALS_JSON_PATH.is_file(), (
        f"{CREDENTIALS_JSON_PATH} exists but is not a regular file."
    )

    actual = CREDENTIALS_JSON_PATH.read_text(encoding="utf-8")
    assert (
        actual == EXPECTED_CREDENTIALS_JSON
    ), (
        f"{CREDENTIALS_JSON_PATH} content mismatch.\n"
        f"--- expected (byte-for-byte) ----------------------------------\n"
        f"{EXPECTED_CREDENTIALS_JSON!r}\n"
        f"--- found -------------------------------------------------------\n"
        f"{actual!r}"
    )


def test_rotation_log_appended_correctly():
    assert ROTATION_LOG_PATH.exists(), (
        f"Rotation log {ROTATION_LOG_PATH} does not exist."
    )
    assert ROTATION_LOG_PATH.is_file(), (
        f"{ROTATION_LOG_PATH} exists but is not a regular file."
    )

    lines = _read_file_lines(ROTATION_LOG_PATH)
    assert len(lines) >= 3, (
        f"{ROTATION_LOG_PATH} should contain at least three lines "
        f"(the new audit entries) but contains only {len(lines)}."
    )

    tail = lines[-3:]

    assert tail == EXPECTED_LOG_LINES, (
        f"The last three lines of {ROTATION_LOG_PATH} do not match the "
        f"required audit entries.\n"
        f"--- expected tail ----------------------------------------------\n"
        f"{EXPECTED_LOG_LINES!r}\n"
        f"--- actual tail ------------------------------------------------\n"
        f"{tail!r}"
    )

    # Ensure file ends with single LF and no blank line after the required tail.
    # Because readlines() keeps newlines, a trailing blank line would show up
    # as an empty string at the end of `lines`.
    assert lines[-1].endswith("\n"), (
        f"The final line of {ROTATION_LOG_PATH} must be newline-terminated."
    )
    assert lines[-1] != "\n", (
        f"{ROTATION_LOG_PATH} has an unexpected blank line at the end."
    )


# ---------------------------------------------------------------------------
# End of file
# ---------------------------------------------------------------------------