A security engineer on your team has asked you to perform a **credential-rotation drill** for three internal services that are configured by simple “*.cfg*” files located under */home/user/infra/*.
The engineer wants the rotation performed according to a very strict pattern so that the company’s compliance automation can later verify that the change happened exactly as expected.

Current state (already present when the session starts):
  • /home/user/infra/db.cfg
  • /home/user/infra/redis.cfg
  • /home/user/infra/api.cfg

Every one of those files already contains exactly two newline-terminated key/value pairs in the order shown below:
    username=<service-specific-fixed-value>
    password=<service-specific-fixed-value>

### Rotation Rule
You MUST apply the following rotation rule to the *.cfg* files:
   • Find the existing *password* value.
   • Replace the four-digit substring “2022” with “2025”.
     (Nothing else about the password string changes – you are literally doing a single, deterministic text substitution.)
   • Leave the *username* line completely untouched.

### Consolidated JSON File
After you finish editing the three *.cfg* files, create a single consolidated JSON file named
       /home/user/infra/credentials.json
that looks **exactly** like this (pay attention to spacing, newlines and quoting because the test harness will check it byte-for-byte):

    {
      "db":    { "username": "db_user",    "password": "db_pass_2025" },
      "redis": { "username": "redis_user", "password": "redis_pass_2025" },
      "api":   { "username": "api_user",   "password": "api_pass_2025" }
    }

Notes:
   • The keys must be in the precise order db, redis, api (the harness is strict).
   • Exactly two spaces before each key inside the JSON object.
   • Exactly one space after every colon.
   • Exactly one space after every comma that separates fields.
   • The file must end with a single trailing newline (Unix LF).

### Audit Trail
Produce an audit trail.
   • Append (or create if it does not yet exist) a CSV log file at
         /home/user/rotation.log
   • The file **must not** have a header row.
   • Add **exactly three** new lines, one per rotated credential, in this order:

        db.cfg,db_pass_2022,db_pass_2025
        redis.cfg,redis_pass_2022,redis_pass_2025
        api.cfg,api_pass_2022,api_pass_2025

     Each line must terminate with a single LF and there must be no blank line at the end of the file.

### Final State
When everything is complete, the following commands should produce the specified results (these commands are only shown here so that *you* understand the final state – do **not** hard-code their output):
      cat /home/user/infra/db.cfg      → shows the rotated password containing “2025”.
      cat /home/user/infra/credentials.json  → exactly matches the JSON block above.
      cat /home/user/rotation.log      → contains the three CSV lines above (plus any historical lines if the file existed before).

### Constraints
You do **not** need root privileges. All work happens in */home/user/*. Do everything from the shell. The end state must comply *exactly* with the requirements for the configuration files, the JSON output, and the audit trail.

The automation that grades your work will compare the contents of /home/user/infra/credentials.json and /home/user/rotation.log exactly, so follow the required spacing, ordering, and line-terminator conventions precisely.