You are acting as a senior database administrator who has been asked to bring hard numbers to a performance-tuning meeting.  
A log of the current “slow” SQL statements already exists at:

    /home/user/db/slow_query.log

Your objectives are:

1.  Produce a tab-separated frequency table of every distinct SQL line appearing in the log.  
    *   The file must be written to  
        /home/user/db/slow_query_frequency.tsv  
    *   Each output line must contain **exactly two columns** in the following order:  
        a) an integer occurrence count (no leading zeroes)  
        b) the literal SQL text (identical to the log line, including the trailing semicolon)  
    *   The two columns must be separated by a single <TAB> character only.  
    *   The file must be sorted  
         – primarily by the count in descending numeric order, and  
         – for ties, by the full SQL text in ascending ASCII order.  
    *   Every line (including the last) must end with a single newline character “\n”.

2.  Create a compact four-line key-value summary file at  

    /home/user/db/slow_query_summary.log

    The exact required format (including capitalisation) is:

        TOTAL_LINES=<number_of_lines_in_original_log>
        TOTAL_UNIQUE_QUERIES=<number_of_distinct_lines>
        TOP_QUERY=<the_most_frequent_SQL_line>
        TOP_QUERY_COUNT=<its_frequency>

    *   Do not surround the SQL text with quotes; write it verbatim.  
    *   Each line must end with “\n”.  
    *   In case of a tie for most-frequent query, the alphabetically first SQL line
        (the same rule used in step 1) must be chosen.

3.  The task must be completed using standard GNU/Linux command-line tools available in a typical non-privileged environment. No external programming languages, no temporary root privileges.

4.  When you are done, verify that:
    *   /home/user/db/slow_query_frequency.tsv exists and matches the format rules above.  
    *   /home/user/db/slow_query_summary.log exists and shows consistent counts.  

The automated test suite will compare your two output files byte-for-byte, so pay
close attention to ordering, delimiters and newlines.