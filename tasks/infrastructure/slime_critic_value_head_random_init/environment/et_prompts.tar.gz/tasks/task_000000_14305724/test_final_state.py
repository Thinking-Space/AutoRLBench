# test_final_state.py
#
# Pytest suite that validates the **FINAL** state of the operating-system /
# container after the student has completed the “slow query” task.
#
# The checks performed are:
#   1. The directory /home/user/db is still present and writable.
#   2. The original log file /home/user/db/slow_query.log is unchanged.
#   3. The artefact /home/user/db/slow_query_frequency.tsv exists, has the
#      exact expected content, and complies with all formatting rules.
#   4. The artefact /home/user/db/slow_query_summary.log exists, has the
#      exact expected content, and is internally consistent with both the
#      original log and the frequency table.
#
# Only the Python standard library and pytest are used.

import os
from pathlib import Path
import re

import pytest

DB_DIR = Path("/home/user/db")

LOG_FILE = DB_DIR / "slow_query.log"
FREQ_FILE = DB_DIR / "slow_query_frequency.tsv"
SUMMARY_FILE = DB_DIR / "slow_query_summary.log"

# ──────────────────────────────────────────────────────────────────────────────
# “Privileged truth” – the correct, final file contents
# ──────────────────────────────────────────────────────────────────────────────
LOG_EXPECTED_LINES = [
    "SELECT * FROM orders WHERE status = 'pending';\n",
    "SELECT id, name FROM customers WHERE country = 'US';\n",
    "UPDATE inventory SET quantity = quantity - 1 WHERE product_id = 42;\n",
    "SELECT * FROM orders WHERE status = 'pending';\n",
    "SELECT * FROM orders WHERE status = 'pending';\n",
    "UPDATE inventory SET quantity = quantity - 1 WHERE product_id = 42;\n",
    "SELECT id, name FROM customers WHERE country = 'US';\n",
    "DELETE FROM sessions WHERE last_active < NOW() - INTERVAL '30 days';\n",
    "SELECT * FROM orders WHERE status = 'pending';\n",
    "DELETE FROM sessions WHERE last_active < NOW() - INTERVAL '30 days';\n",
    "SELECT * FROM orders WHERE status = 'pending';\n",
    "SELECT id, name FROM customers WHERE country = 'US';\n",
    "INSERT INTO audit_log (event, created_at) VALUES ('login', NOW());\n",
    "SELECT * FROM orders WHERE status = 'pending';\n",
]

FREQ_EXPECTED_LINES = [
    "6\tSELECT * FROM orders WHERE status = 'pending';\n",
    "3\tSELECT id, name FROM customers WHERE country = 'US';\n",
    "2\tDELETE FROM sessions WHERE last_active < NOW() - INTERVAL '30 days';\n",
    "2\tUPDATE inventory SET quantity = quantity - 1 WHERE product_id = 42;\n",
    "1\tINSERT INTO audit_log (event, created_at) VALUES ('login', NOW');\n",
]

# Note: The INSERT line in FREQ_EXPECTED_LINES above has 'NOW()' originally? Wait: expected truth: 'NOW()';
# but in sample FREQ lines earlier: "INSERT INTO audit_log (event, created_at) VALUES ('login', NOW());"
# With parentheses. The earlier provided truth: "INSERT INTO audit_log (event, created_at) VALUES ('login', NOW());"
# but we have to ensure EXACT; above is wrong 'NOW');', missing parentheses. Let's correct:

FREQ_EXPECTED_LINES = [
    "6\tSELECT * FROM orders WHERE status = 'pending';\n",
    "3\tSELECT id, name FROM customers WHERE country = 'US';\n",
    "2\tDELETE FROM sessions WHERE last_active < NOW() - INTERVAL '30 days';\n",
    "2\tUPDATE inventory SET quantity = quantity - 1 WHERE product_id = 42;\n",
    "1\tINSERT INTO audit_log (event, created_at) VALUES ('login', NOW());\n",
]

SUMMARY_EXPECTED_LINES = [
    "TOTAL_LINES=14\n",
    "TOTAL_UNIQUE_QUERIES=5\n",
    "TOP_QUERY=SELECT * FROM orders WHERE status = 'pending';\n",
    "TOP_QUERY_COUNT=6\n",
]

# ──────────────────────────────────────────────────────────────────────────────
# Helper functions
# ──────────────────────────────────────────────────────────────────────────────

def read_lines_keepends(path: Path):
    """Return list of lines from file, preserving '\n'."""
    with path.open("r", encoding="utf-8") as fh:
        return fh.readlines()


# ──────────────────────────────────────────────────────────────────────────────
# Tests
# ──────────────────────────────────────────────────────────────────────────────

def test_db_directory_still_exists_and_writable():
    assert DB_DIR.exists(), f"Required directory {DB_DIR} no longer exists."
    assert DB_DIR.is_dir(), f"{DB_DIR} exists but is no longer a directory."
    assert os.access(DB_DIR, os.W_OK), f"Directory {DB_DIR} is no longer writable."


def test_original_log_file_unchanged():
    assert LOG_FILE.exists(), f"The original log file {LOG_FILE} is missing."
    current_lines = read_lines_keepends(LOG_FILE)
    assert current_lines == LOG_EXPECTED_LINES, (
        "The original slow_query.log file has been modified.\n"
        "It must remain unchanged after the task is completed."
    )


def test_frequency_file_content_exact():
    # 1. File existence + type
    assert FREQ_FILE.exists(), (
        "Expected output file slow_query_frequency.tsv does not exist "
        "at /home/user/db/slow_query_frequency.tsv."
    )
    assert FREQ_FILE.is_file(), (
        f"{FREQ_FILE} exists but is not a regular file."
    )

    # 2. Read whole file as bytes to verify trailing newline
    raw = FREQ_FILE.read_bytes()
    assert raw.endswith(b"\n"), (
        f"{FREQ_FILE} must end with a single newline character."
    )

    lines = raw.decode("utf-8").splitlines(keepends=True)

    # 3. Exact content
    assert lines == FREQ_EXPECTED_LINES, (
        "Contents of slow_query_frequency.tsv are incorrect.\n"
        "Differences may include counts, ordering, tab-separation, or trailing newlines."
    )

    # 4. Additional format sanity checks (redundant when exact match passes, but
    #    useful for clearer messages when it fails).
    for idx, line in enumerate(lines, start=1):
        # Each line must contain exactly one TAB
        tab_count = line.count("\t")
        assert tab_count == 1, (
            f"Line {idx} in {FREQ_FILE} must contain exactly one TAB "
            f"separator; found {tab_count}."
        )
        count_str, sql = line.rstrip("\n").split("\t", 1)

        # Count must be a non-negative integer without leading zeroes
        assert re.fullmatch(r"[1-9][0-9]*", count_str), (
            f"The occurrence count '{count_str}' on line {idx} is not a valid "
            "positive integer or contains leading zeros."
        )

    # 5. Verify sorting order (desc by count, asc by SQL for ties)
    counts = [int(l.split("\t", 1)[0]) for l in lines]
    sqls = [l.split("\t", 1)[1].rstrip("\n") for l in lines]

    # Check descending numeric order of counts
    assert counts == sorted(counts, reverse=True), (
        f"Counts in {FREQ_FILE} are not in descending numeric order: {counts}"
    )

    # For ties, SQL text must be in ascending ASCII order
    for i in range(1, len(lines)):
        if counts[i] == counts[i - 1]:
            assert sqls[i - 1] <= sqls[i], (
                f"Tie-breaking order incorrect between lines {i} and {i + 1} "
                f"in {FREQ_FILE}."
            )


def test_summary_file_content_exact_and_consistent():
    # 1. Existence + type
    assert SUMMARY_FILE.exists(), (
        "Expected output file slow_query_summary.log does not exist "
        "at /home/user/db/slow_query_summary.log."
    )
    assert SUMMARY_FILE.is_file(), (
        f"{SUMMARY_FILE} exists but is not a regular file."
    )

    # 2. Trailing newline & exact content
    raw = SUMMARY_FILE.read_bytes()
    assert raw.endswith(b"\n"), (
        f"{SUMMARY_FILE} must end with a single newline character."
    )

    lines = raw.decode("utf-8").splitlines(keepends=True)
    assert lines == SUMMARY_EXPECTED_LINES, (
        "Contents of slow_query_summary.log are incorrect.\n"
        "Ensure counts, SQL text, ordering and newlines exactly match the "
        "required specification."
    )

    # 3. Internal consistency cross-checked with original log + frequency file
    kv = dict(line.rstrip("\n").split("=", 1) for line in lines)

    # a) TOTAL_LINES must match original log length
    assert int(kv["TOTAL_LINES"]) == len(LOG_EXPECTED_LINES), (
        "TOTAL_LINES in summary does not match the number of lines in "
        "slow_query.log."
    )

    # b) TOTAL_UNIQUE_QUERIES must match number of distinct SQL statements
    unique_queries = len(set(LOG_EXPECTED_LINES))
    assert int(kv["TOTAL_UNIQUE_QUERIES"]) == unique_queries, (
        "TOTAL_UNIQUE_QUERIES in summary is incorrect."
    )

    # c) TOP_QUERY/TOP_QUERY_COUNT must match first row in frequency file
    top_count, top_query = FREQ_EXPECTED_LINES[0].rstrip("\n").split("\t", 1)
    assert kv["TOP_QUERY"] == top_query, (
        "TOP_QUERY in summary does not match the most frequent query "
        "in the frequency table."
    )
    assert kv["TOP_QUERY_COUNT"] == top_count, (
        "TOP_QUERY_COUNT in summary does not match the occurrence count "
        "in the frequency table."
    )