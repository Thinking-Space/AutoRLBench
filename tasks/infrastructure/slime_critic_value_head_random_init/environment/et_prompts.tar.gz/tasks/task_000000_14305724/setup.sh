#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


export LANG=C

export LC_ALL=C

apt-get update && \
    apt-get install -y --no-install-recommends python3-pip && \
    pip3 install --no-cache-dir pytest && \
    true

mkdir -p /home/user/db

cat > /home/user/db/slow_query.log <<'EOF'
SELECT * FROM orders WHERE status = 'pending';
SELECT id, name FROM customers WHERE country = 'US';
UPDATE inventory SET quantity = quantity - 1 WHERE product_id = 42;
SELECT * FROM orders WHERE status = 'pending';
SELECT * FROM orders WHERE status = 'pending';
UPDATE inventory SET quantity = quantity - 1 WHERE product_id = 42;
SELECT id, name FROM customers WHERE country = 'US';
DELETE FROM sessions WHERE last_active < NOW() - INTERVAL '30 days';
SELECT * FROM orders WHERE status = 'pending';
DELETE FROM sessions WHERE last_active < NOW() - INTERVAL '30 days';
SELECT * FROM orders WHERE status = 'pending';
SELECT id, name FROM customers WHERE country = 'US';
INSERT INTO audit_log (event, created_at) VALUES ('login', NOW());
SELECT * FROM orders WHERE status = 'pending';
EOF

chmod -R a+rw /home/user/db && \
    chmod 755 /home/user
