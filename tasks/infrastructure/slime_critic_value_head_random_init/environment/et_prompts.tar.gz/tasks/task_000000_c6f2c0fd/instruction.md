You are an integration-developer who wants to organise a tiny, *self-verifying* set of API test artefacts.  
Working only in the Linux terminal, produce the directory tree, files and log described below.  
The **automated checker will read the final files exactly as specified**, so pay close attention to names, paths, capitalisation and byte-counts.

1.  Create the directory  
    /home/user/api_tests/v1  
    with three sub-directories inside it called  
    requests, responses and logs

2.  Two sample request payloads are already present at  
    /home/user/sample_payloads/user_create.json  
    /home/user/sample_payloads/order_create.json  
    • Copy each of them into the new *requests* directory and, **while copying**, rename them to  
      request_user_create.json  
      request_order_create.json

3.  Inside the *responses* directory, create **two new placeholder files** named  
    response_user_create.json  
    response_order_create.json  
    Each placeholder file must contain the exact three-byte string "{}\<newline\>" (an opening brace, a closing brace, then a single line-feed, ASCII 0x0a).

4.  Produce a manifest called  
    /home/user/api_tests/v1/logs/manifest.csv  
    The file must be plain text, UNIX line endings, containing **exactly five lines** in the following comma-separated format:

        <relative_path_from_v1>,<size_in_bytes>

    • The first four lines list every file that now resides **under** api_tests/v1, in any order, **but the path must be *relative* to the v1 directory**.  
      Example (do not copy verbatim):  
      requests/request_xyz.json,123  
    • The fifth and last line must be the literal summary:  
      TOTAL,4

      where the number 4 is the count of listed files.

    The byte-sizes that the checker expects for this task are:
    • 33 bytes for request_user_create.json  
    • 48 bytes for request_order_create.json  
    • 3 bytes  for each of the two response_*.json placeholders

When you are finished:
• the directory /home/user/api_tests/v1 must exist with the exact files and sizes above  
• manifest.csv must exist with the correct five lines and numbers  
• no extra files should appear anywhere under /home/user/api_tests

Do NOT write anything outside the paths mentioned.