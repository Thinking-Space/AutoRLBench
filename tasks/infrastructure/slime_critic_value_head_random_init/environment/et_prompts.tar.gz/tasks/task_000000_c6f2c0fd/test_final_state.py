# test_final_state.py
#
# Pytest module that validates the *final* operating-system / container state
# after the student has executed the shell commands described in the task.
#
# The checks performed here mirror the “Expected final state” section of the
# task description.  They ensure:
#
#   • The directory /home/user/api_tests/v1 exists with the exact three
#     sub-directories requests/, responses/ and logs/.
#   • Exactly four files live beneath requests/ and responses/, with the
#     correct names, byte-sizes and byte-for-byte contents.
#   • A single manifest file exists at logs/manifest.csv whose five lines are
#     correct, reference the right byte-sizes and list exactly the four data
#     files (order of the first four lines may vary, but the last line must be
#     the literal 'TOTAL,4').
#   • No stray files or directories are present anywhere under
#     /home/user/api_tests.
#
# Only the Python standard library and pytest are used.

import os
import stat
import pytest

# --------------------------------------------------------------------------- #
# CONSTANT PATHS
# --------------------------------------------------------------------------- #
API_ROOT_DIR = "/home/user/api_tests"
V1_DIR = os.path.join(API_ROOT_DIR, "v1")
REQUESTS_DIR = os.path.join(V1_DIR, "requests")
RESPONSES_DIR = os.path.join(V1_DIR, "responses")
LOGS_DIR = os.path.join(V1_DIR, "logs")
MANIFEST_PATH = os.path.join(LOGS_DIR, "manifest.csv")

# Expected filenames (no additional files are allowed)
REQUEST_FILES = {
    "request_user_create.json": 33,
    "request_order_create.json": 48,
}
RESPONSE_FILES = {
    "response_user_create.json": 3,
    "response_order_create.json": 3,
}

# Paths to the *truth* request source files (used for byte-for-byte comparison)
SAMPLE_DIR = "/home/user/sample_payloads"
SAMPLE_FILES = {
    "request_user_create.json": os.path.join(SAMPLE_DIR, "user_create.json"),
    "request_order_create.json": os.path.join(SAMPLE_DIR, "order_create.json"),
}


# --------------------------------------------------------------------------- #
# UTILITY HELPERS
# --------------------------------------------------------------------------- #
def _human(size: int) -> str:
    """Return human-readable byte size."""
    return f"{size} byte{'s' if size != 1 else ''}"


def _read_bytes(path: str) -> bytes:
    with open(path, "rb") as fp:
        return fp.read()


def _assert_regular_file(path: str, *, expected_size: int) -> None:
    """Assert that `path` exists, is a regular file and has `expected_size`."""
    assert os.path.exists(path), f"Missing file: {path}"
    st = os.stat(path)
    assert stat.S_ISREG(st.st_mode), f"{path} exists but is not a regular file."
    actual_size = st.st_size
    assert (
        actual_size == expected_size
    ), f"{path} is {_human(actual_size)}, expected {_human(expected_size)}."


# --------------------------------------------------------------------------- #
# TESTS
# --------------------------------------------------------------------------- #
def test_directory_structure_exact():
    """The v1 directory must contain exactly the three required sub-directories."""
    assert os.path.isdir(V1_DIR), f"Directory {V1_DIR!r} is missing."
    entries = set(os.listdir(V1_DIR))
    expected_dirs = {"requests", "responses", "logs"}
    assert (
        entries == expected_dirs
    ), (
        f"Contents of {V1_DIR} are {sorted(entries)}, "
        f"but expected exactly {sorted(expected_dirs)}."
    )

    # Ensure each required entry is indeed a directory
    for sub in expected_dirs:
        p = os.path.join(V1_DIR, sub)
        assert os.path.isdir(p), f"Expected {p} to be a directory."


@pytest.mark.parametrize("filename,expected_size", REQUEST_FILES.items())
def test_request_files_exist_and_match_sample(filename, expected_size):
    """Each request file must exist, have the right size and match the source payload."""
    target_path = os.path.join(REQUESTS_DIR, filename)
    _assert_regular_file(target_path, expected_size=expected_size)

    # Ensure no extra files inside requests/
    requests_contents = set(os.listdir(REQUESTS_DIR))
    assert (
        requests_contents == set(REQUEST_FILES)
    ), (
        f"requests/ directory contains unexpected files: {sorted(requests_contents)}. "
        f"Expected exactly {sorted(REQUEST_FILES)}."
    )

    # Compare byte-for-byte with the sample payload
    sample_path = SAMPLE_FILES[filename]
    assert os.path.exists(
        sample_path
    ), f"Sample payload {sample_path!r} is missing (should have been provided)."

    assert (
        _read_bytes(target_path) == _read_bytes(sample_path)
    ), f"Content of {target_path} does not match the source sample {sample_path}."


@pytest.mark.parametrize("filename,expected_size", RESPONSE_FILES.items())
def test_response_placeholder_files(filename, expected_size):
    """Each response placeholder must contain exactly '{}\\n' (3 bytes)."""
    target_path = os.path.join(RESPONSES_DIR, filename)
    _assert_regular_file(target_path, expected_size=expected_size)

    responses_contents = set(os.listdir(RESPONSES_DIR))
    assert (
        responses_contents == set(RESPONSE_FILES)
    ), (
        f"responses/ directory contains unexpected files: {sorted(responses_contents)}. "
        f"Expected exactly {sorted(RESPONSE_FILES)}."
    )

    content = _read_bytes(target_path)
    assert (
        content == b"{}\n"
    ), f"{filename} should contain the exact bytes '{{}}\\n', but it contains: {content!r}"


def test_logs_directory_and_manifest():
    """logs/ must contain exactly manifest.csv with the correct five lines."""
    assert os.path.isdir(LOGS_DIR), f"Directory {LOGS_DIR!r} is missing."

    log_entries = os.listdir(LOGS_DIR)
    assert log_entries == ["manifest.csv"], (
        f"logs/ directory should contain only 'manifest.csv', "
        f"but contains: {log_entries}"
    )

    _assert_regular_file(MANIFEST_PATH, expected_size=os.stat(MANIFEST_PATH).st_size)

    # Read manifest and split into lines (keeping UNIX newline semantics)
    with open(MANIFEST_PATH, "r", newline="\n") as fp:
        manifest_text = fp.read()

    assert "\r" not in manifest_text, "manifest.csv must use UNIX LF line endings only."

    lines = manifest_text.split("\n")
    if lines and lines[-1] == "":
        # A trailing newline will produce an empty string after split; remove it.
        lines = lines[:-1]

    assert len(lines) == 5, (
        f"manifest.csv should contain exactly 5 non-empty lines, but contains {len(lines)}."
    )

    *file_lines, total_line = lines

    # Build expected path->size map (relative paths)
    expected_map = {
        f"requests/{name}": size for name, size in REQUEST_FILES.items()
    }
    expected_map.update(
        {f"responses/{name}": size for name, size in RESPONSE_FILES.items()}
    )

    # --- Validate the first four lines ------------------------------------------------
    seen_paths = set()
    for line in file_lines:
        parts = line.split(",")
        assert len(parts) == 2, f"Line {line!r} in manifest.csv is not comma-separated."

        rel_path, size_str = parts
        assert not rel_path.startswith(
            "/"
        ), f"Path {rel_path!r} in manifest.csv must be relative, not absolute."
        assert rel_path in expected_map, (
            f"Unexpected path {rel_path!r} in manifest.csv. "
            f"Expected one of: {sorted(expected_map)}"
        )
        assert (
            rel_path not in seen_paths
        ), f"Duplicate entry {rel_path!r} found in manifest.csv."
        seen_paths.add(rel_path)

        # Numeric size
        try:
            size_int = int(size_str)
        except ValueError:  # pragma: no cover
            raise AssertionError(f"Byte size {size_str!r} for {rel_path!r} is not an integer.")

        assert (
            size_int == expected_map[rel_path]
        ), f"Incorrect byte size for {rel_path!r}: got {size_int}, expected {expected_map[rel_path]}."

    assert (
        seen_paths == set(expected_map)
    ), "manifest.csv does not list exactly the expected four file paths."

    # --- Validate TOTAL line ---------------------------------------------------------
    assert (
        total_line == "TOTAL,4"
    ), f"The last line of manifest.csv must be 'TOTAL,4', found {total_line!r}."


def test_no_stray_files_anywhere_under_api_tests():
    """Walk /home/user/api_tests ensuring only the expected files & dirs exist."""
    expected_files = {
        os.path.join(REQUESTS_DIR, name) for name in REQUEST_FILES
    } | {
        os.path.join(RESPONSES_DIR, name) for name in RESPONSE_FILES
    } | {MANIFEST_PATH}

    expected_dirs = {
        API_ROOT_DIR,
        V1_DIR,
        REQUESTS_DIR,
        RESPONSES_DIR,
        LOGS_DIR,
    }

    found_files = set()
    found_dirs = set()

    for dirpath, dirnames, filenames in os.walk(API_ROOT_DIR):
        found_dirs.add(dirpath)
        for fname in filenames:
            found_files.add(os.path.join(dirpath, fname))

    # Directories must match exactly (ignoring ordering)
    assert (
        found_dirs == expected_dirs
    ), (
        "Directory tree under /home/user/api_tests is incorrect.\n"
        f"Expected directories:\n  {sorted(expected_dirs)}\n"
        f"Found directories:\n  {sorted(found_dirs)}"
    )

    # Files must match exactly
    assert (
        found_files == expected_files
    ), (
        "Unexpected files found under /home/user/api_tests (or expected files missing).\n"
        f"Expected files:\n  {sorted(expected_files)}\n"
        f"Found files:\n  {sorted(found_files)}"
    )