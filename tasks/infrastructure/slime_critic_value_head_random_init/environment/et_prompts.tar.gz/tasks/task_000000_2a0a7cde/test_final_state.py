# test_final_state.py
#
# Pytest suite that validates the **final** filesystem state
# after the “ISO-8859-1 ➜ UTF-8 conversion” exercise has been
# completed by the student.
#
# What we assert:
#   • /home/user/project/docs still exists and still contains
#     exactly the three original *.txt files.
#   • Every one of those files is now valid UTF-8, *not* the
#     original ISO-8859-1, and their textual content is intact.
#   • /home/user/project/encoding_conversion.log exists and
#     follows the specification precisely.
#   • No stray *.txt files were created in the docs directory
#     (or its sub-directories) and no extra columns / lines
#     appear in the log.
#
# Only Python stdlib + pytest are used.

import os
import codecs
from pathlib import Path
import pytest

DOCS_DIR = Path("/home/user/project/docs")
LOG_FILE = Path("/home/user/project/encoding_conversion.log")

EXPECTED_FILES = {
    "changelog.txt",
    "license.txt",
    "readme.txt",
}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _list_txt_files(directory: Path, recursive: bool = False):
    """
    Return a set of Path objects for *.txt files found in `directory`.
    If `recursive` is True we descend sub-directories as well.
    """
    if recursive:
        return {p for p in directory.rglob("*.txt") if p.is_file()}
    else:
        return {p for p in directory.glob("*.txt") if p.is_file()}


def _read_binary(path: Path) -> bytes:
    """Read a file in binary mode and return its raw bytes."""
    with path.open("rb") as fh:
        return fh.read()


# ---------------------------------------------------------------------------
# 1.  Directory / file presence checks
# ---------------------------------------------------------------------------

def test_docs_directory_still_exists_and_is_dir():
    assert DOCS_DIR.exists(), (
        f"Expected directory {DOCS_DIR} to still exist, but it is missing."
    )
    assert DOCS_DIR.is_dir(), (
        f"{DOCS_DIR} exists but is no longer a directory."
    )


def test_docs_contains_exact_original_txt_files_only():
    direct_txt_files = _list_txt_files(DOCS_DIR, recursive=False)
    direct_names = {p.name for p in direct_txt_files}

    # Presence of the originals
    missing = EXPECTED_FILES - direct_names
    assert not missing, (
        "These required .txt files are missing after the conversion: "
        f"{', '.join(sorted(missing))}"
    )

    # No extra .txt files directly inside docs/
    extras = direct_names - EXPECTED_FILES
    assert not extras, (
        "Unexpected .txt files have appeared directly in "
        f"{DOCS_DIR}: {', '.join(sorted(extras))}"
    )

    # No extra .txt files in sub-directories either
    recursive_txt_files = _list_txt_files(DOCS_DIR, recursive=True)
    recursive_extras = {p.name for p in recursive_txt_files} - EXPECTED_FILES
    assert not recursive_extras, (
        "Unexpected .txt files found inside sub-directories of "
        f"{DOCS_DIR}: {', '.join(sorted(recursive_extras))}"
    )

# ---------------------------------------------------------------------------
# 2.  Encoding / content checks for each file
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("filename", sorted(EXPECTED_FILES))
def test_each_file_is_now_utf8_and_content_preserved(filename):
    """
    For every legacy document we assert that:
      • The raw bytes form a *valid* UTF-8 byte-stream.
      • Decoding with UTF-8 succeeds.
      • The decoded string contains at least one non-ASCII character
        (so we know we are truly dealing with multibyte UTF-8, not
        plain ASCII that could masquerade as ISO-8859-1).
      • Re-encoding the decoded string with UTF-8 yields *exactly*
        the same byte stream (round-trip integrity).
    """
    file_path = DOCS_DIR / filename
    assert file_path.exists(), f"File {file_path} is unexpectedly missing."

    raw = _read_binary(file_path)

    # 1. Must decode cleanly as UTF-8
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        pytest.fail(
            f"{file_path} must be UTF-8 now, but decoding failed: {exc}"
        )

    # 2. The text should still include at least one non-ASCII character
    #    (accent, ellipsis, en-dash, © etc.) that *must* occupy >1 byte
    #    in UTF-8.  This guards against the file still being ISO-8859-1
    #    by accident.
    assert any(ord(ch) > 127 for ch in text), (
        f"{file_path} contains no non-ASCII characters after conversion; "
        "unable to confirm multibyte UTF-8 sequences."
    )

    # 3. Round-trip integrity:  text → UTF-8 bytes must equal original bytes
    roundtrip = text.encode("utf-8")
    assert raw == roundtrip, (
        f"The textual content of {file_path} changed during conversion "
        "(round-trip UTF-8 encode/decode mismatch)."
    )

# ---------------------------------------------------------------------------
# 3.  Verification log checks
# ---------------------------------------------------------------------------

def test_log_file_exists_and_is_regular_file():
    assert LOG_FILE.exists(), (
        f"The verification log {LOG_FILE} was not created."
    )
    assert LOG_FILE.is_file(), (
        f"{LOG_FILE} exists but is not a regular file."
    )


def test_log_file_has_unix_line_endings_only():
    """
    The specification mandates plain LF (\\n) line endings.
    We therefore assert that:
        • There are no CR characters (0x0D) in the file.
    """
    raw = _read_binary(LOG_FILE)
    assert b"\r" not in raw, (
        "The verification log must use Unix (LF) line endings; "
        "found carriage-return characters (CR / 0x0D)."
    )


def test_log_file_exact_content_and_format():
    """
    The log file must follow the exact CSV schema:
        filename,previous_encoding,new_encoding
        <basename>,ISO-8859-1,UTF-8
        …
    Lines must be sorted alphabetically by filename with no
    extra whitespace or columns.
    """
    lines = LOG_FILE.read_text(encoding="utf-8").split("\n")

    # If the file ends with a trailing newline, the last element will be ''
    # Remove the trailing empty element, but keep internal empty lines if any.
    if lines and lines[-1] == "":
        lines = lines[:-1]

    # ---------------- Header line ----------------
    assert lines, "The verification log is empty."
    header = lines[0]
    expected_header = "filename,previous_encoding,new_encoding"
    assert header == expected_header, (
        f"Incorrect header in the verification log.\n"
        f"Expected: {expected_header!r}\nGot     : {header!r}"
    )

    data_lines = lines[1:]
    assert data_lines, "The verification log contains no data rows."

    # ---------------- Number of lines ----------------
    assert len(data_lines) == len(EXPECTED_FILES), (
        f"The verification log should list exactly {len(EXPECTED_FILES)} files "
        f"but contains {len(data_lines)} data rows."
    )

    # ---------------- Parse and validate each row ----------------
    parsed_files = []
    for i, row in enumerate(data_lines, start=2):  # start=2 => first data line is line 2
        parts = row.split(",")
        assert len(parts) == 3, (
            f"Line {i} in the verification log does not have exactly three "
            f"comma-separated columns: {row!r}"
        )
        fname, prev_enc, new_enc = parts
        assert fname, f"Line {i}: filename column is empty."
        assert prev_enc == "ISO-8859-1", (
            f"Line {i}: previous_encoding should be 'ISO-8859-1' "
            f"but is {prev_enc!r}."
        )
        assert new_enc == "UTF-8", (
            f"Line {i}: new_encoding should be 'UTF-8' "
            f"but is {new_enc!r}."
        )
        parsed_files.append(fname)

    # ---------------- Filenames listed ----------------
    missing_in_log = EXPECTED_FILES - set(parsed_files)
    assert not missing_in_log, (
        "The following converted files are missing from the verification log: "
        f"{', '.join(sorted(missing_in_log))}"
    )

    extras_in_log = set(parsed_files) - EXPECTED_FILES
    assert not extras_in_log, (
        "The verification log lists files that should not be there: "
        f"{', '.join(sorted(extras_in_log))}"
    )

    # ---------------- Alphabetical order ----------------
    sorted_files = sorted(parsed_files)
    assert parsed_files == sorted_files, (
        "Data rows in the verification log are not sorted alphabetically by "
        "filename."
    )

# ---------------------------------------------------------------------------
# 4.  Sanity check: no additional log files created
# ---------------------------------------------------------------------------

def test_no_unexpected_log_files_created():
    """
    The specification forbids creating additional files outside the
    designated log.  We allow other *directories* or NON-log files
    but assert that no extra *.log files exist inside /home/user/project.
    """
    project_dir = Path("/home/user/project")
    extra_logs = [
        p for p in project_dir.glob("*.log")
        if p.is_file() and p != LOG_FILE
    ]
    assert not extra_logs, (
        "Unexpected *.log files were created in /home/user/project: "
        f"{', '.join(str(p) for p in extra_logs)}"
    )