#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y \
        python3 \
        python3-pip \
        locales && \
    locale-gen en_US.UTF-8 && \
    pip3 install --no-cache-dir pytest && \
    mkdir -p /home/user/project/docs

cat > /tmp/readme_utf8.txt <<'EOF'
Curaçao project documentation
=============================
Version 1.0 - août 2023
...
EOF

cat > /tmp/changelog_utf8.txt <<'EOF'
Changelog
---------
* 2023-08-15 : Première version publiée
* 2023-09-01 : Corrections mineures
EOF

cat > /tmp/license_utf8.txt <<'EOF'
Licence MIT
------------
Copyright © 2023 ACME Corp.
Permission est accordée, gratuitement, à toute personne obtenant une copie...
EOF

for name in readme changelog license; do \
        iconv -f UTF-8 -t ISO-8859-1 /tmp/${name}_utf8.txt -o /home/user/project/docs/${name}.txt; \
    done && \
    rm /tmp/*_utf8.txt && \
    chmod -R 755 /home/user && \
    find /home/user -type f -exec chmod 644 {} \; && \
    apt-get clean && \
    true

export LC_ALL=en_US.UTF-8

export LANG=en_US.UTF-8
