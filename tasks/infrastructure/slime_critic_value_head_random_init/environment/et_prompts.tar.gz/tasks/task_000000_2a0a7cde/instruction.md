A developer just inherited a legacy project whose documentation files are still stored in the single-byte ISO-8859-1 encoding.
Your job is to modernise the project by converting every text file under

    /home/user/project/docs

from ISO-8859-1 to UTF-8 and to record what was done.

Detailed requirements that **the automated grader will check**:

**1. Encoding conversion**
   *   Only files whose names end in “.txt” and are **directly** inside /home/user/project/docs (no sub-directories) must be converted.
   *   The conversion must be in-place: after you finish, the original file paths must still exist, but their byte-stream encoding must be UTF-8.
   *   The textual content must stay identical (only the encoding changes).

**2. Verification log**
   *   After all conversions create the log file
         `/home/user/project/encoding_conversion.log`
   *   The log is a single, plain-text CSV file with **Unix line-feeds (LF)**.
   *   Its exact format:
         ```
         filename,previous_encoding,new_encoding
         <file1>,ISO-8859-1,UTF-8
         <file2>,ISO-8859-1,UTF-8
         …
         ```
       a) The first line is the header exactly as written above.
       b) Each subsequent line lists one converted file.
       c) “filename” means *just* the basename (e.g. “readme.txt”), **not** the full path.
       d) Lines must be sorted alphabetically by filename.
       e) There must be **no extra columns, no extra whitespace, and no trailing comma** on any line.

**3. What the grader will test**
   *   Every “.txt” file that originally existed in /home/user/project/docs is now UTF-8 encoded (the grader will inspect the MIME type or run “file -bi”).
   *   The log file exists in exactly the path shown and matches the format above, listing each converted file once and only once.

Perform the task entirely from the command line; do not delete or rename any files and do not create additional files outside the specified log.
When you are finished, the developer should be able to open everything in any modern editor without garbled characters and see a perfectly formatted conversion log.