You are a technical writer who keeps all project-related material under `/home/user/docs`.
For an upcoming documentation sprint you need a fresh, isolated Python setup located at
`/home/user/docs/venv`.

After creating the virtual environment, generate a tiny status file that signals success.

**Precise requirements the automated checker will verify**
*   A directory named `/home/user/docs/venv` must exist and have been created by the `python3 -m venv …` command (so it will contain the usual sub-directories such as `bin`, `lib`, etc., and the file `pyvenv.cfg`).
*   A text file `/home/user/docs/venv_status.log` must exist.
    *   The file must contain exactly one line with the single word
        ```
        READY
        ```
        followed by a single UNIX newline character (ASCII 0x0A).
    *   There must be no extra spaces, blank lines, or carriage returns.

**Important notes for the assistant**
*   Do not use sudo or any privileged operation.
*   Do not install external packages; only create the venv.
*   The checker will fail if `/home/user/docs/venv_status.log` contains anything other than the exact sequence “READY\n”.
*   The checker will also confirm that `/home/user/docs/venv/bin/activate` exists, proving the virtual environment was created correctly.