You are the system administrator overseeing a small group of “local-only” software bundles that live under
/home/user/localpkgs.  
Each bundle is represented by a directory whose name is the package name, and which
contains exactly one file called version.txt holding the current version string on a single line.

Initial conditions that you can rely on
• /home/user/localpkgs exists.  
• Inside that directory there are two sub-directories, bash and coreutils.  
  – /home/user/localpkgs/bash/version.txt currently contains 5.1.16  
  – /home/user/localpkgs/coreutils/version.txt currently contains 8.32  

Make a new directory called /home/user/package_audit.  

Produce an alphabetical inventory of every package under /home/user/localpkgs by reading the individual
version.txt files.  
Save the list to /home/user/package_audit/local_inventory.log.  
Format requirements (exactly, no extra spaces):  
• One package per line,  
• Package name followed by a single space, followed by the version string,  
• Lines sorted in ascending (A→Z) alphabetical order by package name.

Update the version of the package coreutils by replacing the single line in
/home/user/localpkgs/coreutils/version.txt with the new version string 9.3  
(do not add extra blank lines).  
Leave the bash package untouched.

Inside /home/user/package_audit create a file called changes.log.  
Write EXACTLY two lines to that file, in this order:  
   before: coreutils 8.32  
   after:  coreutils 9.3  
(Note the two spaces that follow the colon on the second line so that "after:" is aligned
under "before:". Everything else is single-spaced. No blank lines before or after.)

Verification expectations
• /home/user/package_audit/local_inventory.log must now list:
      bash 5.1.16
      coreutils 9.3
  in that exact order.  
• /home/user/package_audit/changes.log must contain the two precisely formatted lines shown above.  
• /home/user/localpkgs/coreutils/version.txt must now contain only the text 9.3 and a trailing newline.  
• /home/user/localpkgs/bash/version.txt must remain unchanged.

Be sure the task completes entirely from an unprivileged user shell; no sudo is allowed.  
Any temporary files you create outside /home/user/package_audit should be removed before finishing.  
Do not echo the commands you used—only create/modify the requested files.