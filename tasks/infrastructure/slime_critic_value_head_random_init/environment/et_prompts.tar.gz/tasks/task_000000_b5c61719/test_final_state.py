# test_final_state.py
#
# Pytest suite that validates the **final** filesystem state
# after the student has completed the “local-only” package bundles task.

import os
from pathlib import Path
import pytest


HOME = Path("/home/user")
LOCALPKGS = HOME / "localpkgs"
AUDIT_DIR = HOME / "package_audit"

# ---------- Helpers ---------- #

def read_file(path: Path) -> str:
    """Return entire file contents *as text*; fail early if file is missing."""
    assert path.exists(), f"Expected file {path} is missing."
    assert path.is_file(), f"{path} exists but is not a regular file."
    return path.read_text(encoding="utf-8")


# ---------- Tests for /home/user/localpkgs ---------- #

def test_package_directories_still_present_and_intact():
    """
    Both package directories must still exist and still contain exactly one file
    named 'version.txt'.
    """
    for pkg_name in ("bash", "coreutils"):
        pkg_dir = LOCALPKGS / pkg_name
        assert pkg_dir.exists(), f"Package directory {pkg_dir} is missing."
        assert pkg_dir.is_dir(), f"{pkg_dir} exists but is not a directory."
        entries = [e for e in os.listdir(pkg_dir) if not e.startswith(".")]
        assert entries == ["version.txt"], (
            f"{pkg_dir} must contain ONLY 'version.txt' but has: {entries}"
        )

def test_version_files_have_correct_contents():
    """
    Validate the exact contents (including trailing newline) of version.txt
    for each package.
    """
    expected_versions = {
        "bash": "5.1.16\n",
        "coreutils": "9.3\n",
    }
    for pkg, expected_content in expected_versions.items():
        version_file = LOCALPKGS / pkg / "version.txt"
        content = read_file(version_file)
        assert content == expected_content, (
            f"Incorrect contents in {version_file}.\n"
            f"Expected: {repr(expected_content)}\n"
            f"Found   : {repr(content)}"
        )


# ---------- Tests for /home/user/package_audit ---------- #

def test_audit_directory_exists():
    """The audit directory must exist and be a directory."""
    assert AUDIT_DIR.exists(), f"Audit directory {AUDIT_DIR} is missing."
    assert AUDIT_DIR.is_dir(), f"{AUDIT_DIR} exists but is not a directory."


@pytest.fixture(scope="session")
def inventory_content():
    path = AUDIT_DIR / "local_inventory.log"
    return read_file(path)


@pytest.fixture(scope="session")
def changes_content():
    path = AUDIT_DIR / "changes.log"
    return read_file(path)


# --- local_inventory.log --- #

def test_inventory_file_exact_contents(inventory_content):
    """
    /home/user/package_audit/local_inventory.log must list all packages
    alphabetically with correct versions, one per line, and nothing else.
    """
    expected = "bash 5.1.16\ncoreutils 9.3\n"
    assert inventory_content == expected, (
        "Incorrect content in local_inventory.log.\n"
        f"Expected:\n{repr(expected)}\nFound:\n{repr(inventory_content)}"
    )

def test_inventory_sorted_alphabetically(inventory_content):
    """
    Redundant safety check: lines must already be sorted alphabetically.
    Ensures future additions remain sorted.
    """
    lines = inventory_content.rstrip("\n").split("\n")
    sorted_lines = sorted(lines, key=lambda l: l.split()[0])
    assert lines == sorted_lines, (
        "Lines in local_inventory.log are not sorted alphabetically by package name.\n"
        f"Lines : {lines}\nSorted: {sorted_lines}"
    )


# --- changes.log --- #

def test_changes_log_exact_contents(changes_content):
    """
    /home/user/package_audit/changes.log must contain exactly the two required
    lines, including the alignment (two spaces after the colon on 'after:').
    """
    expected = "before: coreutils 8.32\nafter:  coreutils 9.3\n"
    assert changes_content == expected, (
        "Incorrect content in changes.log.\n"
        f"Expected:\n{repr(expected)}\nFound:\n{repr(changes_content)}"
    )

def test_changes_log_line_count(changes_content):
    """Ensure no extra or missing lines exist in changes.log."""
    lines = changes_content.splitlines(keepends=False)
    assert len(lines) == 2, (
        "changes.log must contain exactly two lines.\n"
        f"Found {len(lines)} line(s): {lines}"
    )