# test_final_state.py
#
# Pytest suite that validates the **final** state of the OS / filesystem
# for the “IoT logs” exercise **after** the student has completed the task.
#
# What we verify:
#   • /home/user/iot_logs/error_summary.tsv exists and is a regular file
#   • the file is world-readable (0644) so automated tooling can read it
#   • the file’s contents follow the exact specification:
#       - first line is the fixed header:  "ErrorCode<TAB>Count"
#       - subsequent lines list each distinct error-code exactly once
#       - counts match what is actually found in the three *.log files
#       - rows are ordered by descending count, then ascending error-code
#       - the file ends with exactly one trailing newline, and no extra
#         blank lines, columns, or stray whitespace
#
# The tests intentionally recompute the expected counts *from the log files*
# so that they stay correct even if the harness ever tweaks the fixtures.

import os
import stat
import re
from pathlib import Path
from collections import Counter

import pytest

IOT_LOG_DIR = Path("/home/user/iot_logs")
SUMMARY_PATH = IOT_LOG_DIR / "error_summary.tsv"
LOG_GLOB = "*.log"

###############################################################################
# Helper functions
###############################################################################

def _extract_error_codes_from_line(line: str):
    """
    Given a single line, return a list containing the error-code (e.g. 'E105')
    if and only if the line contains the literal string 'ERROR'.  Otherwise
    return an empty list.
    """
    if "ERROR" not in line:
        return []
    match = re.search(r"\bE\d+\b", line)
    return [match.group(0)] if match else []


def _aggregate_error_counts():
    """
    Scan every *.log file under /home/user/iot_logs/ and build a Counter
    mapping error-code -> occurrence count.
    """
    counts: Counter[str] = Counter()
    for log_path in IOT_LOG_DIR.glob(LOG_GLOB):
        with open(log_path, "r", encoding="utf-8") as fh:
            for line in fh:
                counts.update(_extract_error_codes_from_line(line))
    return counts


def _expected_sorted_items(counts: Counter):
    """
    Return a list of (error_code, count) tuples sorted according to the spec:
        - primary: descending count
        - tie-break: ascending lexicographical error-code
    """
    return sorted(
        counts.items(),
        key=lambda kv: (-kv[1], kv[0])
    )

###############################################################################
# Tests
###############################################################################

def test_summary_file_exists_and_is_regular():
    assert SUMMARY_PATH.exists(), (
        f"Expected summary file {SUMMARY_PATH} does not exist."
    )
    assert SUMMARY_PATH.is_file(), (
        f"{SUMMARY_PATH} exists but is not a regular file."
    )


def test_summary_file_permissions():
    mode = stat.S_IMODE(os.stat(SUMMARY_PATH).st_mode)
    expected_mode = 0o644
    assert mode == expected_mode, (
        f"{SUMMARY_PATH} has permissions {oct(mode)}, "
        f"expected {oct(expected_mode)} (rw-r--r--)."
    )


@pytest.fixture(scope="module")
def summary_lines():
    """
    Read the summary file once and return its lines (without trailing newlines).
    Also verify that the file ends with exactly one final newline and no extra
    blank lines.
    """
    with open(SUMMARY_PATH, "rb") as fh:
        data = fh.read()

    # Must end with exactly one trailing newline byte
    assert data.endswith(b"\n"), (
        f"{SUMMARY_PATH} must end with a single trailing newline."
    )
    assert not data.endswith(b"\n\n"), (
        f"{SUMMARY_PATH} contains extra blank lines at the end."
    )

    text = data.decode("utf-8")
    return text.splitlines()


def test_header_line(summary_lines):
    assert summary_lines, f"{SUMMARY_PATH} is empty."
    expected_header = "ErrorCode\tCount"
    assert summary_lines[0] == expected_header, (
        f"First line of {SUMMARY_PATH} is incorrect.\n"
        f"  Expected: {expected_header!r}\n"
        f"  Found:    {summary_lines[0]!r}"
    )


def test_body_lines_format_and_content(summary_lines):
    body = summary_lines[1:]  # exclude header

    # Re-compute expected counts from the source log files
    expected_counts = _aggregate_error_counts()
    expected_items = _expected_sorted_items(expected_counts)

    # --- Line count ----------------------------------------------------------------
    assert len(body) == len(expected_items), (
        f"{SUMMARY_PATH} should contain {len(expected_items)} data line(s) "
        f"but has {len(body)}."
    )

    # --- Validate each line --------------------------------------------------------
    seen_codes = set()
    for idx, line in enumerate(body):
        parts = line.split("\t")
        assert len(parts) == 2, (
            f"Line {idx + 2} of {SUMMARY_PATH} ('{line}') does not have exactly "
            f"two tab-separated fields."
        )
        code, count_str = parts

        # Non-empty, uppercase 'E' followed by digits
        assert re.fullmatch(r"E\d+", code), (
            f"Invalid error-code '{code}' in line {idx + 2} of {SUMMARY_PATH}."
        )

        # Count must be an integer
        assert count_str.isdigit(), (
            f"Count '{count_str}' in line {idx + 2} of {SUMMARY_PATH} "
            f"is not a valid non-negative integer."
        )
        count_int = int(count_str)

        # Check against expected data
        expected_code, expected_count = expected_items[idx]
        assert code == expected_code, (
            f"Row ordering error in {SUMMARY_PATH}: expected error-code "
            f"'{expected_code}' in line {idx + 2}, found '{code}'."
        )
        assert count_int == expected_count, (
            f"Incorrect count for error-code '{code}' in line {idx + 2}: "
            f"expected {expected_count}, found {count_int}."
        )

        # Duplicate detection (defensive)
        assert code not in seen_codes, (
            f"Duplicate entry for error-code '{code}' in {SUMMARY_PATH}."
        )
        seen_codes.add(code)