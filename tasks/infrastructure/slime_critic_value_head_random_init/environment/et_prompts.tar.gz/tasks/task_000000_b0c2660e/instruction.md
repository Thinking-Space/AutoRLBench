You are an edge-computing engineer who has just collected diagnostic logs from three IoT devices.
The logs are already copied into the directory
`/home/user/iot_logs/`
as the files
`device01.log`
`device02.log`
`device03.log`

Your task is to:
- Scan every “*.log” file in `/home/user/iot_logs` for lines that contain the string “ERROR”.
- From each matching line, extract the third white-space-separated field (this field is the error-code and always starts with an uppercase “E” followed by digits, e.g. E105).
- Count how many times each distinct error-code appears across *all* log files.
- Create a new tab-separated summary file at
`/home/user/iot_logs/error_summary.tsv`

The file **must** follow the exact format below so automated grading can validate it:

*   The very first line is a header and must read exactly (case-sensitive):
`ErrorCode<TAB>Count`
*   Each subsequent line contains one distinct error-code, followed by a tab character, followed by its total count.
*   Sort the lines primarily by descending count and, in the case of a tie, by ascending (lexicographical) error-code.
*   Do not include any extra columns, spaces, or commentary. End the file with a single trailing newline.

Example layout (for illustration only – real numbers come from the actual log contents):

    ErrorCode<TAB>Count
    E999<TAB>5
    E101<TAB>3
    E050<TAB>1

When you have finished, you can print the contents of `/home/user/iot_logs/error_summary.tsv` to the console so I can quickly verify it.