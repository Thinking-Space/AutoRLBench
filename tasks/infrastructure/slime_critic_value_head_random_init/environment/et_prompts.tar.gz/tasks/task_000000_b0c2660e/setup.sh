#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


apt-get update -y && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3 python3-pip ca-certificates

pip3 install --no-cache-dir pytest

mkdir -p /home/user/iot_logs

cat <<'EOF' > /home/user/iot_logs/device01.log
[2023-07-20 12:00:00] INFO  Sensor reading: 23.4
[2023-07-20 12:01:00] ERROR SENSOR_TIMEOUT E105 Connection lost
[2023-07-20 12:02:00] WARN  Retry attempt
[2023-07-20 12:03:00] ERROR LOW_BATTERY E201 Battery level 5%
[2023-07-20 12:04:00] INFO  Sensor reading: 24.1
EOF

cat <<'EOF' > /home/user/iot_logs/device02.log
[2023-07-20 12:10:00] INFO  Boot
[2023-07-20 12:11:00] ERROR SENSOR_TIMEOUT E105 Connection lost
[2023-07-20 12:12:00] ERROR OVERHEAT E301 Temperature 85C
[2023-07-20 12:13:00] ERROR SENSOR_TIMEOUT E105 Connection lost
[2023-07-20 12:14:00] INFO  Sensor reading: 22
EOF

cat <<'EOF' > /home/user/iot_logs/device03.log
[2023-07-20 12:20:00] ERROR LOW_BATTERY E201 Battery level 4%
[2023-07-20 12:21:00] ERROR OVERHEAT E301 Temperature 87C
[2023-07-20 12:22:00] WARN  Retry
[2023-07-20 12:23:00] ERROR LOW_BATTERY E201 Battery level 3%
EOF

chmod 755 /home/user && \
    chmod 0644 /home/user/iot_logs/*.log && \
    chown -R 1000:1000 /home/user || true

export PATH=/usr/local/bin:/usr/bin:/bin:$PATH
