You are the release manager and need to finish a very small pre-deployment
preparation inside your home directory.

Current project layout (already present):
  /home/user/app/
      └── sample.env          # provided template

Goal:
  1. Create a copy of “/home/user/app/sample.env” called
     “/home/user/app/.env”.
  2. Inside “/home/user/app/.env” ensure the following two settings exist
     with the exact values shown (overwriting any existing values with the
     same keys if they are already there):
       APP_ENV=production
       RELEASE_TAG=v2.0.1
  3. Produce a *deployment summary log* at
     “/home/user/deploy_summary.log” containing **exactly two lines** and
     nothing else:
       Line 1: ENV: production
       Line 2: TAG: v2.0.1

Formatting rules that the automated checker will enforce:
  • “/home/user/app/.env” must be a plain UTF-8 text file.
  • Key-value pairs must be on their own lines, with no leading/trailing
    spaces, and must use the exact case shown above.
  • “/home/user/deploy_summary.log” must contain exactly two lines, each
    terminated by a single UNIX newline (LF, \n). No trailing blank line is
    allowed after the second line.
  • The strings “ENV: production” and “TAG: v2.0.1” must appear exactly as
    shown (case-sensitive).

Do not create any additional files or modify anything outside the paths
given above. The automated tests will check only the two files mentioned.