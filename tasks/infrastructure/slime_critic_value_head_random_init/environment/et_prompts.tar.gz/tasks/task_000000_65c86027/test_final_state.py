# test_final_state.py
#
# This test-suite validates the filesystem AFTER the student has finished
# the task.  It must be run after *all* student actions have completed.
#
# Expected artefacts:
#
# 1) /home/user/app/.env               (UTF-8 text file)
#    ├─ Must contain the header line  "# Sample configuration file\n"
#    ├─ Must contain "APP_ENV=production\n"
#    ├─ Must contain "RELEASE_TAG=v2.0.1\n"
#    └─ Must NOT contain the old development values or any duplicates.
#
#    The three lines may appear in any order, but there must be exactly three
#    non-empty lines in total, each terminated with a *single* '\n'.
#
# 2) /home/user/deploy_summary.log     (UTF-8 text file)
#    ├─ Must consist of **exactly** the two lines shown below,
#    │   *each* terminated with a single '\n' and with no extra blank lines:
#    │     "ENV: production\n"
#    │     "TAG: v2.0.1\n"
#    └─ No additional content, whitespace, or lines are permitted.
#
# If any assertion fails, the error message should make clear *what* is still
# wrong so the student can fix it quickly.

from pathlib import Path
import builtins
import pytest

HOME_DIR = Path("/home/user")
APP_DIR = HOME_DIR / "app"
ENV_FILE = APP_DIR / ".env"
SUMMARY_LOG = HOME_DIR / "deploy_summary.log"


def _read_file_lines(path: Path):
    """
    Read *text* lines from a file using UTF-8 and return the raw lines
    including their trailing newlines.  A helpful error is raised if decoding
    fails so that the student knows the file's encoding is wrong.
    """
    try:
        with path.open("r", encoding="utf-8") as fp:
            return fp.readlines()
    except UnicodeDecodeError as exc:
        pytest.fail(
            f"File '{path}' is not valid UTF-8 text: {exc}"
        )


@pytest.mark.describe("Validate the final deployment preparation")
class TestFinalState:

    # --------------------------------------------------------------------- #
    # 1.  .env checks
    # --------------------------------------------------------------------- #
    def test_env_file_exists(self):
        assert ENV_FILE.is_file(), (
            f"Expected '{ENV_FILE}' to exist as a regular file after the task "
            f"is completed, but it is missing or is not a file."
        )

    def test_env_file_content(self):
        lines = _read_file_lines(ENV_FILE)

        # ---- Basic structure ------------------------------------------------
        expected_required = {
            "# Sample configuration file\n",
            "APP_ENV=production\n",
            "RELEASE_TAG=v2.0.1\n",
        }

        unexpected_old = {
            "APP_ENV=development\n",
            "RELEASE_TAG=dev\n",
        }

        # 1) Correct number of lines (exactly 3 non-empty lines)
        assert len(lines) == 3, (
            f"'{ENV_FILE}' should contain exactly 3 lines (header + 2 key/value "
            f"pairs).  Found {len(lines)} line(s):\n{''.join(lines)!r}"
        )

        # 2) All required lines present
        missing = expected_required.difference(lines)
        assert not missing, (
            f"'{ENV_FILE}' is missing the following required line(s): "
            f"{', '.join(repr(l) for l in sorted(missing))}"
        )

        # 3) No old development values still present
        still_present = unexpected_old.intersection(lines)
        assert not still_present, (
            f"'{ENV_FILE}' still contains old development value(s): "
            f"{', '.join(repr(l) for l in sorted(still_present))}"
        )

        # 4) No duplicate keys (simple check: each expected line appears once)
        dup_lines = [
            l for l in expected_required
            if lines.count(l) > 1
        ]
        assert not dup_lines, (
            f"Duplicate line(s) detected in '{ENV_FILE}': "
            f"{', '.join(repr(l) for l in dup_lines)}"
        )

        # 5) Ensure every line ends with a single '\n'
        for idx, line in enumerate(lines, start=1):
            assert line.endswith("\n"), (
                f"Line {idx} of '{ENV_FILE}' is not terminated with a newline."
            )

    # --------------------------------------------------------------------- #
    # 2.  deploy_summary.log checks
    # --------------------------------------------------------------------- #
    def test_deploy_summary_log_exists(self):
        assert SUMMARY_LOG.is_file(), (
            f"Expected '{SUMMARY_LOG}' to exist as a regular file, "
            "but it is missing or is not a file."
        )

    def test_deploy_summary_log_content(self):
        lines = _read_file_lines(SUMMARY_LOG)
        expected_lines = ["ENV: production\n", "TAG: v2.0.1\n"]

        # Exact match required
        assert lines == expected_lines, (
            f"'{SUMMARY_LOG}' must contain *exactly* these two lines:\n"
            f"  1) {expected_lines[0]!r}"
            f"  2) {expected_lines[1]!r}\n"
            f"No additional whitespace or blank lines are allowed.\n\n"
            f"Actual content ({len(lines)} line(s)):\n{''.join(lines)!r}"
        )