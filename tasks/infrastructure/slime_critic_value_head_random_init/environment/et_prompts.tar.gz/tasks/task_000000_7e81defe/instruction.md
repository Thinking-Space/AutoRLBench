You are a monitoring specialist who has just received two CSV-style data files that describe:

1. The set of **required monitoring packages** for the new environment.
2. The set of packages that are **currently installed** on the host.

Your job is to audit the installation status of every required package and generate an alert log that operations can ingest.

STARTING FILES & DIRECTORIES
────────────────────────────
1. /home/user/repo/package_inventory.csv  
   • Format (no header line):  
     package_name,version  
   • Example first three lines (all lines in this file follow the same pattern):  
     htop,3.2.2  
     sysstat,12.5.4  
     iftop,1.0pre4  

2. /home/user/installed/installed_packages.txt  
   • Format (no header line):  
     package_name,version  
   • Example first three lines (all lines in this file follow the same pattern):  
     bash,5.0  
     coreutils,8.30  
     glances,3.3.0  

Both files already exist in the stated locations when your session begins; **do not rename or delete them**.  
All directories are writable by the current user.

WHAT YOU MUST PRODUCE
─────────────────────
1. A new directory called /home/user/alerts (create it if it does not already exist).

2. Inside that directory, a plain-text log file named  
   /home/user/alerts/monitoring_pkg_alerts.log

3. The log file **must contain exactly one line for every package listed in /home/user/repo/package_inventory.csv** and must appear in the same order as in that file. Each line is a “pipe-delimited” record with the following 3 fields:

   package_name|required_version|status

   • package_name        → exactly as it appears in package_inventory.csv  
   • required_version    → exactly as it appears in package_inventory.csv  
   • status              → one of the three literal strings below  
       OK                → the package exists in installed_packages.txt **and** its version matches required_version  
       VERSION_MISMATCH  → the package exists but version differs  
       MISSING           → the package is not listed in installed_packages.txt  

   There should be **no leading or trailing spaces** in any line and **no extra header line**.

   Example of a correctly formatted log (illustrative only):
   htop|3.2.2|MISSING  
   sysstat|12.5.4|MISSING  
   iftop|1.0pre4|MISSING  
   net-tools|2.10|MISSING  
   glances|3.3.0|OK

4. Immediately after creating /home/user/alerts/monitoring_pkg_alerts.log, compress it with gzip so that a file named  
   /home/user/alerts/monitoring_pkg_alerts.log.gz  
   appears alongside the original. **Do not delete the uncompressed log.**

CONSTRAINTS & EXPECTATIONS
──────────────────────────
• Your solution must use standard command-line tools available on a typical Debian/Ubuntu system (bash utilities, coreutils, gzip, etc.).  
• You do **not** have root privileges; do not attempt to install or remove packages from the operating system.  
• The final artefacts (directory, log file, compressed log) **must match the exact paths and content rules described above**, or automated verification will fail.

VALIDATION HINT
───────────────
After you finish, you can inspect the compressed log file to ensure it matches the required format.

Remember: the automated grader will compare the contents of monitoring_pkg_alerts.log **byte-for-byte**, so follow the formatting rules strictly.