#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    echo "Installing Python and pytest ..." && \
    apt-get update -y && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3 \
        python3-pip && \
    pip3 install --no-cache-dir pytest && \
    echo "Preparing directory structure and seed files ..." && \
    install -d -m 0777 /home/user && \
    install -d -m 0777 /home/user/repo && \
    install -d -m 0777 /home/user/installed

cat > /home/user/repo/package_inventory.csv <<'EOF'
htop,3.2.2
sysstat,12.5.4
iftop,1.0pre4
net-tools,2.10
glances,3.3.0
EOF

chmod 0666 /home/user/repo/package_inventory.csv

cat > /home/user/installed/installed_packages.txt <<'EOF'
bash,5.0
coreutils,8.30
glances,3.3.0
EOF

chmod 0666 /home/user/installed/installed_packages.txt

if [ -d /home/user/alerts ]; then \
        rm -rf /home/user/alerts; \
    fi && \
    echo "Container setup complete."

export PYTHONIOENCODING=UTF-8

export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"

chmod 755 /home/user
