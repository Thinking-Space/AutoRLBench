# test_final_state.py
#
# Pytest suite that validates the **FINAL** operating-system / filesystem
# state *after* the student has carried out the monitoring-package audit
# task.  These tests assert the presence, correctness, and integrity of all
# required artefacts.
#
# Guidelines enforced here:
#   • All absolute paths must exist exactly as specified.
#   • Log file must contain the exact expected lines *in order* and use UNIX
#     (LF) line endings only.
#   • A gzip-compressed copy of the log must exist, be non-empty, and when
#     decompressed match the plain log byte-for-byte.
#
# Only the Python standard library and `pytest` are used.

import os
import gzip
from pathlib import Path

import pytest

# --------
# CONSTANTS
# --------
PKG_INVENTORY      = Path("/home/user/repo/package_inventory.csv")
INSTALLED_PACKAGES = Path("/home/user/installed/installed_packages.txt")

ALERTS_DIR   = Path("/home/user/alerts")
ALERT_LOG    = ALERTS_DIR / "monitoring_pkg_alerts.log"
ALERT_LOG_GZ = ALERTS_DIR / "monitoring_pkg_alerts.log.gz"

# Expected contents of the plain-text log, *exactly*.
EXPECTED_LOG_LINES = [
    "htop|3.2.2|MISSING",
    "sysstat|12.5.4|MISSING",
    "iftop|1.0pre4|MISSING",
    "net-tools|2.10|MISSING",
    "glances|3.3.0|OK",
]


# ---------------
# HELPER FUNCTION
# ---------------
def read_file_bytes(path: Path) -> bytes:
    """Return the raw bytes of *path*; assert UNIX line endings only."""
    data = path.read_bytes()
    assert b"\r" not in data, (
        f"{path} contains Windows (CRLF) line endings; "
        "file must use UNIX LF line endings only."
    )
    return data


def read_file_lines(path: Path):
    """Return list of decoded str lines (without the trailing newline)."""
    return read_file_bytes(path).decode("utf-8").splitlines()


# ------
# TESTS
# ------
def test_alerts_directory_exists():
    """/home/user/alerts must exist and be a directory writable by user."""
    assert ALERTS_DIR.exists(), f"Directory missing: {ALERTS_DIR}"
    assert ALERTS_DIR.is_dir(), f"{ALERTS_DIR} exists but is not a directory."

    # Check writability by attempting to open a TemporaryFile inside it.
    try:
        tmp_path = ALERTS_DIR / ".pytest_write_check"
        with tmp_path.open("w") as fh:
            fh.write("ok")
        tmp_path.unlink()
    except Exception as exc:
        pytest.fail(f"{ALERTS_DIR} is not writable by the current user: {exc}")


def test_log_file_exists_and_contents_are_exact():
    """Plain log file must exist and contain the expected audit lines."""
    assert ALERT_LOG.is_file(), f"Log file missing: {ALERT_LOG}"

    actual_lines = read_file_lines(ALERT_LOG)
    assert actual_lines == EXPECTED_LOG_LINES, (
        f"Unexpected contents in {ALERT_LOG}.\n\n"
        f"Expected ({len(EXPECTED_LOG_LINES)} lines):\n{EXPECTED_LOG_LINES}\n\n"
        f"Actual ({len(actual_lines)} lines):\n{actual_lines}"
    )


def test_gz_file_exists_non_empty_and_matches_plain_log():
    """Gzipped copy must exist, be valid gzip, and decompress exactly to the plain log."""
    assert ALERT_LOG_GZ.is_file(), f"Gzip file missing: {ALERT_LOG_GZ}"

    gz_size = ALERT_LOG_GZ.stat().st_size
    assert gz_size > 0, f"{ALERT_LOG_GZ} is zero bytes; compression step likely failed."

    # Decompress safely with gzip module
    try:
        with gzip.open(ALERT_LOG_GZ, "rb") as fh:
            decompressed = fh.read()
    except OSError as exc:  # invalid gzip header, etc.
        pytest.fail(f"{ALERT_LOG_GZ} is not a valid gzip archive: {exc}")

    # Ensure decompressed data has correct UNIX line endings
    assert b"\r" not in decompressed, (
        f"Decompressed data from {ALERT_LOG_GZ} contains CR characters; "
        "log must have UNIX LF line endings only."
    )

    plain_bytes = read_file_bytes(ALERT_LOG)
    assert decompressed == plain_bytes, (
        f"Content mismatch between {ALERT_LOG} and decompressed {ALERT_LOG_GZ}."
    )


def test_original_input_files_untouched():
    """
    Sanity check: initial input files must still exist and keep their original
    content.  This confirms the student's solution did not modify them.
    """
    # Package inventory
    assert PKG_INVENTORY.is_file(), f"Missing original inventory file: {PKG_INVENTORY}"
    inv_expected = [
        "htop,3.2.2",
        "sysstat,12.5.4",
        "iftop,1.0pre4",
        "net-tools,2.10",
        "glances,3.3.0",
    ]
    assert read_file_lines(PKG_INVENTORY) == inv_expected, (
        f"{PKG_INVENTORY} contents were altered."
    )

    # Installed packages
    assert INSTALLED_PACKAGES.is_file(), f"Missing installed-packages file: {INSTALLED_PACKAGES}"
    installed_expected = [
        "bash,5.0",
        "coreutils,8.30",
        "glances,3.3.0",
    ]
    assert read_file_lines(INSTALLED_PACKAGES) == installed_expected, (
        f"{INSTALLED_PACKAGES} contents were altered."
    )