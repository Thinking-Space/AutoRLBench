# test_final_state.py
#
# Pytest-suite that validates the **FINAL** state of the operating system /
# container *after* the student has carried out the “permissions audit” task.
#
# What we verify:
#
#   1. The original source files are still present *and* were **not** modified.
#   2. The two required artefacts exist at exactly the specified absolute paths.
#   3. validation.log
#        • is a plain-text file with **exactly** three lines
#          (including the mandatory trailing newline).
#        • lines read:
#              VALIDATION_RESULT: OK
#              USERS_TOTAL: 4
#              ADMIN_USERS: carol
#   4. admin_users.json
#        • exists and its bytes match the canonical pretty-printed JSON
#          shown in the specification (again including the trailing newline).
#        • parses as JSON and contains precisely one user object for “carol”
#          with uid 0 and “admin” permission.
#
# Any divergence from the expectations will raise a clear and focused
# assertion error describing **what is still wrong**.
#
# Only the Python standard library and pytest are used.
import json
import os
import pathlib
import stat
import pytest

# ---------------------------------------------------------------------------
# Constant paths
# ---------------------------------------------------------------------------
AUDIT_DIR         = pathlib.Path("/home/user/audit")
PERMISSIONS_FILE  = AUDIT_DIR / "permissions.json"
SCHEMA_FILE       = AUDIT_DIR / "permissions.schema.json"
VALIDATION_LOG    = AUDIT_DIR / "validation.log"
ADMIN_USERS_JSON  = AUDIT_DIR / "admin_users.json"

# ---------------------------------------------------------------------------
# Canonical, byte-for-byte expectations (all include the trailing newline)
# ---------------------------------------------------------------------------
EXPECTED_PERMISSIONS_JSON = """{
  "users": [
    { "username": "alice", "uid": 1001, "permissions": ["read", "write"] },
    { "username": "bob", "uid": 1002, "permissions": ["read"] },
    { "username": "carol", "uid": 0, "permissions": ["read", "write", "execute", "admin"] },
    { "username": "dave", "uid": 1003, "permissions": ["read", "write", "execute"] }
  ]
}
"""

EXPECTED_SCHEMA_JSON = """{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "required": ["users"],
  "properties": {
    "users": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["username", "uid", "permissions"],
        "properties": {
          "username": { "type": "string" },
          "uid": { "type": "integer" },
          "permissions": {
            "type": "array",
            "items": { "type": "string" }
          }
        }
      }
    }
  }
}
"""

EXPECTED_VALIDATION_LOG = (
    "VALIDATION_RESULT: OK\n"
    "USERS_TOTAL: 4\n"
    "ADMIN_USERS: carol\n"
)

EXPECTED_ADMIN_USERS_JSON = """[
  {
    "username": "carol",
    "uid": 0,
    "permissions": [
      "read",
      "write",
      "execute",
      "admin"
    ]
  }
]
"""

# ---------------------------------------------------------------------------
# Helper fixtures & utilities
# ---------------------------------------------------------------------------
def _read(path: pathlib.Path) -> str:
    """Utility: read file as UTF-8 text.  Raises clear error if missing."""
    assert path.exists(), f"Required file {path} is missing."
    return path.read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def original_files_content():
    """
    Returns the *raw* bytes for the two source JSON files.
    Used to ensure they were not modified.
    """
    return {
        PERMISSIONS_FILE: _read(PERMISSIONS_FILE),
        SCHEMA_FILE: _read(SCHEMA_FILE),
    }


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------
def test_source_files_untouched(original_files_content):
    """
    permissions.json and permissions.schema.json must be byte-identical to
    the canonical specimens supplied at exercise start.
    """
    assert original_files_content[PERMISSIONS_FILE] == EXPECTED_PERMISSIONS_JSON, (
        f"{PERMISSIONS_FILE} was modified. Restore it to the original content."
    )
    assert original_files_content[SCHEMA_FILE] == EXPECTED_SCHEMA_JSON, (
        f"{SCHEMA_FILE} was modified. Restore it to the original content."
    )


def test_validation_log_exists_and_exact_content():
    raw = _read(VALIDATION_LOG)
    assert raw == EXPECTED_VALIDATION_LOG, (
        f"{VALIDATION_LOG} content mismatch.\n\n"
        "Expected exactly:\n"
        f"{EXPECTED_VALIDATION_LOG!r}\n\n"
        "Got:\n"
        f"{raw!r}"
    )

    # Additionally, ensure *exactly* three lines (the trailing newline
    # creates an empty fourth element when splitting with keepends=False).
    lines = raw.splitlines()
    assert len(lines) == 3, (
        f"{VALIDATION_LOG} must contain exactly 3 lines; found {len(lines)}."
    )


def test_admin_users_json_exists_and_exact_content():
    raw = _read(ADMIN_USERS_JSON)
    assert raw == EXPECTED_ADMIN_USERS_JSON, (
        f"{ADMIN_USERS_JSON} content mismatch.\n"
        "It must match the pretty-printed JSON shown in the specification, "
        "byte for byte (including indentation and trailing newline)."
    )

    # Sanity-check that the JSON parses and has the expected semantics.
    data = json.loads(raw)
    assert isinstance(data, list) and len(data) == 1, (
        f"{ADMIN_USERS_JSON} must contain exactly one user object."
    )
    user = data[0]
    assert user.get("username") == "carol", "Expected admin user 'carol' not found."
    assert user.get("uid") == 0, "Admin user 'carol' must have uid 0."
    assert "admin" in user.get("permissions", []), (
        "Admin user 'carol' must have 'admin' in permissions array."
    )


def test_artifact_file_permissions():
    """
    Validate that artefact files are not world-writable, i.e. respect a
    reasonable default umask (rw-r--r-- or more restrictive).
    The requirement is *not* super strict, we just forbid dangerous modes.
    """
    for path in (VALIDATION_LOG, ADMIN_USERS_JSON):
        mode = stat.S_IMODE(os.stat(path).st_mode)
        assert not (mode & 0o002), f"{path} is world-writable, which is insecure."


# EOF