You are acting as a security auditor who has just received a small JSON-based user-permission manifest that lives in

    /home/user/audit/permissions.json

and its companion JSON-Schema stored at

    /home/user/audit/permissions.schema.json

Validate that the data file actually satisfies the rules spelled out in the schema.
*   If every user object contains **all** three required keys – “username”, “uid”, and “permissions” – and the top-level key “users” exists and is an array, consider the file valid.

Extract every user that fulfils at least one of these “dangerous” conditions:
*   uid is 0
*   the “permissions” array contains the literal string “admin”

Produce two artefacts in the same directory (/home/user/audit):

a) validation.log – **plain-text** file, three (or four) lines, **exactly** in this order and formatting (case-sensitive, colon followed by a single space, no extra whitespace):

    VALIDATION_RESULT: OK|FAIL
    USERS_TOTAL: <integer>
    ADMIN_USERS: <comma-separated list with no spaces>
    (OPTIONAL) ERRORS: <short free-text description>   ← include only when result is FAIL

    Example of a correct *success* file:

    VALIDATION_RESULT: OK
    USERS_TOTAL: 4
    ADMIN_USERS: carol

b) admin_users.json – a pretty-printed JSON array that contains the full objects of every qualifying admin/root user, in the same order they appear in the source file.

Nothing else in /home/user/audit should be changed. Do **not** rename or delete any existing file.

When you are done, both files must exist exactly as specified so that an automated test can compare them byte-for-byte.