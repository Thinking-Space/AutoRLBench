You are a machine-learning engineer who has just logged in to a brand-new Linux workstation.
Before you start preprocessing large training datasets you want to create a repeatable “health-check” snapshot so you (and your team) can compare system conditions over time.

Create one directory and **exactly two files** according to the specification below.
The automated grader will look only at the directory/filenames, the presence of the required section headers / column headers, and the exact spelling & ordering of those headers.
It will NOT validate the numeric values that your commands record, so you can keep whatever numbers the workstation returns.

A directory must be created at this location (create parent directories if they do not already exist):
`/home/user/ml_diag`

Inside that directory, create a plain-text log file called:
`/home/user/ml_diag/system_snapshot.log`

The file must contain the *five* section headers shown below **in this exact order** (uppercase, surrounded by three hash marks and a single space on each side).
For every header, the appropriate system information must appear directly beneath it.
The grader will only check that each header exists on its own line and appears once, so do not change their spelling, case, or the number of hash marks.

Required headers:

```
### DATE ###
### CPU ###
### MEMORY ###
### DISK ###
### TOP5_PROCESSES ###
```

Formatting rules:
*   Each header is on its own line.
*   Immediately after a header comes *at least one* non-empty line of the relevant system information.
*   There must be a final trailing newline at the end of the file.

Inside the same directory, create a CSV file called:
`/home/user/ml_diag/top5_mem.csv`

The CSV must satisfy all of the following:
*   First line is the exact header row: `pid,user,percent_mem,command`
    (all lowercase, comma-separated, **no spaces**).
*   Exactly five additional data lines must follow (one per process).
*   Every line, including the last, ends with a newline character.

When you are finished you should have:

```
/home/user/ml_diag/                  (directory exists)
/home/user/ml_diag/system_snapshot.log   (text file with the five headers)
/home/user/ml_diag/top5_mem.csv          (CSV with six lines total)
```

The grader will fail if:
*   Any header line is misspelled, missing, duplicated, or out of order.
*   The CSV header row is incorrect or the file contains more or fewer than six total lines.
*   Either file is missing or located elsewhere.