# test_final_state.py
#
# Pytest suite that validates the **FINAL** state of the operating system
# after the student has created the required diagnostic artefacts for the
# “health-check” snapshot.
#
# The tests assert that:
# • /home/user/ml_diag           exists and is a directory
# • /home/user/ml_diag/system_snapshot.log
#     - exists
#     - contains the five mandatory headers in the correct order
#     - each header appears exactly once
#     - at least one non-empty line follows every header
#     - the file ends with a trailing newline
# • /home/user/ml_diag/top5_mem.csv
#     - exists
#     - contains exactly six lines (header + 5 data rows)
#     - first line is exactly “pid,user,percent_mem,command”
#     - every line in the file ends with “\n”
#
# Only the Python standard library and `pytest` are used.

import os
from pathlib import Path
import pytest

# Absolute paths mandated by the specification
BASE_DIR = Path("/home/user/ml_diag")
LOG_FILE = BASE_DIR / "system_snapshot.log"
CSV_FILE = BASE_DIR / "top5_mem.csv"

# --------------------------------------------------------------------------- #
# Helper functions
# --------------------------------------------------------------------------- #
def _read_binary(path: Path) -> bytes:
    """Return raw bytes content of a file."""
    with path.open("rb") as fh:
        return fh.read()


def _read_text_lines(path: Path):
    """Return list of lines (with newline chars intact) read in text mode."""
    with path.open("r", encoding="utf-8", newline="") as fh:
        return fh.readlines()


# --------------------------------------------------------------------------- #
# Directory & File existence tests
# --------------------------------------------------------------------------- #
def test_ml_diag_directory_exists():
    assert BASE_DIR.is_dir(), (
        f"Expected directory {BASE_DIR} is missing or not a directory."
    )


@pytest.mark.parametrize(
    "path,label",
    [
        (LOG_FILE, "/home/user/ml_diag/system_snapshot.log"),
        (CSV_FILE, "/home/user/ml_diag/top5_mem.csv"),
    ],
)
def test_target_files_exist(path: Path, label: str):
    assert path.is_file(), f"Required file {label} is missing or not a regular file."


# --------------------------------------------------------------------------- #
# system_snapshot.log content tests
# --------------------------------------------------------------------------- #
MANDATORY_HEADERS = [
    "### DATE ###",
    "### CPU ###",
    "### MEMORY ###",
    "### DISK ###",
    "### TOP5_PROCESSES ###",
]


def test_log_file_trailing_newline():
    content = _read_binary(LOG_FILE)
    assert content.endswith(b"\n"), (
        f"{LOG_FILE} must end with a single trailing newline."
    )


def test_log_headers_order_and_uniqueness():
    lines = _read_text_lines(LOG_FILE)

    # Strip only the trailing newline for comparison, retain internal spacing
    stripped = [ln.rstrip("\n") for ln in lines]

    # Verify each mandatory header appears exactly once and in correct order
    current_index = -1
    seen_headers = set()

    for header in MANDATORY_HEADERS:
        try:
            idx = stripped.index(header)
        except ValueError:
            pytest.fail(f"Header '{header}' is missing from {LOG_FILE}.")

        if idx <= current_index:
            pytest.fail(
                f"Header '{header}' appears out of order in {LOG_FILE}."
            )
        current_index = idx

        if header in seen_headers:
            pytest.fail(f"Header '{header}' appears more than once in {LOG_FILE}.")
        seen_headers.add(header)

    # Sanity: total occurrences should equal mandatory list length
    assert len(seen_headers) == len(MANDATORY_HEADERS)


def test_log_sections_have_data():
    """
    Ensure that at least one non-empty line of data follows each header.
    """
    lines = _read_text_lines(LOG_FILE)
    # Record index of every header
    header_indices = {
        i: ln.rstrip("\n")
        for i, ln in enumerate(lines)
        if ln.rstrip("\n") in MANDATORY_HEADERS
    }

    # Sort by the order headers appear in the file
    ordered_indices = sorted(header_indices.keys())

    for pos, start_idx in enumerate(ordered_indices):
        header = header_indices[start_idx]
        # Determine the slice that belongs to this header
        end_idx = (
            ordered_indices[pos + 1]  # next header
            if pos + 1 < len(ordered_indices)
            else len(lines)  # or EOF
        )
        data_block = lines[start_idx + 1 : end_idx]

        # Remove pure newline lines for emptiness check
        non_empty = [ln for ln in data_block if ln.strip()]
        assert non_empty, (
            f"No data found under header '{header}' in {LOG_FILE}. "
            "There must be at least one non-empty line following each header."
        )


# --------------------------------------------------------------------------- #
# top5_mem.csv content tests
# --------------------------------------------------------------------------- #
def test_csv_line_count_and_trailing_newlines():
    raw = _read_binary(CSV_FILE)
    assert raw.endswith(b"\n"), f"{CSV_FILE} must end with a newline character."

    lines = _read_text_lines(CSV_FILE)
    assert len(lines) == 6, (
        f"{CSV_FILE} should contain exactly 6 lines "
        f"(1 header + 5 data rows); found {len(lines)}."
    )


def test_csv_header_row():
    header_line = _read_text_lines(CSV_FILE)[0].rstrip("\n")
    expected = "pid,user,percent_mem,command"
    assert header_line == expected, (
        f"CSV header mismatch in {CSV_FILE}.\n"
        f"Expected: {expected}\n"
        f"Found:    {header_line}"
    )


def test_csv_data_rows_have_four_columns_and_non_empty():
    lines = _read_text_lines(CSV_FILE)[1:]  # skip header
    for idx, line in enumerate(lines, start=2):  # start=2 reflects file line numbers
        row = line.rstrip("\n")
        cols = row.split(",")
        assert len(cols) == 4, (
            f"Line {idx} in {CSV_FILE} should have exactly 4 comma-separated "
            f"fields; found {len(cols)} field(s)."
        )
        assert all(
            col != "" for col in cols
        ), f"Line {idx} in {CSV_FILE} contains empty fields, which is not allowed."


# --------------------------------------------------------------------------- #
# End of test suite
# --------------------------------------------------------------------------- #