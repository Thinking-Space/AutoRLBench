# test_final_state.py
#
# Pytest suite that validates the *final* state of the operating-system /
# container after the student has completed the “diagnostic bundle” task.
#
# The tests are intentionally strict and verify the following:
#   • /home/user/exp_reports             exists as a directory (permissions 755).
#   • It contains *exactly* three files:
#         system_snapshot.log
#         experiment_summary.json
#         top_memory_processes.csv
#     Each must have permissions 644.
#   • The byte-for-byte contents of the three files match the specification.
#   • The information inside the files is *consistent* with the source data
#     found in metrics.csv and mock_ps.txt — so simply hard-coding wrong
#     numbers will not pass.
#
# Only the Python standard library and pytest are used.

import csv
import json
import os
import stat
from pathlib import Path

import pytest

# --------------------------------------------------------------------------- #
# Constants                                                                  #
# --------------------------------------------------------------------------- #
HOME = Path("/home/user").resolve()
EXP_REPORTS_DIR = HOME / "exp_reports"

SNAPSHOT_LOG = EXP_REPORTS_DIR / "system_snapshot.log"
SUMMARY_JSON = EXP_REPORTS_DIR / "experiment_summary.json"
TOP_PROCS_CSV = EXP_REPORTS_DIR / "top_memory_processes.csv"

METRICS_CSV = HOME / "experiments/run_01/metrics.csv"
MOCK_PS_TXT = HOME / "mock_ps.txt"

# Expected byte-exact contents for deliverables
EXPECTED_SNAPSHOT = "CPU_USAGE:65.6%\nMEM_USAGE:32.1%\n"
EXPECTED_SUMMARY_JSON = (
    "{\n"
    '  "run_id": "run_01",\n'
    '  "final_epoch": 5,\n'
    '  "final_accuracy": 0.85,\n'
    '  "average_loss": 0.526\n'
    "}\n"
)
EXPECTED_TOP_PROCS = (
    "PID,USER,%CPU,%MEM,COMMAND\n"
    "2345,user,2.1,15.2,chrome\n"
    "3456,user,0.5,10.0,java\n"
    "5678,user,0.7,5.5,node\n"
)

EXPECTED_FILE_SET = {
    SNAPSHOT_LOG.name,
    SUMMARY_JSON.name,
    TOP_PROCS_CSV.name,
}

# --------------------------------------------------------------------------- #
# Helper utilities                                                            #
# --------------------------------------------------------------------------- #
def assert_path_permissions(path: Path, expected_mode: int):
    """Assert *path* has octal permissions *expected_mode* (e.g. 0o644)."""
    mode = path.stat().st_mode & 0o777
    assert (
        mode == expected_mode
    ), f"{path} has permissions {oct(mode)}; expected {oct(expected_mode)}."


def read_text(path: Path) -> str:
    """Read *path* as UTF-8 text and return the full string."""
    return path.read_text(encoding="utf-8")


def parse_mock_ps() -> list[dict]:
    """
    Parse /home/user/mock_ps.txt into a list of dicts with the keys:
    PID, USER, %CPU, %MEM, COMMAND
    """
    with MOCK_PS_TXT.open(encoding="utf-8") as fp:
        lines = [ln.strip() for ln in fp if ln.strip()]
    header, *rows = lines
    header_cols = header.split()
    data = []
    for row in rows:
        parts = row.split()
        record = dict(zip(header_cols, parts))
        # Convert numeric fields
        record["%CPU"] = float(record["%CPU"])
        record["%MEM"] = float(record["%MEM"])
        data.append(record)
    return data


def parse_metrics() -> list[dict]:
    """Parse metrics.csv and return list of dicts."""
    with METRICS_CSV.open(encoding="utf-8", newline="") as fp:
        reader = csv.DictReader(fp)
        return [
            {"epoch": int(r["epoch"]), "loss": float(r["loss"]), "accuracy": float(r["accuracy"])}
            for r in reader
        ]


# --------------------------------------------------------------------------- #
# Tests                                                                       #
# --------------------------------------------------------------------------- #
def test_exp_reports_directory_exists_with_correct_permissions():
    assert EXP_REPORTS_DIR.is_dir(), (
        f"The directory {EXP_REPORTS_DIR} is missing or is not a directory."
    )
    assert_path_permissions(EXP_REPORTS_DIR, 0o755)


def test_exp_reports_contains_exactly_three_expected_files():
    present_files = {p.name for p in EXP_REPORTS_DIR.iterdir() if p.is_file()}
    extra = present_files - EXPECTED_FILE_SET
    missing = EXPECTED_FILE_SET - present_files
    assert not extra, (
        f"Unexpected file(s) found in {EXP_REPORTS_DIR}: {', '.join(sorted(extra))}. "
        "Remove temporary or backup files."
    )
    assert not missing, (
        f"The following required file(s) are missing in {EXP_REPORTS_DIR}: "
        f"{', '.join(sorted(missing))}."
    )


@pytest.mark.parametrize("path", [SNAPSHOT_LOG, SUMMARY_JSON, TOP_PROCS_CSV])
def test_each_output_file_has_correct_permissions(path: Path):
    assert path.is_file(), f"Expected file {path} is missing."
    assert_path_permissions(path, 0o644)


def test_snapshot_log_content_and_consistency():
    content = read_text(SNAPSHOT_LOG)
    assert content == EXPECTED_SNAPSHOT, (
        f"{SNAPSHOT_LOG} content does not match the required specification.\n"
        "Expected:\n"
        f"{EXPECTED_SNAPSHOT!r}\nGot:\n{content!r}"
    )

    # Consistency check with mock_ps.txt
    records = parse_mock_ps()
    total_cpu = round(sum(r["%CPU"] for r in records), 1)
    total_mem = round(sum(r["%MEM"] for r in records), 1)
    expected_line1 = f"CPU_USAGE:{total_cpu}%"
    expected_line2 = f"MEM_USAGE:{total_mem}%"
    lines = content.splitlines()
    assert lines[0] == expected_line1, (
        f"{SNAPSHOT_LOG} CPU line should be {expected_line1!r} but is {lines[0]!r}"
    )
    assert lines[1] == expected_line2, (
        f"{SNAPSHOT_LOG} MEM line should be {expected_line2!r} but is {lines[1]!r}"
    )


def test_experiment_summary_json_content_and_consistency():
    raw = read_text(SUMMARY_JSON)
    assert raw == EXPECTED_SUMMARY_JSON, (
        f"{SUMMARY_JSON} content does not match the byte-for-byte specification."
    )

    # Validate it is valid JSON and consistent with metrics.csv
    data = json.loads(raw)
    metrics = parse_metrics()

    assert data["run_id"] == "run_01", "run_id in JSON must be 'run_01'."

    final_epoch = max(m["epoch"] for m in metrics)
    assert data["final_epoch"] == final_epoch, (
        f"final_epoch should be {final_epoch}."
    )

    final_acc = next(m["accuracy"] for m in metrics if m["epoch"] == final_epoch)
    assert data["final_accuracy"] == final_acc, (
        f"final_accuracy should be {final_acc}."
    )

    avg_loss = round(sum(m["loss"] for m in metrics) / len(metrics), 3)
    assert data["average_loss"] == avg_loss, (
        f"average_loss should be {avg_loss}."
    )


def test_top_memory_processes_csv_content_and_consistency():
    content = read_text(TOP_PROCS_CSV)
    assert content == EXPECTED_TOP_PROCS, (
        f"{TOP_PROCS_CSV} content does not match the required specification."
    )

    # Consistency check with mock_ps.txt
    expected_records = [
        {"PID": "2345", "USER": "user", "%CPU": "2.1", "%MEM": "15.2", "COMMAND": "chrome"},
        {"PID": "3456", "USER": "user", "%CPU": "0.5", "%MEM": "10.0", "COMMAND": "java"},
        {"PID": "5678", "USER": "user", "%CPU": "0.7", "%MEM": "5.5", "COMMAND": "node"},
    ]

    with TOP_PROCS_CSV.open(encoding="utf-8", newline="") as fp:
        reader = csv.DictReader(fp)
        rows = list(reader)

    assert rows == expected_records, (
        f"The rows in {TOP_PROCS_CSV} are not exactly as required."
    )

    # Verify they are indeed the top-3 by %MEM from mock_ps.txt
    ps_records = parse_mock_ps()
    top_by_mem = sorted(ps_records, key=lambda r: r["%MEM"], reverse=True)[:3]
    top_pids = [r["PID"] for r in top_by_mem]
    csv_pids = [r["PID"] for r in rows]
    assert csv_pids == top_pids, (
        f"{TOP_PROCS_CSV} is not listing the top-3 memory processes "
        f"from {MOCK_PS_TXT}. Expected PIDs {top_pids}, got {csv_pids}."
    )