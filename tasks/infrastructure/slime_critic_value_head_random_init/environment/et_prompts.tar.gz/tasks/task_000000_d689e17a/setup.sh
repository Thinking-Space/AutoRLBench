#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


export PATH=/usr/local/bin:/usr/bin:/bin:$PATH

set -e && \
    apt-get update && \
    apt-get install -y --no-install-recommends python3 python3-pip && \
    pip3 install --no-cache-dir pytest

mkdir -p /home/user/experiments/run_01

cat > /home/user/experiments/run_01/metrics.csv << 'EOF'
epoch,loss,accuracy
1,0.80,0.71
2,0.60,0.78
3,0.45,0.82
4,0.40,0.84
5,0.38,0.85
EOF

chmod 644 /home/user/experiments/run_01/metrics.csv

cat > /home/user/mock_ps.txt << 'EOF'
PID USER %CPU %MEM COMMAND
1234 user 12.3 1.1 python
2345 user 2.1 15.2 chrome
3456 user 0.5 10.0 java
4567 user 50.0 0.3 gcc
5678 user 0.7 5.5 node
EOF

chmod 644 /home/user/mock_ps.txt

chmod 755 /home/user && \
    chmod 755 /home/user/experiments && \
    chmod 755 /home/user/experiments/run_01
