You are an MLOps engineer who has just finished a deep-learning experiment
and now need to generate a *diagnostic bundle* for archival and post-mortem
analysis.

Important context: The following files are already present on disk
  • Experiment metrics:      /home/user/experiments/run_01/metrics.csv
  • Mocked process list:     /home/user/mock_ps.txt

(No other files or directories are relevant for this task.)

Your goals
  1. Create the directory /home/user/exp_reports  (if it does not already
     exist).
  2. Inside that directory, create exactly three files with the precise
     names and **strict final contents** shown below.  
     2.1  system_snapshot.log      – two lines summarising CPU and RAM  
     2.2  experiment_summary.json  – JSON summary of the run_01 metrics  
     2.3  top_memory_processes.csv – top-3 memory-hungry processes

File-format specifications that the automated tests will check
  • /home/user/exp_reports/system_snapshot.log  
    ────────────────────────────────────────────  
    Line-1 must look *exactly* like: CPU_USAGE:65.6%  
    Line-2 must look *exactly* like: MEM_USAGE:32.1%  
    (No extra spaces, no blank lines, no trailing characters.)  
    The `CPU_USAGE` value is the sum of the `%CPU` column from `/home/user/mock_ps.txt`.  
    The `MEM_USAGE` value is the sum of the `%MEM` column from `/home/user/mock_ps.txt`.

  • /home/user/exp_reports/experiment_summary.json  
    ───────────────────────────────────────────────  
    This must be valid JSON (UTF-8, no comments, no trailing commas)
    and **must match the following pretty-printed layout byte-for-byte**:

    {
      "run_id": "run_01",
      "final_epoch": 5,
      "final_accuracy": 0.85,
      "average_loss": 0.526
    }
    
    The values are derived from `/home/user/experiments/run_01/metrics.csv`:
    - `run_id` is the name of the experiment's parent directory (`run_01`).
    - `final_epoch` is the last epoch number.
    - `final_accuracy` is the `accuracy` value from the final epoch.
    - `average_loss` is the arithmetic mean of all values in the `loss` column.

  • /home/user/exp_reports/top_memory_processes.csv  
    ────────────────────────────────────────────────  
    CSV with *exactly* four lines, using the comma (,) as separator and
    no surrounding quotes.  Header is mandatory.  The automated checker
    is case-sensitive and will reject superfluous whitespace.
    The three data rows must correspond to the top three memory-consuming processes from `/home/user/mock_ps.txt`, sorted in descending order by the `%MEM` value.

    PID,USER,%CPU,%MEM,COMMAND
    2345,user,2.1,15.2,chrome
    3456,user,0.5,10.0,java
    5678,user,0.7,5.5,node

Additional requirements
  • Do not modify, move or delete any pre-existing files.  
  • Do not leave temporary or backup files in /home/user or sub-folders.  
  • The path /home/user/exp_reports must end up with permissions 755, and
    all three new files with permissions 644.  
  • When you are finished, all three files must exist *and* have exactly
    the contents specified above so that an automated test can do a strict
    diff against the expected output.

Deliverables
  The grading system will check for the *exact* existence, permissions and
  byte-by-byte contents of:

    /home/user/exp_reports/system_snapshot.log
    /home/user/exp_reports/experiment_summary.json
    /home/user/exp_reports/top_memory_processes.csv