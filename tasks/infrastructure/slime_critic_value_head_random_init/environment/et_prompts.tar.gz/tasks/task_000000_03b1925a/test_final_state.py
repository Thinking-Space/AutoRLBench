# test_final_state.py
#
# Pytest suite that validates the *final* state of the operating-system /
# container **after** the student has finished the “FinOps analyst” task.
#
# What is verified:
#   • The checksum artefact /home/user/checksums/invoice_checksums_July2023.txt
#     exists *exactly* as specified (binary-exact match, correct order,
#     single trailing newline, proper delimiters, lower-case SHA-256, etc.).
#   • The verification log /home/user/checksums/verification_July2023.log
#     exists, has exactly two lines that match the required timestamp
#     format, appear in the same order as the checksum file and end in “|OK”.
#   • The original source CSVs are still present and unmodified.
#
# If any assertion fails the error message will describe precisely what
# is still wrong, giving the learner clear guidance on what to fix.

import hashlib
import os
import re
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Constants / Ground-truth data
# ---------------------------------------------------------------------------

CLOUD_DIR = Path("/home/user/cloud_invoices")
CHECKSUMS_DIR = Path("/home/user/checksums")

CHECKSUM_TXT = CHECKSUMS_DIR / "invoice_checksums_July2023.txt"
VERIFICATION_LOG = CHECKSUMS_DIR / "verification_July2023.log"

EXPECTED_SOURCE_FILES = {
    Path("/home/user/cloud_invoices/AWS_2023-07.csv"): {
        "size": 3,
        "sha256": "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
    },
    Path("/home/user/cloud_invoices/GCP_2023-07.csv"): {
        "size": 5,
        "sha256": "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824",
    },
}

# Binary-exact contents expected for the checksum artefact
EXPECTED_CHECKSUM_FILE_BYTES = (
    b"/home/user/cloud_invoices/AWS_2023-07.csv|3|"
    b"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad\n"
    b"/home/user/cloud_invoices/GCP_2023-07.csv|5|"
    b"2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824\n"
)

# Pre-compiled regex for the verification log timestamp
TIMESTAMP_RE = r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}"  # YYYY-MM-DD HH:MM:SS


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def sha256_hex(path: Path) -> str:
    """Return the lower-case SHA-256 hex digest of *path*."""
    h = hashlib.sha256()
    with path.open("rb") as fp:
        for chunk in iter(lambda: fp.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_source_csvs_are_still_intact():
    """
    Re-check that the original CSVs are still present and unchanged.
    This guards against accidental overwrite while completing the task.
    """
    for file_path, meta in EXPECTED_SOURCE_FILES.items():
        assert file_path.exists(), f"Required source file {file_path} is missing."

        # Size must be unchanged.
        size = file_path.stat().st_size
        assert size == meta["size"], (
            f"{file_path} size mutated: expected {meta['size']} bytes, found {size}."
        )

        # SHA-256 digest must be unchanged.
        digest = sha256_hex(file_path)
        assert digest == meta["sha256"], (
            f"{file_path} SHA-256 mismatch after task: expected {meta['sha256']}, "
            f"got {digest}."
        )


def test_checksum_file_exists_and_is_exact():
    """The main output file must exist and match the contract exactly—byte for byte."""
    assert CHECKSUM_TXT.exists(), (
        f"Expected checksum file {CHECKSUM_TXT} is missing."
    )
    assert CHECKSUM_TXT.is_file(), (
        f"{CHECKSUM_TXT} exists but is not a regular file."
    )

    actual_bytes = CHECKSUM_TXT.read_bytes()
    assert (
        actual_bytes == EXPECTED_CHECKSUM_FILE_BYTES
    ), (
        "Checksum artefact contents are incorrect.\n"
        "Expected EXACT binary content:\n"
        f"{EXPECTED_CHECKSUM_FILE_BYTES!r}\n\n"
        "But found:\n"
        f"{actual_bytes!r}"
    )


def parse_verification_log_lines():
    """
    Helper that returns a list of (timestamp, csv_path) tuples read from the
    verification log, asserting basic file existence/type.
    """
    assert VERIFICATION_LOG.exists(), (
        f"Expected verification log {VERIFICATION_LOG} is missing."
    )
    assert VERIFICATION_LOG.is_file(), (
        f"{VERIFICATION_LOG} exists but is not a regular file."
    )

    # Read as *text* because we want to split on newline semantics.
    lines = VERIFICATION_LOG.read_text(encoding="utf-8").splitlines(keepends=False)
    return lines


def test_verification_log_has_correct_structure_and_order():
    lines = parse_verification_log_lines()

    # Must contain exactly two lines—neither more nor less.
    assert len(lines) == 2, (
        f"Verification log must contain exactly 2 lines, found {len(lines)}."
    )

    expected_paths_in_order = [
        "/home/user/cloud_invoices/AWS_2023-07.csv",
        "/home/user/cloud_invoices/GCP_2023-07.csv",
    ]

    seen_paths = []

    for idx, line in enumerate(lines):
        # Regex for the entire line.
        # Example: "2023-08-01 12:34:56|/home/user/cloud_invoices/AWS_2023-07.csv|OK"
        full_re = rf"^{TIMESTAMP_RE}\|(/home/user/cloud_invoices/[A-Za-z0-9_\-]+\.csv)\|OK$"
        m = re.match(full_re, line)
        assert m, (
            f"Line {idx+1} of {VERIFICATION_LOG} does not match the required "
            f'format "YYYY-MM-DD HH:MM:SS|<absolute_path>|OK":\n{line!r}'
        )
        csv_path = m.group(1)
        seen_paths.append(csv_path)

    assert (
        seen_paths == expected_paths_in_order
    ), (
        "Verification log lines are not in the same order as the checksum file.\n"
        f"Expected order: {expected_paths_in_order}\n"
        f"Found order   : {seen_paths}"
    )


def test_only_two_ok_lines_present_in_log():
    """
    Guard against additional stray “|OK” lines that might sneak in and confuse
    auditors or automated graders.
    """
    content = VERIFICATION_LOG.read_text(encoding="utf-8")
    ok_lines = [ln for ln in content.splitlines() if ln.endswith("|OK")]
    assert len(ok_lines) == 2, (
        f"Verification log must contain exactly two lines ending with '|OK', "
        f"found {len(ok_lines)} such lines."
    )