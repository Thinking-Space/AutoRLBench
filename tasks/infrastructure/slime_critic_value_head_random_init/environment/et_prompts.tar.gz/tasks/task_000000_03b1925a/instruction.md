You are playing the role of a FinOps analyst who has just received July-2023 cost-export files from two cloud providers.  
Your objective is to make sure those invoice files have not been tampered with in transit.

For every “*.csv” file in `/home/user/cloud_invoices`, you must calculate a SHA-256 checksum and capture the file size. Based on this, you will create two new files.

**Checksum File**

Create a single, new text file located at `/home/user/checksums/invoice_checksums_July2023.txt`.
This file must contain one line per CSV file, with no header line.

*   **Exact output format** that **will** be machine-checked:
    ```
    <absolute_path_to_csv>|<size_in_bytes>|<lower-case_hex_sha256>
    ```
*   **Example of the required structure** (values will obviously differ):
    ```
    /home/user/cloud_invoices/Dummy.csv|123|1a2b3c...
    ```
*   The file size must be captured in raw bytes, **no thousand separators, no units**.
*   Lines must be ordered in **case-sensitive alphabetical order of the absolute path**.
*   Use the vertical bar character “|” as the only delimiter.
*   Use a single trailing newline after the last line—no blank lines anywhere.

**Execution Log File**

To produce an execution log that makes later audits easy, create `/home/user/checksums/verification_July2023.log` with one line per verified file.

*   **Mandatory line format** (again, checked by the grader):
    ```
    YYYY-MM-DD HH:MM:SS|<absolute_path_to_csv>|OK
    ```
*   Use your system’s current local time when the verification step for each file finishes.
*   The timestamp must be in 24-hour format, zero-padded.
*   The literal string “OK” must appear exactly as shown if the checksum calculation succeeded.
*   Write the log lines in the same order you appended to the checksum file.

**Final Action**

When everything is done, display the contents of both newly created files to the console so a human reviewer can immediately see the results.