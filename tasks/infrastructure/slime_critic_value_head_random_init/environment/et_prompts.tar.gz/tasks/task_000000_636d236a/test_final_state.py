# test_final_state.py
#
# Pytest suite that validates the **final** state of the operating-system /
# container after the student has completed the “observability env settings”
# exercise.
#
# The assertions below are based on the privileged *truth* data provided by
# the platform.  If any of them fails the student’s solution is incomplete or
# incorrect and the error message will explain exactly what is still wrong.

import os
import re
import stat
from pathlib import Path
import pytest

# ---------------------------------------------------------------------------
# CONSTANTS ── absolute paths whose existence, content, and permissions are
#             verified.  Do NOT modify.
# ---------------------------------------------------------------------------
MONITORING_DIR = Path("/home/user/monitoring")
CONF_DIR       = MONITORING_DIR / "conf"
LOGS_DIR       = MONITORING_DIR / "logs"
ENV_SH         = CONF_DIR / "env.sh"
ENV_LOG        = LOGS_DIR / "env_check.log"

EXPECTED_ENV_SH_CONTENT = (
    "# Managed by AI assistant – observability env settings\n"
    "export TZ=\"UTC\"\n"
    "export LC_ALL=\"C\"\n"
)

TIMESTAMP_REGEX = re.compile(
    r"^TIMESTAMP=\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$"
)

# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def _assert_permissions(path: Path, expected_mode: int):
    """
    Ensure path has the exact permission bits given in ``expected_mode`` (e.g.
    0o755).  Fails with an informative message if not.
    """
    actual_mode = stat.S_IMODE(path.stat().st_mode)
    assert actual_mode == expected_mode, (
        f"Path '{path}' has permissions {oct(actual_mode)}, "
        f"expected {oct(expected_mode)}."
    )

def _read_bytes(path: Path) -> bytes:
    with path.open("rb") as fp:
        return fp.read()

# ---------------------------------------------------------------------------
# TESTS
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "path",
    [MONITORING_DIR, CONF_DIR, LOGS_DIR]
)
def test_directories_exist_and_have_correct_permissions(path):
    assert path.exists(), f"Directory '{path}' is missing."
    assert path.is_dir(), f"'{path}' exists but is not a directory."
    _assert_permissions(path, 0o755)


def test_env_sh_exists_and_content_and_permissions():
    assert ENV_SH.exists(), f"Expected file '{ENV_SH}' does not exist."
    assert ENV_SH.is_file(), f"'{ENV_SH}' exists but is not a regular file."
    _assert_permissions(ENV_SH, 0o644)

    content = _read_bytes(ENV_SH).decode("utf-8", errors="replace")
    assert content == EXPECTED_ENV_SH_CONTENT, (
        "The content of 'env.sh' is incorrect.\n"
        "Expected EXACTLY:\n"
        f"{EXPECTED_ENV_SH_CONTENT!r}\n"
        "But got:\n"
        f"{content!r}"
    )


def test_env_log_exists_content_format_and_permissions():
    assert ENV_LOG.exists(), f"Expected file '{ENV_LOG}' does not exist."
    assert ENV_LOG.is_file(), f"'{ENV_LOG}' exists but is not a regular file."
    _assert_permissions(ENV_LOG, 0o644)

    data = _read_bytes(ENV_LOG)
    # Must have exactly three newline characters (=> three lines),
    # and the file must end with '\n'.
    newline_count = data.count(b"\n")
    assert newline_count == 3, (
        f"'env_check.log' must contain exactly 3 newline-terminated lines, "
        f"found {newline_count} newline character(s)."
    )
    assert data.endswith(b"\n"), (
        "'env_check.log' must end with a single trailing newline character."
    )

    try:
        decoded = data.decode("ascii")
    except UnicodeDecodeError:
        pytest.fail("'env_check.log' must contain only ASCII characters.")

    lines = decoded.splitlines()

    # There should be exactly three lines after splitlines().
    assert len(lines) == 3, (
        f"'env_check.log' must contain exactly 3 lines, found {len(lines)}."
    )

    # 1) ISO-8601 UTC time stamp with trailing 'Z'
    assert TIMESTAMP_REGEX.fullmatch(lines[0]), (
        "Line 1 of 'env_check.log' is invalid.\n"
        "Expected format: TIMESTAMP=YYYY-MM-DDTHH:MM:SSZ\n"
        f"Got: {lines[0]!r}"
    )

    # 2) TZ variable
    assert lines[1] == "TZ=UTC", (
        "Line 2 of 'env_check.log' must be exactly 'TZ=UTC'.\n"
        f"Got: {lines[1]!r}"
    )

    # 3) LC_ALL variable
    assert lines[2] == "LC_ALL=C", (
        "Line 3 of 'env_check.log' must be exactly 'LC_ALL=C'.\n"
        f"Got: {lines[2]!r}"
    )