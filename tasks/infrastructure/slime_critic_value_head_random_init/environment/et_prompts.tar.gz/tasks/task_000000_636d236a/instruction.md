You are acting as an observability engineer who wants every metric-collection shell script to run strictly in the UTC time-zone and the classic “C” locale, no matter what the host’s defaults are.

Your goal:

1.  Create an environment-initialisation script called
    `/home/user/monitoring/conf/env.sh`
    that other scripts can source.

    Required **exact** file content (including the comment on the first line and the trailing newline at the very end of the file):
    ```
    # Managed by AI assistant – observability env settings
    export TZ="UTC"
    export LC_ALL="C"
    ```

    *   The first line must start with “#”.
    *   Each export must be on its own line.
    *   The file must end with a single trailing newline.

2.  Produce a one-time verification log
    `/home/user/monitoring/logs/env_check.log`
    whose contents prove that those variables are active.

    Required format of `env_check.log` (three lines, no extra spaces):
    ```
    TIMESTAMP=YYYY-MM-DDTHH:MM:SSZ
    TZ=UTC
    LC_ALL=C
    ```

    *   The first line must be an ISO-8601 UTC timestamp generated at run-time (use the “Z” suffix to show UTC, e.g. `2025-04-19T14:22:05Z`).
    *   The second and third lines must show the effective values of the `TZ` and `LC_ALL` environment variables exactly as above.
    *   Every line must be terminated by a single newline character.
    *   No additional lines, spaces, or characters are allowed.

3.  Make sure both parent directories
    `/home/user/monitoring/conf`
    `/home/user/monitoring/logs`
    exist before creating the files.

Validation the automated grader will perform:

*   `/home/user/monitoring/conf/env.sh` exists and the entire file content is exactly the three lines specified above (including the leading “#” and the trailing newline).
*   `/home/user/monitoring/logs/env_check.log` exists.
*   `env_check.log` contains exactly three newline-terminated lines.
*   Line 1 matches the regex `^TIMESTAMP=\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$`
*   Line 2 is exactly `TZ=UTC`
*   Line 3 is exactly `LC_ALL=C`

No other output or files are required.