#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


apt-get update -y && \
    apt-get install -y python3 python3-pip && \
    true

pip3 install --no-cache-dir pytest

mkdir -p /home/user/logs

cat > /home/user/logs/auth.log <<'EOF'
Jan 21 10:10:10 host sshd[12345]: Failed password for invalid user admin from 192.168.1.20 port 55874 ssh2
Jan 21 10:10:12 host sshd[12346]: Failed password for root from 192.168.1.30 port 55875 ssh2
Jan 21 10:10:13 host sshd[12347]: Accepted password for user1 from 192.168.1.40 port 55876 ssh2
Jan 21 10:10:15 host sshd[12348]: Failed password for user2 from 192.168.1.50 port 55877 ssh2
Jan 21 11:00:00 host sshd[12349]: Failed password for invalid user test from 192.168.1.60 port 55878 ssh2
Jan 21 11:05:00 host sshd[12350]: Failed password for user3 from 192.168.1.70 port 55879 ssh2
Jan 21 12:00:00 host sshd[12351]: Accepted password for user4 from 192.168.1.80 port 55880 ssh2
EOF

chmod 0777 /home/user/logs && \
    chmod 0644 /home/user/logs/auth.log && \
    chmod 755 /home/user

export PATH="/usr/local/bin:/usr/bin:/bin:${PATH}"

mkdir -p /home/user && cd /home/user
