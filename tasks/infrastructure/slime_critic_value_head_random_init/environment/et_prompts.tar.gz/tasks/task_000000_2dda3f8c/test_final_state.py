# test_final_state.py
#
# This pytest suite validates the **final** state of the operating-system
# after the learner has completed the exercise.  It ensures that the report
# file has been created exactly as specified, that the original log file
# remains intact, and that no stray artefacts were left behind.
#
# Rules enforced:
#   * /home/user/logs/failed_login_report.txt must exist and have the exact
#     one-line content:  "Failed login attempts: 5\n"
#   * /home/user/logs/auth.log must remain completely unchanged.
#   * No additional files may exist in /home/user/logs.
#
# Only the Python standard library and pytest are used.

import os
from pathlib import Path

import pytest

HOME = Path("/home/user")
LOG_DIR = HOME / "logs"

AUTH_LOG = LOG_DIR / "auth.log"
REPORT_FILE = LOG_DIR / "failed_login_report.txt"

# Expected exact (stripped) lines inside /home/user/logs/auth.log (same as in
# the initial-state tests, duplicated here for immutability validation).
EXPECTED_AUTH_LOG_LINES = [
    "Jan 21 10:10:10 host sshd[12345]: Failed password for invalid user admin from 192.168.1.20 port 55874 ssh2",
    "Jan 21 10:10:12 host sshd[12346]: Failed password for root from 192.168.1.30 port 55875 ssh2",
    "Jan 21 10:10:13 host sshd[12347]: Accepted password for user1 from 192.168.1.40 port 55876 ssh2",
    "Jan 21 10:10:15 host sshd[12348]: Failed password for user2 from 192.168.1.50 port 55877 ssh2",
    "Jan 21 11:00:00 host sshd[12349]: Failed password for invalid user test from 192.168.1.60 port 55878 ssh2",
    "Jan 21 11:05:00 host sshd[12350]: Failed password for user3 from 192.168.1.70 port 55879 ssh2",
    "Jan 21 12:00:00 host sshd[12351]: Accepted password for user4 from 192.168.1.80 port 55880 ssh2",
]


def _strip_newlines(lines):
    """
    Helper to strip trailing CR/LF from a list of byte or str lines.
    Returns a list of str without line terminators.
    """
    cleaned = []
    for ln in lines:
        if isinstance(ln, bytes):
            ln = ln.decode("utf-8", errors="replace")
        cleaned.append(ln.rstrip("\r\n"))
    return cleaned


@pytest.mark.order(1)
def test_report_file_exists():
    """
    The report file must exist and be a regular file.
    """
    assert REPORT_FILE.exists(), (
        f"Expected report file {REPORT_FILE} does not exist. "
        "Did you create it at the correct path?"
    )
    assert REPORT_FILE.is_file(), f"{REPORT_FILE} exists but is not a regular file."


@pytest.mark.order(2)
def test_report_file_content_exact():
    """
    The content of the report file must match *exactly*:
        Failed login attempts: 5\n
    No extra spaces, lines, or other characters are allowed.
    """
    with REPORT_FILE.open("rb") as fh:
        data = fh.read()

    expected_bytes = b"Failed login attempts: 5\n"
    assert (
        data == expected_bytes
    ), (
        "The content of {file} is incorrect.\n"
        "EXPECTED (repr): {exp!r}\n"
        "ACTUAL   (repr): {act!r}".format(
            file=REPORT_FILE, exp=expected_bytes, act=data
        )
    )


@pytest.mark.order(3)
def test_auth_log_unchanged():
    """
    Verify that /home/user/logs/auth.log is still present and completely
    unchanged from its original state.
    """
    assert AUTH_LOG.exists(), f"Original log file {AUTH_LOG} has gone missing."
    assert AUTH_LOG.is_file(), f"{AUTH_LOG} exists but is not a regular file."

    with AUTH_LOG.open("rb") as fh:
        raw_lines = fh.readlines()

    lines = _strip_newlines(raw_lines)

    # 1. Exact line count
    assert len(lines) == len(
        EXPECTED_AUTH_LOG_LINES
    ), (
        f"{AUTH_LOG} should still contain exactly "
        f"{len(EXPECTED_AUTH_LOG_LINES)} lines, but now contains {len(lines)}."
    )

    # 2. Exact content
    if lines != EXPECTED_AUTH_LOG_LINES:
        diff = [
            f"LINE {idx+1}:\n  EXPECTED: {exp}\n  ACTUAL  : {act}"
            for idx, (exp, act) in enumerate(zip(EXPECTED_AUTH_LOG_LINES, lines))
            if exp != act
        ]
        raise AssertionError(
            f"The content of {AUTH_LOG} has been modified.\n" + "\n".join(diff)
        )


@pytest.mark.order(4)
def test_no_extra_files_in_logs_directory():
    """
    Ensure that no extra files (temporary or otherwise) were created in
    /home/user/logs.  Only 'auth.log' and 'failed_login_report.txt' are allowed.
    """
    allowed = {"auth.log", "failed_login_report.txt"}
    present = {p.name for p in LOG_DIR.iterdir() if p.is_file()}

    extra = present - allowed
    missing = allowed - present

    assert not missing, (
        f"Expected file(s) {', '.join(sorted(missing))} not found in {LOG_DIR}."
    )
    assert not extra, (
        "Unexpected file(s) present in {dir}: {files}. "
        "Please avoid leaving intermediate or temporary files.".format(
            dir=LOG_DIR, files=", ".join(sorted(extra))
        )
    )