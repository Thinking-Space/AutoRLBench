You are acting as a SOC (Security Operations Center) analyst who has been asked to provide a very quick metric from a single Linux host.

1.  A system log file has already been collected and placed at the absolute path
    `/home/user/logs/auth.log`
    (the directory `/home/user/logs` already exists and is writable by the current user).
2.  From that file, determine how many SSH failed-authentication events occurred. Every line that represents a failed SSH password attempt contains the exact phrase:
    `Failed password`
    and no other lines contain this exact phrase.
3.  Produce a one-line text report that follows *exactly* the format shown below—case sensitive, no extra spaces, and terminated by a single trailing newline character:

    `Failed login attempts: N`

    where N is the integer count you extracted.
4.  Save that single-line report to the file
    `/home/user/logs/failed_login_report.txt`
    overwriting the file if it already exists. Do **not** include any other output in that file. No intermediate files should be left behind.

The automated grader will read `/home/user/logs/failed_login_report.txt` directly, expecting the exact format described above.