#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y \
        python3 \
        python3-pip \
        --no-install-recommends && \
    pip3 install --no-cache-dir pytest && \
    true

mkdir -p /home/user/project/locale

cat <<"EOF_EN" > /home/user/project/locale/en_US.ini
[CORE]
greeting = Hello
farewell = Goodbye
prompt   = What would you like to do?
thanks   = Thank you
error_message = An unexpected error has occurred.
EOF_EN

cat <<"EOF_FR" > /home/user/project/locale/fr_FR.ini
[CORE]
greeting = Bonjour
farewell = Au revoir
prompt   = Que voulez-vous faire ?
EOF_FR

echo >> /home/user/project/locale/fr_FR.ini

chmod -R a+rwX /home/user && \
    chmod 755 /home/user

export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"
