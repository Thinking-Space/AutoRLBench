# test_final_state.py
#
# Pytest suite that validates the *final* operating-system / filesystem
# state after the student has synchronised the localisation files.
#
# The tests assert that:
#   1. /home/user/project/locale/fr_FR.ini now contains exactly the five
#      required keys (and only those keys) in the correct order, all inside a
#      single [CORE] section.
#   2. The two new keys (thanks, error_message) have empty values.
#   3. The file ends with exactly one newline character.
#   4. /home/user/project/update_log.txt exists and contains exactly two
#      lines in the required timestamped “ADDED …” format, in the same order
#      the keys were appended to fr_FR.ini.
#
# Only the Python stdlib and pytest are used.

import os
import re
from pathlib import Path

import pytest

HOME = Path("/home/user")
PROJECT_DIR = HOME / "project"
LOCALE_DIR = PROJECT_DIR / "locale"
EN_FILE = LOCALE_DIR / "en_US.ini"          # not modified but kept for reference
FR_FILE = LOCALE_DIR / "fr_FR.ini"
LOG_FILE = PROJECT_DIR / "update_log.txt"

# --------------------------------------------------------------------------- #
# Helper utilities
# --------------------------------------------------------------------------- #
def extract_core_pairs(path: Path):
    """
    Return a list of (key, value) tuples that appear *inside* the [CORE]
    section of the given .ini file, in the exact textual order they occur.

    • Lines that do not contain an '=' sign, or that are blank / comments,
      are ignored.
    • Parsing stops once a new [SECTION] begins (if any).
    """
    pairs = []
    in_core = False
    with path.open(encoding="utf-8") as fh:
        for raw in fh:
            stripped = raw.strip()

            if not stripped or stripped.startswith(("#", ";")):
                continue  # skip blanks & comments

            # Section header?
            if stripped.startswith("[") and stripped.endswith("]"):
                section_name = stripped[1:-1].strip().lower()
                in_core = section_name == "core"
                continue

            if in_core:
                # If the line starts another section, break
                if "[" in stripped and "]" in stripped:
                    break

                if "=" in stripped:
                    key, _, value = stripped.partition("=")
                    pairs.append((key.strip(), value.strip()))
    return pairs


def file_ends_with_single_newline(path: Path) -> bool:
    """
    Return True if the file ends with exactly one '\n' character (Unix style)
    and NOT with two or more consecutive newline characters.
    """
    with path.open("rb") as fh:
        content = fh.read()

    # Empty files are outside the scope here; just be defensive
    if not content:
        return False

    # Must end with \n
    if not content.endswith(b"\n"):
        return False

    # Must NOT end with two consecutive \n
    return not content.endswith(b"\n\n")


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #
def test_translation_file_exists():
    assert FR_FILE.is_file(), (
        f"Expected translation file {FR_FILE} does not exist."
    )


def test_translation_file_core_section_contents():
    expected_order = [
        ("greeting", "Bonjour"),
        ("farewell", "Au revoir"),
        ("prompt", "Que voulez-vous faire ?"),
        ("thanks", ""),
        ("error_message", ""),
    ]

    core_pairs = extract_core_pairs(FR_FILE)

    found_keys = [k for k, _ in core_pairs]
    expected_keys = [k for k, _ in expected_order]
    assert found_keys == expected_keys, (
        f"{FR_FILE} must contain the keys {expected_keys} "
        f"in that exact order inside the [CORE] section.\n"
        f"Currently found order: {found_keys}"
    )

    # Verify the associated values (after stripping whitespace)
    for (exp_key, exp_val), (_, found_val) in zip(expected_order, core_pairs):
        if exp_val:  # Non-empty string
            assert found_val == exp_val, (
                f"Key '{exp_key}' in {FR_FILE} should have the value "
                f"'{exp_val}', but found '{found_val}'."
            )
        else:
            assert found_val == "", (
                f"Key '{exp_key}' in {FR_FILE} should have an empty value "
                f"(nothing after '='), but found '{found_val}'."
            )


def test_translation_file_has_single_core_section():
    """
    Ensure there is only one [CORE] section – the file must not contain
    duplicates that could confuse parsers.
    """
    with FR_FILE.open(encoding="utf-8") as fh:
        section_headers = [
            line.strip().lower()
            for line in fh
            if line.strip().startswith("[") and line.strip().endswith("]")
        ]

    core_count = section_headers.count("[core]")
    assert core_count == 1, (
        f"{FR_FILE} contains {core_count} [CORE] sections; "
        "exactly one is required."
    )


def test_translation_file_trailing_newline():
    assert file_ends_with_single_newline(FR_FILE), (
        f"{FR_FILE} must end with exactly one newline character "
        "(and not multiple)."
    )


def test_update_log_exists():
    assert LOG_FILE.is_file(), (
        f"Expected log file {LOG_FILE} does not exist."
    )


def test_update_log_format_and_contents():
    """
    The log file must:
      • Contain exactly two lines.
      • Each line must match the regex
        ^YYYY-MM-DD HH:MM:SS - ADDED (thanks|error_message)$
      • First line documents 'thanks', second 'error_message'.
    """
    with LOG_FILE.open(encoding="utf-8") as fh:
        lines = [ln.rstrip("\n") for ln in fh]

    assert len(lines) == 2, (
        f"{LOG_FILE} must contain exactly 2 lines, but contains {len(lines)}."
    )

    # Regex to validate the strict format
    pattern = re.compile(
        r"^\d{4}-\d{2}-\d{2} "          # Date  YYYY-MM-DD
        r"\d{2}:\d{2}:\d{2} "           # Time  HH:MM:SS
        r"- ADDED (thanks|error_message)$"
    )

    for idx, line in enumerate(lines, start=1):
        assert pattern.match(line), (
            f"Line {idx} of {LOG_FILE} does not match the required format:\n"
            f"  {line}\n"
            "Expected pattern:\n"
            "  YYYY-MM-DD HH:MM:SS - ADDED <key_name>"
        )

    # Confirm the order of keys in the log
    first_key = lines[0].split()[-1]
    second_key = lines[1].split()[-1]
    assert (first_key, second_key) == ("thanks", "error_message"), (
        f"{LOG_FILE} must list 'thanks' on the first line and "
        f"'error_message' on the second line, but found: "
        f"first='{first_key}', second='{second_key}'."
    )


def test_update_log_trailing_newlines():
    """
    The log file must be newline-terminated, and must NOT have blank lines
    after the two records.
    """
    with LOG_FILE.open("rb") as fh:
        content = fh.read()

    # Must end with a single '\n'
    assert content.endswith(b"\n"), (
        f"{LOG_FILE} must be terminated by a newline character."
    )
    assert not content.endswith(b"\n\n"), (
        f"{LOG_FILE} must NOT end with more than one newline."
    )