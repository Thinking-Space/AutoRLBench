You are acting as a localization engineer who has just received an updated master English-language INI file.  
Your assignment is to synchronize the existing French translation file with the new keys that were added to the master.

**Existing project layout**
1. `/home/user/project/locale/en_US.ini` ➜ the master file  
2. `/home/user/project/locale/fr_FR.ini` ➜ the French translation file

**Current contents**
• `/home/user/project/locale/en_US.ini`  
```
[CORE]
greeting = Hello
farewell = Goodbye
prompt   = What would you like to do?
thanks   = Thank you
error_message = An unexpected error has occurred.
```

• `/home/user/project/locale/fr_FR.ini`  
```
[CORE]
greeting = Bonjour
farewell = Au revoir
prompt   = Que voulez-vous faire ?
```

**Task**

Identify every key that exists in `en_US.ini` but is missing in `fr_FR.ini`. Append these missing keys to `/home/user/project/locale/fr_FR.ini`, preserving the exact key order found in `en_US.ini`.

*   The value placed after the equal sign for every newly-added key must be an empty string.  
*   Keep the file’s existing `[CORE]` section; do NOT create a second `[CORE]` section.  

Additionally, produce a plain-text report file named `/home/user/project/update_log.txt` that records exactly which keys were added and when.

**Strict output format for `/home/user/project/update_log.txt`**
*   One line per added key.  
*   Each line must follow the pattern (no extra spaces):
    `YYYY-MM-DD HH:MM:SS - ADDED <key_name>`
*   Use your system’s current local time for the timestamp.  
*   Lines must appear in the same order the keys were added to `fr_FR.ini`.

When you are finished, only the two missing keys—`thanks` and `error_message`—should have been appended to `fr_FR.ini` with empty values, and `update_log.txt` should list exactly two lines documenting those additions.

**Deliverables to verify**
*   `/home/user/project/locale/fr_FR.ini` contains a `[CORE]` section with five keys in the order: `greeting`, `farewell`, `prompt`, `thanks`, `error_message` (with `thanks =` and `error_message =` having no text after the equal sign).
*   `/home/user/project/update_log.txt` exists and follows the exact format described above with precisely two entries.

Do NOT output the updated files here; perform the edits directly in the filesystem from the terminal. The automated tests will inspect the files for correctness.