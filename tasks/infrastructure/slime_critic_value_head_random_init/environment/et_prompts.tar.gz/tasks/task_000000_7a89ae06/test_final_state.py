# test_final_state.py
#
# This pytest suite validates the **FINAL** state of the workspace
# *after* the student’s script has run.  It checks that
#
#   1. /home/user/build_logs/error_summary.csv exists.
#   2. The CSV conforms exactly to the required specification and
#      contains the correct data.
#   3. The original branch_*.log files are still present **and
#      unmodified** (students were told not to touch them).
#
# Only the Python standard library and pytest are used.

import os
from pathlib import Path
import stat
import pytest

HOME = Path("/home/user")
BUILD_LOGS_DIR = HOME / "build_logs"
SUMMARY_FILE = BUILD_LOGS_DIR / "error_summary.csv"

# ---------------------------------------------------------------------------
# 1. Invariant expectations for the original log files
# ---------------------------------------------------------------------------

EXPECTED_LOG_FILES = {
    "branch_main.log",
    "branch_release.log",
    "branch_featureA.log",
}

EXPECTED_LOG_CONTENTS = {
    "branch_main.log": [
        "BuildStart: 2023-08-15 14:23:11",
        "[INFO] Checking dependencies",
        "[ERROR:] Missing library xyz",
        "[INFO] Build aborted",
    ],
    "branch_release.log": [
        "BuildStart: 2023-08-16 09:04:51",
        "[INFO] Preparing build",
        "[INFO] Compiling...",
        "[FAILURE:] Unit tests failed",
        "[ERROR:] Code signing failed",
        "[INFO] Build failed",
    ],
    "branch_featureA.log": [
        "BuildStart: 2023-08-17 11:39:05",
        "[INFO] Setup...",
        "[INFO] Build succeeded",
        "[INFO] Cleaning up",
    ],
}

# We will also need these values when computing the *expected* CSV.
EXPECTED_BRANCH_DATA = {
    # branch : (timestamp, error_count, first_error_line)
    "featureA": ("2023-08-17 11:39:05", 0, "-"),
    "main": ("2023-08-15 14:23:11", 1, "[ERROR:] Missing library xyz"),
    "release": ("2023-08-16 09:04:51", 2, "[FAILURE:] Unit tests failed"),
}


# ---------------------------------------------------------------------------
# 2. Helper functions
# ---------------------------------------------------------------------------

def read_text_lines(path: Path):
    """
    Read a text file in UTF-8 and return a list of lines **without**
    trailing LF characters.  Assert that all newlines are LF ('\\n') and
    that the file is encoded in UTF-8 without a BOM.
    """
    raw = path.read_bytes()
    # No UTF-8 BOM allowed.
    bom = b'\xef\xbb\xbf'
    assert not raw.startswith(bom), (
        f"{path} contains a UTF-8 BOM, which is forbidden."
    )
    # All newlines must be LF only.
    assert b'\r' not in raw, (
        f"{path} contains CR characters; newlines must be LF only."
    )
    # File must end with exactly one newline so that readline behaviour
    # is well defined.
    assert raw.endswith(b'\n'), (
        f"{path} must end with a single LF newline."
    )
    text = raw.decode('utf-8')
    # splitlines() drops the trailing newline, which is what we want.
    return text.split('\n')[:-1]  # drop the final empty element


def get_file_metadata(path: Path):
    """
    Return size and mtime so that we can check later that a file was
    *not* modified by the student's script.
    """
    st = path.stat()
    return st.st_size, st.st_mtime


# ---------------------------------------------------------------------------
# 3. Record initial metadata of the log files so that we can later assert
#    they have not been changed.
# ---------------------------------------------------------------------------

INITIAL_METADATA = {
    filename: get_file_metadata(BUILD_LOGS_DIR / filename)
    for filename in EXPECTED_LOG_FILES
}


# ---------------------------------------------------------------------------
# 4. Tests
# ---------------------------------------------------------------------------

def test_summary_file_exists():
    """
    /home/user/build_logs/error_summary.csv must exist and be a regular file.
    """
    assert SUMMARY_FILE.exists(), f"{SUMMARY_FILE} is missing."
    assert SUMMARY_FILE.is_file(), f"{SUMMARY_FILE} exists but is not a regular file."


def test_summary_file_permissions():
    """
    The summary file should be world-readable (at least 0o644) so
    downstream jobs can read it.
    """
    mode = SUMMARY_FILE.stat().st_mode
    assert stat.S_IMODE(mode) & 0o444 == 0o444, (
        f"{SUMMARY_FILE} is not world-readable; current mode is "
        f"{oct(stat.S_IMODE(mode))}"
    )


def test_summary_file_exact_content():
    """
    The CSV must match the byte-for-byte expected content.
    """
    expected_lines = ["branch,timestamp,error_count,first_error_line"]
    for branch in sorted(EXPECTED_BRANCH_DATA.keys()):  # ASCII order
        ts, count, first = EXPECTED_BRANCH_DATA[branch]
        expected_lines.append(f"{branch},{ts},{count},{first}")

    actual_lines = read_text_lines(SUMMARY_FILE)

    assert actual_lines == expected_lines, (
        f"Content of {SUMMARY_FILE} does not match the expected CSV.\n\n"
        f"Expected lines:\n{expected_lines!r}\n\nActual lines:\n{actual_lines!r}"
    )


def test_summary_file_line_count():
    """
    Validate the number of data rows (should match the number of
    branch_*.log files processed).
    """
    rows = read_text_lines(SUMMARY_FILE)
    header, data_rows = rows[0], rows[1:]
    assert header == "branch,timestamp,error_count,first_error_line", (
        "CSV header line is incorrect."
    )
    assert len(data_rows) == len(EXPECTED_LOG_FILES), (
        f"CSV should contain {len(EXPECTED_LOG_FILES)} data lines but "
        f"has {len(data_rows)}."
    )


def test_summary_error_totals():
    """
    Parse the CSV and verify that the total error_count column equals 3,
    as per the known ground truth.
    """
    rows = read_text_lines(SUMMARY_FILE)[1:]  # skip header
    total_errors = 0
    for line in rows:
        parts = line.split(",", 3)
        assert len(parts) == 4, (
            f"CSV line has wrong number of fields: {line!r}"
        )
        total_errors += int(parts[2])

    assert total_errors == 3, (
        f"Total error_count across CSV rows should be 3 but is {total_errors}."
    )


# ---------------------------------------------------------------------------
# 5. Verify that the original log files are still intact (contents AND
#    metadata) – students were instructed not to touch them.
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("filename", sorted(EXPECTED_LOG_FILES))
def test_original_log_files_unchanged(filename):
    """
    Confirm that each branch_*.log file still exists **and** is byte-for-byte
    identical to the original version recorded at test collection time.
    """
    path = BUILD_LOGS_DIR / filename
    assert path.exists(), f"Required log file {path} has been removed."
    assert path.is_file(), f"{path} exists but is not a regular file."

    # Size and mtime must match what we recorded before any student code ran.
    size_now, mtime_now = get_file_metadata(path)
    size_initial, mtime_initial = INITIAL_METADATA[filename]

    assert size_now == size_initial, (
        f"{path} has changed size (was {size_initial} bytes, now {size_now} bytes)."
    )
    assert mtime_now == mtime_initial, (
        f"{path} modification time has changed; the file should not be edited."
    )

    # Content check (reading is cheap and 100% certain).
    expected_lines = EXPECTED_LOG_CONTENTS[filename]
    actual_lines = read_text_lines(path)

    assert actual_lines == expected_lines, (
        f"Content of {path} has been modified.\n"
        f"Expected:\n{expected_lines!r}\n\nGot:\n{actual_lines!r}"
    )