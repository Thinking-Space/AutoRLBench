#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    export DEBIAN_FRONTEND=noninteractive && \
    apt-get update && \
    apt-get install -y --no-install-recommends python3 python3-pip && \
    pip3 install --no-cache-dir pytest && \
    true

mkdir -p /home/user/build_logs

cat >/home/user/build_logs/branch_main.log <<'EOF'
BuildStart: 2023-08-15 14:23:11
[INFO] Checking dependencies
[ERROR:] Missing library xyz
[INFO] Build aborted
EOF

cat >/home/user/build_logs/branch_release.log <<'EOF'
BuildStart: 2023-08-16 09:04:51
[INFO] Preparing build
[INFO] Compiling...
[FAILURE:] Unit tests failed
[ERROR:] Code signing failed
[INFO] Build failed
EOF

cat >/home/user/build_logs/branch_featureA.log <<'EOF'
BuildStart: 2023-08-17 11:39:05
[INFO] Setup...
[INFO] Build succeeded
[INFO] Cleaning up
EOF

rm -f /home/user/build_logs/error_summary.csv || true

chmod -R a+rwX /home/user

export LC_ALL=C.UTF-8

export LANG=C.UTF-8
