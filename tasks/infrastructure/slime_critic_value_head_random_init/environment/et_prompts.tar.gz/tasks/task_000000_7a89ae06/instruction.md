You are acting as the build-and-release engineer for a mobile-app CI/CD system.  
Inside the workspace there is already a directory

    /home/user/build_logs

containing several historical build log files.  
Your assignment is to create a single CSV file that summarises which branches failed and why, so that a downstream metrics job can consume it.

Process every file in `/home/user/build_logs` whose name starts with exactly “branch_” and ends in “.log”. Do not touch any other files.

For every such log file, determine the following information:
*   **branch** – the portion of the filename between “branch_” and “.log”.
*   **timestamp** – the date-time that appears after the string “BuildStart:” on the very first line of the file.
*   **error_count** – the number of lines inside that same file that contain either the substring “ERROR:” or the substring “FAILURE:”.
*   **first_error_line** – the very first line (in original order) that contains one of those two substrings, stripped of leading/trailing white-space.
    *   If the file contains zero error lines, this value should be a single dash character “-” (without the quotes).

Write the collected data to the new file:

    /home/user/build_logs/error_summary.csv

The CSV must obey ALL of the following formatting rules so that an automated test can parse it:

*   It is plain UTF-8 text, no BOM.
*   The first line is a header line and MUST be exactly:

        branch,timestamp,error_count,first_error_line

*   One subsequent line per processed log file.
*   Lines are ordered by the branch name in strict ASCII ascending order (a-z).
*   Fields are separated by a literal comma “,” with no spaces around the comma.
*   The newline separator is LF (‘\n’), even on macOS or Windows.
*   Do not surround fields with quotes, even if they contain spaces or special characters.
*   If `first_error_line` is “-”, it must be exactly a single dash.

After creating the CSV, print a one-line summary to STDOUT in the exact format:

    Processed N builds with a total of M error(s). Summary stored at /home/user/build_logs/error_summary.csv

where:
*   `N` is the count of “branch_*.log” files you processed, and
*   `M` is the sum of the `error_count` column you just wrote.

**SUCCESS CRITERIA**

The test will check that:
*   `/home/user/build_logs/error_summary.csv` exists.
*   Its content matches the rules above exactly.
*   The line printed to STDOUT follows the required wording and the numbers match what is inside the CSV.

Do NOT move, rename or delete the original log files.  
You do NOT need root privileges.  
All work must happen in `/home/user` and its sub-directories only.