#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3 \
        python3-pip && \
    pip3 install --no-cache-dir pytest

export BASE=/home/user

mkdir -p /home/user/deployment/releases && \
    mkdir -p /home/user/deployment/config && \
    mkdir -p /home/user/deployment/releases/v1.0.0 && \
    mkdir -p /home/user/deployment/releases/v1.1.0 && \
    mkdir -p /home/user/deployment/releases/v1.2.0

cat > /home/user/deployment/releases/v1.0.0/NOTES.md <<'EOF'
FEATURE: Add login functionality
FEATURE: Add logout functionality
FIX: Correct typo in README
EOF

cat > /home/user/deployment/releases/v1.1.0/NOTES.md <<'EOF'
FEATURE: Add password reset
EOF

cat > /home/user/deployment/releases/v1.2.0/NOTES.md <<'EOF'
FEATURE: Improve UI
FIX: Fix crash on launch
FEATURE: Add dark mode
FIX: Memory leak fix
FEATURE: Optimize database queries
EOF

cat > /home/user/deployment/config/app.conf <<'EOF'
# Application configuration
environment=staging
# the version key will be added/updated by the agent
EOF

chmod -R a+rX /home/user/deployment

chmod 755 /home/user

python3 -c "import pytest; print('pytest version:', pytest.__version__)"
