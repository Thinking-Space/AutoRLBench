You are a deployment engineer who has just finished pushing three successive
    application releases into the staging area located under
    /home/user/deployment/releases/.  
    Every release directory (e.g. /home/user/deployment/releases/v1.0.0/)
    already contains a markdown file named NOTES.md that enumerates every
    user-visible change in that release.

Your goal is to prepare the staging area so that the deployment pipeline can promote the latest build to production.

*   Create a release-wide changelog file at
    /home/user/deployment/changelog.log using *exactly* the following
    fixed-width, pipe-separated layout (the automated tests will check exact
    spacing, capitalisation and number formatting):

       Release | Features | Fixes
       vX.Y.Z  | <N>      | <M>

    *   The very first line must be the literal header shown above
        (single spaces around the pipes, capital “R” in “Release”).
    *   One data line per release must follow, sorted in ascending semantic-
        version order (v1.0.0 first, v1.1.0 second, and so on).
    *   Count how many lines inside each NOTES.md start with the exact prefix
        “FEATURE:” (features) or “FIX:” (fixes) to populate &lt;N&gt; and &lt;M&gt;.
    *   The spacing must match the header column widths:
        *   “Release” column 8 characters wide (left-aligned)
        *   “Features” column 9 characters wide (right-aligned)
        *   “Fixes” column 6 characters wide (right-aligned)
        Use plain spaces, no tabs.

    Example of a single, correctly aligned data line  
    (DO **NOT** copy; generate real numbers):
       v1.0.0 |         2 |     1

*   Append a one-line audit entry to /home/user/deployment/logs/update_actions.log
    (create intermediate directories if they do not exist).  
    The line must follow this exact pattern (single spaces only):

       [YYYY-MM-DD HH:MM] generated changelog for X releases

    where the timestamp is the current system time **in UTC** when the line
    is written, and X is the count of releases processed (should be “3” given
    the current staging contents).

*   Edit /home/user/deployment/config/app.conf so that the property

       version=

    is updated (or added if missing) to contain the latest semantic version
    found in the release directories (e.g. “version=1.2.0”). Leave every other line
    of the file unchanged and preserve its original order.

Verification notes for you:
*   All three paths must exist when you are done:
    /home/user/deployment/changelog.log
    /home/user/deployment/logs/update_actions.log
    /home/user/deployment/config/app.conf
*   The automated grader will perform byte-level comparison of
    /home/user/deployment/changelog.log and a regex match for the audit line,
    so follow the instructed spacing and punctuation exactly.
*   Do not hard-code any numbers; derive counts programmatically from the
    NOTES.md files.