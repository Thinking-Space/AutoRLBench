# test_final_state.py
#
# Robust pytest suite that validates the **final** state of the operating
# system / container *after* the student has completed the assignment.
#
# The tests make no assumptions about *how* the student produced the artefacts;
# they only assert that the observable end-state matches the specification and
# the privileged truth data supplied to the grader.
#
# ──────────────────────────────────────────────────────────────────────────────
# What is validated:
#
# 1. /home/user/deployment/changelog.log
#    • Must exist and contain exactly four lines:
#        – a mandatory header
#        – one data line for each release directory present underneath
#          /home/user/deployment/releases/
#    • Data lines must be in ascending semantic-version order.
#    • Column widths, spacing and alignment must match the spec
#      (Release 8 left-aligned | Features 9 right-aligned | Fixes 6 right-aligned).
#
# 2. /home/user/deployment/logs/update_actions.log
#    • Must exist and contain *at least one* line that matches
#      r"^\[20\d{2}-\d{2}-\d{2} \d{2}:\d{2}\] generated changelog for 3 releases$"
#
# 3. /home/user/deployment/config/app.conf
#    • Must contain exactly one line beginning with "version=" whose value is
#      the latest semantic version encountered in the releases directory.
#    • All pre-existing lines (e.g. "environment=staging") must still be present.
#
# Only the Python standard library and pytest are used.

import re
from pathlib import Path
from typing import Dict, List, Tuple

import pytest

# ──────────────────────────────────────────────────────────────────────────────
# Constant paths
HOME = Path("/home/user")
DEPLOYMENT = HOME / "deployment"
RELEASES_DIR = DEPLOYMENT / "releases"
CHANGELOG = DEPLOYMENT / "changelog.log"
UPDATE_LOG = DEPLOYMENT / "logs" / "update_actions.log"
APP_CONF = DEPLOYMENT / "config" / "app.conf"

# -----------------------------------------------------------------------------
# Helper functions
# -----------------------------------------------------------------------------


def parse_version(ver: str) -> Tuple[int, int, int]:
    """
    Convert a semantic version string like 'v1.2.3' to an (1, 2, 3) tuple that
    is sortable in natural ascending order.
    """
    if not ver.startswith("v"):
        pytest.fail(f"Release directory name '{ver}' does not start with 'v'.")
    try:
        major, minor, patch = map(int, ver[1:].split("."))
    except ValueError as exc:  # pragma: no cover
        pytest.fail(f"Could not parse semantic version '{ver}': {exc}")
    return major, minor, patch


def collect_expected_counts() -> Dict[str, Tuple[int, int]]:
    """
    Scan every NOTES.md underneath the releases directory and return a mapping
    {version_str: (feature_count, fix_count)}.
    """
    expected: Dict[str, Tuple[int, int]] = {}

    for release_dir in RELEASES_DIR.iterdir():
        if not release_dir.is_dir():
            continue
        version = release_dir.name

        notes_file = release_dir / "NOTES.md"
        assert notes_file.is_file(), (
            f"Expected {notes_file} to exist so that feature/fix counts can be "
            "computed, but it is missing."
        )

        features = fixes = 0
        with notes_file.open(encoding="utf-8") as fp:
            for line in fp:
                if line.startswith("FEATURE:"):
                    features += 1
                elif line.startswith("FIX:"):
                    fixes += 1

        expected[version] = (features, fixes)

    assert expected, (
        f"No release directories found under {RELEASES_DIR}. "
        "Cannot verify changelog without them."
    )
    return expected


def build_expected_changelog_text() -> str:
    """
    Build the exact expected contents of /home/user/deployment/changelog.log
    based on the current NOTES.md files and the formatting rules in the spec.
    """
    counts = collect_expected_counts()
    versions_sorted: List[str] = sorted(counts, key=parse_version)

    header = "Release | Features | Fixes\n"

    data_lines: List[str] = []
    for ver in versions_sorted:
        feats, fixs = counts[ver]
        # Fixed-width, pipe-separated formatting.
        release_col = f"{ver:<8}"          # 8-char, left-aligned
        features_col = f"{feats:>9}"       # 9-char, right-aligned
        fixes_col = f"{fixs:>6}"           # 6-char, right-aligned
        line = f"{release_col} | {features_col} | {fixes_col}\n"
        data_lines.append(line)

    return header + "".join(data_lines)


# -----------------------------------------------------------------------------
# Tests
# -----------------------------------------------------------------------------


def test_changelog_exists_and_content_exact():
    """
    The changelog file must exist and match the *exact* expected bytes, including
    trailing newlines, spacing and alignment.
    """
    assert CHANGELOG.is_file(), (
        f"Changelog file {CHANGELOG} is missing. "
        "Did you create it at the correct absolute path?"
    )

    actual_bytes = CHANGELOG.read_bytes()
    expected_text = build_expected_changelog_text()
    expected_bytes = expected_text.encode("utf-8")

    assert (
        actual_bytes == expected_bytes
    ), (
        "The contents of changelog.log do not match the expected layout "
        "or data.\n\n"
        f"--- Expected ({len(expected_bytes)} bytes) ---\n"
        f"{expected_text}"
        f"--- Got ({len(actual_bytes)} bytes) ---\n"
        f"{actual_bytes.decode('utf-8', errors='replace')}"
    )

    # Extra defence: ensure exactly 4 lines (header + 3 releases).
    lines = expected_text.splitlines(keepends=False)
    assert len(lines) == 4, "`build_expected_changelog_text` should yield 4 lines."
    actual_lines = actual_bytes.decode("utf-8").splitlines()
    assert len(actual_lines) == 4, (
        f"changelog.log should contain exactly 4 lines "
        f"(header + 3 releases) but contains {len(actual_lines)}."
    )


def test_update_actions_log_entry_present():
    """
    update_actions.log must contain at least one correctly formatted audit line.
    """
    assert UPDATE_LOG.is_file(), (
        f"Log file {UPDATE_LOG} is missing. "
        "Did you create it at the correct absolute path?"
    )

    pattern = re.compile(
        r"^\[20\d{2}-\d{2}-\d{2} \d{2}:\d{2}\] generated changelog for 3 releases$"
    )

    with UPDATE_LOG.open(encoding="utf-8") as fp:
        lines = [ln.rstrip("\n") for ln in fp]

    assert any(pattern.fullmatch(ln) for ln in lines), (
        "No valid audit entry found inside update_actions.log.\n"
        "Each line must match:\n"
        "[YYYY-MM-DD HH:MM] generated changelog for 3 releases"
    )


def test_app_conf_version_updated_correctly():
    """
    app.conf must contain exactly one 'version=' entry and its value must be the
    latest semantic version discovered among the release directories.
    """
    assert APP_CONF.is_file(), (
        f"Configuration file {APP_CONF} is missing. "
        "Did you create it at the correct absolute path?"
    )

    with APP_CONF.open(encoding="utf-8") as fp:
        lines = [ln.rstrip("\n") for ln in fp]

    # Ensure the pre-existing key is still there.
    assert any(ln.strip() == "environment=staging" for ln in lines), (
        f"{APP_CONF} is expected to still contain the line 'environment=staging', "
        "but it is missing."
    )

    version_lines = [ln for ln in lines if ln.lstrip().startswith("version=")]
    assert len(version_lines) == 1, (
        f"{APP_CONF} should contain exactly one 'version=' entry, "
        f"but found {len(version_lines)}: {version_lines!r}"
    )

    # Determine the latest version among the releases.
    latest_version = max(collect_expected_counts(), key=parse_version)
    expected_version_line = f"version={latest_version[1:]}"  # strip leading 'v'

    assert (
        version_lines[0].strip() == expected_version_line
    ), (
        f"The 'version=' entry in {APP_CONF} should be '{expected_version_line}' "
        f"but is '{version_lines[0].strip()}'."
    )


# End of file