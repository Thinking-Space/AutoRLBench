# test_final_state.py
"""
Robust pytest suite that validates the **FINAL** operating-system / container
state after the student has completed the archiving & monitoring task.

The assertions below use the privileged *truth* data supplied by the exercise
author and therefore know the one exact, correct end-state.

If any check fails, the accompanying assertion message explains **precisely**
what is still wrong so the student can fix it quickly.

The tests purposefully use **absolute** paths only (never relative ones) as
required by the grading specification.
"""

from pathlib import Path
import pytest

# --------------------------------------------------------------------------- #
# Constants                                                                   #
# --------------------------------------------------------------------------- #

HOME = Path("/home/user")

# Directories
EXPERIMENTS_DIR = HOME / "experiments"
ARCHIVE_DIR = EXPERIMENTS_DIR / "2024-06-15_run_42"
RAW_RUN_DIR = HOME / "raw_runs" / "run_42"  # May or may not still exist

# Files inside the archive
MODEL_FILE = ARCHIVE_DIR / "model.pt"
METRICS_JSON_FILE = ARCHIVE_DIR / "metrics.json"
SYSMON_LOG = ARCHIVE_DIR / "sysmon.log"
REPORT_FILE = ARCHIVE_DIR / "experiment_report.txt"

# Expected file contents ----------------------------------------------------- #

EXPECTED_SYSMON_LINES = [
    "2024-06-15T00:00:01 CPU: 23.1% | MEM: 45.2%\n",
    "2024-06-15T00:00:02 CPU: 25.5% | MEM: 46.1%\n",
    "2024-06-15T00:00:03 CPU: 26.3% | MEM: 47.0%\n",
    "2024-06-15T00:00:04 CPU: 24.1% | MEM: 46.5%\n",
    "2024-06-15T00:00:05 CPU: 22.8% | MEM: 45.9%\n",
]

EXPECTED_REPORT_LINES = [
    "Experiment: run_42\n",
    "Artifacts: model.pt, metrics.json\n",
    "System monitor log lines: 5\n",
    "Peak CPU: 26.3%\n",
    "Peak MEM: 47.0%\n",
]


# --------------------------------------------------------------------------- #
# Helper functions                                                            #
# --------------------------------------------------------------------------- #

def _assert_is_dir(path: Path):
    assert path.exists(), f"Directory is missing: {path}"
    assert path.is_dir(), f"Expected a directory at {path}, but found something else"


def _assert_is_file(path: Path):
    assert path.exists(), f"Required file is missing: {path}"
    assert path.is_file(), f"{path} exists but is not a regular file"


# --------------------------------------------------------------------------- #
# Tests                                                                       #
# --------------------------------------------------------------------------- #

def test_archive_directory_exists():
    """
    The new archive directory must have been created exactly as specified.
    """
    _assert_is_dir(ARCHIVE_DIR)


def test_artifact_files_moved_and_intact():
    """
    model.pt (0-byte) and metrics.json (two-character file) must now live in
    the archive directory and **must not** still exist in their old location.
    """
    # --- Inside archive ------------------------------------------------------
    # model.pt
    _assert_is_file(MODEL_FILE)
    size_model = MODEL_FILE.stat().st_size
    assert size_model == 0, (
        f"{MODEL_FILE} should still be an empty placeholder (0 bytes) "
        f"but is {size_model} bytes"
    )

    # metrics.json
    _assert_is_file(METRICS_JSON_FILE)
    content_metrics = METRICS_JSON_FILE.read_text(encoding="utf-8")
    assert content_metrics == "{}\n", (
        f"{METRICS_JSON_FILE} content mismatch.\n"
        f"Expected: '{{}}\\n'\n"
        f"Found:    {content_metrics!r}"
    )

    # --- No longer at original location -------------------------------------
    old_model = RAW_RUN_DIR / "model.pt"
    old_metrics = RAW_RUN_DIR / "metrics.json"

    assert not old_model.exists(), (
        f"{old_model} should have been moved to {ARCHIVE_DIR} but still exists"
    )
    assert not old_metrics.exists(), (
        f"{old_metrics} should have been moved to {ARCHIVE_DIR} but still exists"
    )


def test_sysmon_log_contents_exact():
    """
    sysmon.log must contain exactly the five expected lines, in order, with
    correct timestamps and utilisation figures (one decimal place).
    """
    _assert_is_file(SYSMON_LOG)

    lines = SYSMON_LOG.read_text(encoding="utf-8").splitlines(keepends=True)
    assert lines == EXPECTED_SYSMON_LINES, (
        f"{SYSMON_LOG} content mismatch.\n"
        "Expected lines:\n"
        + "".join(EXPECTED_SYSMON_LINES)
        + "Found lines:\n"
        + "".join(lines)
    )


def test_experiment_report_contents_exact():
    """
    experiment_report.txt must contain exactly five lines that match the
    required template and whose peak values line up with sysmon.log.
    """
    _assert_is_file(REPORT_FILE)

    report_lines = REPORT_FILE.read_text(encoding="utf-8").splitlines(keepends=True)
    assert report_lines == EXPECTED_REPORT_LINES, (
        f"{REPORT_FILE} content mismatch.\n"
        "Expected lines:\n"
        + "".join(EXPECTED_REPORT_LINES)
        + "Found lines:\n"
        + "".join(report_lines)
    )


def test_consistency_between_report_and_sysmon():
    """
    Cross-check: the numeric values stated in experiment_report.txt must truly
    reflect the data in sysmon.log.  This guards against a hard-coded report.
    """
    # Parse utilisation numbers from sysmon.log ------------------------------
    sysmon_lines = [
        ln.strip() for ln in SYSMON_LOG.read_text(encoding="utf-8").splitlines()
    ]

    cpu_values = []
    mem_values = []
    for ln in sysmon_lines:
        # Example line:
        # 2024-06-15T00:00:01 CPU: 23.1% | MEM: 45.2%
        try:
            timestamp_part, rest = ln.split(" CPU: ")
            cpu_part, mem_part = rest.split(" | MEM: ")
            cpu_values.append(float(cpu_part.rstrip("%")))
            mem_values.append(float(mem_part.rstrip("%")))
        except ValueError:
            pytest.fail(f"Line in {SYSMON_LOG} has unexpected format: {ln!r}")

    assert len(cpu_values) == 5, "sysmon.log should have exactly 5 utilisation lines"

    # Determine peaks
    peak_cpu = max(cpu_values)
    peak_mem = max(mem_values)

    # Extract the numbers reported in experiment_report.txt ------------------
    report_lines = [
        ln.strip() for ln in REPORT_FILE.read_text(encoding="utf-8").splitlines()
    ]
    try:
        reported_cpu = float(report_lines[3].split(": ")[1].rstrip("%"))
        reported_mem = float(report_lines[4].split(": ")[1].rstrip("%"))
    except (IndexError, ValueError):
        pytest.fail(
            f"{REPORT_FILE} lines 4 or 5 are malformed:\n" + "\n".join(report_lines)
        )

    assert pytest.approx(peak_cpu, rel=0, abs=1e-3) == reported_cpu, (
        f"Peak CPU reported in {REPORT_FILE} is {reported_cpu}%, "
        f"but actual peak in sysmon.log is {peak_cpu}%"
    )
    assert pytest.approx(peak_mem, rel=0, abs=1e-3) == reported_mem, (
        f"Peak MEM reported in {REPORT_FILE} is {reported_mem}%, "
        f"but actual peak in sysmon.log is {peak_mem}%"
    )