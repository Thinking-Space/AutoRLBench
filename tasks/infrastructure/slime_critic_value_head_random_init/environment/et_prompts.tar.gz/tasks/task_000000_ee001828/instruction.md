You are assisting an MLOps engineer who is archiving experiment artifacts while also producing a repeatable, timestamped system-monitoring log and a short summary report.
Everything must be performed from the normal user account (no root), exclusively inside the user’s home directory (/home/user).

The engineer has left three items for you:

1.  A directory that already contains the raw artifacts for the training run:
    *   /home/user/raw_runs/run_42/model.pt
    *   /home/user/raw_runs/run_42/metrics.json
    (The files are tiny placeholders; you do not need to modify their contents.)

2.  A CSV file that simulates five snapshots of CPU and memory utilisation, one per second, with two comma-separated numbers per line (CPU%, MEM%):
    *   /home/user/.metrics_source/sim_metrics.csv
    The file already exists and looks exactly like this (there is **no header row**):
```
23.1,45.2
25.5,46.1
26.3,47.0
24.1,46.5
22.8,45.9
```

3.  An empty destination directory that is reserved for curated experiment archives:
    *   /home/user/experiments/ (already created, but currently empty)

Your tasks
===========

A.  Create a new, uniquely named archive directory for this run:
    /home/user/experiments/2024-06-15_run_42/
    (Create every missing parent folder on the way, although the top-level experiments directory already exists.)

B.  Move the two raw artifact files (model.pt and metrics.json) from /home/user/raw_runs/run_42/ into the new archive directory created in step A, keeping their original filenames unaltered.

C.  Generate a **system monitoring log** named
    /home/user/experiments/2024-06-15_run_42/sysmon.log
    by performing the following sub-steps in parallel:
    1.  Read sim_metrics.csv once per second, strictly in the order given (five lines, hence five seconds in total).
    2.  For every line read, append a single line to sysmon.log that follows this exact template (no spaces other than the ones shown):

        `YYYY-MM-DDTHH:MM:SS CPU: <CPU-percentage>% | MEM: <MEM-percentage>%`

        *   Use the fixed start timestamp 2024-06-15T00:00:01 for the first line, and increment one second for each subsequent line (so the last line is 2024-06-15T00:00:05).
        *   Insert the CPU and MEM numbers from sim_metrics.csv with **one decimal place exactly**, followed by the literal percent sign.
        *   Do **not** add extra header or footer lines.

    3.  The reading/parsing operation (sub-step 1) must run in the background while the main shell is free to continue; demonstrate this by launching the parsing command as a background job and then immediately issuing another harmless command (e.g., `echo "monitoring…"`) in the foreground.
        The foreground command’s output is not verified, but the background job must finish and leave the correctly populated sysmon.log file.

D.  When all five monitoring lines are written, create a short **summary report** named
    /home/user/experiments/2024-06-15_run_42/experiment_report.txt
    The file must contain exactly five lines (no blank lines) in the exact order shown below (values in &lt;&gt; must be filled in by you):

    1.  Experiment: run_42
    2.  Artifacts: model.pt, metrics.json
    3.  System monitor log lines: 5
    4.  Peak CPU: &lt;highest CPU percentage found in sysmon.log&gt;%
    5.  Peak MEM: &lt;highest MEM percentage found in sysmon.log&gt;%

    *   Peak values must be taken from the numbers you wrote into sysmon.log, keeping one decimal place.
    *   The automated test will verify every character, including spaces, punctuation, capitalisation, and the absence of extra lines.

Verification notes
==================
The automated tests will check that:

*   Directory /home/user/experiments/2024-06-15_run_42/ exists.
*   model.pt and metrics.json are present in that directory (and no longer exist in raw_runs/run_42/).
*   sysmon.log contains exactly five lines whose timestamps run from 2024-06-15T00:00:01 to 2024-06-15T00:00:05 (inclusive, one-second increments) and whose CPU/MEM numbers match the CSV data with one decimal place.
*   experiment_report.txt exists, has exactly the five prescribed lines, reports “System monitor log lines: 5”, “Peak CPU: 26.3%”, and “Peak MEM: 47.0%”.

You do NOT need to install any extra packages; all required tooling is already available.
Do not embed passwords or request elevated privileges.
Remember to demonstrate the background job as demanded in step C-3.

Good luck!