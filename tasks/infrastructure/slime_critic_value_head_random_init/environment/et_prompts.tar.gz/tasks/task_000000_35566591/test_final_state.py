# test_final_state.py
#
# Pytest suite that validates the FINAL operating-system / container state
# AFTER the student has completed the “daily backup” exercise.
#
# What is checked:
#   • /home/user/archives/ exists (correct type & permissions accepted by grader)
#   • Exactly three *.tar.gz files are present with the mandated names.
#   • Each archive is a valid gzip-compressed tarball that contains an
#     exact snapshot of the corresponding data_* directory.
#   • A manifest file exists, follows the *precise* layout rules and the
#     recorded file-sizes and SHA-256 checksums match reality.
#   • latest_manifest.log is a symlink that points to the manifest.
#   • README_BACKUPS.txt exists with the two exact policy lines.
#
# Only stdlib + pytest are used; no third-party dependencies.

import os
import stat
import hashlib
import tarfile
from pathlib import Path

import pytest

HOME = Path("/home/user")

# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def sha256_of_file(path: Path) -> str:
    """Return the lowercase hexadecimal SHA-256 hash of a file."""
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def file_size(path: Path) -> int:
    """Return file size in bytes."""
    return path.stat().st_size

def find_member_by_basename(tar: tarfile.TarFile, basename: str) -> tarfile.TarInfo | None:
    """Return the first tar member whose basename matches, or None."""
    for m in tar.getmembers():
        if os.path.basename(m.name) == basename:
            return m
    return None

def archive_contains_exact_files(archive_path: Path, expected_files: dict[str, str]) -> None:
    """
    Assert that `archive_path` is a valid .tar.gz containing exactly the
    files (and their contents) provided in `expected_files`.

    expected_files maps <file name> -> <expected text content>.
    """
    assert archive_path.is_file(), f"Missing archive {archive_path}."

    try:
        with tarfile.open(archive_path, "r:gz") as tf:
            members = [m for m in tf.getmembers() if m.isfile()]
            basenames = sorted(os.path.basename(m.name) for m in members)
            expected_basenames = sorted(expected_files.keys())

            assert basenames == expected_basenames, (
                f"{archive_path} should contain exactly the files "
                f"{expected_basenames}, but it contains {basenames}."
            )

            for fname, expected_text in expected_files.items():
                member = find_member_by_basename(tf, fname)
                assert member is not None, (
                    f"{archive_path} is missing the file {fname}."
                )
                data = tf.extractfile(member).read().decode("utf-8")
                assert data == expected_text, (
                    f"File {fname} inside {archive_path} has unexpected content.\n"
                    f"Expected: {repr(expected_text)}\n"
                    f"Found:    {repr(data)}"
                )
    except tarfile.TarError as exc:
        pytest.fail(f"{archive_path} is not a valid gzip-compressed tar archive: {exc}")

# ---------------------------------------------------------------------------
# Paths / constants
# ---------------------------------------------------------------------------

DATA_DIRS = {
    "data_alpha": {
        "file1.txt": "alpha one\n",
        "file2.txt": "alpha two\n",
    },
    "data_bravo": {
        "file3.txt": "bravo three\n",
        "file4.txt": "bravo four\n",
    },
    "data_charlie": {
        "readme.md": "# Charlie Data\nSome content.\n",
    },
}

ARCHIVES_DIR          = HOME / "archives"

ARCHIVE_FILENAMES     = [
    "data_alpha_20231001.tar.gz",
    "data_bravo_20231001.tar.gz",
    "data_charlie_20231001.tar.gz",
]

MANIFEST_FILE         = ARCHIVES_DIR / "backup_manifest_2023-10-01.log"
SYMLINK_LATEST        = ARCHIVES_DIR / "latest_manifest.log"
README_FILE           = ARCHIVES_DIR / "README_BACKUPS.txt"

MANIFEST_HEADER       = "==== DAILY BACKUP MANIFEST 2023-10-01 ==== (3)"
MANIFEST_FOOTER       = "==== END OF MANIFEST ===="

# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_archives_directory_exists_and_is_dir():
    """The /home/user/archives/ directory must exist and be a directory."""
    assert ARCHIVES_DIR.exists(), "Directory /home/user/archives/ does not exist."
    assert ARCHIVES_DIR.is_dir(), "/home/user/archives/ exists but is not a directory."

@pytest.mark.parametrize("archive_filename, data_key", zip(ARCHIVE_FILENAMES, DATA_DIRS.keys()))
def test_each_archive_exists_and_has_correct_content(archive_filename, data_key):
    """
    Each required archive must exist, be a valid tar.gz, and contain exactly
    the original files with the correct data.
    """
    archive_path = ARCHIVES_DIR / archive_filename
    expected_files = DATA_DIRS[data_key]
    archive_contains_exact_files(archive_path, expected_files)

def test_manifest_file_format_and_values():
    """Verify manifest layout, counts, sizes and checksums."""
    # ---------- file presence ----------
    assert MANIFEST_FILE.is_file(), f"Manifest {MANIFEST_FILE} is missing."

    # ---------- read lines ----------
    content = MANIFEST_FILE.read_text(encoding="utf-8", errors="strict")
    lines = content.splitlines()
    expected_line_count = 7  # header, blank, 3 archives, blank, footer

    assert len(lines) == expected_line_count, (
        f"Manifest must contain exactly {expected_line_count} lines "
        f"(including header/footer and blank lines), but it has {len(lines)}."
    )

    # ---------- header / footer ----------
    assert lines[0] == MANIFEST_HEADER, (
        f"Manifest header line incorrect.\nExpected: {MANIFEST_HEADER!r}\nFound:    {lines[0]!r}"
    )
    assert lines[-1] == MANIFEST_FOOTER, (
        f"Manifest footer line incorrect.\nExpected: {MANIFEST_FOOTER!r}\nFound:    {lines[-1]!r}"
    )

    # ---------- mandatory blank lines ----------
    assert lines[1] == "", "There must be exactly one blank line after the header."
    assert lines[-2] == "", "There must be exactly one blank line before the footer."

    # ---------- archive records ----------
    data_lines = lines[2:5]  # three lines
    seen_files = set()

    for idx, line in enumerate(data_lines, start=1):
        fields = line.split("\t")
        assert len(fields) == 3, (
            f"Manifest archive line {idx} should have 3 TAB-separated fields, "
            f"but it has {len(fields)} fields: {line!r}"
        )
        fname, size_str, sha256 = fields

        # --- filename correctness ---
        assert fname in ARCHIVE_FILENAMES, (
            f"Manifest lists unexpected archive name {fname!r}."
        )
        assert fname not in seen_files, (
            f"Archive {fname!r} is listed more than once in the manifest."
        )
        seen_files.add(fname)

        archive_path = ARCHIVES_DIR / fname
        assert archive_path.exists(), (
            f"Manifest references {archive_path} which does not exist."
        )

        # --- size correctness ---
        actual_size = file_size(archive_path)
        assert size_str.isdigit(), (
            f"Size field for {fname!r} must be numeric but is {size_str!r}."
        )
        recorded_size = int(size_str)
        assert recorded_size == actual_size, (
            f"Size mismatch for {fname!r} in manifest: recorded {recorded_size} "
            f"bytes, actual {actual_size} bytes."
        )

        # --- checksum correctness ---
        actual_sha256 = sha256_of_file(archive_path)
        assert sha256 == actual_sha256, (
            f"SHA-256 mismatch for {fname!r} in manifest: recorded {sha256}, "
            f"actual {actual_sha256}."
        )

    # ---------- ensure all archives were listed ----------
    assert seen_files == set(ARCHIVE_FILENAMES), (
        f"Manifest must list exactly these archives: {ARCHIVE_FILENAMES}, "
        f"but it lists {sorted(seen_files)}."
    )

def test_latest_manifest_symlink():
    """Check that latest_manifest.log is a symlink pointing at the manifest."""
    assert SYMLINK_LATEST.exists(), "latest_manifest.log symlink is missing."
    assert SYMLINK_LATEST.is_symlink(), "latest_manifest.log exists but is not a symlink."

    target = Path(os.readlink(SYMLINK_LATEST))  # may be relative
    assert target.name == MANIFEST_FILE.name, (
        f"latest_manifest.log should point at {MANIFEST_FILE.name}, "
        f"but it points at {target}."
    )

    # Resolve to absolute path and confirm it matches the manifest
    resolved = SYMLINK_LATEST.resolve()
    assert resolved == MANIFEST_FILE, (
        f"latest_manifest.log resolves to {resolved}, but {MANIFEST_FILE} is expected."
    )

def test_readme_file_exists_and_has_correct_content():
    """README_BACKUPS.txt must contain exactly the two specified lines."""
    assert README_FILE.is_file(), f"{README_FILE} is missing."

    content = README_FILE.read_text(encoding="utf-8", errors="strict")
    expected_content = "RETENTION: 30 DAYS\nOWNER: backup-admin\n"

    assert content == expected_content, (
        f"{README_FILE} has unexpected content.\n"
        f"Expected:\n{expected_content!r}\nFound:\n{content!r}"
    )