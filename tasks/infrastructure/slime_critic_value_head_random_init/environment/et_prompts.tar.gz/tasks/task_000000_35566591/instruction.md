You are working as the company’s new “backup-administrator”.  
A colleague has already placed three data directories that must be archived every night:

    /home/user/data_alpha/
    /home/user/data_bravo/
    /home/user/data_charlie/

Goal  
----  
Create compressed archives (tar + gzip) of each data_* directory.  
   • All archives must be placed inside  /home/user/archives/ (create it if it does not exist).  
   • Every archive file must follow the EXACT name template  

         <directoryName>_20231001.tar.gz  

     For example, the archive of /home/user/data_alpha/ **must** be called  

         /home/user/archives/data_alpha_20231001.tar.gz  

   • The fixed date string “20231001” is mandatory – assume that today is 2023-10-01, regardless of the actual date in the container.

Produce a human-readable manifest file that summarises the backup run.  
   • The manifest must be created at  

         /home/user/archives/backup_manifest_2023-10-01.log  

   • Its exact text layout (line breaks and spacing) must be:

         ==== DAILY BACKUP MANIFEST 2023-10-01 ==== (3)
         
         <archive_name_1>    <size_bytes_1>    <sha256sum_1>
         <archive_name_2>    <size_bytes_2>    <sha256sum_2>
         <archive_name_3>    <size_bytes_3>    <sha256sum_3>
         
         ==== END OF MANIFEST ====

     Formatting rules:  
     a. The first header line and the footer line must start with four “=” characters, a single space, then the given sentence verbatim.  
     b. Immediately after the header line there must be ONE blank line.  
     c. Each archive line contains three TAB-separated fields in this order:  
          • the file name only (e.g. “data_alpha_20231001.tar.gz”)  
          • the size of the file in **bytes**  
          • the lowercase hexadecimal SHA-256 checksum  
     d. After the last archive line there must again be ONE blank line, followed by the footer and a final newline (manifest ends with “\n”).  

   • The automated test will reject any deviation in spelling, spacing, or missing newlines.

Create /home/user/archives/latest_manifest.log as a symbolic link that points to the newly generated manifest.

Write a short policy note to /home/user/archives/README_BACKUPS.txt containing exactly these two lines (no extra spaces):

         RETENTION: 30 DAYS
         OWNER: backup-admin

   The file must end with a single newline.

What will be verified
---------------------  
• All three .tar.gz files exist under /home/user/archives/ with the correct names.  
• Their contents really are compressed archives of the corresponding data_* directories.  
• The manifest file exists, has precisely the format described above, and the size/check-sum values match the actual files.  
• The symbolic link latest_manifest.log exists and resolves to the manifest.  
• README_BACKUPS.txt exists with the two specified lines.