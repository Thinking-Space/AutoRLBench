# test_final_state.py
#
# Pytest suite that validates the **final** filesystem state **after** the
# student has run the backup procedure described in the assignment.
#
# The tests cover:
#   1. Correct creation of the timestamped backup directory and copied files.
#   2. Correct creation and structure of the gzip-compressed tarball.
#   3. Integrity of file contents in both the backup directory and tarball.
#   4. Correctness of the appended line in /home/user/backup/backup.log.
#
# IMPORTANT:
#   • Only Python stdlib + pytest are used (no third-party libraries).
#   • All paths are absolute and must match the specification exactly.
#   • Failed assertions explain **exactly** what is still wrong so the student
#     knows what to fix.
#
# ---------------------------------------------------------------------------

import hashlib
import os
import tarfile
import tempfile
import stat
import re
import pytest

HOME = "/home/user"

# ---- Source (original) data -------------------------------------------------
SRC_DIR = os.path.join(HOME, "k8s", "manifests")
SRC_FILES = {
    "deployment.yaml": """\
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nginx
spec:
  replicas: 2
""",
    "service.yaml": """\
apiVersion: v1
kind: Service
metadata:
  name: nginx
spec:
  type: ClusterIP
""",
    "configmap.yaml": """\
apiVersion: v1
kind: ConfigMap
metadata:
  name: nginx-config
data:
  key: value
""",
}

# ---- Expected backup artefacts ---------------------------------------------
TIMESTAMP = "20240102-150000"
ISO_TS   = "2024-01-02T15:00:00Z"

BACKUP_ROOT      = os.path.join(HOME, "backup")
BACKUP_DIR       = os.path.join(BACKUP_ROOT, TIMESTAMP)
ARCHIVES_DIR     = os.path.join(BACKUP_ROOT, "archives")
ARCHIVE_FILENAME = f"k8s_backup_{TIMESTAMP}.tar.gz"
ARCHIVE_PATH     = os.path.join(ARCHIVES_DIR, ARCHIVE_FILENAME)
LOG_FILE         = os.path.join(BACKUP_ROOT, "backup.log")

# --------------------------------------------------------------------------- #
# Helper utilities                                                            #
# --------------------------------------------------------------------------- #
def sha256_of_file(path, blocksize=65536):
    hasher = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(blocksize), b""):
            hasher.update(chunk)
    return hasher.hexdigest()

def sha256_of_str(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()

# --------------------------------------------------------------------------- #
# Tests                                                                       #
# --------------------------------------------------------------------------- #

# 1. Backup directory exists and contains the three manifests copied verbatim.
def test_backup_directory_exists_with_correct_files():
    assert os.path.isdir(BACKUP_DIR), (
        f"Backup directory {BACKUP_DIR} is missing. "
        "Did you create it using the fixed timestamp?"
    )

    files_in_backup = sorted(
        f for f in os.listdir(BACKUP_DIR) if os.path.isfile(os.path.join(BACKUP_DIR, f))
    )
    expected_files_sorted = sorted(SRC_FILES.keys())
    assert files_in_backup == expected_files_sorted, (
        f"{BACKUP_DIR} must contain exactly the three manifest files "
        f"{expected_files_sorted}. Found: {files_in_backup}"
    )

    # Content integrity
    for filename, expected_content in SRC_FILES.items():
        backup_file_path = os.path.join(BACKUP_DIR, filename)
        src_file_path    = os.path.join(SRC_DIR, filename)

        with open(backup_file_path, "r", encoding="utf-8") as fh:
            backup_content = fh.read()

        with open(src_file_path, "r", encoding="utf-8") as fh:
            src_content = fh.read()

        assert backup_content == expected_content == src_content, (
            f"Content mismatch for {filename} between source and backup."
        )

        # Extra guard: SHA-256 digests identical
        assert (
            sha256_of_str(backup_content) == sha256_of_str(expected_content)
        ), f"SHA-256 mismatch for copied file {backup_file_path}."

# 2. Archive exists and can be opened as gzip tar; contents correct & identical
def test_archive_exists_and_structure_is_correct():
    assert os.path.isdir(ARCHIVES_DIR), (
        f"Directory {ARCHIVES_DIR} is missing – did you create the archives/ directory?"
    )
    assert os.path.isfile(ARCHIVE_PATH), (
        f"Expected archive {ARCHIVE_PATH} not found. "
        "Did you create it with the correct name and location?"
    )

    # Try opening the archive
    try:
        tar = tarfile.open(ARCHIVE_PATH, "r:gz")
    except tarfile.ReadError as exc:
        pytest.fail(f"Archive {ARCHIVE_PATH} is not a valid gzip-compressed tarball: {exc}")

    members = tar.getmembers()
    member_names = sorted(m.name for m in members)
    expected_names = sorted(SRC_FILES.keys())
    assert member_names == expected_names, (
        "Archive must contain exactly the three manifest files at the archive root\n"
        f"Expected: {expected_names}\nFound in tar: {member_names}"
    )

    # Extract to temporary dir and compare contents
    with tempfile.TemporaryDirectory() as tmpdir:
        tar.extractall(path=tmpdir)
        for filename, expected_content in SRC_FILES.items():
            extracted_path = os.path.join(tmpdir, filename)
            assert os.path.isfile(extracted_path), (
                f"{filename} missing after extracting archive."
            )
            with open(extracted_path, "r", encoding="utf-8") as fh:
                extracted_content = fh.read()
            assert extracted_content == expected_content, (
                f"Content of {filename} inside archive differs from source manifest."
            )

    tar.close()

# 3. Log file exists, last line matches the required pipe-separated schema
def test_log_last_line_is_correct_and_checksum_matches():
    assert os.path.isfile(LOG_FILE), (
        f"Log file {LOG_FILE} does not exist – did you forget to create it?"
    )
    # Ensure log is readable and writable
    assert os.access(LOG_FILE, os.R_OK), f"Cannot read log file {LOG_FILE}."
    assert os.access(LOG_FILE, os.W_OK) or (
        stat.S_IMODE(os.stat(LOG_FILE).st_mode) & stat.S_IWUSR
    ), f"Log file {LOG_FILE} is not writable (must be append-only)."

    with open(LOG_FILE, "r", encoding="utf-8") as fh:
        lines = [line.rstrip("\n") for line in fh]

    assert lines, f"Log file {LOG_FILE} is empty – must contain at least one entry."
    last = lines[-1]

    # Split the line and perform primary structural checks
    parts = last.split("|")
    assert len(parts) == 4, (
        "Audit log entry must contain four pipe-separated fields:\n"
        "TIMESTAMP|ARCHIVE_PATH|FILES|SHA256_CHECKSUM"
    )

    ts_field, path_field, files_field, checksum_field = parts

    assert ts_field == ISO_TS, (
        f"Timestamp field in log must be '{ISO_TS}', but got '{ts_field}'."
    )
    assert path_field == ARCHIVE_PATH, (
        f"Archive path field in log must be '{ARCHIVE_PATH}', but got '{path_field}'."
    )
    assert files_field == "3", (
        f"FILES field in log must be '3', but got '{files_field}'."
    )
    # Check checksum format
    hex64_re = re.compile(r"^[0-9a-f]{64}$")
    assert hex64_re.match(checksum_field), (
        f"SHA-256 field must be a 64-character hexadecimal string, got '{checksum_field}'."
    )

    # Verify checksum correctness
    calculated_checksum = sha256_of_file(ARCHIVE_PATH)
    assert (
        checksum_field == calculated_checksum
    ), (
        "SHA-256 checksum recorded in log does not match the checksum of the archive.\n"
        f"Recorded:   {checksum_field}\n"
        f"Calculated: {calculated_checksum}"
    )