You are the on-call Kubernetes operator.  
A colleague just pushed three manifest files to  
/home/user/k8s/manifests  

    deployment.yaml  
    service.yaml  
    configmap.yaml  

Your job is to create a **repeatable, timestamped backup** of those manifests and record the action in a log that an automated audit system will later consume.

Detailed requirements:

1. Use the fixed timestamp 20240102-150000 (10 January 02 15:00:00) for every artefact created in this exercise.  
   • Directory names, archive names, and the log entry must all embed that exact string.  
   • The ISO-8601 time in the log must be 2024-01-02T15:00:00Z.

2. Build the directory structure shown below (create anything that is missing):
   /home/user/backup/20240102-150000        ← copy of the manifests goes here  
   /home/user/backup/archives               ← parent directory for the tarball  
   /home/user/backup/backup.log             ← audit log (append one line)

3. Copy every file that is currently present inside /home/user/k8s/manifests  
   into /home/user/backup/20240102-150000, preserving the original filenames.

4. Pack the **files themselves (not the directory)** into a gzip-compressed
   archive named exactly  
   /home/user/backup/archives/k8s_backup_20240102-150000.tar.gz  
   Requirements for the archive:
   • It must contain only the three manifest files at the archive root  
     (paths inside the archive: deployment.yaml, service.yaml, configmap.yaml).  
   • No parent directories such as “k8s” or “20240102-150000” should appear inside the tarball.

5. Immediately after creating the archive, calculate its SHA-256 checksum.

6. Append a single new line to /home/user/backup/backup.log using **pipe-separated
   fields** in this exact order, with **no spaces** between the pipes:

   TIMESTAMP|ARCHIVE_PATH|FILES|SHA256_CHECKSUM

   For this task the line must therefore look like:

   2024-01-02T15:00:00Z|/home/user/backup/archives/k8s_backup_20240102-150000.tar.gz|3|<checksum>

   • Replace &lt;checksum&gt; with the real 64-character hexadecimal digest you computed.  
   • Do not add extra whitespace, trailing pipes, or additional text.

7. Once finished, print the calculated checksum to STDOUT so the requester can
   see it immediately.

Notes & constraints:

• You do NOT need root privileges; everything must stay inside /home/user.  
• Only the three manifest files currently present in /home/user/k8s/manifests
  should appear in the backup.  
• The log file must stay append-only: leave any earlier lines untouched if the
  file already exists.  
• The automated verification will:  
  – check that the new directory, archive, and log entry exist,  
  – extract the archive to confirm it contains exactly three files at the root,  
  – recompute the SHA-256 digest and compare it with the value in the log.  

When everything is done correctly you should have:

/home/user/backup/20240102-150000/deployment.yaml  
/home/user/backup/20240102-150000/service.yaml  
/home/user/backup/20240102-150000/configmap.yaml  

/home/user/backup/archives/k8s_backup_20240102-150000.tar.gz  

And the last line of /home/user/backup/backup.log identical in structure to the
example shown above, with the real checksum in place of &lt;checksum&gt;.