# test_final_state.py
"""
Pytest suite to validate the **FINAL** state of the filesystem *after*
the student has finished the “artifact-manager” task.

The assertions are intentionally exhaustive: any deviation from
the spec should raise a clear, actionable failure message.

Nothing in here modifies the filesystem – it only inspects.
"""

import os
import re
import hashlib
from datetime import datetime

import pytest

# --------------------------------------------------------------------------- #
# Constants – absolute paths only                                             #
# --------------------------------------------------------------------------- #
SOURCE_DIR = "/home/user/artifacts-source"
REPO_DIR = "/home/user/repositories/core"
INDEX_PATH = os.path.join(REPO_DIR, "INDEX.txt")
LOG_PATH = os.path.join(REPO_DIR, "curation.log")

ALPHA_SRC = os.path.join(SOURCE_DIR, "alpha.bin")
BETA_SRC = os.path.join(SOURCE_DIR, "beta.bin")

ALPHA_DST = os.path.join(REPO_DIR, "alpha.bin")
BETA_DST = os.path.join(REPO_DIR, "beta.bin")


# --------------------------------------------------------------------------- #
# Helper utilities                                                            #
# --------------------------------------------------------------------------- #
def _read(path: str) -> bytes:
    """Read a file in binary mode and return its bytes."""
    with open(path, "rb") as fp:
        return fp.read()


def _sha256_hex(data: bytes) -> str:
    """Return SHA-256 hexdigest for *data*."""
    return hashlib.sha256(data).hexdigest()


def _file_info(path: str):
    """
    Return (bytes_data, size_int, sha256_hex) for *path*.
    Fails early with a descriptive message if the file is missing.
    """
    assert os.path.isfile(
        path
    ), f"Expected file {path!r} is missing or not a regular file."
    data = _read(path)
    return data, len(data), _sha256_hex(data)


def _assert_exact_byte_copy(src: str, dst: str):
    """Assert that *dst* exists and is byte-for-byte identical to *src*."""
    src_data, src_size, src_sha = _file_info(src)
    dst_data, dst_size, dst_sha = _file_info(dst)

    assert (
        src_data == dst_data
    ), f"Destination file {dst!r} differs in content from source {src!r}."
    assert (
        src_size == dst_size
    ), f"Size mismatch: {dst!r} is {dst_size} bytes but should be {src_size}."
    assert (
        src_sha == dst_sha
    ), f"SHA-256 mismatch for {dst!r}: expected {src_sha}, found {dst_sha}."
    return dst_size, dst_sha  # convenient for later checks


# --------------------------------------------------------------------------- #
# Tests                                                                       #
# --------------------------------------------------------------------------- #
def test_repository_directory_exists():
    assert os.path.isdir(
        REPO_DIR
    ), f"Repository directory {REPO_DIR!r} is missing."


def test_binary_copies_are_correct():
    """
    Both alpha.bin and beta.bin must be present in the repository and must
    be byte-for-byte identical with the originals.
    """
    _assert_exact_byte_copy(ALPHA_SRC, ALPHA_DST)
    _assert_exact_byte_copy(BETA_SRC, BETA_DST)


# The following two fixtures pre-compute size & sha256 for downstream tests.
@pytest.fixture(scope="session")
def artifacts_metadata():
    """
    Returns a dict:
        {
            'alpha.bin': {'size': 6, 'sha': '...'},
            'beta.bin' : {'size': 5, 'sha': '...'},
        }
    """
    meta = {}
    for name, src, dst in (
        ("alpha.bin", ALPHA_SRC, ALPHA_DST),
        ("beta.bin", BETA_SRC, BETA_DST),
    ):
        size, sha = _assert_exact_byte_copy(src, dst)
        meta[name] = {"size": size, "sha": sha}
    return meta


# --------------------------------------------------------------------------- #
# INDEX.txt validation                                                         #
# --------------------------------------------------------------------------- #
def test_index_file_exists_and_format_is_correct(artifacts_metadata):
    # ---------- file existence ----------
    assert os.path.isfile(
        INDEX_PATH
    ), f"Required index file {INDEX_PATH!r} is missing."

    with open(INDEX_PATH, "r", encoding="utf-8", newline="") as fp:
        content = fp.read()

    # ---------- trailing newline rules ----------
    assert content.endswith(
        "\n"
    ), f"{INDEX_PATH!r} must end with a single trailing newline."
    if content.endswith("\n\n"):
        pytest.fail(
            f"{INDEX_PATH!r} contains more than one trailing newline."
        )

    # ---------- line parsing ----------
    lines = content.splitlines()  # removes newline char
    assert (
        len(lines) == 2
    ), f"{INDEX_PATH!r} must contain exactly 2 lines, found {len(lines)}."

    expected_order = ["alpha.bin", "beta.bin"]
    # Ensure alphabetical order
    actual_order = [ln.split("\t")[0] for ln in lines]
    assert (
        actual_order == expected_order
    ), f"Lines in {INDEX_PATH!r} are not in alphabetical order: {actual_order!r}"

    # ---------- per-line validation ----------
    for line in lines:
        parts = line.split("\t")
        assert (
            len(parts) == 3
        ), f"Line {line!r} in {INDEX_PATH!r} does not have exactly 3 TAB-separated columns."

        name, size_txt, sha_hex = parts
        assert (
            name in artifacts_metadata
        ), f"Unexpected artifact {name!r} listed in {INDEX_PATH!r}."

        # Size column
        expected_size = artifacts_metadata[name]["size"]
        assert size_txt.isdigit(), (
            f"Size field for {name!r} in {INDEX_PATH!r} "
            f"must be numeric, found {size_txt!r}."
        )
        actual_size_int = int(size_txt)
        assert (
            actual_size_int == expected_size
        ), (
            f"Incorrect size for {name!r} in {INDEX_PATH!r}: "
            f"expected {expected_size}, found {actual_size_int}."
        )

        # SHA-256 column
        expected_sha = artifacts_metadata[name]["sha"]
        assert re.fullmatch(r"[a-f0-9]{64}", sha_hex), (
            f"Invalid SHA-256 digest {sha_hex!r} for {name!r} in {INDEX_PATH!r}."
        )
        assert (
            sha_hex == expected_sha
        ), (
            f"SHA-256 mismatch for {name!r} in {INDEX_PATH!r}: "
            f"expected {expected_sha}, found {sha_hex}."
        )


# --------------------------------------------------------------------------- #
# curation.log validation                                                     #
# --------------------------------------------------------------------------- #
TIMESTAMP_RE = re.compile(
    r"^20\d{2}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$"
)


def _valid_timestamp(ts: str) -> bool:
    """Return True iff *ts* matches UTC ISO-8601 ‘YYYY-MM-DDTHH:MM:SSZ’."""
    if not TIMESTAMP_RE.fullmatch(ts):
        return False
    try:
        # datetime throws ValueError on invalid date/time
        datetime.strptime(ts, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError:
        return False
    return True


def test_curation_log_exists_and_format_is_correct(artifacts_metadata):
    # ---------- file existence ----------
    assert os.path.isfile(
        LOG_PATH
    ), f"Required log file {LOG_PATH!r} is missing."

    with open(LOG_PATH, "r", encoding="utf-8", newline="") as fp:
        content = fp.read()

    # ---------- trailing newline rules ----------
    assert content.endswith(
        "\n"
    ), f"{LOG_PATH!r} must end with a single trailing newline."
    if content.endswith("\n\n"):
        pytest.fail(
            f"{LOG_PATH!r} contains more than one trailing newline."
        )

    # ---------- line parsing ----------
    lines = content.splitlines()
    assert (
        len(lines) == 2
    ), f"{LOG_PATH!r} must contain exactly 2 lines, found {len(lines)}."

    expected_order = ["alpha.bin", "beta.bin"]
    actual_order = []
    for line in lines:
        parts = line.split(" | ")
        assert (
            len(parts) == 3
        ), f"Line {line!r} in {LOG_PATH!r} must have exactly 3 fields separated by ' | '."
        ts, name, sha_hex = parts

        actual_order.append(name)

        # Timestamp validation
        assert _valid_timestamp(
            ts
        ), f"Timestamp {ts!r} in {LOG_PATH!r} is not a valid UTC ISO-8601 value."

        # Artifact name validation
        assert (
            name in artifacts_metadata
        ), f"Unexpected artifact {name!r} present in {LOG_PATH!r}."

        # SHA-256 validation
        expected_sha = artifacts_metadata[name]["sha"]
        assert re.fullmatch(r"[a-f0-9]{64}", sha_hex), (
            f"Invalid SHA-256 digest {sha_hex!r} for {name!r} in {LOG_PATH!r}."
        )
        assert (
            sha_hex == expected_sha
        ), (
            f"SHA-256 mismatch for {name!r} in {LOG_PATH!r}: "
            f"expected {expected_sha}, found {sha_hex}."
        )

    # ---------- alphabetical order ----------
    assert (
        actual_order == expected_order
    ), f"Lines in {LOG_PATH!r} are not in alphabetical order: {actual_order!r}"