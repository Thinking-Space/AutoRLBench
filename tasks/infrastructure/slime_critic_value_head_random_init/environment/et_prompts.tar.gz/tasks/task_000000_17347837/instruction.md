You are acting as an artifact-manager who curates in-house binary repositories.
A starter directory containing raw binaries has already been placed on the system for you:

    /home/user/artifacts-source/
        ├── alpha.bin   (ASCII text, 6 bytes, contains the string “ALPHA\n”)
        └── beta.bin    (ASCII text, 5 bytes, contains the string “BETA\n”)

Your goal is to turn these two raw binaries into a **very small, file-system based repository** under `/home/user/repositories/core/`.

The final repository at `/home/user/repositories/core/` must be created and contain copies of both `alpha.bin` and `beta.bin` from the source location.

Additionally, the repository must contain a plain-text index file and an operational log file with the following specifications:

**INDEX.txt File**

A file named exactly `/home/user/repositories/core/INDEX.txt` must exist and fulfil **all** of these formatting rules:
*   One binary per line.
*   Lines must be sorted in *ascending alphabetical* order by the artifact’s file-name.
*   The line format is three TAB-separated columns (that is, a single ASCII 0x09 character between the fields):

        <artifact_name><TAB><size_in_bytes>.<TAB><sha256sum>

    Example (spacing shown with “·” characters):
        alpha.bin·6·2b73564f…
        beta.bin·5·35a39d3b…

*   **No** leading or trailing whitespace on any line.
*   The file must end with a single trailing newline (UNIX “\n”).

**curation.log File**

An operational log named `/home/user/repositories/core/curation.log` must exist. The log must contain *exactly two* lines — one for each binary — using the precise layout below:

    <UTC-ISO8601 timestamp>Z | <artifact_name> | <sha256sum>

Formatting requirements:
*   The timestamp must be in UTC with the literal trailing “Z” (e.g. 2023-10-05T14:26:03Z).
*   A single space, a vertical bar “|”, and another single space separate the three fields.
*   Alphabetical order of the artifact-names (alpha.bin first).
*   Only these two lines; end the file with one trailing “\n”.

To complete the task, print (to STDOUT) the contents of both `INDEX.txt` and `curation.log` for visual inspection. Do not add any extra commentary when you print.

Notes & Constraints
-------------------
*   You do *not* have root rights; stay entirely in /home/user.
*   All paths in this task are absolute — use them verbatim.
*   The automated checker will:
    - Ensure both files exist.
    - Parse and validate the exact formatting rules.
    - Independently recalculate the checksums for comparison.
*   If you need temporary workspace, create it inside /home/user/tmp and remove it afterwards.
*   Avoid interactive programs; everything must run non-interactively.