### Configuration-management simulation: tracking a simple “package” change

#### Background
A small in-house configuration manager records the exact package list before and after **every** change.
Your job is to simulate the addition of the package “jq 1.6” to an already-installed system and produce the diff the manager stores.

#### Required end-state of the system (everything **under /home/user**, no sudo needed)

1.  **Directory**  
    /home/user/cfgmgr

2.  **Baseline file – *before* the change**  
    Path: /home/user/cfgmgr/installed_packages_before.txt  
    Exact textual content (two lines, Unix line-endings, trailing newline **after each line**):
    ```
    curl 7.88.1
    git 2.39.2
    ```

3.  **New state file – *after* the change**  
    Path: /home/user/cfgmgr/installed_packages_after.txt  
    Exact textual content (three lines, Unix line-endings, trailing newline **after each line**):
    ```
    curl 7.88.1
    git 2.39.2
    jq 1.6
    ```

4.  **Unified diff patch**  
    Path: /home/user/cfgmgr/jq_install_diff.patch  
    It must be the literal output produced by running  
    `diff -u --label BEFORE --label AFTER installed_packages_before.txt installed_packages_after.txt`  
    from inside `/home/user/cfgmgr`.  
    The file must therefore contain **exactly five lines** (each ending with “\n”) and look precisely like this:
    ```
    --- BEFORE
    +++ AFTER
    @@ -1,2 +1,3 @@
     curl 7.88.1
     git 2.39.2
    +jq 1.6
    ```

    Notes on verification:
    *   No timestamps or extra whitespace are allowed.
    *   Lines beginning with a single space must really start with one literal space.
    *   The “+jq 1.6” line starts with a plus sign immediately followed by “jq”.

Only those three files inside `/home/user/cfgmgr` will be checked by the automated grader.
If any of them is missing, named differently, has extra blank lines, or deviates from the specified text, the task will be marked as failed.