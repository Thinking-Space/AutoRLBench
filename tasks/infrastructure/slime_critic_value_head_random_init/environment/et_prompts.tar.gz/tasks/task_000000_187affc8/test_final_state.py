# test_final_state.py
#
# Pytest suite that validates the FINAL state of the system **after**
# the student has finished the configuration-management simulation task.
#
# What we assert:
#   • /home/user/cfgmgr exists and is a directory.
#   • That directory contains **exactly** the three required artefacts
#       - installed_packages_before.txt
#       - installed_packages_after.txt
#       - jq_install_diff.patch
#     (no more, no fewer).
#   • Each artefact’s textual content matches the authoritative truth
#     byte-for-byte, including trailing newlines.
#
# If any check fails we raise an assertion with a clear explanation of
# what is still wrong.



import os
from pathlib import Path

import pytest

# ---------- Canonical absolute paths ----------
CFG_DIR = Path("/home/user/cfgmgr")
BEFORE_FILE = CFG_DIR / "installed_packages_before.txt"
AFTER_FILE = CFG_DIR / "installed_packages_after.txt"
PATCH_FILE = CFG_DIR / "jq_install_diff.patch"

REQUIRED_FILES = {
    BEFORE_FILE.name,
    AFTER_FILE.name,
    PATCH_FILE.name,
}

# ---------- Authoritative (truth) contents ----------
BEFORE_CONTENT = "curl 7.88.1\n" "git 2.39.2\n"

AFTER_CONTENT = (
    "curl 7.88.1\n"
    "git 2.39.2\n"
    "jq 1.6\n"
)

PATCH_CONTENT = (
    "--- BEFORE\n"
    "+++ AFTER\n"
    "@@ -1,2 +1,3 @@\n"
    " curl 7.88.1\n"
    " git 2.39.2\n"
    "+jq 1.6\n"
)


# ---------- Helper -----------------------------------------------------------------


def _read_text(path: Path) -> str:
    """
    Read a text file **exactly** as it exists on disk using UTF-8 decoding
    (diff output and package lists are plain ASCII, UTF-8 is safe).

    We do not strip newline characters; they are significant for this task.
    """
    # The diff output and package list are plain ASCII, but we decode as UTF-8
    # to stay in the standard default for Python text processing.
    return path.read_text(encoding="utf-8")


# ---------- Tests ------------------------------------------------------------------


def test_cfg_directory_exists_and_is_a_directory():
    assert CFG_DIR.exists(), (
        f"{CFG_DIR} is missing.  You must create this directory "
        "to store the configuration-manager artefacts."
    )
    assert CFG_DIR.is_dir(), f"{CFG_DIR} exists but is not a directory."


def test_cfg_directory_contains_only_expected_files():
    """
    No extra files are allowed in /home/user/cfgmgr, and none of the
    required ones may be missing.
    """
    present = {p.name for p in CFG_DIR.iterdir() if p.is_file()}
    missing = REQUIRED_FILES - present
    extra = present - REQUIRED_FILES

    assert not missing, (
        "The following required file(s) are missing from "
        f"{CFG_DIR}: {', '.join(sorted(missing))}"
    )
    assert not extra, (
        "The cfgmgr directory contains unexpected file(s): "
        f"{', '.join(sorted(extra))}.  Only the three specified artefacts "
        "should be present."
    )


@pytest.mark.parametrize(
    "path,expected_content",
    [
        (BEFORE_FILE, BEFORE_CONTENT),
        (AFTER_FILE, AFTER_CONTENT),
        (PATCH_FILE, PATCH_CONTENT),
    ],
    ids=["installed_packages_before.txt", "installed_packages_after.txt", "jq_install_diff.patch"],
)
def test_file_has_exact_expected_content(path: Path, expected_content: str):
    """
    Compare each artefact's exact textual content (including trailing newlines)
    with the authoritative truth data.
    """
    assert path.exists(), f"Required file {path} is missing."

    actual = _read_text(path)
    assert (
        actual == expected_content
    ), (
        f"Content mismatch in {path}.\n"
        "---- Expected (truth) --------------------------------------\n"
        f"{expected_content!r}\n"
        "---- Actual -------------------------------------------------\n"
        f"{actual!r}\n"
        "-------------------------------------------------------------\n"
        "Ensure the file matches exactly, byte-for-byte, including "
        "all trailing newlines and without any extra whitespace."
    )


def test_patch_file_has_exactly_six_lines():
    """
    The diff output must contain exactly six lines:
        1. '--- BEFORE'
        2. '+++ AFTER'
        3. '@@ -1,2 +1,3 @@'
        4. ' curl 7.88.1'
        5. ' git 2.39.2'
        6. '+jq 1.6'
    (All lines must be terminated with a '\n'.)
    """
    lines = _read_text(PATCH_FILE).splitlines(keepends=True)
    expected_line_count = 6
    assert (
        len(lines) == expected_line_count
    ), (
        f"{PATCH_FILE} must contain exactly {expected_line_count} lines, "
        f"but it contains {len(lines)}."
    )

    # As an extra guard, verify the individual lines match the canonical ones.
    expected_lines = PATCH_CONTENT.splitlines(keepends=True)
    assert (
        lines == expected_lines
    ), (
        f"The lines in {PATCH_FILE} do not match the expected diff output.\n"
        "Check labels, hunk header, leading spaces, plus signs and "
        "trailing newlines."
    )