You are a script-developer who keeps all source scripts under “/home/user/dev/bin”.
For daily convenience you want symbolic links to those scripts inside “/home/user/bin”.

Current situation (already present when the session starts):

*   The directory “/home/user/dev/bin” exists and contains two executable files:
    *   /home/user/dev/bin/run_backup.sh
    *   /home/user/dev/bin/check_status.sh
*   There is an **out-of-date** symbolic link called “run_backup” inside “/home/user/bin” that points to “/usr/local/bin/run_backup_old”.

Goal – bring your personal bin directory up-to-date:

1.  Make sure the directory “/home/user/bin” exists (create it if it does not).
2.  Delete the obsolete symlink “/home/user/bin/run_backup” (only if it exists).
3.  Create two new symbolic links:
    *   /home/user/bin/run_backup   → /home/user/dev/bin/run_backup.sh
    *   /home/user/bin/check_status → /home/user/dev/bin/check_status.sh
    (Links must be absolute, exactly as written above.)
4.  Produce a plain-text log file “/home/user/symlink_creation.log”.
    *   The file must contain **exactly two lines**, one per link.
    *   Each line must have this exact format:  
        `<absolute-path-to-symlink><single space>-><single space><absolute-path-to-target>`
    *   The order of the lines must be: first the run_backup line, then the check_status line.
    *   Example of the required final content (do NOT add extra spaces or trailing newline after the second line):
        ```
        /home/user/bin/run_backup -> /home/user/dev/bin/run_backup.sh
        /home/user/bin/check_status -> /home/user/dev/bin/check_status.sh
        ```

The automated evaluation script will:

*   Verify that “/home/user/bin/run_backup” and “/home/user/bin/check_status” exist and are valid symbolic links pointing to the correct targets.
*   Confirm that “/home/user/bin/run_backup” no longer points to “/usr/local/bin/run_backup_old”.
*   Check that the log file “/home/user/symlink_creation.log” exists and its content matches the two-line format shown above exactly (no extra blank lines, no additional text).