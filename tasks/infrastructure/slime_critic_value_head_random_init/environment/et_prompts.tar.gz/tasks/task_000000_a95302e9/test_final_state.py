# test_final_state.py
#
# Pytest suite that validates the *final* filesystem state after the
# student has finished the exercise.  It checks:
#   1. /home/user/bin exists as a directory.
#   2. The two required symlinks exist and point to the exact, absolute
#      targets inside /home/user/dev/bin.
#   3. The obsolete target (/usr/local/bin/run_backup_old) is **not**
#      referenced anymore.
#   4. The log file /home/user/symlink_creation.log exists and contains
#      exactly two properly-formatted lines, with no trailing newline.
#
# Only the Python standard library and pytest are used.

import os
from pathlib import Path
import pytest

HOME = Path("/home/user")

BIN_DIR          = HOME / "bin"
DEV_BIN_DIR      = HOME / "dev" / "bin"

RUN_BACKUP_SRC   = DEV_BIN_DIR / "run_backup.sh"
CHECK_STATUS_SRC = DEV_BIN_DIR / "check_status.sh"

RUN_BACKUP_LINK  = BIN_DIR / "run_backup"
CHECK_STATUS_LINK = BIN_DIR / "check_status"

LOG_FILE         = HOME / "symlink_creation.log"

EXPECTED_LOG_LINES = [
    f"{RUN_BACKUP_LINK} -> {RUN_BACKUP_SRC}",
    f"{CHECK_STATUS_LINK} -> {CHECK_STATUS_SRC}",
]
EXPECTED_LOG_CONTENT = "\n".join(EXPECTED_LOG_LINES)


def _assert_symlink(path: Path, expected_target: Path) -> None:
    """
    Assert that `path` exists, is a symlink and its *raw* link target
    matches `expected_target` exactly (byte-for-byte, no relative paths).
    """
    assert path.exists(), f"Expected symlink {path} to exist, but it is missing."
    assert path.is_symlink(), f"{path} exists but is not a symbolic link."

    # os.readlink returns the link as it was created (no automatic resolution)
    actual_target = Path(os.readlink(path))
    assert actual_target == expected_target, (
        f"Symlink {path} points to {actual_target!s}, "
        f"but it must point to {expected_target!s} exactly."
    )


def test_bin_directory_exists():
    """
    /home/user/bin must be present and be a directory.
    """
    assert BIN_DIR.exists(), f"Directory {BIN_DIR} is missing."
    assert BIN_DIR.is_dir(), f"{BIN_DIR} exists but is not a directory."


@pytest.mark.parametrize(
    "link_path, expected_target",
    [
        (RUN_BACKUP_LINK, RUN_BACKUP_SRC),
        (CHECK_STATUS_LINK, CHECK_STATUS_SRC),
    ],
)
def test_required_symlinks_exist_and_point_correctly(link_path: Path, expected_target: Path):
    """
    Both symlinks must exist and point to the correct absolute targets.
    """
    _assert_symlink(link_path, expected_target)


def test_obsolete_run_backup_symlink_replaced():
    """
    The old link target (/usr/local/bin/run_backup_old) must no longer be referenced.
    """
    assert RUN_BACKUP_LINK.exists(), "run_backup symlink is missing."
    # We already know it's a symlink from previous test; read it again for clarity.
    current_target = Path(os.readlink(RUN_BACKUP_LINK))
    assert str(current_target) != "/usr/local/bin/run_backup_old", (
        "run_backup symlink still points to the obsolete "
        "/usr/local/bin/run_backup_old instead of the new script."
    )


def test_symlink_creation_log_exists_and_is_correct():
    """
    Validate that the log file exists and its contents match **exactly** the
    two required lines with no extra newline at the end.
    """
    assert LOG_FILE.exists(), f"Log file {LOG_FILE} is missing."
    assert LOG_FILE.is_file(), f"{LOG_FILE} exists but is not a regular file."

    content = LOG_FILE.read_text(encoding="utf-8")
    assert content == EXPECTED_LOG_CONTENT, (
        "Log file contents do not match the required format.\n"
        "Expected exactly:\n"
        f"{EXPECTED_LOG_CONTENT!r}\n"
        f"Got:\n{content!r}"
    )