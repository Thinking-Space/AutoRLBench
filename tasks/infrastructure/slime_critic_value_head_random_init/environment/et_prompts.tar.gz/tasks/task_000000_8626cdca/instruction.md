A security engineer has asked you to perform a **credential-rotation** procedure for a small command-line application that stores its database credentials in a “dotenv” file.

Initial system state (already present before you start):
  • Directory: /home/user/app
  • File: /home/user/app/.env
    └─ Content (exactly two lines, Unix line-endings):
       APP_DB_USER=olduser
       APP_DB_PASS=oldpass123

Your task is to perform the credential rotation. The final state of the system must meet the following criteria:

*   A **backup** of the original `/home/user/app/.env` file must be created at `/home/user/app/.env.bak`. The backup must be an exact, byte-for-byte copy of the original file before any modifications.
*   The `/home/user/app/.env` file must be overwritten with the **new credentials** below (exactly two lines, no extra spaces, Unix line-endings):
        APP_DB_USER=newuser2023
        APP_DB_PASS=newpass!56
*   The new values must be exported into the **current shell environment** so that, for the remainder of the session, the commands `echo $APP_DB_USER` and `echo $APP_DB_PASS` would output “newuser2023” and “newpass!56” respectively.
*   An **audit log** must be produced to document the rotation.
    *   The directory `/home/user/rotation_logs` must exist if it does not already.
    *   The file `/home/user/rotation_logs/credential_rotation.log` must be created or overwritten with _exactly_ the six lines shown below, in this order, with a trailing newline after each line (again, Unix LF line-endings):
        OLD_USER=olduser
        OLD_PASS=oldpass123
        NEW_USER=newuser2023
        NEW_PASS=newpass!56
        STATUS=SUCCESS
    *   *Note:* “credential_rotation.log” must **not** contain timestamps or any other text; only the six lines above.
*   All new or modified files must be world-readable (mode 0644) and owned by the current unprivileged user.

Verification criteria (what the automated grader will check):
  • /home/user/app/.env.bak exists and is identical to the original .env file.
  • /home/user/app/.env now contains the new credentials and **only** those two lines.
  • /home/user/rotation_logs/credential_rotation.log exists and its content is byte-for-byte identical to the six-line block shown above.
  • File permissions for the three files are 0644 (rw-r--r--).
  • The directory /home/user/rotation_logs exists.
  • Optional: Environment variables may be inspected, but they are not part of the strict automated check, so feel free to print them to the console for human visibility.