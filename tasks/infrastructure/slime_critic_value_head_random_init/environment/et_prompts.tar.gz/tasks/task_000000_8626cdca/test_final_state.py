# test_final_state.py
#
# This pytest suite validates the **final** operating-system / container state
# after the credential-rotation task has been completed.  If any test in this
# file fails, the procedure was *not* carried out exactly as required.
#
# The tests only use the Python standard library and pytest.

import os
import stat
from pathlib import Path

############################
# Constant paths & content #
############################

APP_DIR = Path("/home/user/app")
ENV_FILE = APP_DIR / ".env"
ENV_BACKUP = APP_DIR / ".env.bak"

ROTATION_LOG_DIR = Path("/home/user/rotation_logs")
ROTATION_LOG_FILE = ROTATION_LOG_DIR / "credential_rotation.log"

# Expected *byte* sequences (include trailing LF; must be Unix newlines only)
OLD_ENV_BYTES = b"APP_DB_USER=olduser\nAPP_DB_PASS=oldpass123\n"
NEW_ENV_BYTES = b"APP_DB_USER=newuser2023\nAPP_DB_PASS=newpass!56\n"
ROTATION_LOG_BYTES = (
    b"OLD_USER=olduser\n"
    b"OLD_PASS=oldpass123\n"
    b"NEW_USER=newuser2023\n"
    b"NEW_PASS=newpass!56\n"
    b"STATUS=SUCCESS\n"
)

##########################
# Helper utility methods #
##########################


def _assert_mode_0644(path: Path):
    """Assert that path has permissions 0644 exactly."""
    mode = stat.S_IMODE(path.stat().st_mode)
    assert mode == 0o644, (
        f"{path} must have permissions 0644 (rw-r--r--); "
        f"found {oct(mode)} instead."
    )


def _assert_owned_by_current_user(path: Path):
    """Assert that path is owned by the user running the test suite."""
    file_uid = path.stat().st_uid
    expected_uid = os.getuid()
    assert (
        file_uid == expected_uid
    ), f"{path} must be owned by uid {expected_uid}; found uid {file_uid}."


#############
# The tests #
#############


def test_backup_file_exists_and_correct():
    assert ENV_BACKUP.is_file(), (
        f"Backup file {ENV_BACKUP} is missing. "
        "It must be created during the rotation procedure."
    )

    data = ENV_BACKUP.read_bytes()
    assert data == OLD_ENV_BYTES, (
        f"Backup file {ENV_BACKUP} content is incorrect.\n"
        "It must be a byte-for-byte copy of the *original* .env file:\n"
        f"Expected:\n{OLD_ENV_BYTES!r}\nFound:\n{data!r}"
    )

    # Common checks
    _assert_mode_0644(ENV_BACKUP)
    _assert_owned_by_current_user(ENV_BACKUP)


def test_env_file_updated_correctly():
    assert ENV_FILE.is_file(), f"Required file {ENV_FILE} is missing."

    data = ENV_FILE.read_bytes()

    # 1. Must contain the *new* credential lines exactly
    assert data == NEW_ENV_BYTES, (
        f"{ENV_FILE} content is incorrect.\n"
        f"Expected:\n{NEW_ENV_BYTES!r}\nFound:\n{data!r}"
    )

    # 2. Must NOT contain Windows CRLF
    assert b"\r" not in data, f"{ENV_FILE} must use Unix LF line endings only."

    # Common checks
    _assert_mode_0644(ENV_FILE)
    _assert_owned_by_current_user(ENV_FILE)


def test_rotation_log_exists_and_correct():
    # Directory must exist
    assert ROTATION_LOG_DIR.is_dir(), (
        f"Directory {ROTATION_LOG_DIR} is missing. "
        "It must be created as part of the rotation procedure."
    )

    # File must exist
    assert ROTATION_LOG_FILE.is_file(), (
        f"Audit log {ROTATION_LOG_FILE} is missing."
    )

    data = ROTATION_LOG_FILE.read_bytes()

    assert data == ROTATION_LOG_BYTES, (
        f"{ROTATION_LOG_FILE} content is incorrect.\n"
        f"Expected:\n{ROTATION_LOG_BYTES!r}\nFound:\n{data!r}"
    )

    # Ensure Unix line endings
    assert b"\r" not in data, (
        f"{ROTATION_LOG_FILE} must use Unix LF line endings only."
    )

    # Exactly 5 non-empty lines plus trailing LF
    lines = data.split(b"\n")[:-1]  # drop final empty element
    assert len(lines) == 5, (
        f"{ROTATION_LOG_FILE} must contain exactly 5 lines; "
        f"found {len(lines)} lines."
    )

    # Common checks
    _assert_mode_0644(ROTATION_LOG_FILE)
    _assert_owned_by_current_user(ROTATION_LOG_FILE)


def test_backup_differs_from_updated_env():
    """Sanity check: backup and current .env must differ (old vs new)."""
    backup = ENV_BACKUP.read_bytes()
    current = ENV_FILE.read_bytes()
    assert backup != current, (
        ".env and .env.bak should *not* be identical after rotation—"
        "one should have the old credentials, the other the new ones."
    )