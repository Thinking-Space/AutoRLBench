# test_final_state.py
#
# This pytest file validates the **FINAL** state of the operating system
# after the student has carried out the “user-accounts” task.
#
# The checks performed are:
# 1. The directory /home/user/data still exists.
# 2. The original CSV (/home/user/data/user_accounts.csv) is still present
#    and unchanged (defensive guard; it must not be mangled during the task).
# 3. /home/user/data/usernames.txt exists and has the exact four‐line
#    content required, in the correct order and with no header or blank lines.
# 4. /home/user/data/new_userlist.csv exists and has the exact four‐line,
#    two-column (role,username) content required, in the correct order and
#    with no header or blank lines.
# 5. Both newly-created files are regular, readable files.
#
# Any deviation from the expected state results in a clear, actionable
# pytest failure message.

from pathlib import Path
import pytest

DATA_DIR = Path("/home/user/data")

# -----  Expected absolute paths  ------------------------------------------------
CSV_PATH_ORIGINAL = DATA_DIR / "user_accounts.csv"
USERNAMES_TXT = DATA_DIR / "usernames.txt"
NEW_USERLIST_CSV = DATA_DIR / "new_userlist.csv"

# -----  Ground-truth content  ---------------------------------------------------
EXPECTED_CSV_LINES = [
    "username,email,role",
    "alice,alice@example.com,editor",
    "bob,bob@example.com,admin",
    "carol,carol@example.com,viewer",
    "dave,dave@example.com,editor",
]

EXPECTED_USERNAMES_LINES = [
    "alice",
    "bob",
    "carol",
    "dave",
]

EXPECTED_NEW_USERLIST_LINES = [
    "editor,alice",
    "admin,bob",
    "viewer,carol",
    "editor,dave",
]


# --------------------------------------------------------------------------- #
#                               Helper utilities                              #
# --------------------------------------------------------------------------- #
def read_lines(path: Path):
    """
    Return a list of lines from *path* with only the trailing LF removed.
    CRLF will never appear in the container, but rstrip('\n') is safer than
    str.splitlines() because it preserves possible embedded CR characters.
    """
    with path.open("r", encoding="utf-8") as fh:
        return [ln.rstrip("\n") for ln in fh]


def assert_regular_readable(path: Path):
    """
    Assert that *path* exists, is a regular file, and is readable by the
    current Python process.
    """
    assert path.exists(), f"Required file {path} does not exist."
    assert path.is_file(), f"{path} exists but is not a regular file."
    try:
        with path.open("r", encoding="utf-8"):
            pass
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"File {path} is not readable: {exc!r}")


# --------------------------------------------------------------------------- #
#                                   Tests                                     #
# --------------------------------------------------------------------------- #
def test_data_directory_still_present():
    assert DATA_DIR.exists(), f"Required directory {DATA_DIR} is missing."
    assert DATA_DIR.is_dir(), f"{DATA_DIR} exists but is not a directory."


def test_original_csv_unchanged():
    """
    Guard against accidental modification/removal of the source file.
    """
    assert_regular_readable(CSV_PATH_ORIGINAL)
    lines = read_lines(CSV_PATH_ORIGINAL)
    assert (
        lines == EXPECTED_CSV_LINES
    ), (
        "user_accounts.csv has been altered.\n\n"
        f"Expected:\n{EXPECTED_CSV_LINES}\n\nFound:\n{lines}"
    )


def test_usernames_txt_created_correctly():
    assert_regular_readable(USERNAMES_TXT)
    lines = read_lines(USERNAMES_TXT)

    # Validate exact content and order.
    assert (
        lines == EXPECTED_USERNAMES_LINES
    ), (
        "/home/user/data/usernames.txt content mismatch.\n\n"
        f"Expected lines:\n{EXPECTED_USERNAMES_LINES}\n\nFound:\n{lines}"
    )

    # Extra guard: no commas, no header.
    assert all("," not in ln for ln in lines), (
        "usernames.txt must contain only the username on each line—"
        "no commas or additional columns."
    )


def test_new_userlist_csv_created_correctly():
    assert_regular_readable(NEW_USERLIST_CSV)
    lines = read_lines(NEW_USERLIST_CSV)

    # Validate exact content and order.
    assert (
        lines == EXPECTED_NEW_USERLIST_LINES
    ), (
        "/home/user/data/new_userlist.csv content mismatch.\n\n"
        f"Expected lines:\n{EXPECTED_NEW_USERLIST_LINES}\n\nFound:\n{lines}"
    )

    # Extra guard: each line must have exactly one comma separating role,username.
    for idx, ln in enumerate(lines, start=1):
        parts = ln.split(",")
        assert len(parts) == 2, (
            f"Line {idx} in new_userlist.csv does not have exactly two columns: "
            f"'{ln}'"
        )
        role, username = parts
        # Ensure no accidental whitespace padding
        assert role == role.strip(), (
            f"Role field on line {idx} has leading/trailing whitespace: '{role}'"
        )
        assert username == username.strip(), (
            f"Username field on line {idx} has leading/trailing whitespace: "
            f"'{username}'"
        )