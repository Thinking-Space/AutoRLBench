You are acting as the site administrator for a small web service.
A data dump of the current user table has been placed at

    /home/user/data/user_accounts.csv

The file is **already present** and has the exact five-line content shown below
(including the header on the first line and using the *literal* comma character
as the field separator).

```
username,email,role
alice,alice@example.com,editor
bob,bob@example.com,admin
carol,carol@example.com,viewer
dave,dave@example.com,editor
```

Your job is to create two new helper files, both in the same directory
(`/home/user/data`):

1.  `/home/user/data/usernames.txt`
    *   One username per line, in the original order found in
        `user_accounts.csv`.
    *   No extra blank lines, spaces, or header. The file must look **exactly** like:

    ```
    alice
    bob
    carol
    dave
    ```

2.  `/home/user/data/new_userlist.csv`
    *   Two columns only: role (first) and username (second).
    *   Comma-separated, no header line, same row order as in the source file.
    *   The file must look **exactly** like:

    ```
    editor,alice
    admin,bob
    viewer,carol
    editor,dave
    ```

**Constraints**

*   Do **not** hard-code the lines; the data must be extracted from the existing CSV file.
*   Make sure both output files are placed in `/home/user/data` and are readable by the current unprivileged user.

The automated test will verify:

*   that `/home/user/data/usernames.txt` exists **and** matches the exact four-line content shown above;
*   that `/home/user/data/new_userlist.csv` exists **and** matches the exact four-line, two-column CSV content shown above;
*   that no header line is present in either new file.

No additional changes are required.