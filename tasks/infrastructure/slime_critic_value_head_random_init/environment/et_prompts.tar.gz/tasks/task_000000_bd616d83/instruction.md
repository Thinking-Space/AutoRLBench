You are the systems administrator of several servers and need to prepare a very small “status-at-a-glance” report that managers can read.
Everything you need is already on disk. Your job is to build the file
/home/user/reports/connection_load_summary.tsv
by combining selected columns from two existing tab-separated log files.

Source material (already on disk):

1)  /home/user/raw_logs/active_connections.tsv
    – tab-separated, **five** columns, first row is a header

        HOSTNAME<tab>IP<tab>PORT<tab>STATE<tab>PID
        web01<tab>10.0.0.1<tab>80<tab>ESTABLISHED<tab>2345
        db01<tab>10.0.0.2<tab>5432<tab>ESTABLISHED<tab>5432
        cache01<tab>10.0.0.3<tab>6379<tab>LISTEN<tab>3333

2)  /home/user/raw_logs/cpu_load.tsv
    – tab-separated, **four** columns, first row is a header

        HOSTNAME<tab>1min<tab>5min<tab>15min
        web01<tab>0.10<tab>0.12<tab>0.15
        db01<tab>0.55<tab>0.53<tab>0.50
        cache01<tab>0.20<tab>0.25<tab>0.30

What the report must look like (exact byte-for-byte target; “<tab>” means an ASCII TAB 0x09):

        HOSTNAME<tab>PORT<tab>STATE<tab>1min_LOAD
        web01<tab>80<tab>ESTABLISHED<tab>0.10
        db01<tab>5432<tab>ESTABLISHED<tab>0.55
        cache01<tab>6379<tab>LISTEN<tab>0.20

Notes on building the report:
*   Do **not** re-type the data manually.
*   Preserve the order of rows exactly as they appear in active_connections.tsv.
*   The column to pull from each source file is as follows
    – active\_connections.tsv : 1 (HOSTNAME), 3 (PORT), 4 (STATE)
    – cpu\_load.tsv : 2 (1min)
    Rename the cpu\_load column to 1min\_LOAD in the final header.

Command logging requirement:
While you work, append every command you actually execute (in the exact form you typed it) to
/home/user/reports/summary_commands.log
Put one command per line, in execution order, with no extra commentary.
This allows an auditor to replay your steps later.

Summary of what must exist when you are done:

1)  /home/user/reports/connection\_load\_summary.tsv – containing exactly the three data lines plus the header shown above.
2)  /home/user/reports/summary\_commands.log – a plain-text list of all commands you issued, each on its own line.

The automated grader will check:

*   That the summary file exists at the exact path and matches the precise content and ordering above, byte-for-byte.
*   That the commands log exists at the exact path and is non-empty.

Do not move or rename any of the source log files.
Do not use sudo or elevated privileges; everything is writable by the current user.
Work only with what is described here and place nothing outside /home/user/reports.
When you’re convinced all requirements are satisfied, you can consider the task complete.