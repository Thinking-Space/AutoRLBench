# test_final_state.py
#
# Pytest suite that validates the **final** state of the operating-system /
# container AFTER the student has completed the “connection_load_summary”
# reporting task.
#
# The checks performed here must all pass for the solution to be accepted:
#
#   1) /home/user/reports/connection_load_summary.tsv
#        • exists
#        • contains EXACTLY the four lines (header + 3 data rows) shown in the
#          task description, in the same order, separated by ASCII TABs.
#
#   2) /home/user/reports/summary_commands.log
#        • exists and is non-empty
#        • contains at least TWO *different* lines that include the substring
#          “cut”
#        • contains at least ONE line that includes the substring “paste”
#
# Any deviation from these expectations should result in a clear, actionable
# failure message.
#
# Only the Python standard library and pytest are used.

from pathlib import Path
import textwrap

import pytest

# --------------------------------------------------------------------------- #
# Constants
# --------------------------------------------------------------------------- #
HOME = Path("/home/user")
REPORTS_DIR = HOME / "reports"

SUMMARY_FILE = REPORTS_DIR / "connection_load_summary.tsv"
COMMANDS_LOG = REPORTS_DIR / "summary_commands.log"

EXPECTED_LINES = [
    "HOSTNAME\tPORT\tSTATE\t1min_LOAD",
    "web01\t80\tESTABLISHED\t0.10",
    "db01\t5432\tESTABLISHED\t0.55",
    "cache01\t6379\tLISTEN\t0.20",
]


# --------------------------------------------------------------------------- #
# Helper Functions
# --------------------------------------------------------------------------- #
def _read_lines(path: Path):
    """
    Return a list of lines from *path* with trailing newlines stripped.
    Empty lines (if any) are preserved so that byte-for-byte validation is
    possible—i.e. a physical blank line will show up as ''.
    """
    with path.open("r", encoding="utf-8") as fh:
        return [ln.rstrip("\n") for ln in fh]


def _pretty_diff(expected, actual):
    """
    Produce a unified diff-style string that highlights the first place the
    two sequences differ.  Keeps the error message readable.
    """
    from difflib import ndiff

    diff = ndiff(
        [f"{idx+1:>2}: {line!r}" for idx, line in enumerate(expected)],
        [f"{idx+1:>2}: {line!r}" for idx, line in enumerate(actual)],
    )
    # Truncate long diffs—only show the first dozen lines to keep pytest
    # output compact, but indicate additional context exists.
    diff_list = list(diff)
    if len(diff_list) > 12:
        diff_list = diff_list[:12] + ["... (diff truncated) ..."]
    return "\n".join(diff_list)


# --------------------------------------------------------------------------- #
# Tests for the summary TSV
# --------------------------------------------------------------------------- #
def test_summary_file_exists():
    assert SUMMARY_FILE.is_file(), (
        f"Expected report file is missing: {SUMMARY_FILE}\n"
        f"Make sure your commands produced the file at the exact path."
    )


def test_summary_file_contents_exact_match():
    actual_lines = _read_lines(SUMMARY_FILE)

    # Check total number of lines first for a quick, clear error.
    assert len(actual_lines) == len(
        EXPECTED_LINES
    ), textwrap.dedent(
        f"""
        {SUMMARY_FILE} has {len(actual_lines)} non-empty line(s); expected {len(EXPECTED_LINES)}.
        Expected lines:
        {EXPECTED_LINES!r}
        Found lines:
        {actual_lines!r}
        """
    )

    # Compare line-by-line for exact match.
    if actual_lines != EXPECTED_LINES:
        diff = _pretty_diff(EXPECTED_LINES, actual_lines)
        pytest.fail(
            textwrap.dedent(
                f"""
                Contents of {SUMMARY_FILE} do not match the expected target.

                Diff (expected ⟶ actual):
                {diff}
                """
            )
        )


def test_summary_file_tab_integrity_and_column_counts():
    """
    Sanity check to ensure each line uses tabs and has the right number of
    columns (4).  This gives the student a more precise hint if spacing is
    wrong.
    """
    for idx, line in enumerate(EXPECTED_LINES, start=1):
        cols = line.split("\t")
        assert (
            len(cols) == 4
        ), f"Internal error in tests: EXPECTED_LINES line {idx} has {len(cols)} cols."

    for idx, line in enumerate(_read_lines(SUMMARY_FILE), start=1):
        cols = line.split("\t")
        assert (
            len(cols) == 4
        ), (
            f"Line {idx} in {SUMMARY_FILE} has {len(cols)} column(s); "
            f"each line must have exactly 4 columns separated by TABs."
        )


# --------------------------------------------------------------------------- #
# Tests for the commands log
# --------------------------------------------------------------------------- #
def test_commands_log_exists_and_not_empty():
    assert COMMANDS_LOG.is_file(), (
        f"Command log {COMMANDS_LOG} is missing.\n"
        f"Ensure you appended every command you ran to this file."
    )

    lines = _read_lines(COMMANDS_LOG)
    # If the user left a trailing newline at EOF, _read_lines() will include a
    # final '' entry.  Treat a file with only '' as empty.
    non_blank_lines = [ln for ln in lines if ln.strip()]
    assert non_blank_lines, (
        f"{COMMANDS_LOG} is empty. It must contain the commands you executed."
    )


def test_commands_log_contains_required_cut_and_paste():
    lines = _read_lines(COMMANDS_LOG)

    cut_lines = [ln for ln in lines if "cut" in ln]
    paste_lines = [ln for ln in lines if "paste" in ln]

    unique_cut = {ln for ln in cut_lines}

    assert (
        len(unique_cut) >= 2
    ), (
        f"{COMMANDS_LOG} must contain at least TWO distinct lines that include "
        f"the substring 'cut'. Found {len(unique_cut)} such line(s):\n{unique_cut}"
    )

    assert paste_lines, (
        f"{COMMANDS_LOG} must contain at least ONE line that includes the "
        f"substring 'paste'. No such line was found."
    )


# --------------------------------------------------------------------------- #
# End of test suite
# --------------------------------------------------------------------------- #