You are a container-platform specialist who needs to prepare a clean list of currently running micro-services for an automated deployment pipeline.

The following input file is already present on the workstation:

*   `/home/user/services/registry.txt`
    Each line has the format
    `<service_name><TAB><port_number><TAB><status>`
    where “status” is either “up” or “down”.
    Lines may contain leading / trailing spaces or be indented with tabs; there are no comment lines.

Your goal is to transform that file into a new CSV file that the pipeline can consume:

*   `/home/user/services/active_services.csv`

Exact requirements for `active_services.csv`:

1.  Include only the services whose status column is exactly the literal word `up` (case-sensitive).
2.  For every selected service, write a single line containing just
    `service_name,port_number`
    (i.e., two values separated by ONE literal comma, with NO spaces before or after the comma).
3.  Sort the lines alphabetically by `service_name` (ascending, plain ASCII sort).
4.  Do NOT add a header line and do NOT leave a trailing blank line at the end of the file (the final character of the file must be the trailing newline of the last data row).
5.  Overwrite the file if it already exists.

When you are finished, `active_services.csv` must exist exactly in the path shown and match the specified format so that an automated test can read it.
Display the file’s full contents in the terminal as a final confirmation step.