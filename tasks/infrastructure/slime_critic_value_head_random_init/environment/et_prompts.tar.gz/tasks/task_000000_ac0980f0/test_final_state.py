# test_final_state.py
#
# This pytest module validates the FINAL state of the workstation
# AFTER the learner has finished the task.  It focuses on the
# presence and exact contents of /home/user/services/active_services.csv.
#
# The checks below enforce every requirement from the exercise
# description and will clearly report what is still wrong if any
# assertion fails.
#
# Only the Python standard library and pytest are used.

import pathlib
import re
import pytest

SERVICES_DIR = pathlib.Path("/home/user/services")
REGISTRY_FILE = SERVICES_DIR / "registry.txt"
ACTIVE_CSV   = SERVICES_DIR / "active_services.csv"

# Canonical truth taken from the exercise statement: the registry
# must already contain these exact records BEFORE the learner starts.
# Format: (service_name, port_number, status)
TRUTH_REGISTRY = [
    ("webapp",   "8080", "up"),
    ("auth",     "9090", "up"),
    ("payments", "7070", "down"),
    ("monitor",  "8181", "up"),
    ("search",   "9200", "down"),
    ("cache",    "6379", "up"),
]


def _parse_registry(path):
    """
    Parse /home/user/services/registry.txt and return a list of
    (service_name, port, status) tuples while being tolerant of leading /
    trailing whitespace in each line.
    """
    records = []
    with path.open(encoding="utf-8") as fh:
        for lineno, raw in enumerate(fh, 1):
            stripped = raw.strip()
            if not stripped:
                # Skip blank lines (including a possible trailing blank line)
                continue

            # Split on ANY run of whitespace (tabs or spaces)
            parts = re.split(r"[ \t]+", stripped)
            if len(parts) != 3:
                pytest.fail(
                    f"{path} line {lineno} should contain exactly 3 columns "
                    f"(<service> <port> <status>) separated by whitespace. "
                    f"Found: {parts}"
                )
            records.append(tuple(parts))
    return records


def _expected_active_lines():
    """
    Return the list of CSV rows that MUST appear in active_services.csv,
    sorted alphabetically by service name as specified.
    """
    up_records = [
        (name, port) for name, port, status in TRUTH_REGISTRY if status == "up"
    ]
    # Sort by service_name (index 0)
    up_records.sort(key=lambda tpl: tpl[0])
    return [f"{name},{port}" for name, port in up_records]


def test_active_csv_exists_and_is_file():
    assert ACTIVE_CSV.exists(), (
        f"The file {ACTIVE_CSV} does not exist.  "
        "It must be created by your commands."
    )
    assert ACTIVE_CSV.is_file(), (
        f"{ACTIVE_CSV} exists but is not a regular file."
    )


def test_active_csv_contents_exact_match():
    # ------------------------------------------------------------------
    # 1. Read the file exactly as bytes to check new-line semantics
    #    (no extra blank line at the end).
    # ------------------------------------------------------------------
    raw_bytes = ACTIVE_CSV.read_bytes()
    assert raw_bytes, f"{ACTIVE_CSV} is empty."
    assert raw_bytes.endswith(b"\n"), (
        f"{ACTIVE_CSV} must end with a single newline character."
    )
    # The file must NOT end with two consecutive newlines (blank line)
    assert not raw_bytes.endswith(b"\n\n"), (
        f"{ACTIVE_CSV} ends with a blank line.  "
        "Remove the extra empty line after the last record."
    )

    # ------------------------------------------------------------------
    # 2. Parse logical lines as decoded UTF-8 strings
    # ------------------------------------------------------------------
    lines = ACTIVE_CSV.read_text(encoding="utf-8").splitlines()

    expected_lines = _expected_active_lines()

    # 2a. Check record count
    assert len(lines) == len(expected_lines), (
        f"{ACTIVE_CSV} should contain exactly {len(expected_lines)} line(s) "
        f"but has {len(lines)}."
    )

    # 2b. Check alphabetical sort order
    assert lines == sorted(lines), (
        f"Lines in {ACTIVE_CSV} are not alphabetically sorted by service name. "
        "Expected order:\n  " + "\n  ".join(expected_lines)
    )

    # 2c. Check for unwanted header
    header_pattern = re.compile(r"service|name|port", re.IGNORECASE)
    assert not header_pattern.search(lines[0]), (
        f"{ACTIVE_CSV} must NOT contain a header line, but the first line "
        f"looks like one: {lines[0]!r}"
    )

    # 2d. Validate individual line formats and absence of spaces
    invalid_formats = [
        line for line in lines
        if not re.fullmatch(r"[^\s,]+,[^\s,]+", line)
    ]
    assert not invalid_formats, (
        "The following line(s) in "
        f"{ACTIVE_CSV} do not match the required format "
        "'service_name,port_number' with NO spaces:\n  " +
        "\n  ".join(invalid_formats)
    )

    # 2e. Exact content comparison with truth
    missing = [line for line in expected_lines if line not in lines]
    unexpected = [line for line in lines if line not in expected_lines]

    assert not missing, (
        f"{ACTIVE_CSV} is missing expected line(s):\n  " +
        "\n  ".join(missing)
    )
    assert not unexpected, (
        f"{ACTIVE_CSV} contains unexpected line(s):\n  " +
        "\n  ".join(unexpected)
    )


def test_registry_file_unchanged():
    """
    Sanity guard: the learner's commands should not have altered
    the original registry.txt.  Re-parse it and ensure it matches
    the truth data exactly.
    """
    actual_records = _parse_registry(REGISTRY_FILE)
    assert actual_records == TRUTH_REGISTRY, (
        f"{REGISTRY_FILE} was modified.  It must remain unchanged."
    )