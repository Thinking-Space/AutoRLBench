# test_final_state.py
#
# Pytest suite that validates the *final* state of the operating system /
# container after the student has completed the “ports-must-be-well-known”
# task.  The tests make no assumptions about *how* the artefacts were created;
# they inspect only the end result on disk.
#
# The suite asserts:
#   • /home/user/output/ exists and is a directory.
#   • /home/user/output/high_ports.txt exists and its contents are
#     byte-for-byte correct (including the mandatory trailing newline).
#   • The file contains only TCP ports strictly greater than 1024, one per
#     line, numerically sorted in ascending order with no duplicates.
#   • /home/user/output/compliance.log exists, contains exactly one line of the
#     mandated format, and the count reported matches the number of ports
#     listed in high_ports.txt.
#
# Only the Python standard library and pytest are used.

import os
import re
import pytest

OUTPUT_DIR = "/home/user/output"
HIGH_PORTS_PATH = os.path.join(OUTPUT_DIR, "high_ports.txt")
COMPLIANCE_LOG_PATH = os.path.join(OUTPUT_DIR, "compliance.log")

# Expected truth data (including trailing newline)
EXPECTED_PORTS = ["3306", "5432", "8080", "10022", "12000"]
EXPECTED_HIGH_PORTS_CONTENT = "\n".join(EXPECTED_PORTS) + "\n"
EXPECTED_LOG_CONTENT = "High ports extracted: 5\n"


def test_output_directory_exists():
    assert os.path.exists(OUTPUT_DIR), (
        f"Output directory {OUTPUT_DIR} was not found. "
        "Make sure you created it."
    )
    assert os.path.isdir(OUTPUT_DIR), (
        f"{OUTPUT_DIR} exists but is not a directory."
    )


def test_high_ports_file_exists():
    assert os.path.exists(HIGH_PORTS_PATH), (
        f"Required file {HIGH_PORTS_PATH} is missing."
    )
    assert os.path.isfile(HIGH_PORTS_PATH), (
        f"Expected a regular file at {HIGH_PORTS_PATH}, but something else is there."
    )


def test_high_ports_file_contents():
    with open(HIGH_PORTS_PATH, "r", encoding="utf-8") as fh:
        content = fh.read()

    # Exact byte-for-byte check (including trailing newline)
    assert content == EXPECTED_HIGH_PORTS_CONTENT, (
        f"Contents of {HIGH_PORTS_PATH} are incorrect.\n\n"
        "Expected (repr):\n"
        f"{repr(EXPECTED_HIGH_PORTS_CONTENT)}\n\n"
        "Actual (repr):\n"
        f"{repr(content)}"
    )

    # Additional sanity-checks (helpful in partial-credit debugging)
    lines = content.splitlines()
    # 1. All lines must be digits only.
    bad_lines = [ln for ln in lines if not ln.isdigit()]
    assert not bad_lines, (
        f"The following lines in {HIGH_PORTS_PATH} are not pure port numbers: {bad_lines}"
    )
    # 2. Ports must all be >1024.
    not_high = [ln for ln in lines if int(ln) <= 1024]
    assert not not_high, (
        f"The following ports are not strictly greater than 1024: {not_high}"
    )
    # 3. Ensure numeric ascending order.
    numeric_lines = [int(ln) for ln in lines]
    assert numeric_lines == sorted(numeric_lines), (
        f"Ports are not sorted numerically ascending in {HIGH_PORTS_PATH}: {lines}"
    )
    # 4. Duplicates check.
    assert len(lines) == len(set(lines)), (
        "Duplicate port numbers found in high_ports.txt."
    )


def test_compliance_log_exists():
    assert os.path.exists(COMPLIANCE_LOG_PATH), (
        f"Required file {COMPLIANCE_LOG_PATH} is missing."
    )
    assert os.path.isfile(COMPLIANCE_LOG_PATH), (
        f"Expected a regular file at {COMPLIANCE_LOG_PATH}, but something else is there."
    )


def test_compliance_log_contents_and_count():
    with open(COMPLIANCE_LOG_PATH, "r", encoding="utf-8") as fh:
        log_content = fh.read()

    # Exact match first.
    assert log_content == EXPECTED_LOG_CONTENT, (
        f"Contents of {COMPLIANCE_LOG_PATH} are incorrect.\n\n"
        "Expected (repr):\n"
        f"{repr(EXPECTED_LOG_CONTENT)}\n\n"
        "Actual (repr):\n"
        f"{repr(log_content)}"
    )

    # Regex sanity-check in case exact match fails in future changes
    match = re.fullmatch(r"High ports extracted: (\d+)\n", log_content)
    assert match, (
        f"{COMPLIANCE_LOG_PATH} must contain exactly one line in the form "
        "'High ports extracted: N' followed by a newline."
    )
    logged_count = int(match.group(1))

    with open(HIGH_PORTS_PATH, "r", encoding="utf-8") as fh:
        actual_count = len([ln for ln in fh.read().splitlines() if ln.strip() != ""])

    assert logged_count == actual_count, (
        f"Mismatch between reported count in compliance.log ({logged_count}) and "
        f"actual number of ports in high_ports.txt ({actual_count})."
    )