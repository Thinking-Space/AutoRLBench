You are a DevSecOps engineer who must quickly enforce a “ports-must-be-well-known” policy on a CSV inventory.
Everything you need is already on disk.

1.  A comma-separated file exists at
    `/home/user/policies/service_ports.csv`

2.  Your job is to create BOTH of the following artefacts inside the directory
    `/home/user/output`
    (create the directory first if it does not yet exist):
    a. `/home/user/output/high_ports.txt`
       *   Contains ONLY the TCP port numbers that are **strictly greater than 1024**.
       *   One port per line, nothing else, no extra spaces or blank lines.
       *   The list must be numerically sorted in ascending order and deduplicated.
    b. `/home/user/output/compliance.log`
       *   Single-line log entry in the exact form
           `High ports extracted: N`
           where N is the total count of lines (ports) that ended up in `high_ports.txt`.

3.  After creating the required files, verify your work by printing the contents of both new files to the terminal so the auditor can see the results.

The automated tests will check:
*   The presence of `/home/user/output/high_ports.txt` and `/home/user/output/compliance.log`
*   That `high_ports.txt` contains only the correct port numbers, one per line, sorted ascending, no duplicates.
*   That `compliance.log` contains exactly one line matching the required format with the correct count.