# test_final_state.py
#
# Pytest suite that validates the **FINAL** system/container state **after**
# the learner has completed the “INI audit-log” task.
#
# The assertions below use privileged “truth” data supplied by the exercise
# author.  They confirm that:
#
# 1. The original configuration file /home/user/compliance/app.conf
#    • still exists
#    • is unmodified (permissions + content)
#
# 2. A new directory  /home/user/compliance/audit/      now exists (0755)
# 3. A new file       /home/user/compliance/audit/audit.log
#    • exists (0644)
#    • has exactly four lines, in the prescribed order/format
#    • ends with a single trailing newline and no extra blank lines
#
# 4. No extra files were created inside the audit directory.
#
# Any deviation from the expected end-state produces a clear, actionable
# failure message.
#
# Only stdlib + pytest are used, per project requirements.

import os
import stat
import configparser
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Constants (truth data)
# ---------------------------------------------------------------------------

CONF_PATH   = Path("/home/user/compliance/app.conf")
AUDIT_DIR   = Path("/home/user/compliance/audit")
AUDIT_FILE  = AUDIT_DIR / "audit.log"

EXPECTED_APP_CONF_MODE   = 0o644           # must remain unchanged
EXPECTED_AUDIT_DIR_MODE  = 0o755           # default mkdir perms
EXPECTED_AUDIT_FILE_MODE = 0o644           # any umask should yield this or tighter

# Expected lines and full file payload (note final \n).
EXPECTED_LINES = [
    "2023-01-01T00:00:00Z | Security | encryption       | AES256",
    "2023-01-01T00:00:00Z | Security | password_policy  | strong",
    "2023-01-01T00:00:00Z | Network  | port             | 443",
    "2023-01-01T00:00:00Z | Network  | tls              | enabled",
]
EXPECTED_AUDIT_PAYLOAD = "\n".join(EXPECTED_LINES) + "\n"

# Expected key/value pairs in the original INI file
EXPECTED_SETTINGS = {
    ("Security", "encryption"): "AES256",
    ("Security", "password_policy"): "strong",
    ("Network",  "port"): "443",
    ("Network",  "tls"):  "enabled",
}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mode(path: Path) -> int:
    """Return mode bits (e.g. 0o644) for *path*."""
    return stat.S_IMODE(path.stat().st_mode)


def _read_config(path: Path) -> configparser.ConfigParser:
    """Read INI file with case preserved."""
    cp = configparser.ConfigParser()
    cp.optionxform = str
    with path.open() as fp:
        cp.read_file(fp)
    return cp

# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

# 1. Original configuration file must still be present & unchanged
def test_app_conf_still_intact():
    assert CONF_PATH.exists() and CONF_PATH.is_file(), (
        f"Pre-existing config file missing or not a file: {CONF_PATH}"
    )

    perms = _mode(CONF_PATH)
    assert perms == EXPECTED_APP_CONF_MODE, (
        f"{CONF_PATH} permissions changed: now {oct(perms)}, expected 0o644"
    )

    parser = _read_config(CONF_PATH)
    mismatches = []

    for (section, key), expected_val in EXPECTED_SETTINGS.items():
        if not parser.has_section(section):
            mismatches.append(f"missing section [{section}]")
            continue
        if not parser.has_option(section, key):
            mismatches.append(f"missing key '{key}' in [{section}]")
            continue
        actual_val = parser.get(section, key).strip()
        if actual_val != expected_val:
            mismatches.append(
                f"[{section}] {key}={actual_val!r} (expected {expected_val!r})"
            )

    if mismatches:
        pytest.fail(
            "The original configuration file was modified:\n  - "
            + "\n  - ".join(mismatches)
        )

# 2. Audit directory existence & permissions
def test_audit_directory_exists_with_correct_perms():
    assert AUDIT_DIR.exists(), f"Audit directory not found: {AUDIT_DIR}"
    assert AUDIT_DIR.is_dir(), f"{AUDIT_DIR} exists but is not a directory"

    actual_mode = _mode(AUDIT_DIR)
    # Accept exact 0755 or any stricter (e.g. 0700) permissions
    assert actual_mode & 0o777 == EXPECTED_AUDIT_DIR_MODE, (
        f"{AUDIT_DIR} permissions are {oct(actual_mode)}, expected 0o755"
    )

# 3. audit.log existence & permissions
def test_audit_log_exists_with_correct_perms():
    assert AUDIT_FILE.exists(), f"Audit log not found: {AUDIT_FILE}"
    assert AUDIT_FILE.is_file(), f"{AUDIT_FILE} exists but is not a regular file"

    actual_mode = _mode(AUDIT_FILE)
    # Accept exact 0644 or stricter (0600) permissions
    assert (actual_mode & 0o777) == EXPECTED_AUDIT_FILE_MODE, (
        f"{AUDIT_FILE} permissions are {oct(actual_mode)}, expected 0o644"
    )

# 4. audit.log content must match truth data exactly
def test_audit_log_content_is_exact():
    data = AUDIT_FILE.read_text()

    # 4a. Exact payload including final newline
    assert data == EXPECTED_AUDIT_PAYLOAD, (
        "audit.log content mismatch.\n"
        "Expected:\n"
        f"{EXPECTED_AUDIT_PAYLOAD!r}\n\n"
        "Found:\n"
        f"{data!r}"
    )

    # 4b. No extra blank lines (covering the case of additional newlines)
    lines = data.splitlines()
    assert len(lines) == 4, (
        f"audit.log should have exactly 4 lines; found {len(lines)}"
    )

# 5. No extra artefacts in audit directory
def test_no_extra_files_in_audit_directory():
    items = [p.name for p in AUDIT_DIR.iterdir()]
    extras = [name for name in items if name != AUDIT_FILE.name]
    assert not extras, (
        f"Unexpected files/directories in {AUDIT_DIR}: {', '.join(extras)}"
    )