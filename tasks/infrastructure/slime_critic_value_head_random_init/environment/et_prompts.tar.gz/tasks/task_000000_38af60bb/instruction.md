As part of a lightweight internal controls check, you have been given a pre-existing INI style configuration file located at
    
        /home/user/compliance/app.conf
    
Your goal is to extract four very specific settings and write a one-off audit log that can later be ingested by the compliance team’s central monitoring service.

Existing configuration file layout (for reference only – do **NOT** modify it):

    [Security]
    encryption = AES256
    password_policy = strong

    [Network]
    port = 443
    tls  = enabled

    [Database]
    backup = daily

The final state must meet these requirements:

*   The directory `/home/user/compliance/audit` must exist.
*   A plain-text file named `audit.log` must exist inside that directory.
*   The `audit.log` file must contain data from the following case-sensitive keys in `app.conf`:
      * `encryption`          (within [Security])
      * `password_policy`     (within [Security])
      * `port`                (within [Network])
      * `tls`                 (within [Network])
*   `audit.log` must be populated with *exactly* four lines – one per key – in this strict, pipe-delimited format:

      `2023-01-01T00:00:00Z | <SECTION> | <KEY> | <VALUE>`

    Mandatory, verifiable details:
    *   The timestamp string **must** be exactly `2023-01-01T00:00:00Z` (hard-coded; do not substitute the current time).
    *   A single space must precede and follow each vertical bar (" | ").
    *   Lines must appear in the following order:

            1. 2023-01-01T00:00:00Z | Security | encryption       | AES256
            2. 2023-01-01T00:00:00Z | Security | password_policy  | strong
            3. 2023-01-01T00:00:00Z | Network  | port             | 443
            4. 2023-01-01T00:00:00Z | Network  | tls              | enabled

    *   No blank lines or trailing whitespace after the final newline.
    *   The file's contents must not be altered after its initial creation.

The compliance test harness will look only for the exact file path and the precise content/format shown above, so please follow these requirements verbatim.