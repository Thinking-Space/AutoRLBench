# test_final_state.py
#
# Pytest suite that validates the **FINAL** operating-system / container state
# for the “profiling environment variables” exercise.
#
# It asserts, byte-for-byte, that
#   1.  /home/user/.config/profiling/.env
#   2.  /home/user/profiling_env.log
# both exist and contain the exact required contents, *and nothing more*.
#
# It also spawns a fresh POSIX shell, sources the dotenv file, and confirms
# that the two variables are exposed to every child process exactly as
# specified.
#
# If any assertion fails the test output will explain precisely what is wrong,
# helping the student pinpoint the missing or incorrect step.
#
# Only Python’s standard library and `pytest` are used.

import os
import subprocess
import textwrap

import pytest

# ---------------------------------------------------------------------------
# Constants used in every test
# ---------------------------------------------------------------------------

ENV_FILE = "/home/user/.config/profiling/.env"
LOG_FILE = "/home/user/profiling_env.log"

# Two lines, UNIX line-feeds, *no* trailing blank line.
# (i.e. exactly two '\n' characters, last byte is '\n')
EXPECTED_BYTES = b"APP_MODE=profiling\nPROFILER_PORT=6060\n"
EXPECTED_LINES = [
    "APP_MODE=profiling",
    "PROFILER_PORT=6060",
]


# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------


def _read_bytes(path):
    """
    Convenience wrapper that makes an explicit assertion that the file exists
    before trying to read it, so that any failure message is crystal clear.
    """
    assert os.path.exists(path), f"Expected file '{path}' does not exist."
    with open(path, "rb") as fh:
        return fh.read()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("path", [ENV_FILE, LOG_FILE])
def test_files_exist(path):
    """Both the dotenv and the log file must be present."""
    assert os.path.exists(
        path
    ), f"Required file '{path}' is missing. Did you create it at the exact path?"


@pytest.mark.parametrize(
    "path,location",
    [
        (ENV_FILE, "dotenv"),
        (LOG_FILE, "log"),
    ],
)
def test_file_contents_exact(path, location):
    """
    The dotenv and log files must be byte-for-byte identical to the expected
    truth.  We test bytes so that even invisible characters (extra spaces,
    carriage returns, wrong newline style, etc.) are caught.
    """
    data = _read_bytes(path)

    # Exact byte match first
    assert (
        data == EXPECTED_BYTES
    ), textwrap.dedent(
        f"""
        The {location} file '{path}' does not match the required contents.

        --- expected (repr) ---
        {repr(EXPECTED_BYTES)}
        ---   found (repr) ---
        {repr(data)}
        -----------------------

        Make sure:
          * There are **only** the two required lines.
          * Each line ends with a single UNIX newline ('\\n').
          * No extra blank line, spaces, or carriage returns are present.
        """
    )

    # Now do some structural sanity checks to give even friendlier failure
    # messages should the byte-for-byte assertion ever pass for some strange
    # reason yet structure be wrong (defensive programming).
    lines = data.decode().splitlines()
    assert lines == EXPECTED_LINES, (
        f"The {location} file '{path}' should have exactly these two lines:\n"
        f"{EXPECTED_LINES}\nBut it actually has:\n{lines}"
    )
    assert data.endswith(
        b"\n"
    ), f"The {location} file '{path}' must end with a single '\\n' character."


def test_log_matches_env_file():
    """
    The demonstration log must contain *exactly* what was in the original
    dotenv file—nothing more, nothing less.
    """
    env_bytes = _read_bytes(ENV_FILE)
    log_bytes = _read_bytes(LOG_FILE)
    assert (
        env_bytes == log_bytes
    ), "The log file differs from the dotenv file. It must be an exact copy."


def test_variables_available_in_fresh_shell():
    """
    Spawn a *new* non-interactive POSIX shell, source the dotenv file,
    and confirm that the two variables are exposed with the correct values.
    This mirrors how the automated checker will evaluate the submission.
    """
    shell_cmd = (
        ". {env} && printf '%s\\n' \"$APP_MODE\" \"$PROFILER_PORT\"".format(
            env=ENV_FILE
        )
    )

    # Run `/bin/sh -c "<cmd>"` and capture its STDOUT.
    proc = subprocess.run(
        ["/bin/sh", "-c", shell_cmd],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )

    # Expected output is two lines: profiling \n 6060 \n
    out_lines = proc.stdout.splitlines()
    assert out_lines == [
        "profiling",
        "6060",
    ], textwrap.dedent(
        f"""
        After sourcing '{ENV_FILE}', the spawned shell did not observe the
        expected variable values.

        --- stdout (split) ---
        {out_lines}
        ----------------------

        Expected:
          1st line: 'profiling'
          2nd line: '6060'

        Make sure you exported both variables in the dotenv file and that the
        values are exactly as required.
        """
    )


# ---------------------------------------------------------------------------
# End of test_final_state.py
# ---------------------------------------------------------------------------