# test_final_state.py
# ============================================================
# Pytest suite that validates the *final* state of the sandbox
# AFTER the student has performed the task.
#
# It verifies that the diagnostic artefacts have been created
# exactly as specified in the exercise description.
#
# IMPORTANT:
#   • All paths are checked using their absolute values.
#   • Only the Python standard library and pytest are used.
#   • Any failure message should clearly describe what is wrong
#     so the student can quickly identify and fix the issue.
# ============================================================

import os
import stat
import pytest

# ---------- Canonical paths -------------------------------------------------
LOG_PATH = "/home/user/app/logs/runtime.log"
SUPPORT_DIR = "/home/user/support"
DIAG_FILE = "/home/user/support/diag_summary.txt"

# ---------- Helper fixtures -------------------------------------------------
@pytest.fixture(scope="module")
def log_first_line():
    """
    Returns the very first line (excluding the trailing newline) from the
    pre-existing runtime log.  Fails the test run immediately if the log is
    missing or unreadable.
    """
    if not os.path.isfile(LOG_PATH):
        pytest.fail(
            f"Pre-existing log {LOG_PATH!r} is missing.  "
            "The automated environment depends on it."
        )
    try:
        with open(LOG_PATH, "r", encoding="utf-8") as fh:
            first = fh.readline()
    except Exception as exc:
        pytest.fail(f"Could not read {LOG_PATH!r}: {exc}")

    if first == "":
        pytest.fail(f"{LOG_PATH!r} is empty but must contain at least one line.")

    # Strip ONLY the trailing newline for comparison purposes
    return first.rstrip("\n")


@pytest.fixture(scope="module")
def diag_stat():
    """
    Returns os.stat_result for /home/user/support/diag_summary.txt.
    Performs early existence checks.
    """
    if not os.path.exists(DIAG_FILE):
        pytest.fail(
            f"Expected diagnostic file {DIAG_FILE!r} is missing.  "
            "Did you create it in the correct location?"
        )
    return os.stat(DIAG_FILE, follow_symlinks=True)


# ---------- Directory level tests -------------------------------------------
def test_support_directory_exists_and_is_directory():
    """Verify that /home/user/support exists and is a directory."""
    assert os.path.exists(SUPPORT_DIR), (
        f"Directory {SUPPORT_DIR!r} does not exist."
    )
    assert os.path.isdir(SUPPORT_DIR), (
        f"{SUPPORT_DIR!r} exists but is not a directory."
    )


# ---------- File presence & metadata tests ----------------------------------
def test_diag_summary_exists_and_is_regular_file(diag_stat):
    """Verify that diag_summary.txt exists and is a regular file."""
    assert stat.S_ISREG(diag_stat.st_mode), (
        f"{DIAG_FILE!r} exists but is not a regular file."
    )


def test_diag_summary_permissions(diag_stat):
    """Verify that diag_summary.txt has permissions 0644 (rw-r--r--)."""
    expected_perms = 0o644
    perms = stat.S_IMODE(diag_stat.st_mode)
    assert perms == expected_perms, (
        f"{DIAG_FILE!r} has permissions {oct(perms)}, "
        f"expected {oct(expected_perms)} (rw-r--r--)."
    )


# ---------- File content tests ---------------------------------------------
def test_diag_summary_content_exact(log_first_line):
    """
    Verify that diag_summary.txt contains exactly one line:
        init_log=<FIRST_LINE_OF_RUNTIME_LOG>
    followed solely by the terminating newline character.
    """
    try:
        with open(DIAG_FILE, "r", encoding="utf-8") as fh:
            data = fh.read()
    except Exception as exc:
        pytest.fail(f"Could not read {DIAG_FILE!r}: {exc}")

    # 1. The file must contain exactly one newline character (the terminator)
    newline_count = data.count("\n")
    assert newline_count == 1, (
        f"{DIAG_FILE!r} must contain exactly one newline character, "
        f"found {newline_count}."
    )

    # 2. The file must end with a newline
    assert data.endswith("\n"), (
        f"{DIAG_FILE!r} must end with a newline (\\n)."
    )

    # 3. Extract the logical single line (without its newline)
    logical_line = data.rstrip("\n")

    # 4. Line must start with the literal prefix "init_log="
    assert logical_line.startswith("init_log="), (
        f"The line in {DIAG_FILE!r} must start with the literal 'init_log='."
    )

    # 5. The content after 'init_log=' must match the first line of runtime.log
    expected_line = f"init_log={log_first_line}"
    assert logical_line == expected_line, (
        f"The content of {DIAG_FILE!r} is incorrect.\n"
        f"Expected exactly:\n    {expected_line!r}\n"
        f"Found:\n    {logical_line!r}"
    )