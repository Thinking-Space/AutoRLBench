You are acting as a first-line support engineer who has been asked to collect a *very* small diagnostic from a running service.

1.  A text log already exists at  
    `/home/user/app/logs/runtime.log`

2.  Create a new directory that will hold the diagnostic bundle:  
    `/home/user/support`

3.  Inside that directory, create a single-line text file named  
    `/home/user/support/diag_summary.txt`

    The file must contain **exactly one line** (followed by the normal trailing newline produced by the shell/editor) that obeys the following format:

        init_log=<FIRST_LINE_OF_/home/user/app/logs/runtime.log>

    *   Replace `<FIRST_LINE_OF_/home/user/app/logs/runtime.log>` with the literal text of the very first line that is already present in `/home/user/app/logs/runtime.log`.
    *   Do **not** add any extra spaces before or after the equals sign.
    *   Do **not** include any additional lines, headers, timestamps, or surrounding quotes.
    *   Preserve the original capitalisation and punctuation of that first line exactly as it appears in the source log.

4.  When you are finished, the automated checker will confirm that:
    *   `/home/user/support` exists and is a directory.
    *   `/home/user/support/diag_summary.txt` exists and is a regular file.
    *   The file’s sole line starts with the literal string “init_log=” and the text after the equals sign is byte-for-byte identical to the first line of `/home/user/app/logs/runtime.log`.
    *   The file contains exactly one newline character (i.e. one logical line of text).

Example of *correct* `diag_summary.txt` format (the actual message will vary depending on the log content):

    init_log=System initialized successfully

No other output artefacts are required. Leave no temporary files behind.