You are a localization engineer who has just received two requests from the web-platform team:

1. Verify that the new staging hostnames resolve to the correct IP addresses.
2. Add a missing French translation, compile the catalogue, and write a short report.

The directories and files that already exist when the session starts are:

*   `/home/user/projects/website/locale/fr/LC_MESSAGES/messages.po`  
    (PO file with one untranslated entry)
*   `/home/user/resources/dns_seed.txt`  
    (a tiny text file that the team placed in the repo to avoid relying on external DNS)
*   `/home/user/projects/website/logs/`  
    (an empty directory in which you will place your report)

Exact current contents of the two important files:

--------------------------------------------------
/home/user/projects/website/locale/fr/LC_MESSAGES/messages.po
--------------------------------------------------
```
msgid ""
msgstr ""
"Project-Id-Version: website 1.4\n"
"Language: fr\n"
"Content-Type: text/plain; charset=UTF-8\n"

#: src/errors.c:45
msgid "Server unreachable"
msgstr ""
```
--------------------------------------------------
/home/user/resources/dns_seed.txt
--------------------------------------------------
```
staging.l10n.test 203.0.113.30
api.l10n.test     203.0.113.31
```
--------------------------------------------------

Your tasks, in order:

A. Read the two hostnames from `/home/user/resources/dns_seed.txt` and find their corresponding IP addresses (they are on the same line, separated by whitespace).  
B. Insert the French translation “Serveur injoignable” for the `msgid "Server unreachable"` in the PO file mentioned above. Keep exactly that spelling and all pre-existing formatting/whitespace in the PO file intact.  
C. Compile the PO file into a binary MO file named `messages.mo` in the same directory.  
D. Create a **new** plain-text report file exactly at  
   `/home/user/projects/website/logs/update_2023-10-31.log`  
   (the team wants the date fixed to 2023-10-31 for bookkeeping).  
   The report must contain **four lines, in this exact order**, each terminated by a single ASCII newline character (LF):

   1. `[RESOLVE] staging.l10n.test -> 203.0.113.30`
   2. `[RESOLVE] api.l10n.test -> 203.0.113.31`
   3. `[TRANSLATION] messages.po updated OK`
   4. `[COMPILE] messages.mo compiled OK`

Important format rules the automatic grader will check:

*   The report file path and name must match exactly (including the embedded date).
*   There must be no extra spaces before the opening bracket nor after “OK”.
*   Ensure each line ends with ‘\n’.
*   The PO file must now contain the line `msgstr "Serveur injoignable"` immediately after the `msgid "Server unreachable"` block (preserving any comment lines that might be present).
*   `messages.mo` must be produced by a standard `msgfmt` compilation of the updated `messages.po` and reside at:  
    `/home/user/projects/website/locale/fr/LC_MESSAGES/messages.mo`

You do not have root access, so stay within `/home/user`. Record everything in the single report file; no additional output files are allowed.