# test_final_state.py
#
# Pytest suite that validates the **FINAL** operating-system / container state
# after the student has completed the localisation task.
#
# It asserts that:
#   1. messages.po now contains the French translation “Serveur injoignable”
#      exactly in place of the previous empty msgstr "" block.
#   2. messages.mo exists and looks like a valid binary GNU MO file.
#   3. The fixed-date report update_2023-10-31.log exists with the four exact
#      lines requested, each terminated with a single LF.
#   4. No extra files have been created inside /home/user/projects/website/logs/.
#
# Only the Python standard library and pytest are used.

import os
from pathlib import Path
import stat
import pytest
import struct

# ---------------------------------------------------------------------------

HOME = Path("/home/user").resolve()

PO_PATH = HOME / "projects/website/locale/fr/LC_MESSAGES/messages.po"
MO_PATH = HOME / "projects/website/locale/fr/LC_MESSAGES/messages.mo"
LOGS_DIR = HOME / "projects/website/logs"
REPORT_PATH = LOGS_DIR / "update_2023-10-31.log"

# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------


def read_text_lines(path: Path, *, keep_newlines: bool = False):
    """Return list of lines; optionally retain trailing newline characters."""
    mode = "r"
    with path.open(mode, encoding="utf-8") as fp:
        if keep_newlines:
            return fp.readlines()
        return [ln.rstrip("\n") for ln in fp.readlines()]


def mo_file_magic(path: Path):
    """
    Return the 4-byte magic number at the start of *path* as an int,
    or None if the file is shorter than 4 bytes.
    """
    with path.open("rb") as fp:
        data = fp.read(4)
    if len(data) != 4:
        return None
    # struct.unpack reads little-endian by default with '<I'
    return struct.unpack("<I", data)[0]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_po_file_is_translated_correctly():
    assert PO_PATH.is_file(), f"PO file {PO_PATH} is missing."

    lines = read_text_lines(PO_PATH)

    # Look for the three-line translated sequence in order.
    translated_snippet = (
        '#: src/errors.c:45',
        'msgid "Server unreachable"',
        'msgstr "Serveur injoignable"',
    )

    for i in range(len(lines) - len(translated_snippet) + 1):
        if tuple(lines[i : i + 3]) == translated_snippet:
            break
    else:  # pragma: no cover
        snippet_text = "\n".join(translated_snippet)
        raise AssertionError(
            f"{PO_PATH} does not contain the expected translated block:\n"
            f"{snippet_text}\n\n"
            "Either the translation line is missing, has incorrect spelling, "
            "or the original empty msgstr \"\" has not been replaced."
        )

    # Ensure the old untranslated msgstr "" immediately after the target msgid
    # no longer exists for that particular message.
    # (It may legitimately exist for OTHER messages.)
    untranslated_block = (
        '#: src/errors.c:45',
        'msgid "Server unreachable"',
        'msgstr ""',
    )
    for i in range(len(lines) - len(untranslated_block) + 1):
        if tuple(lines[i : i + 3]) == untranslated_block:
            raise AssertionError(
                f"{PO_PATH} still contains an untranslated block for "
                '"Server unreachable" with msgstr "", which should have been '
                "replaced by the French translation."
            )


def test_mo_file_exists_and_is_valid():
    assert MO_PATH.is_file(), f"Compiled MO file {MO_PATH} is missing."

    file_stat = MO_PATH.stat()
    assert file_stat.st_size > 0, f"{MO_PATH} is empty."

    # Check execute bit is NOT set (it should be data file), just as a sanity
    # check (not required but helpful).
    is_executable = bool(file_stat.st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH))
    assert not is_executable, (
        f"{MO_PATH} has executable permission bits set; it should be "
        "a data file, not a program."
    )

    magic = mo_file_magic(MO_PATH)
    # Valid GNU MO files start with 0x950412de (little endian) or 0xde120495
    assert magic in (0x950412de, 0xde120495), (
        f"{MO_PATH} does not start with a valid GNU MO magic number. "
        "Ensure the file was generated via msgfmt and is not plain text."
    )


def test_report_file_contents_and_format():
    assert REPORT_PATH.is_file(), f"Report file {REPORT_PATH} is missing."

    # Read *with* newline characters so we can verify they exist.
    lines_with_ends = read_text_lines(REPORT_PATH, keep_newlines=True)

    expected_lines = [
        "[RESOLVE] staging.l10n.test -> 203.0.113.30\n",
        "[RESOLVE] api.l10n.test -> 203.0.113.31\n",
        "[TRANSLATION] messages.po updated OK\n",
        "[COMPILE] messages.mo compiled OK\n",
    ]

    assert lines_with_ends == expected_lines, (
        f"Report file {REPORT_PATH} has incorrect contents.\n\n"
        f"Expected ({len(expected_lines)} lines):\n"
        + "".join(expected_lines)
        + "\nActual ({len(lines_with_ends)} lines):\n"
        + "".join(lines_with_ends)
    )


def test_no_extra_files_in_logs_directory():
    assert LOGS_DIR.is_dir(), f"Logs directory {LOGS_DIR} is missing."

    files = [p for p in LOGS_DIR.iterdir() if p.is_file()]
    extra = [p for p in files if p != REPORT_PATH]

    assert not extra, (
        f"Only {REPORT_PATH.name} should exist inside {LOGS_DIR}, "
        f"but found extra files: {[p.name for p in extra]}"
    )