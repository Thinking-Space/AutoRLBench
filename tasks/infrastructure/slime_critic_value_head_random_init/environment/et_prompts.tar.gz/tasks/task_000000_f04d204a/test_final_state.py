# test_final_state.py
#
# Pytest suite that verifies the **final** operating-system / container state
# after the student has completed the capacity-planning task.
#
# The checks are performed against the ground-truth declared in the task
# description.  If any assertion fails, the error message will pinpoint exactly
# what is still wrong.

import difflib
import hashlib
import os
import stat
import textwrap

import pytest

HOME = "/home/user"
CAPACITY_DIR = os.path.join(HOME, "capacity_data")
CSV_PATH = os.path.join(CAPACITY_DIR, "server_usage.csv")
LOG_PATH = os.path.join(CAPACITY_DIR, "usage_summary.log")

# --------------------------------------------------------------------------- #
# Helper functions and fixtures                                                #
# --------------------------------------------------------------------------- #
def _mode(path: str) -> int:
    """Return only the permission bits (e.g. 0o644) for *path*."""
    return stat.S_IMODE(os.stat(path).st_mode)


@pytest.fixture(scope="session")
def expected_csv_content() -> str:
    """Ground-truth contents of server_usage.csv (including final newline)."""
    return textwrap.dedent(
        """\
        server_id,cpu_usage_pct,mem_usage_pct
        s1,45,67
        s1,55,65
        s2,80,70
        s2,60,75
        s3,30,40
        """
    )


@pytest.fixture(scope="session")
def expected_log_content() -> str:
    """Ground-truth contents of usage_summary.log (including final newline)."""
    return textwrap.dedent(
        """\
        s1 50.0 66.0
        s2 70.0 72.5
        s3 30.0 40.0
        """
    )


@pytest.fixture(scope="session")
def expected_log_md5(expected_log_content) -> str:
    """Pre-computed MD5 for the expected log file."""
    return hashlib.md5(expected_log_content.encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------- #
# Tests for the *final* state                                                 #
# --------------------------------------------------------------------------- #
def test_csv_unchanged_permissions_and_content(expected_csv_content):
    """
    server_usage.csv must still be present, with the original permissions and
    *byte-for-byte* identical contents.
    """
    assert os.path.isfile(CSV_PATH), (
        f"Expected CSV file {CSV_PATH!r} to still exist, but it is missing."
    )

    expected_mode = 0o644
    actual_mode = _mode(CSV_PATH)
    assert actual_mode == expected_mode, (
        f"File permissions for {CSV_PATH!r} changed. "
        f"Expected {oct(expected_mode)}, found {oct(actual_mode)}."
    )

    with open(CSV_PATH, "r", encoding="utf-8") as fh:
        current = fh.read()

    assert current == expected_csv_content, (
        "Contents of server_usage.csv were modified.\n"
        "Diff (expected → current):\n"
        + "\n".join(
            difflib.unified_diff(
                expected_csv_content.splitlines(),
                current.splitlines(),
                lineterm=""
            )
        )
    )


def test_log_file_exists_and_permissions():
    """usage_summary.log must exist and be world-readable (0644)."""
    assert os.path.isfile(LOG_PATH), (
        f"Expected log file {LOG_PATH!r} to be created, but it does not exist."
    )

    expected_mode = 0o644
    actual_mode = _mode(LOG_PATH)
    assert actual_mode == expected_mode, (
        f"File {LOG_PATH!r} should have permissions {oct(expected_mode)}, "
        f"but has {oct(actual_mode)} instead."
    )


def test_log_file_content_exact(expected_log_content):
    """
    usage_summary.log must match the specification exactly
    (spacing, order, trailing newline).
    """
    with open(LOG_PATH, "r", encoding="utf-8") as fh:
        current = fh.read()

    if current != expected_log_content:
        diff = "\n".join(
            difflib.unified_diff(
                expected_log_content.splitlines(),
                current.splitlines(),
                fromfile="expected",
                tofile="found",
                lineterm=""
            )
        )
        pytest.fail(
            "usage_summary.log content does not match specification.\n"
            "Diff (expected → found):\n" + diff
        )


def test_log_file_md5(expected_log_md5):
    """MD5 checksum must match the announced reference value."""
    with open(LOG_PATH, "rb") as fh:
        current_md5 = hashlib.md5(fh.read()).hexdigest()

    assert current_md5 == expected_log_md5, (
        "MD5 checksum of usage_summary.log is incorrect.\n"
        f"Expected: {expected_log_md5}\n"
        f"Found   : {current_md5}"
    )


def test_no_extra_files_present():
    """
    After completion, the directory must contain *only* server_usage.csv and
    usage_summary.log – nothing else (no hidden files either).
    """
    expected_entries = {"server_usage.csv", "usage_summary.log"}
    actual_entries = {
        entry.name
        for entry in os.scandir(CAPACITY_DIR)
        if entry.is_file()
    }

    assert actual_entries == expected_entries, (
        f"Unexpected files found in {CAPACITY_DIR!r}.\n"
        f"Expected: {sorted(expected_entries)}\n"
        f"Found   : {sorted(actual_entries)}"
    )