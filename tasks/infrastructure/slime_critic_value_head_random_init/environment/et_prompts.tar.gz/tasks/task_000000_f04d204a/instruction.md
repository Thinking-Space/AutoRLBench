A capacity-planning analyst has placed last week’s raw utilisation snapshot in
`/home/user/capacity_data/server_usage.csv`.
You have to create a concise per-server utilisation report that the analyst
can drop straight into a slide deck.

The input file is `/home/user/capacity_data/server_usage.csv`.
*   The file is a plain CSV with a **header row** and the following
    columns in this exact order:
    `server_id,cpu_usage_pct,mem_usage_pct`
*   The values are already percentages, without the `%` symbol.

For every unique `server_id`, calculate the arithmetic mean of
`cpu_usage_pct` and `mem_usage_pct`.

Save the result to `/home/user/capacity_data/usage_summary.log`
using **exactly** the format shown below.
*   Columns are separated by a single space (ASCII 0x20).
*   Numbers must be printed with exactly **one digit after
    the decimal point**, even if that digit is zero.
*   The rows must be sorted by `server_id` in ascending order.
*   No header, no extra blank lines.

```
server_id␠avg_cpu_usage_pct␠avg_mem_usage_pct
s1␠50.0␠66.0
s2␠70.0␠72.5
s3␠30.0␠40.0
```
(␠ represents a single literal space; do **not** include the angle
brackets or the explanatory text.)

When everything is complete, the only visible output in
`/home/user/capacity_data` should be:
*   `server_usage.csv` (unchanged)
*   `usage_summary.log` (newly created, exact contents as specified)

The automated tests will read `usage_summary.log` and verify that it
matches the required format byte-for-byte, so pay very close attention to
spacing, number formatting and line order.