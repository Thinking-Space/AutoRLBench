# test_final_state.py
#
# Pytest suite that validates the **final** operating-system/container state
# after the student has completed the “payment-errors” filtering task.
#
# These tests assert that:
#   • /home/user/release/filtered/ exists with sane permissions.
#   • /home/user/release/filtered/payment-errors.log exists, is world–readable,
#     and contains exactly the expected two “[ERROR] [payment-service]” lines,
#     in order, each ending with “\n”, with no extra whitespace or blank lines,
#     and the file itself ends with one (and only one) trailing newline.
#   • No other files were created inside /home/user/release/filtered/.
#
# IMPORTANT: If any assertion fails the error message will describe precisely
# what is still wrong so the student can fix only what is missing.

import os
import stat
from pathlib import Path

import pytest

FILTERED_DIR = Path("/home/user/release/filtered")
ERROR_LOG = FILTERED_DIR / "payment-errors.log"

EXPECTED_LINES = [
    "2023-10-01T02:17:01Z [ERROR] [payment-service] NullPointer exception at PaymentProcessor.java:87\n",
    "2023-10-01T02:19:55Z [ERROR] [payment-service] Timeout while contacting bank API\n",
]


# --------------------------------------------------------------------------- #
# Helper utilities
# --------------------------------------------------------------------------- #
def _octal_permissions(mode: int) -> int:
    """
    Return only the permission bits (e.g. 0o644) from os.stat().st_mode.
    """
    return stat.S_IMODE(mode)


def _is_world_readable(mode: int) -> bool:
    """
    Return True if the given permission mode is at least world-readable (0o4).
    """
    return bool(mode & 0o004)


def _is_world_executable(mode: int) -> bool:
    """
    Return True if the given permission mode is at least world-executable (0o1).
    """
    return bool(mode & 0o001)


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #
def test_filtered_directory_exists_with_permissions():
    """
    The /home/user/release/filtered/ directory must exist and be at least 0o755.
    """
    assert FILTERED_DIR.exists(), (
        f"Directory {FILTERED_DIR} does not exist. "
        "Create it to store the filtered log."
    )
    assert FILTERED_DIR.is_dir(), f"{FILTERED_DIR} exists but is not a directory."

    mode = _octal_permissions(FILTERED_DIR.stat().st_mode)

    # Directory must be readable & executable by everyone so files can be listed.
    assert _is_world_readable(mode), (
        f"{FILTERED_DIR} is not world-readable (mode {oct(mode)}). "
        "Run: chmod a+rX /home/user/release/filtered"
    )
    assert _is_world_executable(mode), (
        f"{FILTERED_DIR} is not world-executable (mode {oct(mode)}). "
        "Directories require the execute bit for traversal."
    )


def test_only_expected_file_present():
    """
    No extra files should have been created inside /home/user/release/filtered/.
    Only payment-errors.log is allowed.
    """
    entries = [p.name for p in FILTERED_DIR.iterdir() if p.is_file()]
    assert entries == ["payment-errors.log"], (
        f"Unexpected files in {FILTERED_DIR}: {entries}. "
        "Only payment-errors.log should exist."
    )


def test_error_log_file_exists_and_permissions():
    """
    The filtered payment-errors log must exist and be world-readable (>= 0o644).
    """
    assert ERROR_LOG.exists(), (
        f"{ERROR_LOG} does not exist. "
        "Generate it by filtering the raw deployment log."
    )
    assert ERROR_LOG.is_file(), f"{ERROR_LOG} exists but is not a regular file."

    mode = _octal_permissions(ERROR_LOG.stat().st_mode)
    assert _is_world_readable(mode), (
        f"{ERROR_LOG} is not world-readable (mode {oct(mode)}). "
        "Run: chmod 644 /home/user/release/filtered/payment-errors.log"
    )


def test_error_log_file_contents_exact():
    """
    payment-errors.log must contain exactly the expected two lines, each
    terminated by a single newline character, with nothing else before,
    after, or in between.
    """
    with ERROR_LOG.open("r", encoding="utf-8") as fh:
        contents = fh.read()

    # 1. File must end with exactly one trailing newline.
    assert contents.endswith("\n"), (
        f"{ERROR_LOG} must end with a single newline character."
    )
    assert not contents.endswith("\n\n"), (
        f"{ERROR_LOG} ends with more than one newline. Remove the extras."
    )

    # 2. Split into lines (retaining newline characters with splitlines(keepends=True))
    lines = contents.splitlines(keepends=True)

    # 3. Exactly two lines expected
    assert len(lines) == 2, (
        f"{ERROR_LOG} should contain exactly 2 lines, found {len(lines)}."
    )

    # 4. Lines must match exactly, in order.
    assert lines == EXPECTED_LINES, (
        "Contents of payment-errors.log do not match the expected lines.\n"
        f"Expected:\n{''.join(EXPECTED_LINES)}\n"
        f"Found:\n{''.join(lines)}"
    )


# --------------------------------------------------------------------------- #
# End of file
# --------------------------------------------------------------------------- #