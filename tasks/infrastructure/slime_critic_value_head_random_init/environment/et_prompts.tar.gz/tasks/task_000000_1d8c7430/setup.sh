#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


apt-get update && \
    apt-get install -y --no-install-recommends python3 python3-pip && \
    pip3 install --no-cache-dir pytest && \
    apt-get clean && true

useradd -m -u 1000 user || true

mkdir -p /home/user/release/logs

cat > /home/user/release/logs/deploy-2023-10-01.log <<'EOF'
2023-10-01T02:15:43Z [INFO] [user-service] Deployed successfully
2023-10-01T02:17:01Z [ERROR] [payment-service] NullPointer exception at PaymentProcessor.java:87
2023-10-01T02:18:22Z [WARN] [inventory-service] Slow response detected
2023-10-01T02:19:55Z [ERROR] [payment-service] Timeout while contacting bank API
2023-10-01T02:20:01Z [INFO] [payment-service] Health check passed
EOF

chmod 755 /home/user && \
    chmod 755 /home/user/release && \
    chmod 755 /home/user/release/logs && \
    chmod 644 /home/user/release/logs/deploy-2023-10-01.log
