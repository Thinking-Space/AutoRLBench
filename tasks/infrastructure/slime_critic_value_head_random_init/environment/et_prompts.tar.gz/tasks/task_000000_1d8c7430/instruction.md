You are the release manager preparing a deployment.  
A raw application log already exists at:  
`/home/user/release/logs/deploy-2023-10-01.log`  

**Goal**  
From the log file, isolate every line that simultaneously contains the exact, case-sensitive tokens `[ERROR] [payment-service]`. Write those matching lines, in the original order, to a new file called `/home/user/release/filtered/payment-errors.log`.

**Technical requirements the automated checker will verify**  
*   The directory `/home/user/release/filtered/` must exist when you finish.  
*   `/home/user/release/filtered/payment-errors.log` must exist and be world-readable (chmod 644 or more open).  
*   `payment-errors.log` must contain ONLY the matching lines, with no extra blank lines, spaces, or header text.  
*   The file must end with a single newline character.  
*   There must be exactly two lines in the file, each identical to the corresponding line in the source log.  
*   No other files in `/home/user/release/filtered/` should be created or modified.