You are a platform engineer maintaining a CI/CD pipeline.  
A small Python micro-service that is ready to be published has already been staged for you at  

    /home/user/source_release  

The directory currently contains exactly two files:  
1. app.py  
2. requirements.txt  

Your goal is to package this directory, generate an inventory of the archive, and stage an extracted copy for final smoke-tests.  

Exact requirements:

1. Create a compressed tarball called  
   `/home/user/package/source_release_v1.tar.gz`  
   • The archive must contain the *entire* `source_release` directory as its top-level entry, preserving the two files and their paths.

2. After the archive is created, produce a plain-text listing of its contents at  
   `/home/user/package/source_release_v1.list`  
   • The listing file must contain exactly three lines, in this precise order and with the exact spelling and punctuation shown below (each followed by a UNIX newline):  
     ```
     source_release/
     source_release/app.py
     source_release/requirements.txt
     ```

3. Extract the newly-created archive into the directory  
   `/home/user/testing_area`  
   so that, after extraction, the following paths exist on disk:  
   `/home/user/testing_area/source_release/app.py`  
   `/home/user/testing_area/source_release/requirements.txt`  

You should end with these three artefacts present and correct:
• `/home/user/package/source_release_v1.tar.gz`  
• `/home/user/package/source_release_v1.list` (with the three exact lines)  
• `/home/user/testing_area/source_release/` (containing the two original files)

No additional files are expected. The automated grader will verify the existence of the tarball, the exact content of the listing file, and the successful extraction of the two files in the `testing_area` directory.