# test_final_state.py
#
# This pytest suite validates the **final** state of the filesystem
# after the learner has completed the packaging task.
#
# Expected artefacts and their exact requirements (recap):
#
# 1. /home/user/package/source_release_v1.tar.gz
#    - The archive must contain exactly three entries, *in this order*:
#        source_release/
#        source_release/app.py
#        source_release/requirements.txt
#
# 2. /home/user/package/source_release_v1.list
#    - Must contain the three lines above, in the same order,
#      each terminated by a single UNIX line-feed (`\n`), with no
#      extra blank lines or carriage-returns.
#
# 3. Extracted copy in /home/user/testing_area/source_release/
#    containing app.py and requirements.txt whose contents are
#    byte-for-byte identical to the originals in
#    /home/user/source_release/.
#
# No other files should exist under /home/user/package or
# /home/user/testing_area.
#
# Only the Python standard library and `pytest` are used.

import os
import subprocess
from pathlib import Path

import pytest

# ---------- Constant paths -------------------------------------------------

SRC_DIR = Path("/home/user/source_release")
PKG_DIR = Path("/home/user/package")
TESTING_DIR = Path("/home/user/testing_area")

TARBALL = PKG_DIR / "source_release_v1.tar.gz"
LIST_FILE = PKG_DIR / "source_release_v1.list"

ARCHIVE_EXPECTED_LINES = [
    "source_release/",
    "source_release/app.py",
    "source_release/requirements.txt",
]

# ---------- Helper functions ----------------------------------------------


def _read_binary(path: Path) -> bytes:
    """Read a file in binary mode (helper for byte-exact comparison)."""
    with path.open("rb") as fh:
        return fh.read()


def _tar_list(tar_path: Path) -> list[str]:
    """
    Return the list of members in the tarball *in archive order*.

    Uses the external `tar` utility to guarantee identical output
    to the one specified in the task description (`tar -tzf ...`).
    """
    result = subprocess.run(
        ["tar", "-tzf", str(tar_path)],
        check=True,
        capture_output=True,
        text=True,
    )
    # Split on \n and drop the final empty string if the output
    # ends with a newline.
    members = result.stdout.splitlines()
    return members


def _original_file(path_in_src: str) -> Path:
    """Return Path object inside the original source directory."""
    return SRC_DIR / path_in_src


def _extracted_file(path_in_testing: str) -> Path:
    """Return Path object inside the extracted testing area."""
    return TESTING_DIR / "source_release" / path_in_testing


# ---------- Tests ----------------------------------------------------------


def test_tarball_exists():
    """The compressed tarball must exist at the expected absolute path."""
    assert TARBALL.is_file(), (
        f"Missing archive {TARBALL}. You may have created it in the "
        "wrong location or under a different name."
    )


def test_tarball_contents_exact():
    """
    The tarball must contain exactly the three expected entries
    in the precise order required by the spec.
    """
    members = _tar_list(TARBALL)

    assert members == ARCHIVE_EXPECTED_LINES, (
        "Archive member list is incorrect.\n"
        f"Expected (order matters):\n  {ARCHIVE_EXPECTED_LINES}\n"
        f"Got:\n  {members}"
    )


def test_listing_file_exists():
    """The plain-text inventory file must exist."""
    assert LIST_FILE.is_file(), (
        f"Missing listing file {LIST_FILE}. Did you generate it with "
        "`tar -tzf ... > ...` in the prescribed location?"
    )


def test_listing_file_contents_exact():
    """
    The listing file must contain the three expected lines terminated
    by single line-feeds and no extra content.
    """
    raw_bytes = _read_binary(LIST_FILE)

    # Ensure the file ends with a single '\n'
    assert raw_bytes.endswith(b"\n"), (
        f"{LIST_FILE} must end with a single UNIX newline."
    )

    lines = raw_bytes.decode("utf-8").splitlines()
    assert lines == ARCHIVE_EXPECTED_LINES, (
        "Contents of the listing file are incorrect.\n"
        f"Expected (order matters):\n  {ARCHIVE_EXPECTED_LINES}\n"
        f"Got:\n  {lines}"
    )


def test_extracted_directory_structure():
    """
    After extraction the testing area must contain the source_release/
    directory with exactly app.py and requirements.txt.
    """
    expected_files = {"app.py", "requirements.txt"}
    extracted_root = TESTING_DIR / "source_release"

    assert extracted_root.is_dir(), (
        f"Expected directory {extracted_root} to exist after extraction."
    )

    actual_files = {p.name for p in extracted_root.iterdir() if p.is_file()}
    assert actual_files == expected_files, (
        f"{extracted_root} should contain exactly {sorted(expected_files)}; "
        f"found {sorted(actual_files)} instead."
    )


@pytest.mark.parametrize("relative_path", ["app.py", "requirements.txt"])
def test_extracted_file_contents_match_original(relative_path):
    """
    The contents of each extracted file must be byte-for-byte identical
    to the original staged source.
    """
    original = _original_file(relative_path)
    extracted = _extracted_file(relative_path)

    assert extracted.is_file(), (
        f"Extracted file {extracted} is missing."
    )

    assert _read_binary(original) == _read_binary(extracted), (
        f"Contents of {extracted} do not match the original "
        f"{original}. The packaging/extraction step may have corrupted "
        "the file or chosen the wrong source."
    )