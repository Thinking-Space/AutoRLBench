#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


export DEBIAN_FRONTEND=noninteractive \
    HOME=/home/user

apt-get update && \
    apt-get install -y --no-install-recommends python3 python3-pip && \
    pip3 install --no-cache-dir pytest && \
    apt-get clean && \
    true

mkdir -p /home/user/incoming_reports && \
    chmod 755 /home/user && \
    chmod 755 /home/user/incoming_reports

cat > /home/user/incoming_reports/aws_costs_2023-09.csv << 'EOF'
service,cost_usd
EC2,25.50
S3,7.25
Lambda,2.40
EOF

cat > /home/user/incoming_reports/azure_costs_2023-09.csv << 'EOF'
service,cost_usd
VM,30.00
Storage,5.75
Functions,1.10
EOF

cat > /home/user/incoming_reports/gcp_costs_2023-09.csv << 'EOF'
service,cost_usd
ComputeEngine,18.60
CloudStorage,6.90
CloudFunctions,0.95
EOF

chmod 644 /home/user/incoming_reports/*.csv
