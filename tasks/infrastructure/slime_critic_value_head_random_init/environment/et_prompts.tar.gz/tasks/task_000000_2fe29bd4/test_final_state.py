# test_final_state.py
#
# This pytest suite validates the **FINAL** state of the operating-system /
# container _after_ the student has completed the “FinOps month-end export”
# task.
#
# It asserts that:
#   • The exact directory hierarchy exists under /home/user/FinOps/2023/09/
#   • Files have been moved and renamed correctly (no originals remain
#     in /home/user/incoming_reports/)
#   • Every directory has mode 0755 and every file 0644
#   • summary.txt files are one-liners without a trailing newline and contain
#     the correct arithmetic totals to two decimals
#   • cost_summary_2023-09.log exists, has three JSON lines in the required
#     alphabetical order, and each total matches the provider’s CSV and
#     summary.txt
#   • No extra or missing files/directories are present
#
# Only the Python standard library and pytest are used.

import json
import os
import stat
from pathlib import Path

import pytest

HOME = Path("/home/user")
INCOMING = HOME / "incoming_reports"
FINAL_ROOT = HOME / "FinOps" / "2023" / "09"

PROVIDERS = {
    "aws": {
        "original": INCOMING / "aws_costs_2023-09.csv",
        "expected_lines": [
            "service,cost_usd",
            "EC2,25.50",
            "S3,7.25",
            "Lambda,2.40",
        ],
        "expected_total": 35.15,
    },
    "azure": {
        "original": INCOMING / "azure_costs_2023-09.csv",
        "expected_lines": [
            "service,cost_usd",
            "VM,30.00",
            "Storage,5.75",
            "Functions,1.10",
        ],
        "expected_total": 36.85,
    },
    "gcp": {
        "original": INCOMING / "gcp_costs_2023-09.csv",
        "expected_lines": [
            "service,cost_usd",
            "ComputeEngine,18.60",
            "CloudStorage,6.90",
            "CloudFunctions,0.95",
        ],
        "expected_total": 26.45,
    },
}


# --------------------------------------------------------------------------- #
# Helper functions
# --------------------------------------------------------------------------- #

def _mode(path: Path) -> int:
    """Return the permission bits (e.g. 0o644) for the given path."""
    return path.stat().st_mode & 0o777


def _read_csv_cost_total(csv_file: Path) -> float:
    """
    Read a CSV file whose second column is 'cost_usd' and return the arithmetic
    sum of that column.
    """
    with csv_file.open(encoding="utf-8") as fh:
        lines = [ln.strip() for ln in fh.readlines() if ln.strip()]

    header, *rows = lines
    assert header.split(",")[1] == "cost_usd", (
        f"CSV '{csv_file}' does not have 'cost_usd' as the second column header."
    )

    total = 0.0
    for row in rows:
        parts = row.split(",")
        assert len(parts) >= 2, (
            f"Malformed row in '{csv_file}': '{row}' "
            "(expected at least two comma-separated fields)."
        )
        cost = float(parts[1])
        total += cost
    return round(total, 2)


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #

def test_directory_structure_and_permissions():
    """Ensure the FinOps/2023/09 hierarchy and permissions are correct."""
    assert FINAL_ROOT.is_dir(), (
        f"Required directory '{FINAL_ROOT}' is missing."
    )

    # Expected provider directories
    for provider in PROVIDERS:
        p_dir = FINAL_ROOT / provider
        assert p_dir.exists(), f"Directory '{p_dir}' is missing."
        assert p_dir.is_dir(), f"'{p_dir}' exists but is not a directory."
        assert _mode(p_dir) == 0o755, (
            f"Directory '{p_dir}' must have permissions 755 "
            f"(found {oct(_mode(p_dir))})."
        )

    # No unexpected items at root except provider dirs and the consolidated log
    expected_root_items = set(PROVIDERS.keys()) | {
        "cost_summary_2023-09.log"
    }
    actual_root_items = {p.name for p in FINAL_ROOT.iterdir()}
    unexpected = actual_root_items - expected_root_items
    missing    = expected_root_items - actual_root_items

    assert not missing, (
        f"Missing item(s) in '{FINAL_ROOT}': {', '.join(sorted(missing))}"
    )
    assert not unexpected, (
        f"Unexpected item(s) present in '{FINAL_ROOT}': "
        f"{', '.join(sorted(unexpected))}"
    )


@pytest.mark.parametrize("provider", sorted(PROVIDERS))
def test_costs_csv_and_summary_txt(provider):
    """Validate each costs.csv and matching summary.txt."""
    p_dir = FINAL_ROOT / provider
    costs_csv = p_dir / "costs.csv"
    summary_txt = p_dir / "summary.txt"

    # ------------------------------------------------------------------ #
    # costs.csv checks
    # ------------------------------------------------------------------ #
    assert costs_csv.exists(), f"'{costs_csv}' is missing."
    assert costs_csv.is_file(), f"'{costs_csv}' exists but is not a regular file."
    assert _mode(costs_csv) == 0o644, (
        f"File '{costs_csv}' must have permissions 644 "
        f"(found {oct(_mode(costs_csv))})."
    )

    # Content must match the original CSV that was moved
    with costs_csv.open(encoding="utf-8") as fh:
        content_lines = [ln.rstrip("\n\r") for ln in fh.readlines()]

    assert content_lines == PROVIDERS[provider]["expected_lines"], (
        f"Content of '{costs_csv}' does not match the expected original data."
    )

    # Arithmetic total derived from the CSV
    calculated_total = _read_csv_cost_total(costs_csv)
    expected_total   = PROVIDERS[provider]["expected_total"]
    assert abs(calculated_total - expected_total) < 1e-2, (
        f"Computed total for '{provider}' from '{costs_csv}' "
        f"is {calculated_total:.2f}, expected {expected_total:.2f}."
    )

    # ------------------------------------------------------------------ #
    # summary.txt checks
    # ------------------------------------------------------------------ #
    assert summary_txt.exists(), f"'{summary_txt}' is missing."
    assert summary_txt.is_file(), (
        f"'{summary_txt}' exists but is not a regular file."
    )
    assert _mode(summary_txt) == 0o644, (
        f"File '{summary_txt}' must have permissions 644 "
        f"(found {oct(_mode(summary_txt))})."
    )

    # Read as bytes to verify absence of trailing newline
    with summary_txt.open("rb") as fh:
        summary_bytes = fh.read()

    assert not summary_bytes.endswith(b"\n"), (
        f"'{summary_txt}' must NOT end with a newline character."
    )

    summary_text = summary_bytes.decode("utf-8")
    expected_line = f"TotalCost={expected_total:.2f}"
    assert summary_text == expected_line, (
        f"Content of '{summary_txt}' must be '{expected_line}' "
        f"(found '{summary_text}')."
    )


def test_cost_summary_log():
    """Validate the consolidated cost_summary_2023-09.log file."""
    log_file = FINAL_ROOT / "cost_summary_2023-09.log"
    assert log_file.exists(), f"'{log_file}' is missing."
    assert log_file.is_file(), f"'{log_file}' exists but is not a regular file."
    assert _mode(log_file) == 0o644, (
        f"File '{log_file}' must have permissions 644 "
        f"(found {oct(_mode(log_file))})."
    )

    with log_file.open(encoding="utf-8") as fh:
        lines_raw = fh.read().splitlines()

    assert len(lines_raw) == 3, (
        f"'{log_file}' must contain exactly 3 lines "
        f"(found {len(lines_raw)})."
    )

    # Validate alphabetical order: aws, azure, gcp
    expected_order = sorted(PROVIDERS.keys())
    actual_order   = []

    for ln in lines_raw:
        # No leading/trailing whitespace per line
        assert ln == ln.strip(), (
            f"Line in '{log_file}' has leading/trailing whitespace: '{ln}'"
        )
        obj = None
        try:
            obj = json.loads(ln)
        except json.JSONDecodeError as exc:
            pytest.fail(
                f"Line in '{log_file}' is not valid JSON: '{ln}' "
                f"(error: {exc})"
            )

        # Schema check
        assert set(obj.keys()) == {"provider", "total_cost_usd"}, (
            f"JSON object in '{log_file}' must have exactly the keys "
            "'provider' and 'total_cost_usd' (found {list(obj.keys())})."
        )

        provider = obj["provider"]
        total    = obj["total_cost_usd"]
        actual_order.append(provider)

        # Provider name must be one of the known ones
        assert provider in PROVIDERS, (
            f"Unknown provider '{provider}' found in '{log_file}'."
        )

        # Numeric total must match expected value
        expected_total = PROVIDERS[provider]["expected_total"]
        assert abs(float(total) - expected_total) < 1e-2, (
            f"Total cost for provider '{provider}' in '{log_file}' "
            f"is {total:.2f}, expected {expected_total:.2f}."
        )

    assert actual_order == expected_order, (
        f"Lines in '{log_file}' are not in alphabetical order "
        f"(expected {expected_order}, found {actual_order})."
    )


def test_no_extra_files_in_provider_directories():
    """Provider directories must contain only costs.csv and summary.txt."""
    for provider in PROVIDERS:
        p_dir = FINAL_ROOT / provider
        expected = {"costs.csv", "summary.txt"}
        actual   = {p.name for p in p_dir.iterdir()}
        unexpected = actual - expected
        missing    = expected - actual
        assert not missing, (
            f"Missing file(s) in '{p_dir}': {', '.join(sorted(missing))}"
        )
        assert not unexpected, (
            f"Unexpected file(s) found in '{p_dir}': "
            f"{', '.join(sorted(unexpected))}"
        )


def test_original_csvs_have_been_moved():
    """
    After completion, the original CSVs must have been **moved** out of
    /home/user/incoming_reports/.  They must therefore no longer exist there.
    """
    if INCOMING.exists():
        remaining = [p.name for p in INCOMING.iterdir() if p.is_file()]
        assert not remaining, (
            "The following file(s) still exist in the incoming_reports "
            "directory but should have been moved to /home/user/FinOps/"
            f": {', '.join(sorted(remaining))}"
        )


def test_permissions_recursive():
    """
    Recursively walk under /home/user/FinOps and ensure permissions:
      • directories 0755
      • files       0644
    """
    for root, dirs, files in os.walk(FINAL_ROOT):
        for d in dirs:
            p = Path(root) / d
            assert _mode(p) == 0o755, (
                f"Directory '{p}' must have permissions 755 "
                f"(found {oct(_mode(p))})."
            )
        for f in files:
            p = Path(root) / f
            assert _mode(p) == 0o644, (
                f"File '{p}' must have permissions 644 "
                f"(found {oct(_mode(p))})."
            )