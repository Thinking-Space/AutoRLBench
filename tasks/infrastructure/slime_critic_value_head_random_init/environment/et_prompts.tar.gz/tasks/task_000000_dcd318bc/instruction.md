You are acting as a mobile build-and-release engineer who needs to capture the list of *all* current Android application versions that are shown on a tiny internal dashboard page.

The dashboard HTML file is already in the workspace at `/home/user/webpages/mobile_builds.html`.

Inside that file every version appears in a span element of the exact form:
`<span class="version">v1.2.3</span>`
(i.e. the literal substring `class="version"`, then the letter “v”, then three dot-separated integers).

Your job is to write a short headless-scraping routine (it can be shell utilities, Python, Node, or any tool you like that runs without a GUI) that reads the HTML file and produces the following report file:
`/home/user/reports/latest_build_versions.log`

**Report requirements**
*   One version per line, *only* the text between the span tags (e.g. `v1.2.3`) with no extra spaces.
*   Preserve the appearance order from top to bottom of the HTML document.
*   End the file with a single newline character. No blank lines before or after the list.

When you are done, display the contents of `/home/user/reports/latest_build_versions.log` to the terminal so that automated grading can inspect it.