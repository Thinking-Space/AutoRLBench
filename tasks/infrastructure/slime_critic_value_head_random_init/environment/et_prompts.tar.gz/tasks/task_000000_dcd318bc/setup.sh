#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


export PATH="/usr/local/bin:/usr/bin:/bin:${PATH}"

apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3 \
        python3-pip \
        ca-certificates \
        curl && \
    apt-get clean && \
    true

pip3 install --no-cache-dir pytest

mkdir -p /home/user/webpages && \
    mkdir -p /home/user/reports

cat >/home/user/webpages/mobile_builds.html <<'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Internal Mobile Build Dashboard</title>
</head>
<body>
<h1>Latest Android Builds</h1>
<ul id="build-list">
  <li><span class="version">v2.3.1</span>  –  2024-03-01 14:22</li>
  <li><span class="version">v2.3.0</span>  –  2024-02-17 09:51</li>
  <li><span class="version">v2.2.5</span>  –  2024-02-03 18:07</li>
  <li><span class="version">v2.2.4</span>  –  2024-01-19 11:35</li>
</ul>
</body>
</html>
EOF

chmod 755 /home/user && \
    chmod 755 /home/user/webpages && \
    chmod 755 /home/user/reports && \
    chmod 644 /home/user/webpages/mobile_builds.html
