# test_final_state.py
"""
Pytest suite that validates the FINAL operating-system / filesystem state
AFTER the student’s solution has run.

It asserts that the required report file
    /home/user/reports/latest_build_versions.log
exists, has the correct permissions, and contains **exactly** the expected
version strings in the same order as they appear in
    /home/user/webpages/mobile_builds.html.

Failures are worded so that the student immediately sees what is still wrong.
The suite uses only the Python standard library and pytest.
"""

import os
import re
from pathlib import Path

import pytest

# --------------------------------------------------------------------------- #
# Constants                                                                   
# --------------------------------------------------------------------------- #
REPORTS_DIR = Path("/home/user/reports")
REPORT_FILE = REPORTS_DIR / "latest_build_versions.log"

HTML_FILE = Path("/home/user/webpages/mobile_builds.html")

# Expected versions in the order they appear in the HTML file
EXPECTED_VERSIONS = [
    "v2.3.1",
    "v2.3.0",
    "v2.2.5",
    "v2.2.4",
]

# File-mode values that are explicitly accepted by the grading rubric
ACCEPTED_FILE_MODES = {0o600, 0o644}

# Regex used to pull version spans from the HTML (taken from the initial-state test)
VERSION_REGEX = re.compile(r'<span\s+class="version">(v\d+\.\d+\.\d+)</span>')


# --------------------------------------------------------------------------- #
# Helper functions                                                            
# --------------------------------------------------------------------------- #
def _octal_mode(path: Path) -> int:
    """Return the permission bits (e.g. 0o644) of a path."""
    return path.stat().st_mode & 0o777


def _versions_from_html(html_path: Path) -> list[str]:
    """Extract the list of version strings from the dashboard HTML."""
    text = html_path.read_text(encoding="utf-8")
    return VERSION_REGEX.findall(text)


# --------------------------------------------------------------------------- #
# Tests                                                                       
# --------------------------------------------------------------------------- #
def test_reports_directory_exists_and_permissions():
    assert REPORTS_DIR.is_dir(), (
        f"Directory {REPORTS_DIR} does not exist. "
        "Create it so the report file can live there."
    )

    mode = _octal_mode(REPORTS_DIR)
    assert mode & 0o500 == 0o500, (
        f"Directory {REPORTS_DIR} exists but lacks user read / execute permissions "
        f"(current mode: {oct(mode)}). The user must be able to cd into it."
    )


def test_report_file_exists_and_permissions():
    assert REPORT_FILE.exists(), (
        f"Required report file {REPORT_FILE} is missing."
    )
    assert REPORT_FILE.is_file(), f"{REPORT_FILE} exists but is not a regular file."

    mode = _octal_mode(REPORT_FILE)
    assert mode in ACCEPTED_FILE_MODES, (
        f"Report file {REPORT_FILE} has incorrect permissions {oct(mode)}. "
        f"Accepted modes are: {', '.join(map(oct, sorted(ACCEPTED_FILE_MODES)))}"
    )


def test_report_file_contents_exactly_match_expected_versions():
    raw_bytes = REPORT_FILE.read_bytes()
    try:
        content = raw_bytes.decode("utf-8")
    except UnicodeDecodeError as exc:
        pytest.fail(
            f"Report file {REPORT_FILE} is not valid UTF-8 text: {exc}"
        )

    # 1. File must end with **exactly one** newline character
    assert content.endswith("\n"), (
        f"Report file {REPORT_FILE} must end with a single newline."
    )
    # Splitting by newline keeps an empty last element after the trailing '\n';
    # strip that away for comparison.
    lines = content.split("\n")
    if lines and lines[-1] == "":
        lines = lines[:-1]

    # 2. No blank lines before or after, no extra whitespace on each line
    stripped_lines = [ln.strip() for ln in lines]
    assert lines == stripped_lines, (
        f"Report file {REPORT_FILE} contains leading/trailing whitespace on "
        f"one or more lines. Expected clean version strings only."
    )

    # 3. Correct count
    assert len(lines) == len(EXPECTED_VERSIONS), (
        f"Report file {REPORT_FILE} should contain {len(EXPECTED_VERSIONS)} "
        f"lines, but {len(lines)} were found: {lines!r}"
    )

    # 4. Correct order & values
    assert lines == EXPECTED_VERSIONS, (
        f"Contents of {REPORT_FILE} do not match the expected versions "
        f"or are in the wrong order.\nExpected: {EXPECTED_VERSIONS}\nFound:    {lines}"
    )


def test_report_lines_match_html_source_order():
    """
    Safety net: ensure the student did not hard-code the versions by comparing
    the report against the actual order inside the HTML dashboard.
    """
    html_versions = _versions_from_html(HTML_FILE)
    report_versions = REPORT_FILE.read_text(encoding="utf-8").rstrip("\n").split("\n")

    # Only run this check if the HTML and report lengths match; otherwise
    # the "exactly match" test above will fail first.
    if len(html_versions) == len(report_versions):
        assert report_versions == html_versions, (
            "The report file versions do not follow the order found in the HTML "
            "dashboard. They must appear from top to bottom exactly as shown "
            "in /home/user/webpages/mobile_builds.html.\n"
            f"HTML order:   {html_versions}\n"
            f"Report order: {report_versions}"
        )