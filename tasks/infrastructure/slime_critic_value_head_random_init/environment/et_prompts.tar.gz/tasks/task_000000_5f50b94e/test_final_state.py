# test_final_state.py
#
# Pytest test-suite that validates the *end-state* of the operating system
# after the student has completed the “incident responder” task.
#
# The tests confirm that:
#   1. /home/user/incident2024 exists and contains *only* the three required
#      artefacts.
#   2. validation.log contains the correct OK/ERR lines in the right order.
#   3. high_alerts.json is a **pretty-printed** JSON array whose contents and
#      order are correct.
#   4. summary.log exists, follows the exact three-line template, and reports
#      the correct integer values.
#
# Only the Python standard library and pytest are used.

import json
import re
from pathlib import Path

import pytest

###############################################################################
# Constant paths
###############################################################################

HOME = Path("/home/user")
LOGS_DIR = HOME / "logs"
SCHEMAS_DIR = HOME / "schemas"
WORK_DIR = HOME / "incident2024"

ALERTS_JSON = LOGS_DIR / "alerts.json"
VALIDATION_LOG = WORK_DIR / "validation.log"
HIGH_ALERTS_JSON = WORK_DIR / "high_alerts.json"
SUMMARY_LOG = WORK_DIR / "summary.log"

REQUIRED_FILES = {
    VALIDATION_LOG.name,
    HIGH_ALERTS_JSON.name,
    SUMMARY_LOG.name,
}

###############################################################################
# Helper data derived from the *source* files (truth data)
###############################################################################


def _load_source_alerts():
    """Return the list of alert objects from the source ND-JSON file."""
    with ALERTS_JSON.open(encoding="utf-8") as fp:
        return [json.loads(line.rstrip("\n")) for line in fp if line.rstrip("\n")]


SOURCE_ALERTS = _load_source_alerts()
SOURCE_IDS = [a["id"] for a in SOURCE_ALERTS]
HIGH_ALERTS = [a for a in SOURCE_ALERTS if a.get("severity") == "high"]
UNIQUE_HOSTS = {a["host"] for a in SOURCE_ALERTS}

###############################################################################
# Tests
###############################################################################


def test_work_directory_exists_and_has_only_expected_files():
    """Validate that /home/user/incident2024 exists and contains no extras."""
    assert WORK_DIR.is_dir(), f"Working directory {WORK_DIR} does not exist."

    present = {p.name for p in WORK_DIR.iterdir()}
    missing = REQUIRED_FILES - present
    extra = present - REQUIRED_FILES

    assert not missing, (
        f"The following required files are missing from {WORK_DIR}: {sorted(missing)}"
    )
    assert not extra, (
        f"Unexpected files/directories found in {WORK_DIR}: {sorted(extra)} ; "
        "only validation.log, high_alerts.json and summary.log are allowed."
    )


###############################################################################
# validation.log checks
###############################################################################


def test_validation_log_content_and_order():
    """Ensure validation.log has one OK/ERR line per alert, in the right order."""
    assert VALIDATION_LOG.is_file(), f"{VALIDATION_LOG} does not exist."

    with VALIDATION_LOG.open(encoding="utf-8") as fp:
        lines = [ln.rstrip("\n") for ln in fp]

    # Must have exactly one line per alert
    assert len(lines) == len(
        SOURCE_ALERTS
    ), f"{VALIDATION_LOG} should have {len(SOURCE_ALERTS)} lines, found {len(lines)}."

    # Validate format and content line-by-line
    line_re = re.compile(r"^(OK|ERR):([A-Za-z0-9_\-]+)$")

    for idx, (line, expected_id) in enumerate(zip(lines, SOURCE_IDS), start=1):
        m = line_re.fullmatch(line)
        assert m, (
            f"Line {idx} in {VALIDATION_LOG} has an invalid format.\n"
            "Expected exactly 'OK:<id>' or 'ERR:<id>' with no spaces."
        )
        status, alert_id = m.groups()

        assert (
            alert_id == expected_id
        ), f"Line {idx}: alert ID mismatch. Expected {expected_id}, found {alert_id}."

        # All sample alerts conform to the schema, so every status must be OK.
        assert (
            status == "OK"
        ), f"Line {idx}: alert {alert_id} should be marked OK but is {status}."


###############################################################################
# high_alerts.json checks
###############################################################################


def test_high_alerts_json_exists_and_is_pretty_printed_array():
    """Ensure high_alerts.json contains only the high-severity alerts in order."""
    assert HIGH_ALERTS_JSON.is_file(), f"{HIGH_ALERTS_JSON} does not exist."

    # 1. Load and validate JSON structure
    with HIGH_ALERTS_JSON.open(encoding="utf-8") as fp:
        try:
            loaded = json.load(fp)
        except json.JSONDecodeError as exc:
            pytest.fail(f"{HIGH_ALERTS_JSON} is not valid JSON: {exc}")

    assert isinstance(
        loaded, list
    ), f"{HIGH_ALERTS_JSON} must contain a JSON *array*, not {type(loaded).__name__}."

    # 2. Verify contents and order
    assert (
        loaded == HIGH_ALERTS
    ), "high_alerts.json does not contain the expected high-severity alerts in the correct order."

    # 3. Ensure file is pretty-printed (i.e., multi-line, indented)
    with HIGH_ALERTS_JSON.open(encoding="utf-8") as fp:
        raw_text = fp.read()

    assert raw_text.startswith(
        "[\n"
    ), "high_alerts.json should start with '[' followed by a newline (pretty-printed JSON)."
    assert "\n  {" in raw_text, (
        "high_alerts.json does not appear to be indented—make sure it is pretty-printed with spaces."
    )
    assert raw_text.rstrip().endswith(
        "]"
    ), "high_alerts.json should end with a closing ']' (and optional newline)."


###############################################################################
# summary.log checks
###############################################################################


def _parse_summary_log():
    """Return a dict of {key: value} parsed from summary.log."""
    with SUMMARY_LOG.open(encoding="utf-8") as fp:
        lines = [ln.rstrip("\n") for ln in fp]

    assert (
        len(lines) == 3
    ), f"{SUMMARY_LOG} must contain exactly three lines, found {len(lines)}."

    parsed = {}
    for idx, line in enumerate(lines, start=1):
        if ": " not in line:
            pytest.fail(
                f"Line {idx} in {SUMMARY_LOG!s} does not follow the '<Key>: <int>' format."
            )
        key, val = line.split(": ", 1)
        if not val.isdigit():
            pytest.fail(
                f"Line {idx} in {SUMMARY_LOG!s} has a non-integer value: '{val}'."
            )
        parsed[key] = int(val)
    return parsed, lines


def test_summary_log_values_and_format():
    """Validate the summary.log file content and correctness of the numbers."""
    assert SUMMARY_LOG.is_file(), f"{SUMMARY_LOG} does not exist."

    summary_dict, lines = _parse_summary_log()

    # Verify exact keys and their order
    expected_keys_order = ["TotalAlerts", "HighSeverity", "UniqueHosts"]
    actual_keys_order = [ln.split(": ", 1)[0] for ln in lines]
    assert (
        actual_keys_order == expected_keys_order
    ), f"summary.log keys/order mismatch.\nExpected: {expected_keys_order}\nFound   : {actual_keys_order}"

    # Check the integer values
    assert summary_dict["TotalAlerts"] == len(
        SOURCE_ALERTS
    ), f"TotalAlerts should be {len(SOURCE_ALERTS)} but is {summary_dict['TotalAlerts']}."

    assert summary_dict["HighSeverity"] == len(
        HIGH_ALERTS
    ), f"HighSeverity should be {len(HIGH_ALERTS)} but is {summary_dict['HighSeverity']}."

    assert summary_dict["UniqueHosts"] == len(
        UNIQUE_HOSTS
    ), f"UniqueHosts should be {len(UNIQUE_HOSTS)} but is {summary_dict['UniqueHosts']}."