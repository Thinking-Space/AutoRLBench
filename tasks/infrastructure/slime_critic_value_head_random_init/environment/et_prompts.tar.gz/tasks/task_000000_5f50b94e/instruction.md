You are an on-call incident responder who has just been given a small sample of IDS (alert) data.  
Two files have already been staged for you:

1.  `/home/user/logs/alerts.json`  
    *   New-line-delimited JSON (one complete JSON object per line).
2.  `/home/user/schemas/alert_schema.json`  
    *   A JSON Schema Draft-07 document that formally describes what every alert object must look like.

Your objectives are:

A. Create a new working directory called `/home/user/incident2024`.  
B. Validate every line in `/home/user/logs/alerts.json` against `/home/user/schemas/alert_schema.json`.  
    *   Save the validation results in `/home/user/incident2024/validation.log`.  
    *   The log must contain exactly one line per alert in the *same order* they appear in `alerts.json`.  
    *   Each line must be either:  
        `OK&nbsp;:&nbsp;<alert_id>`   —for a valid alert  
        `ERR:&nbsp;<alert_id>`   —for an invalid alert  
        (There are no spaces around the colon.)  
    *   No extra text or blank lines are allowed in `validation.log`.

C. Extract every alert whose `severity` field equals `"high"`.  
    *   Save them as a *pretty-printed* JSON array (not ND-JSON) in  
        `/home/user/incident2024/high_alerts.json`.  
    *   Preserve every field from the original objects unmodified and keep them in the same order they appeared in the source file.

D. Produce a three-line human-readable summary, exactly in the format below, and store it in `/home/user/incident2024/summary.log`

   ```
   TotalAlerts: <integer>
   HighSeverity: <integer>
   UniqueHosts: <integer>
   ```

    *   `TotalAlerts` = the total number of objects in `alerts.json`  
    *   `HighSeverity` = the number of objects whose `severity=="high"`  
    *   `UniqueHosts` = the count of distinct values of the `host` field across *all* alerts (case-sensitive).  
    *   The three key names and the order shown above must be used verbatim.  
    *   No thousands separators, no extra spaces.

You may use any CLI tools available in a standard Debian/Ubuntu system, but do NOT hard-code the numbers—derive them from the data.

When you are finished, the automated tests will confirm that:

1.  `/home/user/incident2024/validation.log` exists and contains one OK/ERR line per alert in the proper format.  
2.  `/home/user/incident2024/high_alerts.json` exists, is a valid JSON array, and contains only the high-severity alerts in the correct order.  
3.  `/home/user/incident2024/summary.log` exists and matches the exact three-line template shown above with the correct computed integers.

No additional files should be created inside `/home/user/incident2024`.