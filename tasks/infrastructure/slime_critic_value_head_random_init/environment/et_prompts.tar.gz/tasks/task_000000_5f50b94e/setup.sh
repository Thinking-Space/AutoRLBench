#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3 \
        python3-pip && \
    pip3 install --no-cache-dir pytest jsonschema && \
    true

mkdir -p /home/user/logs /home/user/schemas

cat > /home/user/logs/alerts.json <<'EOF'
{"id":"a1","timestamp":"2024-05-01T10:00:00Z","host":"web01","severity":"low","signature":"SQLi attempt","src_ip":"10.0.0.5"}
{"id":"a2","timestamp":"2024-05-01T10:05:00Z","host":"web02","severity":"high","signature":"XSS attempt","src_ip":"10.0.0.6"}
{"id":"a3","timestamp":"2024-05-01T10:10:00Z","host":"db01","severity":"medium","signature":"Login failure","src_ip":"10.0.0.7"}
{"id":"a4","timestamp":"2024-05-01T10:15:00Z","host":"web02","severity":"high","signature":"SQLi attempt","src_ip":"10.0.0.8"}
{"id":"a5","timestamp":"2024-05-01T10:20:00Z","host":"web03","severity":"low","signature":"Port scan","src_ip":"10.0.0.9"}
EOF

cat > /home/user/schemas/alert_schema.json <<'EOF'
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "required": ["id", "timestamp", "host", "severity", "signature", "src_ip"],
  "properties": {
    "id":        { "type": "string" },
    "timestamp": { "type": "string", "format": "date-time" },
    "host":      { "type": "string" },
    "severity":  { "type": "string", "enum": ["low", "medium", "high"] },
    "signature": { "type": "string" },
    "src_ip":    { "type": "string", "format": "ipv4" }
  },
  "additionalProperties": false
}
EOF

chmod 0777 /home/user && \
    chmod 0755 /home/user/logs /home/user/schemas && \
    chmod 0644 /home/user/logs/alerts.json /home/user/schemas/alert_schema.json

export LC_ALL=C

export LANG=C

chmod 755 /home/user
