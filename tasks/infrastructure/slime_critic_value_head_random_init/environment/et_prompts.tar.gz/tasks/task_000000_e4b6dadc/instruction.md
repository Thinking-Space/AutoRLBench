You are a build-and-release engineer who has just cloned a tiny demo project located in
    /home/user/artifact-project (the directory exists but is empty right now).

    Your goal is to author a GNU Makefile that automates a complete build / test / package
    workflow while demonstrating the use of *parallel* recipe lines in the “compile” phase.

    Final deliverables that MUST exist **after you run “make all”**:

    1. /home/user/artifact-project/build/mytool  
       • regular text file  
       • exact, single-line contents:  
         `int main(){return 0;}`

    2. /home/user/artifact-project/reports/test-results.log  
       • regular text file  
       • exact, single-line contents:  
         `TEST_SUITE_RESULT: PASS`

    3. /home/user/artifact-project/dist/mytool-1.0.0.tar.gz  
       • gzip-compressed tar archive  
       • the *ONLY* two members inside the archive, in this exact order, must be  
         a) build/mytool  
         b) reports/test-results.log

       To be crystal-clear, the command  
       `tar -tzf /home/user/artifact-project/dist/mytool-1.0.0.tar.gz`  
       must output *exactly* (two newline-terminated lines, no leading “./”):

           build/mytool
           reports/test-results.log

    4. The Makefile itself, stored at /home/user/artifact-project/Makefile, must define at
       least the following phony targets:

       • compile   – produces build/mytool  
         - *Must* launch and synchronize at least two commands that run in parallel. This parallelism must be managed within the recipe itself, so that `make -j` is *not* required for the concurrency to occur.
         - Each parallel command should print a short “Building …” status line and
           pause for ~1 second using `sleep 1` (simulating two compilation units).

       • test      – generates reports/test-results.log with the exact line specified
                     above.

       • package   – creates dist/, then packages both artefacts into
                     dist/mytool-1.0.0.tar.gz exactly as described.

       • clean     – removes build/, reports/ and dist/.

       • all       – default target that depends on compile, test and package
                     in that order.

    5. The Makefile must also declare `.PHONY: all compile test package clean`.

    Operating constraints & tips:

    • You have standard GNU coreutils and GNU Make on the system.  
    • You do *not* need a C compiler—just create the text file containing the dummy
      “int main(){return 0;}” line to represent the compiled binary.  
    • Do not hard-code absolute paths inside the Makefile; assume it is executed
      from /home/user/artifact-project.  
    • Ensure all intermediate directories (build/, reports/, dist/) are created
      automatically by the corresponding targets.  

    Verification expectations:

    • File and directory names are *case-sensitive*.  
    • No extra files may appear inside the tarball.  
    • Text files must contain the exact lines shown—no additional whitespace.  
    • The timestamps and permissions are irrelevant to grading; only existence
      and exact file contents/ordering are checked.