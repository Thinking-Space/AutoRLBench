# test_final_state.py
#
# Pytest suite that validates the **FINAL** state of the operating-system /
# container for the “artifact-project” exercise *after* the student has
# finished.  It performs three major groups of assertions:
#
#   1. Makefile existence & static analysis (required targets, phony list,
#      parallelism requirements in “compile” recipe).
#   2. Functional verification – we actually run
#          $ make -C /home/user/artifact-project clean
#          $ make -C /home/user/artifact-project all
#      and ensure the commands succeed.
#   3. Precise inspection of the generated artefacts (file presence,
#      exact contents, tar member list & ordering).
#
# Only the Python standard library and pytest are used.

import os
import re
import subprocess
import tarfile
from pathlib import Path

import pytest

PROJECT_ROOT = Path("/home/user/artifact-project").resolve()
MAKEFILE_PATH = PROJECT_ROOT / "Makefile"

# --------------------------------------------------------------------------- #
# 1. Static Makefile checks
# --------------------------------------------------------------------------- #
def test_makefile_exists_and_is_regular():
    assert MAKEFILE_PATH.exists(), (
        f"Makefile expected at {MAKEFILE_PATH} but does not exist."
    )
    assert MAKEFILE_PATH.is_file(), (
        f"Path {MAKEFILE_PATH} exists but is not a regular file."
    )


@pytest.fixture(scope="session")
def makefile_text():
    """Returns the contents of the Makefile as a single string."""
    with MAKEFILE_PATH.open("r", encoding="utf-8") as fh:
        return fh.read()


def test_required_targets_present(makefile_text):
    """
    The Makefile must declare the five required targets:
    all, compile, test, package, clean
    """
    required = {"all", "compile", "test", "package", "clean"}
    # Look at the left-hand side of rules (start of line, before ':')
    targets = {
        m.group(1).strip()
        for m in re.finditer(r"^\s*([A-Za-z0-9_.-]+)\s*:", makefile_text, re.MULTILINE)
    }
    missing = required - targets
    assert not missing, (
        f"Makefile is missing required target(s): {', '.join(sorted(missing))}"
    )


def test_phony_declaration(makefile_text):
    """
    .PHONY line must exist and list at least the five required phony targets.
    """
    phony_lines = [
        ln for ln in makefile_text.splitlines() if ln.lstrip().startswith(".PHONY:")
    ]
    assert phony_lines, ".PHONY declaration is missing from the Makefile."

    # Collect tokens after '.PHONY:'
    declared = set()
    for line in phony_lines:
        declared.update(line.split(":")[1].strip().split())

    required = {"all", "compile", "test", "package", "clean"}
    missing = required - declared
    assert not missing, (
        ".PHONY is missing the following target(s): "
        f"{', '.join(sorted(missing))}"
    )


def test_compile_recipe_parallelism(makefile_text):
    """
    The compile target must launch at least two backgrounded commands ('&')
    followed by a single 'wait'.  We *statically* inspect the recipe.
    """
    # Extract recipe lines: lines that begin with a TAB *after* a 'compile:' rule
    # We collect until the next non-indented line or EOF.
    compile_rule = re.search(r"^\s*compile\s*:[^\n]*\n((\t[^\n]*\n)+)", makefile_text,
                             re.MULTILINE)
    assert compile_rule, "Could not locate the recipe/body of the 'compile' target."

    recipe_block = compile_rule.group(1)
    ampersands = recipe_block.count("&")
    waits = recipe_block.count("wait")

    assert ampersands >= 2, (
        "The 'compile' recipe must contain *at least* two backgrounded "
        "commands using '&', but fewer were found."
    )
    assert waits >= 1, (
        "The 'compile' recipe must synchronise the backgrounded commands "
        "with a single 'wait', but none was found."
    )

# --------------------------------------------------------------------------- #
# 2. Functional verification – run the actual build
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="session")
def run_make_all():
    """
    Executes `make clean` and then `make all` inside the project directory.
    The commands are only run once per test session to save time.
    """
    def _run(target):
        subprocess.run(
            ["make", "-C", str(PROJECT_ROOT), target],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )

    # First clean – ignore failure if clean does not exist yet.
    try:
        _run("clean")
    except subprocess.CalledProcessError as exc:
        pytest.fail(
            f"`make clean` failed with exit code {exc.returncode}.\n"
            f"stdout:\n{exc.stdout.decode()}\n"
            f"stderr:\n{exc.stderr.decode()}"
        )

    # Then build everything
    try:
        _run("all")
    except subprocess.CalledProcessError as exc:
        pytest.fail(
            f"`make all` failed with exit code {exc.returncode}.\n"
            f"stdout:\n{exc.stdout.decode()}\n"
            f"stderr:\n{exc.stderr.decode()}"
        )

    # Return path convenience object for downstream tests
    return {
        "mytool": PROJECT_ROOT / "build" / "mytool",
        "results": PROJECT_ROOT / "reports" / "test-results.log",
        "tarball": PROJECT_ROOT / "dist" / "mytool-1.0.0.tar.gz",
    }


# --------------------------------------------------------------------------- #
# 3. Artefact inspection
# --------------------------------------------------------------------------- #
def test_build_mytool_exists_and_content(run_make_all):
    mytool = run_make_all["mytool"]
    assert mytool.exists(), f"Expected file {mytool} was not created by 'make all'."
    assert mytool.is_file(), f"{mytool} exists but is not a regular file."

    contents = mytool.read_text(encoding="utf-8")
    expected = "int main(){return 0;}\n"
    assert contents == expected, (
        f"Incorrect contents for {mytool}.\n"
        f"Expected exactly:\n{expected!r}\n"
        f"Got:\n{contents!r}"
    )


def test_test_results_exists_and_content(run_make_all):
    results = run_make_all["results"]
    assert results.exists(), f"Expected file {results} was not produced."
    assert results.is_file(), f"{results} exists but is not a regular file."

    contents = results.read_text(encoding="utf-8")
    expected = "TEST_SUITE_RESULT: PASS\n"
    assert contents == expected, (
        f"Incorrect contents for {results}.\n"
        f"Expected exactly:\n{expected!r}\n"
        f"Got:\n{contents!r}"
    )


def test_tarball_contents_and_order(run_make_all):
    tarball = run_make_all["tarball"]
    assert tarball.exists(), f"Expected tarball {tarball} was not produced."
    assert tarball.is_file(), f"{tarball} exists but is not a regular file."

    # Read using tarfile to inspect member list *in order*.
    with tarfile.open(tarball, mode="r:gz") as tf:
        members = tf.getmembers()
        names = [m.name for m in members]

    expected_names = ["build/mytool", "reports/test-results.log"]
    assert names == expected_names, (
        f"Tarball member list/order is incorrect.\n"
        f"Expected exactly:\n  {expected_names}\n"
        f"Got:\n  {names}"
    )

    assert len(names) == 2, (
        f"Tarball should contain exactly 2 members, but contains {len(names)}."
    )