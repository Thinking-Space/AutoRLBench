# test_final_state.py
#
# Pytest suite that validates the *final* state of the filesystem
# after the student’s data-preparation script has run.
#
# What we assert:
# 1. The required directory hierarchy exists under /home/user/dataset
#    with correct permissions (0755).
# 2. /home/user/dataset/images/ contains exactly the three .jpg files
#    (cat.jpg, dog.jpg, bird.jpg) and those files are regular, non-empty.
# 3. The original source directory /home/user/raw_images/ now contains
#    only logo.png – the .jpg files must have been moved away.
# 4. The manifest file train_manifest.txt exists and its textual
#    content is *exactly* as specified (three lines, alphabetical order,
#    no extra whitespace, relative paths only).
# 5. The log file prep.log exists and its textual content is exactly the
#    two required lines (no extra whitespace).
#
# Only Python’s standard library and pytest are used.

import os
from pathlib import Path
import stat

import pytest

DATASET_ROOT = Path("/home/user/dataset")
IMAGES_DIR = DATASET_ROOT / "images"
RAW_DIR = Path("/home/user/raw_images")

EXPECTED_JPGS = ["cat.jpg", "dog.jpg", "bird.jpg"]
EXPECTED_MANIFEST_LINES = [
    "images/bird.jpg",
    "images/cat.jpg",
    "images/dog.jpg",
]
EXPECTED_LOG_LINES = [
    "Files moved: 3",
    "Manifest created: train_manifest.txt",
]


# ---------------------------------------------------------------------------
# Helper-utilities
# ---------------------------------------------------------------------------

def _mode(path: Path) -> str:
    """Return the octal permission bits of a filesystem object as a string."""
    return oct(path.stat().st_mode & 0o777)


def _read_non_empty_text(path: Path) -> str:
    """Read a text file and assert it is not empty."""
    assert path.exists(), f"Required file {path} is missing."
    assert path.is_file(), f"{path} exists but is not a regular file."
    content = path.read_text(encoding="utf-8")
    assert content, f"{path} is empty – it must contain the required lines."
    return content


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_directories_exist_with_correct_permissions():
    # Root dataset directory
    assert DATASET_ROOT.exists(), (
        f"Directory {DATASET_ROOT} does not exist. "
        "Your script must create it."
    )
    assert DATASET_ROOT.is_dir(), f"{DATASET_ROOT} exists but is not a directory."
    assert (DATASET_ROOT.stat().st_mode & 0o777) == 0o755, (
        f"{DATASET_ROOT} has permissions {_mode(DATASET_ROOT)}, "
        "but must be 0o755 (rwxr-xr-x)."
    )

    # images/ sub-directory
    assert IMAGES_DIR.exists(), (
        f"Directory {IMAGES_DIR} does not exist. "
        "It must be created inside the dataset root."
    )
    assert IMAGES_DIR.is_dir(), f"{IMAGES_DIR} exists but is not a directory."
    assert (IMAGES_DIR.stat().st_mode & 0o777) == 0o755, (
        f"{IMAGES_DIR} has permissions {_mode(IMAGES_DIR)}, "
        "but must be 0o755 (rwxr-xr-x)."
    )


def test_images_directory_contains_exactly_three_jpgs():
    present_files = sorted(p.name for p in IMAGES_DIR.iterdir() if p.is_file())
    assert present_files == sorted(EXPECTED_JPGS), (
        f"{IMAGES_DIR} must contain exactly the three JPG files "
        f"{EXPECTED_JPGS}, but currently contains: {present_files}"
    )

    # All JPGs must be non-empty regular files
    for name in EXPECTED_JPGS:
        file_path = IMAGES_DIR / name
        assert file_path.is_file(), f"{file_path} is missing or not a regular file."
        size = file_path.stat().st_size
        assert size > 0, f"{file_path} is empty; it must contain binary data."


def test_raw_images_directory_now_contains_only_logo_png():
    present_after = sorted(p.name for p in RAW_DIR.iterdir() if p.is_file())
    assert present_after == ["logo.png"], (
        f"After moving the JPGs, {RAW_DIR} should contain only logo.png, "
        f"but currently contains: {present_after}"
    )


def test_manifest_file_contents_exact():
    manifest_path = DATASET_ROOT / "train_manifest.txt"
    content = _read_non_empty_text(manifest_path)

    # Splitlines without keeping ends – we accept an optional final newline
    lines = content.splitlines()
    assert lines == EXPECTED_MANIFEST_LINES, (
        f"{manifest_path} has incorrect content.\n"
        f"Expected lines:\n  " + "\n  ".join(EXPECTED_MANIFEST_LINES) + "\n"
        f"Actual lines:\n  " + "\n  ".join(lines)
    )

    # No trailing spaces allowed
    offending = [ln for ln in lines if ln.rstrip() != ln]
    assert not offending, (
        f"The following lines in {manifest_path} contain trailing whitespace:\n  "
        + "\n  ".join(offending)
    )


def test_prep_log_contents_exact():
    log_path = DATASET_ROOT / "prep.log"
    content = _read_non_empty_text(log_path)
    lines = content.splitlines()
    assert lines == EXPECTED_LOG_LINES, (
        f"{log_path} has incorrect content.\n"
        f"Expected lines:\n  " + "\n  ".join(EXPECTED_LOG_LINES) + "\n"
        f"Actual lines:\n  " + "\n  ".join(lines)
    )

    # No trailing spaces allowed
    offending = [ln for ln in lines if ln.rstrip() != ln]
    assert not offending, (
        f"The following lines in {log_path} contain trailing whitespace:\n  "
        + "\n  ".join(offending)
    )