You are helping a machine-learning engineer organise a tiny sample of training data that already exists on the machine.

Current situation (already on disk):
1.  Directory `/home/user/raw_images/` contains four image files:
    *   `cat.jpg`
    *   `dog.jpg`
    *   `bird.jpg`
    *   `logo.png` (should be ignored – it is not part of the training data)

Goal (what the automated test will verify):
A. A new directory hierarchy rooted at `/home/user/dataset/` must be created with exactly one sub-directory named `images`
    *   `/home/user/dataset/images/` will finally hold the three `*.jpg` files (`cat.jpg`, `dog.jpg`, `bird.jpg`) and only those three files.
    *   `logo.png` must remain in its original place (`/home/user/raw_images/`) and must NOT appear inside `/home/user/dataset/images/`.

B. A manifest file `/home/user/dataset/train_manifest.txt` must be produced with the following exact textual content (three lines, Unix line-endings, no trailing spaces, alphabetical order):

    ```
    images/bird.jpg
    images/cat.jpg
    images/dog.jpg
    ```

C. A very small preparation log `/home/user/dataset/prep.log` must be created with exactly two lines (Unix line-endings, no trailing spaces) in this precise format:

    ```
    Files moved: 3
    Manifest created: train_manifest.txt
    ```

Instructions & constraints the agent must respect:
*   Accomplish the job from a Bash prompt.
*   Do NOT hard-code absolute paths in the manifest, only the relative path prefix `images/` (as shown above).
*   Make sure the three `.jpg` files are moved, not just copied, so `/home/user/raw_images/` ends up containing only `logo.png`.
*   The agent is free to display command output, but the final state of the filesystem must match parts A–C exactly, because the automated grader will check:
    1.  That the directory structure and file placements are correct.
    2.  That `train_manifest.txt` contains exactly the three lines shown, in that order, with nothing else.
    3.  That `prep.log` contains exactly the two lines shown, in that order, with nothing else.