# test_final_state.py
# -*- coding: utf-8 -*-
#
# Pytest suite that validates the *final* state of the operating-system /
# container once the student has completed the “disaster-recovery” drill.
#
# The tests rely solely on the Python standard library plus pytest.
# Any failure message should clearly tell the student **what is still wrong**.

import os
import stat
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Canonical paths & constants
# ---------------------------------------------------------------------------

HOME = Path("/home/user").resolve()

PROJECT_DIR         = HOME / "project"
BACKUP_DIR          = PROJECT_DIR / "data_backup" / "20230115"
LINK_DIR            = PROJECT_DIR / "data_links"

RESTORE_LOG_DIR     = HOME / "restore_logs"
RESTORE_LOG         = RESTORE_LOG_DIR / "restore_20230115.log"

BACKUP_FILES = {
    "report.txt": "Quarterly report – 2022 Q4\n",
    "stats.csv":  "year,quarter,revenue\n2022,4,12345\n",
    "image.png":  "PNGDATA\n",
}

EXPECTED_LINK_TARGETS = {
    "report.txt": BACKUP_DIR / "report.txt",
    "stats.csv":  BACKUP_DIR / "stats.csv",
    "image.png":  BACKUP_DIR / "image.png",
}

# Exact, byte-for-byte expected log file content (including spaces & trailing LF)
EXPECTED_LOG_LINES = [
    "/home/user/project/data_links/report.txt -> /home/user/project/data_backup/20230115/report.txt [OK]",
    "/home/user/project/data_links/stats.csv  -> /home/user/project/data_backup/20230115/stats.csv  [OK]",
    "/home/user/project/data_links/image.png  -> /home/user/project/data_backup/20230115/image.png  [OK]",
]
EXPECTED_LOG_CONTENT = "\n".join(EXPECTED_LOG_LINES) + "\n"   # final newline is mandatory


# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------

def _assert_is_regular_file(path: Path, *, msg: str = "") -> None:
    assert path.is_file(), msg or f"Expected a regular file at {path!s}, but it is missing or not a file."


def _assert_is_symlink(path: Path, *, msg: str = "") -> None:
    assert path.is_symlink(), msg or f"Expected a symlink at {path!s}, but it is not a symlink."


def _file_mode(path: Path) -> int:
    """Return the file’s permission bits (e.g., 0o644)."""
    return stat.S_IMODE(path.stat().st_mode)


# ---------------------------------------------------------------------------
# Tests for final state
# ---------------------------------------------------------------------------

def test_required_directories_still_exist():
    """
    Core directory skeleton must still be present.
    """
    for d in (PROJECT_DIR, BACKUP_DIR, LINK_DIR, RESTORE_LOG_DIR):
        assert d.is_dir(), f"Directory {d!s} is expected to exist in the final state."


@pytest.mark.parametrize("filename,expected_content", BACKUP_FILES.items())
def test_backup_files_intact(filename, expected_content):
    """
    The validated backup copies must remain untouched.
    """
    fpath = BACKUP_DIR / filename
    _assert_is_regular_file(fpath)

    with fpath.open("r", encoding="utf-8") as fh:
        data = fh.read()
    assert data == expected_content, (
        f"Content of backup file {fpath!s} was modified. "
        "These files must stay exactly as they were."
    )


@pytest.mark.parametrize("filename,expected_target", EXPECTED_LINK_TARGETS.items())
def test_symlinks_relinked_correctly(filename, expected_target):
    """
    Each symlink in data_links/ must now resolve *exactly* to the file in data_backup/20230115/.
    """
    link_path = LINK_DIR / filename
    _assert_is_symlink(link_path)

    # readlink() gives the link's own stored target (possibly relative);
    # resolve() follows it to an absolute, canonical path.
    resolved_target = link_path.resolve(strict=True)
    assert resolved_target == expected_target, (
        f"{link_path!s} resolves to {resolved_target!s}, "
        f"but must resolve to {expected_target!s}."
    )

    # Link must not be broken anymore.
    assert resolved_target.exists(), (
        f"{link_path!s} is still broken – target {resolved_target!s} does not exist."
    )


def test_no_extra_entries_inside_restore_logs():
    """
    /home/user/restore_logs/ must contain exactly one file: restore_20230115.log
    """
    entries = sorted(p.name for p in RESTORE_LOG_DIR.iterdir())
    assert entries == [RESTORE_LOG.name], (
        f"Unexpected files found in {RESTORE_LOG_DIR!s}: {', '.join(entries)}. "
        "Directory must contain only the required log file."
    )


def test_restore_log_file_correctness():
    """
    The log file must exist, have appropriate permissions, and be byte-for-byte identical
    to the required content (including final newline).
    """
    _assert_is_regular_file(RESTORE_LOG, msg="The restore log file is missing.")

    # Check permissions: anything between 0644 and 0666 is acceptable.
    perm = _file_mode(RESTORE_LOG)
    assert 0o644 <= perm <= 0o666, (
        f"Permissions of {RESTORE_LOG!s} are {oct(perm)}, "
        "but must be between 0644 and 0666."
    )

    with RESTORE_LOG.open("r", encoding="utf-8") as fh:
        content = fh.read()
    assert content == EXPECTED_LOG_CONTENT, (
        "restore_20230115.log content does not match the required specification.\n"
        "Expected:\n"
        f"{EXPECTED_LOG_CONTENT!r}\n"
        "Got:\n"
        f"{content!r}"
    )


def test_restore_log_has_exactly_three_lines():
    """
    Ensure the log file has exactly three non-empty lines.
    """
    with RESTORE_LOG.open("r", encoding="utf-8") as fh:
        lines = fh.read().splitlines()
    assert len(lines) == 3, (
        f"restore_20230115.log must contain exactly 3 lines, found {len(lines)}."
    )