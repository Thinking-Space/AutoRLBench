#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update -y && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3 \
        python3-pip && \
    pip3 install --no-cache-dir pytest && \
    true

set -e && \
    mkdir -p /home/user/project/data_backup/20230115 && \
    mkdir -p /home/user/project/data_links && \
    mkdir -p /home/user/old_backups

set -e && \
    printf 'Quarterly report – 2022 Q4\n'         > /home/user/project/data_backup/20230115/report.txt && \
    printf 'year,quarter,revenue\n2022,4,12345\n' > /home/user/project/data_backup/20230115/stats.csv && \
    printf 'PNGDATA\n'                            > /home/user/project/data_backup/20230115/image.png

set -e && \
    chmod 664 /home/user/project/data_backup/20230115/report.txt && \
    chmod 664 /home/user/project/data_backup/20230115/stats.csv && \
    chmod 664 /home/user/project/data_backup/20230115/image.png

set -e && \
    ln -sf /home/user/old_backups/report.txt /home/user/project/data_links/report.txt && \
    ln -sf /home/user/old_backups/stats.csv  /home/user/project/data_links/stats.csv && \
    ln -sf /home/user/old_backups/image.png  /home/user/project/data_links/image.png

set -e && \
    chmod -R a+rX,u+w,g+w,o+w /home/user && \
    chmod 755 /home/user

export LANG=C.UTF-8
