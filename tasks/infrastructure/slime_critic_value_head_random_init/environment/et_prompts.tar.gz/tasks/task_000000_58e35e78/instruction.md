A small “disaster-recovery” drill has been staged for you, the backup operator.    
1.  Three data files have already been copied to the backup area  
        `/home/user/project/data_backup/20230115/`  
        *   `report.txt`  
        *   `stats.csv`  
        *   `image.png`  

    Their checksums have been validated, so you must **not** touch the copies themselves.

2.  In the live link area  
        `/home/user/project/data_links/`  
    you will find three *broken* symbolic links that still point to an old, decommissioned
    directory (`/home/user/old_backups/…`). Your task is to relink them so that the
    application can once again reach the valid copies under `data_backup/20230115/`.

**Required result after you finish**
---
*   `/home/user/project/data_links/report.txt` → `/home/user/project/data_backup/20230115/report.txt`  
*   `/home/user/project/data_links/stats.csv` → `/home/user/project/data_backup/20230115/stats.csv`  
*   `/home/user/project/data_links/image.png` → `/home/user/project/data_backup/20230115/image.png`  

Directory layout and permissions must remain otherwise unchanged; simply replace the links.

**Log file (MUST be created)**
---
When you are done, create  
    `/home/user/restore_logs/restore_20230115.log`  

The file must contain **exactly three lines**, one for each relinked file, in this precise format:

    /home/user/project/data_links/report.txt -> /home/user/project/data_backup/20230115/report.txt [OK]
    /home/user/project/data_links/stats.csv  -> /home/user/project/data_backup/20230115/stats.csv  [OK]
    /home/user/project/data_links/image.png  -> /home/user/project/data_backup/20230115/image.png  [OK]

*   No leading/trailing spaces other than those shown above.  
*   Lines must be separated by a single ‘\n’.  
*   Do **not** add any header or footer lines.