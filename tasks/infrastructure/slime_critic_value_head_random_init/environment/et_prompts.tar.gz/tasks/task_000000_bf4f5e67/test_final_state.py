# test_final_state.py
#
# This pytest suite validates the *final* state of the operating system
# after the student’s solution has run.  It ensures that:
#
#   1. The required audit log /home/user/permission_audit.log exists.
#   2. The file’s *exact* contents match the specification—character-for-
#      character, byte-for-byte (including the trailing newline).
#   3. The original /home/user/project workspace has NOT been altered:
#      every file and directory is still present and retains its
#      expected Unix permission bits.
#
# Only the Python standard library and pytest are used.

import os
import stat
import pytest

# ----------------------------------------------------------------------
# Ground-truth for the /home/user/project tree.
# ----------------------------------------------------------------------

EXPECTED_LAYOUT = [
    ("/home/user/project",                       0o755, 'dir'),
    ("/home/user/project/config.cfg",            0o644, 'file'),
    ("/home/user/project/scripts",               0o755, 'dir'),
    ("/home/user/project/scripts/build.sh",      0o750, 'file'),
    ("/home/user/project/data",                  0o700, 'dir'),
    ("/home/user/project/data/raw.txt",          0o600, 'file'),
]

# ----------------------------------------------------------------------
# Expected content of the audit log, assembled directly from
# EXPECTED_LAYOUT so that the test source-of-truth is in a single place.
# ----------------------------------------------------------------------

def _build_expected_log_content():
    """
    Construct the exact, final string that must appear in
    /home/user/permission_audit.log, including the terminating newline.
    """
    # Sort the paths strictly ASCII-alphabetically.
    sorted_entries = sorted(EXPECTED_LAYOUT, key=lambda t: t[0])

    lines = []
    for path, mode, _ in sorted_entries:
        # Convert e.g. 0o755 -> '755' (strip the '0o' prefix).
        octal_digits = oct(mode)[2:]
        lines.append(f"{octal_digits} {path}")

    # Join with '\n' and ensure the file ends with a single trailing
    # newline character.
    return "\n".join(lines) + "\n"


EXPECTED_LOG_CONTENT = _build_expected_log_content()
AUDIT_LOG_PATH = "/home/user/permission_audit.log"

# ----------------------------------------------------------------------
# Tests for the audit log itself
# ----------------------------------------------------------------------

def test_audit_log_exists_and_is_regular_file():
    """
    The audit log must exist **and** be a regular file (not a directory,
    symlink, FIFO, etc.).
    """
    assert os.path.exists(AUDIT_LOG_PATH), (
        f"Required log file {AUDIT_LOG_PATH!r} does not exist."
    )
    assert os.path.isfile(AUDIT_LOG_PATH), (
        f"{AUDIT_LOG_PATH!r} exists but is not a regular file."
    )


def test_audit_log_content_is_exactly_correct():
    """
    The audit log’s byte-for-byte contents must match the expected
    string defined above—including the final newline.
    """
    with open(AUDIT_LOG_PATH, "r", newline='') as fh:
        actual_content = fh.read()

    assert actual_content == EXPECTED_LOG_CONTENT, (
        "The contents of /home/user/permission_audit.log are incorrect.\n\n"
        "EXPECTED:\n"
        f"{EXPECTED_LOG_CONTENT!r}\n\n"
        "GOT:\n"
        f"{actual_content!r}"
    )

# ----------------------------------------------------------------------
# Defensive checks: make sure the original project tree is still present
# and retains its original permission bits.  These tests intentionally
# duplicate some of the initial-state checks to catch accidental
# modifications made by the student’s solution.
# ----------------------------------------------------------------------

@pytest.mark.parametrize("path, expected_mode, kind", EXPECTED_LAYOUT)
def test_project_paths_still_exist_with_correct_type(path, expected_mode, kind):
    """
    Confirm that each file/directory in /home/user/project still exists
    and is of the expected type.
    """
    assert os.path.exists(path), f"Expected {path!r} to exist, but it does not."

    if kind == 'file':
        assert os.path.isfile(path), f"Expected {path!r} to be a regular file."
    elif kind == 'dir':
        assert os.path.isdir(path), f"Expected {path!r} to be a directory."
    else:  # Defensive programming—should never occur
        pytest.fail(f"Internal test error: unknown kind {kind!r} for {path!r}.")


@pytest.mark.parametrize("path, expected_mode, _", EXPECTED_LAYOUT)
def test_project_paths_still_have_original_permissions(path, expected_mode, _):
    """
    Ensure that none of the original permission bits were modified.
    """
    actual_mode = stat.S_IMODE(os.stat(path).st_mode)
    assert actual_mode == expected_mode, (
        f"Permissions for {path!r} have changed: "
        f"expected {oct(expected_mode)[2:]}, got {oct(actual_mode)[2:]}."
    )