A security audit is being performed on the “project” workspace that
has already been staged for you under

    /home/user/project

The auditor needs a **plain-text log file** that captures the current
Unix permissions for every file and directory in that tree
(including the root of the tree itself).

Your task is to generate a report named `/home/user/permission_audit.log` that contains an entry for everything located recursively within `/home/user/project`. The report must follow **exactly** the format described below and overwrite any existing file of the same name.

Required report format (this will be used verbatim by automated
grading scripts):

• One entry per line.  
• Each line must contain:  
      a. the numeric (octal) permission bits, **without** a leading
         zero (e.g., 755, 644, 700)  
      b. a single space character  
      c. the absolute path of the file or directory  
• No extra spaces or characters.  
• Lines must be sorted in **strict ASCII alphabetical order** by the
  absolute path.  
• Do not include anything outside /home/user/project.  
• Do not include blank lines.

Example of a correctly-formatted line (do *not* hard-code this):

    644 /home/user/project/example.txt

When you have finished, the grader will read
/home/user/permission_audit.log and compare it against the expected
contents. Make sure the file exists and matches the specification
precisely—character-for-character.