# test_final_state.py
#
# Pytest suite that validates the *FINAL* operating-system/container state
# after the student has completed the exercise.
#
# What is verified:
#   1. /home/user/network/output/failures_2023-09-15.log
#      • exists, is a regular file, world-readable (0644)
#      • contains exactly the expected filtered log lines (order preserved)
#   2. /home/user/network/output/error_summary.txt
#      • exists, is a regular file, world-readable (0644)
#      • contains the exact error-code summary lines in the correct order
#
# The tests use only Python’s stdlib + pytest and give clear failure reasons.

from pathlib import Path
import os
import stat
import difflib
import pytest

# ---------------------------------------------------------------------------#
# Constants                                                                  #
# ---------------------------------------------------------------------------#

FAILURES_LOG_PATH = Path("/home/user/network/output/failures_2023-09-15.log")
SUMMARY_PATH      = Path("/home/user/network/output/error_summary.txt")

EXPECTED_FAILURE_LINES = [
    '2023-09-15T00:01:44Z router=nyc-core src=172.16.4.89 dst=1.1.1.1 proto=TCP conn_status=FAIL err=101 detail="SYN timeout"',
    '2023-09-15T01:15:22Z router=nyc-core src=10.10.10.10 dst=142.250.72.238 proto=TCP conn_status=FAIL err=104 detail="RST received"',
    '2023-09-15T02:47:03Z router=sfo-gw1 src=10.0.0.3 dst=198.41.0.4 proto=UDP conn_status=FAIL err=108 detail="Port unreachable"',
    '2023-09-15T03:10:37Z router=lon-edge src=192.168.1.22 dst=8.8.8.8 proto=ICMP conn_status=FAIL err=101 detail="TTL exceeded"',
    '2023-09-15T04:21:12Z router=nyc-core src=172.16.5.5 dst=9.9.9.9 proto=TCP conn_status=FAIL err=104 detail="RST received"',
    '2023-09-15T05:33:19Z router=lon-edge src=192.168.1.42 dst=8.8.4.4 proto=UDP conn_status=FAIL err=108 detail="Timeout"',
    '2023-09-15T06:55:01Z router=nyc-core src=10.10.10.11 dst=142.250.72.238 proto=TCP conn_status=FAIL err=101 detail="SYN timeout"',
    '2023-09-15T09:09:09Z router=sfo-gw1 src=10.0.0.50 dst=198.41.0.4 proto=UDP conn_status=FAIL err=104 detail="Unknown"',
    '2023-09-15T10:10:10Z router=nyc-core src=172.16.5.6 dst=1.1.1.1 proto=TCP conn_status=FAIL err=108 detail="ECN failure"',
]

EXPECTED_SUMMARY_LINES = [
    '101 3',
    '104 3',
    '108 3',
]

EXPECTED_MODE = 0o644  # world-readable, group-readable, owner-rw

# ---------------------------------------------------------------------------#
# Helper functions                                                           #
# ---------------------------------------------------------------------------#

def _assert_regular_readable_file(path: Path):
    """Assert *path* exists, is a regular file and world-readable (0644)."""
    if not path.exists():
        pytest.fail(f"Required file missing: {path}")
    if not path.is_file():
        pytest.fail(f"Path exists but is not a regular file: {path}")

    # Permissions
    mode = stat.S_IMODE(path.stat().st_mode)
    if mode != EXPECTED_MODE:
        pytest.fail(
            f"{path} has mode {oct(mode)}; expected {oct(EXPECTED_MODE)} "
            "(must be world-readable 0644)."
        )

    if not os.access(path, os.R_OK):
        pytest.fail(f"{path} exists but is not readable by current user.")


def _unified_diff(expected, actual, fromfile, tofile):
    """Return a unified diff string between two lists of lines."""
    diff = difflib.unified_diff(
        expected,
        actual,
        fromfile=fromfile,
        tofile=tofile,
        lineterm=""
    )
    return "\n".join(diff)

# ---------------------------------------------------------------------------#
# Tests                                                                      #
# ---------------------------------------------------------------------------#

def test_failures_log_correct():
    """The filtered failures log must exist, have correct permissions and content."""
    _assert_regular_readable_file(FAILURES_LOG_PATH)

    with FAILURES_LOG_PATH.open(encoding="utf-8") as fh:
        actual_lines = fh.read().splitlines()

    if actual_lines != EXPECTED_FAILURE_LINES:
        diff = _unified_diff(
            EXPECTED_FAILURE_LINES,
            actual_lines,
            "expected_failures_2023-09-15.log",
            "actual_failures_2023-09-15.log",
        )
        pytest.fail(
            "Content mismatch in "
            f"{FAILURES_LOG_PATH}.\n"
            "== Unified diff (expected ‑ actual) ==\n"
            f"{diff}"
        )


def test_error_summary_correct():
    """The error-code summary must exist, have correct permissions and content."""
    _assert_regular_readable_file(SUMMARY_PATH)

    with SUMMARY_PATH.open(encoding="utf-8") as fh:
        actual_lines = fh.read().splitlines()

    if actual_lines != EXPECTED_SUMMARY_LINES:
        diff = _unified_diff(
            EXPECTED_SUMMARY_LINES,
            actual_lines,
            "expected_error_summary.txt",
            "actual_error_summary.txt",
        )
        pytest.fail(
            "Content mismatch in "
            f"{SUMMARY_PATH}.\n"
            "== Unified diff (expected ‑ actual) ==\n"
            f"{diff}"
        )