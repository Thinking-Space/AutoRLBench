A network-operations colleague has handed you a raw connection-debug log saved at

    /home/user/network/logs/conn.log

Together with that file, an (empty) directory already exists at

    /home/user/network/output/

Your job is to isolate the log lines that show failed connection attempts *that occurred on 2023-09-15*, and then produce a compact, machine-readable summary of the distinct failure reasons.

You are to produce two output files in `/home/user/network/output/`.

The first file, `/home/user/network/output/failures_2023-09-15.log`, should contain a subset of lines from the source log. This subset includes **only** the lines that satisfy *all* of the following conditions:
*   The timestamp (field #1) is the calendar day **2023-09-15**.
*   The “conn_status” key (field #6) has the literal value **FAIL**.
*   The line contains exactly one “err=” key whose value is a three-digit numeric error code.

This file's contents must be *unchanged* from the source, and the original line order must be preserved. The automated test will read that file verbatim, so the line endings and ordering must stay identical to the source.

The second file, `/home/user/network/output/error_summary.txt`, is a short ASCII report built from the same subset of filtered lines. It should list, one per line, the count of each distinct error code sorted descending by count, then ascending by the numeric code for ties. The report must respect the exact format:

    <error_code><single_space><count>

For example, a possible line might be:

    104 7

Only those two columns—code and count—should appear; no header or extra spacing.

NOTE FOR THE AUTOMATED CHECKER
*   It will confirm that /home/user/network/output/failures_2023-09-15.log contains the precise expected subset (order preserved, no additional lines).
*   It will verify that /home/user/network/output/error_summary.txt matches the exact counts and ordering rule.
*   Make sure both files exist and are world-readable (mode 0644 is fine).

Do *not* modify conn.log itself.