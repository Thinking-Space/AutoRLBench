#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends python3 python3-pip && \
    pip3 install --no-cache-dir pytest && \
    mkdir -p /home/user/network/logs && \
    mkdir -p /home/user/network/output

cat > /home/user/network/logs/conn.log <<'EOF'
2023-09-14T23:58:12Z router=sfo-gw1 src=10.0.0.2 dst=8.8.8.8 proto=ICMP conn_status=OK latency=34ms
2023-09-15T00:01:44Z router=nyc-core src=172.16.4.89 dst=1.1.1.1 proto=TCP conn_status=FAIL err=101 detail="SYN timeout"
2023-09-15T00:02:53Z router=lon-edge src=192.168.1.4 dst=8.8.4.4 proto=UDP conn_status=OK
2023-09-15T01:15:22Z router=nyc-core src=10.10.10.10 dst=142.250.72.238 proto=TCP conn_status=FAIL err=104 detail="RST received"
2023-09-15T02:47:03Z router=sfo-gw1 src=10.0.0.3 dst=198.41.0.4 proto=UDP conn_status=FAIL err=108 detail="Port unreachable"
2023-09-15T03:10:37Z router=lon-edge src=192.168.1.22 dst=8.8.8.8 proto=ICMP conn_status=FAIL err=101 detail="TTL exceeded"
2023-09-15T04:21:12Z router=nyc-core src=172.16.5.5 dst=9.9.9.9 proto=TCP conn_status=FAIL err=104 detail="RST received"
2023-09-15T04:45:44Z router=sfo-gw1 src=10.0.0.25 dst=8.8.4.4 proto=UDP conn_status=OK
2023-09-15T05:33:19Z router=lon-edge src=192.168.1.42 dst=8.8.4.4 proto=UDP conn_status=FAIL err=108 detail="Timeout"
2023-09-15T06:55:01Z router=nyc-core src=10.10.10.11 dst=142.250.72.238 proto=TCP conn_status=FAIL err=101 detail="SYN timeout"
2023-09-15T08:00:00Z router=lon-edge src=192.168.1.45 dst=8.8.8.8 proto=ICMP conn_status=OK latency=37ms
2023-09-15T09:09:09Z router=sfo-gw1 src=10.0.0.50 dst=198.41.0.4 proto=UDP conn_status=FAIL err=104 detail="Unknown"
2023-09-15T10:10:10Z router=nyc-core src=172.16.5.6 dst=1.1.1.1 proto=TCP conn_status=FAIL err=108 detail="ECN failure"
2023-09-15T11:11:11Z router=lon-edge src=192.168.1.46 dst=9.9.9.9 proto=UDP conn_status=OK
2023-09-16T00:00:00Z router=sfo-gw1 src=10.0.0.2 dst=8.8.8.8 proto=ICMP conn_status=FAIL err=104 detail="Next-day test"
EOF

chmod 0755 /home/user && \
    chmod -R 0755 /home/user/network && \
    chmod 0644 /home/user/network/logs/conn.log
