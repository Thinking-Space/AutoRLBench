#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update -y && \
    apt-get install -y --no-install-recommends python3 python3-pip && \
    pip3 install --no-cache-dir pytest && \
    apt-get clean && \
    true

mkdir -p /home/user/syslogs && \
    chmod 755 /home/user /home/user/syslogs

cat > /home/user/syslogs/systemA.log <<'EOF'
2023-08-01T01:00:00Z SRC=10.0.0.1 STATUS=FAIL
2023-08-01T01:05:00Z SRC=10.0.0.2 STATUS=FAIL
2023-08-01T01:10:00Z SRC=10.0.0.1 STATUS=FAIL
2023-08-01T01:15:00Z SRC=10.0.0.3 STATUS=FAIL
2023-08-01T01:20:00Z SRC=10.0.0.1 STATUS=SUCCESS
2023-08-01T01:25:00Z SRC=10.0.0.4 STATUS=FAIL
2023-08-01T01:30:00Z SRC=10.0.0.2 STATUS=FAIL
2023-08-01T01:35:00Z SRC=10.0.0.1 STATUS=FAIL
2023-08-01T01:40:00Z SRC=10.0.0.5 STATUS=FAIL
2023-08-01T01:45:00Z SRC=10.0.0.4 STATUS=SUCCESS
EOF

cat > /home/user/syslogs/systemB.log <<'EOF'
2023-08-01T02:00:00Z SRC=10.0.0.3 STATUS=FAIL
2023-08-01T02:05:00Z SRC=10.0.0.4 STATUS=FAIL
2023-08-01T02:10:00Z SRC=10.0.0.2 STATUS=FAIL
2023-08-01T02:15:00Z SRC=10.0.0.1 STATUS=FAIL
2023-08-01T02:20:00Z SRC=10.0.0.1 STATUS=FAIL
2023-08-01T02:25:00Z SRC=10.0.0.3 STATUS=FAIL
2023-08-01T02:30:00Z SRC=10.0.0.1 STATUS=FAIL
2023-08-01T02:35:00Z SRC=10.0.0.5 STATUS=FAIL
2023-08-01T02:40:00Z SRC=10.0.0.4 STATUS=FAIL
2023-08-01T02:45:00Z SRC=10.0.0.2 STATUS=SUCCESS
EOF

cat > /home/user/syslogs/systemC.log <<'EOF'
2023-08-01T03:00:00Z SRC=10.0.0.1 STATUS=FAIL
2023-08-01T03:05:00Z SRC=10.0.0.2 STATUS=FAIL
2023-08-01T03:10:00Z SRC=10.0.0.3 STATUS=FAIL
2023-08-01T03:15:00Z SRC=10.0.0.1 STATUS=FAIL
2023-08-01T03:20:00Z SRC=10.0.0.2 STATUS=FAIL
2023-08-01T03:25:00Z SRC=10.0.0.3 STATUS=FAIL
2023-08-01T03:30:00Z SRC=10.0.0.1 STATUS=FAIL
2023-08-01T03:35:00Z SRC=10.0.0.5 STATUS=FAIL
2023-08-01T03:40:00Z SRC=10.0.0.4 STATUS=FAIL
2023-08-01T03:45:00Z SRC=10.0.0.5 STATUS=FAIL
EOF

chmod 644 /home/user/syslogs/systemA.log /home/user/syslogs/systemB.log /home/user/syslogs/systemC.log
