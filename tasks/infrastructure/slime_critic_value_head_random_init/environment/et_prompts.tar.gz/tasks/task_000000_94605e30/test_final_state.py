# test_final_state.py
#
# Pytest suite that validates the **FINAL** state of the operating-system /
# container after the student has finished the incident-response task.
#
# The tests assert that
#
#   1.  The original log files are still present and unaltered in both
#       structure and content (exact line-by-line aggregate counts).
#   2.  The directory  /home/user/analysis  now exists.
#   3.  The file       /home/user/analysis/top_ip_counts.log  exists,
#       is a regular file, and contains exactly the five properly-sorted
#       lines with a single trailing newline—no more, no less.
#
# Only Python’s standard library and pytest are used; no third-party
# dependencies are required.

import os
import re
from pathlib import Path

import pytest

HOME = Path("/home/user")

# ---------------------------------------------------------------------------
# 1.  Ground-truth for the *input* log files (must remain unchanged)
# ---------------------------------------------------------------------------
SYSLOG_DIR = HOME / "syslogs"
LOG_FILES = [
    SYSLOG_DIR / "systemA.log",
    SYSLOG_DIR / "systemB.log",
    SYSLOG_DIR / "systemC.log",
]
EXPECTED_IP_COUNTS = {
    "10.0.0.1": 10,
    "10.0.0.2":  6,
    "10.0.0.3":  5,
    "10.0.0.4":  5,
    "10.0.0.5":  4,
}

# Regular expression used to validate each log-file line and to capture the IP.
_LOG_LINE_RE = re.compile(
    r"""
    ^\d{4}-\d{2}-\d{2}T            # YYYY-MM-DDT
    \d{2}:\d{2}:\d{2}Z\s           # HH:MM:SSZ␣
    SRC=(\d{1,3}(?:\.\d{1,3}){3})\s# SRC=<IPv4>␣  (captures IPv4)
    STATUS=(FAIL|SUCCESS)$         # STATUS=<WORD>
    """,
    re.VERBOSE,
)

# ---------------------------------------------------------------------------
# 2.  Expected artefacts produced by the student
# ---------------------------------------------------------------------------
ANALYSIS_DIR = HOME / "analysis"
OUTPUT_FILE = ANALYSIS_DIR / "top_ip_counts.log"
EXPECTED_OUTPUT_LINES = [
    "10.0.0.1 10",
    "10.0.0.2 6",
    "10.0.0.3 5",
    "10.0.0.4 5",
    "10.0.0.5 4",
]

# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def _parse_logs_and_count_ips():
    """
    Parse all three log files, validating every line and returning a dict
    mapping IP → count.  Any format deviation raises an assertion.
    """
    counts: dict[str, int] = {}
    for lf in LOG_FILES:
        assert lf.exists() and lf.is_file(), f"Missing or non-regular log file: {lf}"
        with lf.open("r", encoding="utf-8") as fh:
            lines = fh.read().splitlines()
        # Each log file is expected to have exactly 10 lines.
        assert len(lines) == 10, (
            f"Unexpected number of lines in {lf}. Expected 10, found {len(lines)}."
        )
        for lineno, line in enumerate(lines, start=1):
            m = _LOG_LINE_RE.match(line)
            assert m, (
                f"Line {lineno} in {lf} violates required pattern:\n{line}"
            )
            ip = m.group(1)
            counts[ip] = counts.get(ip, 0) + 1
    return counts


# ---------------------------------------------------------------------------
# 3.  Tests start here
# ---------------------------------------------------------------------------


def test_original_logs_unmodified():
    """
    Confirm the original log files still exist and contain exactly the same
    aggregate per-IP counts as in the pristine state.
    """
    counts = _parse_logs_and_count_ips()
    assert set(counts) == set(EXPECTED_IP_COUNTS), (
        "Set of source IPs in log files has changed.\n"
        f"Observed: {sorted(counts)}\nExpected: {sorted(EXPECTED_IP_COUNTS)}"
    )
    for ip, expected_cnt in EXPECTED_IP_COUNTS.items():
        assert counts[ip] == expected_cnt, (
            f"Count mismatch for IP {ip}: expected {expected_cnt}, found {counts[ip]}"
        )


def test_analysis_directory_exists():
    """The /home/user/analysis directory must now exist and be a directory."""
    assert ANALYSIS_DIR.exists(), (
        f"Missing required directory: {ANALYSIS_DIR}. Did you create it?"
    )
    assert ANALYSIS_DIR.is_dir(), (
        f"{ANALYSIS_DIR} exists but is not a directory."
    )


def test_output_file_exists_and_permissions():
    """
    Validate that /home/user/analysis/top_ip_counts.log exists, is a regular
    file, and is not executable.
    """
    assert OUTPUT_FILE.exists(), f"Missing output file: {OUTPUT_FILE}"
    assert OUTPUT_FILE.is_file(), f"{OUTPUT_FILE} exists but is not a regular file."

    # Ensure the file is not world-executable.  (rw-r--r-- is expected.)
    mode = OUTPUT_FILE.stat().st_mode
    is_executable = mode & 0o111  # Any executable bit set?
    assert not is_executable, (
        f"{OUTPUT_FILE} should not be executable; permission bits are {oct(mode)}"
    )


def test_output_file_content_exact():
    """
    Validate the exact content, ordering, and formatting rules for
    top_ip_counts.log:
      * Exactly five non-blank lines, each 'IP␣COUNT'.
      * Single ASCII space delimiter; no leading/trailing whitespace.
      * Sorted properly (desc count, then asc lexicographic).
      * Final single trailing newline, no extra blank line at EOF.
      * Contents match the expected truth values.
    """
    # Read the file as raw bytes first to check newline discipline.
    data = OUTPUT_FILE.read_bytes()
    assert data.endswith(b"\n"), (
        f"{OUTPUT_FILE} is missing a mandatory trailing newline character."
    )
    assert not data.endswith(b"\n\n"), (
        f"{OUTPUT_FILE} has an extra blank line at the end—only ONE trailing "
        "newline is allowed."
    )

    text = data.decode("utf-8")
    lines = text.rstrip("\n").split("\n")  # rstrip only the final guaranteed NL
    assert len(lines) == 5, (
        f"{OUTPUT_FILE} must contain exactly five lines (no header/footer); "
        f"found {len(lines)}."
    )

    # Validate each line and capture the tuples (ip, count)
    line_re = re.compile(r"^(\d{1,3}(?:\.\d{1,3}){3}) (\d+)$")
    observed_tuples = []
    for idx, line in enumerate(lines, start=1):
        m = line_re.match(line)
        assert m, (
            f"Line {idx} in {OUTPUT_FILE} is incorrectly formatted:\n{line}\n"
            "Expected: '<IPv4> <COUNT>' with a single space and no extra whitespace."
        )
        ip, cnt = m.groups()
        observed_tuples.append((ip, int(cnt)))

    # ---- 3a.  Exact content must match the ground truth --------------------
    expected_tuples = [
        (ip, EXPECTED_IP_COUNTS[ip]) for ip in [
            "10.0.0.1",
            "10.0.0.2",
            "10.0.0.3",
            "10.0.0.4",
            "10.0.0.5",
        ]
    ]
    assert observed_tuples == expected_tuples, (
        f"Content mismatch in {OUTPUT_FILE}.\n"
        f"Observed lines:\n  " + "\n  ".join(lines) + "\n\n"
        f"Expected lines:\n  " + "\n  ".join(EXPECTED_OUTPUT_LINES)
    )

    # ---- 3b.  Double-check sorting rule compliance -------------------------
    # Descending by count
    counts = [cnt for _, cnt in observed_tuples]
    assert counts == sorted(counts, reverse=True), (
        f"Counts are not in descending order: {counts}"
    )
    # For ties, IPs must be in ascending lexicographic order.
    for i in range(1, len(observed_tuples)):
        prev_ip, prev_cnt = observed_tuples[i - 1]
        curr_ip, curr_cnt = observed_tuples[i]
        if curr_cnt == prev_cnt:
            assert curr_ip > prev_ip, (
                "IP addresses with equal counts are not in ascending "
                f"lexicographic order:\nPrevious line: {prev_ip} {prev_cnt}\n"
                f"Current line:  {curr_ip} {curr_cnt}"
            )