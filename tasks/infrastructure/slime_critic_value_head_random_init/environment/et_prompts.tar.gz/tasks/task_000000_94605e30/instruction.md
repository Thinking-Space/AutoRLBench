You are acting as an on–call incident responder who has just received a ticket about an unusual spike in failed authentication requests. A nightly triage play-book says that the very first thing to do is to give the SOC (Security Operations Center) a quick, reproducible list of “who is talking to us the most”.

Your working directory is /home/user.

The raw firewall logs for the previous 24 h are already staged in `/home/user/syslogs/` as three plain-text files:

    /home/user/syslogs/systemA.log
    /home/user/syslogs/systemB.log
    /home/user/syslogs/systemC.log

*   The files are UTF-8, UNIX-line-ending text files.
*   Every line follows the exact pattern:

        2023-08-01THH:MM:SSZ SRC=IPv4 STATUS=WORD

    where
    – HH, MM, SS are two-digit numbers,  
    – IPv4 is a dotted-quad address,  
    – WORD is either “FAIL” or “SUCCESS”.  
    No other fields are present.

Your job is to find the five most frequent source IP addresses across **all** three log files, based on the criteria below, and write the result to a brand-new file:

    /home/user/analysis/top_ip_counts.log

The list of IPs and their counts should be generated as follows:

*   Extract the text that comes **after** “SRC=” (do not include the “SRC=” itself).
*   Count how many times each IP appears in the entire data-set.
*   Sort the counts in **descending numeric order**; if two IPs have the same count, order those IPs in **ascending lexicographic order** (e.g., 10.0.0.3 comes before 10.0.0.4).
*   Keep only the top 5 entries of that sorted list.

The output file **must** obey the following format so that the automated tests can validate your work:

*   File path: exactly `/home/user/analysis/top_ip_counts.log`
*   Each line: `IP_ADDRESS COUNT` (one single ASCII space between the fields).
*   Lines must appear in the order produced by the sort rules specified above.
*   No extra spaces or tabs.
*   A final trailing newline (Unix style) **is required** after the last line.
*   The file must contain exactly five lines—no header, no footer.

For example, the finished file should look structurally like this:

    192.0.2.10 37
    192.0.2.20 18
    198.51.100.5 17
    203.0.113.8 17
    192.0.2.30 12

(The numbers and addresses above are only an illustration; your real numbers will come from the provided logs.)

To keep things tidy, place `top_ip_counts.log` inside a directory called `/home/user/analysis/` (create that directory if it does not yet exist).

Do **not** modify the original log files. You may use any non-privileged command-line tool that already exists in a typical POSIX userland.

When you are satisfied, you may print the contents of `/home/user/analysis/top_ip_counts.log` to the terminal so the SOC can copy-paste it, but that is optional. The automated grader will look only at the file.

The grader will consider the task complete when it finds the file at the exact path and with exactly the expected five properly-sorted lines (and trailing newline).