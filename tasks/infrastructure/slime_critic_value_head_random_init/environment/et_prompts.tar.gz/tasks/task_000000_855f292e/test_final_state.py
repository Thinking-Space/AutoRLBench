# test_final_state.py
#
# This pytest suite validates the **final** state of the operating-system /
# container *after* the student has finished the exercise.  If any test fails
# it must be crystal-clear what is still wrong so that the student knows
# exactly what to fix.
#
# DO **NOT** MODIFY THESE TESTS.
#
# Requirements being verified:
#
# 1.  The virtual-environment directory
#        /home/user/backups/scripts/archive_env
#    exists and is a directory.
# 2.  That virtual environment contains the normal venv structure; at minimum
#    we insist on:
#       • bin/               (directory)
#       • bin/activate       (non-empty file)
#       • pyvenv.cfg         (file)
# 3.  The log file
#        /home/user/backups/archive_env_setup.log
#    exists and its *exact* contents (including trailing newline characters and
#    the absence of Windows “\r” carriage returns) are:
#
#        /home/user/backups/scripts/archive_env\n
#        VENV_READY\n
#
# The tests purposefully avoid any third-party dependencies and use only
# Python’s standard library + pytest.


import os
from pathlib import Path

import pytest

HOME = Path("/home/user")
BACKUPS_DIR = HOME / "backups"
SCRIPTS_DIR = BACKUPS_DIR / "scripts"
VENV_DIR = SCRIPTS_DIR / "archive_env"
BIN_DIR = VENV_DIR / "bin"
ACTIVATE_SCRIPT = BIN_DIR / "activate"
PYVENV_CFG = VENV_DIR / "pyvenv.cfg"
LOG_FILE = BACKUPS_DIR / "archive_env_setup.log"


# --------------------------------------------------------------------------- #
# Virtual-environment directory checks
# --------------------------------------------------------------------------- #
def test_venv_directory_exists_and_is_directory():
    assert VENV_DIR.exists(), (
        f"Virtual-environment directory {VENV_DIR} is missing.\n"
        "Create it with python -m venv or the standard library’s venv module."
    )
    assert VENV_DIR.is_dir(), (
        f"{VENV_DIR} exists but is not a directory.  "
        "It must be a directory that contains the virtual environment."
    )


def test_venv_contains_expected_substructures():
    # The 'bin' directory must exist.
    assert BIN_DIR.exists(), (
        f"Expected {BIN_DIR} to exist inside the virtual environment but it "
        "is missing."
    )
    assert BIN_DIR.is_dir(), (
        f"{BIN_DIR} exists but is not a directory.  The venv should contain a "
        "directory named 'bin'."
    )

    # The activate script must be present **and** non-empty.
    assert ACTIVATE_SCRIPT.exists(), (
        f"The activate script {ACTIVATE_SCRIPT} is missing.  "
        "This indicates that 'python -m venv' did not complete correctly."
    )
    assert ACTIVATE_SCRIPT.is_file(), (
        f"{ACTIVATE_SCRIPT} exists but is not a regular file."
    )
    size = ACTIVATE_SCRIPT.stat().st_size
    assert size > 0, (
        f"The activate script {ACTIVATE_SCRIPT} is empty (size == 0).  "
        "It should contain shell code to activate the venv."
    )

    # pyvenv.cfg should also be created automatically.
    assert PYVENV_CFG.exists(), (
        f"Expected configuration file {PYVENV_CFG} was not found.  "
        "Virtual environments created by the stdlib venv module always "
        "contain this file."
    )
    assert PYVENV_CFG.is_file(), (
        f"{PYVENV_CFG} exists but is not a file."
    )


# --------------------------------------------------------------------------- #
# Log file checks
# --------------------------------------------------------------------------- #
def _read_log_bytes():
    """
    Helper: return the raw bytes of the log file.

    Separating this out makes the assertion messages in the tests cleaner.
    """
    try:
        return LOG_FILE.read_bytes()
    except FileNotFoundError:
        pytest.fail(
            f"Log file {LOG_FILE} does not exist.  "
            "Create it exactly as specified in the task."
        )


def test_log_file_exists():
    assert LOG_FILE.exists(), (
        f"Required log file {LOG_FILE} is missing."
    )
    assert LOG_FILE.is_file(), (
        f"{LOG_FILE} exists but is not a regular file."
    )


def test_log_file_contents_exact_match():
    raw = _read_log_bytes()

    # Requirement: no Windows CR characters.
    assert b"\r" not in raw, (
        f"{LOG_FILE} contains Windows style line endings (\\r\\n).  "
        "Use UNIX line endings (\\n) only."
    )

    # Requirement: file must end with a newline.
    assert raw.endswith(b"\n"), (
        f"{LOG_FILE} must terminate with a single '\\n' at the end of the "
        "second line."
    )

    text = raw.decode("utf-8")
    lines_with_newlines = text.splitlines(keepends=True)

    assert len(lines_with_newlines) == 2, (
        f"{LOG_FILE} must contain exactly two lines, but it contains "
        f"{len(lines_with_newlines)} line(s).  "
        "Expected format:\n"
        "/home/user/backups/scripts/archive_env\\n\n"
        "VENV_READY\\n"
    )

    expected_lines = [
        "/home/user/backups/scripts/archive_env\n",
        "VENV_READY\n",
    ]

    for idx, (expected, actual) in enumerate(zip(expected_lines, lines_with_newlines), 1):
        assert actual == expected, (
            f"Line {idx} of {LOG_FILE} is incorrect.\n"
            f"Expected: {expected!r}\n"
            f"Actual:   {actual!r}"
        )