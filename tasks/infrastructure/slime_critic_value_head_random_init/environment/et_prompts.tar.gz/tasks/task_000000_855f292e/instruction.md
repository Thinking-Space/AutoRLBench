You are a backup administrator who wants to keep every-thing related to archiving jobs fully isolated from the system Python installation.

*   Inside your home directory create a new workspace directory named `/home/user/backups/scripts` (create the entire path if it does not already exist).
*   In that directory create a Python virtual environment called `archive_env` using the standard library’s venv module. The final absolute path of the virtual-environment directory **must be** `/home/user/backups/scripts/archive_env` and, once created, it has to contain the default structure produced by venv (e.g. the `bin/`, `lib/`, `pyvenv.cfg` files etc.).
*   After the virtual environment is successfully created, generate a plain-text log file located at `/home/user/backups/archive_env_setup.log`. The required content and exact format of the log file is:
    *   Line 1 : the exact absolute path to the virtual-environment directory (`/home/user/backups/scripts/archive_env`)
    *   Line 2 : the literal word **VENV_READY** (all capitals, no extra spaces)

    There must be **exactly two lines**, each terminated with a single newline character (UNIX line ending, “\n”).
*   Do not install any additional packages; the task is only to set up the virtual environment and create the log file.

The automated tests will confirm all three of the following:

a) that `/home/user/backups/scripts/archive_env` exists,
b) that its `bin/activate` script exists, proving venv was created, and
c) that `/home/user/backups/archive_env_setup.log` exists and matches the exact two-line format specified above.

You do not need root privileges.