You are a Tier-1 support engineer and have just pulled two raw performance snapshots from a customer system.
Both snapshots are plain text, single-space separated, and already sit on disk:

1.  `/home/user/diag/cpu_usage.log`
    *   column-1 ISO-8601 timestamp
    *   column-2 average CPU utilisation in %
2.  `/home/user/diag/mem_usage.log`
    *   column-1 ISO-8601 timestamp (identical order and count as above)
    *   column-2 resident memory usage in MB

Management wants a single, comma-separated spreadsheet-ready file that merges the two logs on their common timestamp.
Produce that file as `/home/user/diag/combined_usage.csv` with the exact format shown below (including the header row and the final trailing newline character):

    timestamp,cpu_percent,mem_mb
    2023-07-15T10:00:00,12,2048
    2023-07-15T10:05:00,18,2100
    2023-07-15T10:10:00,20,2150
    2023-07-15T10:15:00,25,2200

Requirements and constraints:
*   Use standard GNU coreutils only.
*   Do not re-type the raw numbers manually; extract them from the provided files.
*   After creating the file, display its contents in the terminal so that a reviewer can immediately see the final result.

An automated test will verify:
1.  `/home/user/diag/combined_usage.csv` exists.
2.  The file’s full content is byte-for-byte identical to the block above, including the header and the terminating newline.
3.  The agent printed the same content to stdout during the session.

You have normal user privileges and write permission to `/home/user/diag/`.