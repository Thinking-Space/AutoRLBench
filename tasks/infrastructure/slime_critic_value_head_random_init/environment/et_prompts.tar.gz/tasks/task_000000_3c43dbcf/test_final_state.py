# test_final_state.py
"""
Pytest suite that validates the *final* OS/container state **after** the
exercise has been solved.

Truth we assert:
1. /home/user/diag/combined_usage.csv exists and is byte-for-byte identical to
   the required reference (including the trailing newline).
2. The two original snapshot files are still present and unmodified.
3. The /home/user/diag directory itself still exists and is a directory.

Any mismatch yields a descriptive assertion message so the learner can
immediately see what is still wrong.
"""

from __future__ import annotations

import pathlib
from typing import Final

import pytest

# --------------------------------------------------------------------------- #
# CONSTANTS
# --------------------------------------------------------------------------- #

HOME: Final = pathlib.Path("/home/user")
DIAG_DIR: Final = HOME / "diag"

CPU_LOG: Final = DIAG_DIR / "cpu_usage.log"
MEM_LOG: Final = DIAG_DIR / "mem_usage.log"
COMBINED_CSV: Final = DIAG_DIR / "combined_usage.csv"

CPU_EXPECTED: Final = (
    "2023-07-15T10:00:00 12\n"
    "2023-07-15T10:05:00 18\n"
    "2023-07-15T10:10:00 20\n"
    "2023-07-15T10:15:00 25\n"
)

MEM_EXPECTED: Final = (
    "2023-07-15T10:00:00 2048\n"
    "2023-07-15T10:05:00 2100\n"
    "2023-07-15T10:10:00 2150\n"
    "2023-07-15T10:15:00 2200\n"
)

COMBINED_EXPECTED: Final = (
    "timestamp,cpu_percent,mem_mb\n"
    "2023-07-15T10:00:00,12,2048\n"
    "2023-07-15T10:05:00,18,2100\n"
    "2023-07-15T10:10:00,20,2150\n"
    "2023-07-15T10:15:00,25,2200\n"
)

# --------------------------------------------------------------------------- #
# HELPERS
# --------------------------------------------------------------------------- #


def assert_file_content(path: pathlib.Path, expected: str) -> None:
    """
    Assert that a file exists, is a regular file, and its byte-for-byte
    content equals *expected*.

    A detailed diff-style message is provided on mismatch.
    """
    assert path.exists(), f"Required file is missing: {path}"
    assert path.is_file(), f"{path} exists but is not a regular file."

    data = path.read_text(encoding="utf-8")
    assert (
        data == expected
    ), (
        f"Content mismatch in {path}.\n"
        "---- expected ----\n"
        f"{expected!r}\n"
        "----- found -----\n"
        f"{data!r}"
    )


# --------------------------------------------------------------------------- #
# TESTS
# --------------------------------------------------------------------------- #


def test_diag_directory_still_present():
    """The /home/user/diag directory must still exist and be a directory."""
    assert DIAG_DIR.exists(), f"Directory {DIAG_DIR} is missing."
    assert DIAG_DIR.is_dir(), f"{DIAG_DIR} exists but is not a directory."


def test_source_logs_unchanged():
    """
    The original snapshot log files must still be present and unmodified.
    """
    assert_file_content(CPU_LOG, CPU_EXPECTED)
    assert_file_content(MEM_LOG, MEM_EXPECTED)


def test_combined_usage_csv_exists_and_correct():
    """
    The solution file must exist and match the exact required content,
    *including* the final trailing newline character.
    """
    assert_file_content(COMBINED_CSV, COMBINED_EXPECTED)


@pytest.mark.parametrize(
    ("path", "expected_bytes"),
    [
        (CPU_LOG, len(CPU_EXPECTED.encode())),
        (MEM_LOG, len(MEM_EXPECTED.encode())),
        (COMBINED_CSV, len(COMBINED_EXPECTED.encode())),
    ],
)
def test_no_extra_whitespace_or_binary_bytes(path: pathlib.Path, expected_bytes: int):
    """
    A small sanity check: file size in bytes must equal the size of the
    expected reference string, preventing hidden control characters or
    trailing spaces.
    """
    actual_size = path.stat().st_size
    assert (
        actual_size == expected_bytes
    ), f"{path} has unexpected byte size. Expected {expected_bytes}, got {actual_size}."