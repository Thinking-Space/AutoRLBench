You are assisting a biomedical researcher who keeps experimental measurements under `/home/user/data/`.

A raw file named `/home/user/data/raw_measurements.csv` is already present.
Your job is to create three new artefacts:

1.  `/home/user/data/summary_stats.txt`
    *   Plain-text, two lines, **exactly** in this order and spelling (values must be computed):
        ```
        Average Temperature: <floating-point number with two decimals>
        Average Heart Rate: <integer>
        ```
    *   A final trailing newline must follow the second line.

2.  `/home/user/data/raw_measurements_space.txt`
    *   A copy of `raw_measurements.csv` where every comma “,” has been replaced by a single space “ ”.
    *   No other changes (same line count, same line order, same trailing newline behaviour).

3.  `/home/user/data/temperature_only.tsv`
    *   Tab-separated file (TSV).
    *   First line (header):
        `subject_id<TAB>temperature`
    *   Followed by one line per record, keeping original order, with exactly the two fields `subject_id` and `temperature`.
    *   Each line—including the last—must end with “\n”.

In addition, create a plain-text run log at `/home/user/data/process.log`. This log should document the operations used to create the required files.
Each log entry must be exactly one line in this format (single spaces as shown):

`[YYYY-MM-DD HH:MM:SS] command_used_exactly_as_typed`

Use the current system clock for the timestamps.

Constraints:
*   Do not modify `raw_measurements.csv` itself.
*   Use only `awk` and `sed`.
*   Do not invoke Python, Perl, R, etc.
*   Paths and filenames are case-sensitive; create files exactly where specified.

The automated tests will verify:
*   The precise content and format of all three output files.
*   Correct timestamps (within the test run time window).

When you finish, ensure the files exist with the correct contents and that `process.log` contains the commands you used.