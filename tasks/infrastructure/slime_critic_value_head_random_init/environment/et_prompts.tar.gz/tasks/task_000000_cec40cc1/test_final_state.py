# test_final_state.py
#
# Pytest suite that validates the **final** operating-system / container
# state after the student has completed the task described in the prompt.
#
# DO NOT MODIFY.  These tests must all pass for full credit.

import os
import re
import textwrap
from datetime import datetime, timedelta
from pathlib import Path

import pytest

DATA_DIR = Path("/home/user/data")
RAW_FILE = DATA_DIR / "raw_measurements.csv"

SUMMARY_STATS = DATA_DIR / "summary_stats.txt"
RAW_SPACE = DATA_DIR / "raw_measurements_space.txt"
TEMP_ONLY = DATA_DIR / "temperature_only.tsv"
PROCESS_LOG = DATA_DIR / "process.log"

# ---------------------------------------------------------------------------#
# Reference raw CSV content (including final newline) – must remain unchanged
# ---------------------------------------------------------------------------#
EXPECTED_RAW_CONTENT = textwrap.dedent("""\
    subject_id,temperature,heart_rate
    S1,36.6,72
    S2,37.1,75
    S3,36.9,70
    S4,37.3,80
    S5,36.8,68
    """)  # textwrap removes leading spaces only

# ---------------------------------------------------------------------------#
# Helper functions
# ---------------------------------------------------------------------------#
def read_text(path: Path) -> str:
    """
    Read a UTF-8 text file exactly as-is.  Fail with a helpful assertion message
    if the file is missing or not UTF-8.
    """
    assert path.is_file(), f"Required file {path} is missing."
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        pytest.fail(f"{path} is not valid UTF-8: {exc}")  # pragma: no cover


def parse_raw_csv() -> list[tuple[str, float, int]]:
    """
    Return list of (subject_id, temperature, heart_rate) from the raw CSV.
    """
    rows = []
    for idx, line in enumerate(EXPECTED_RAW_CONTENT.strip().splitlines()):
        if idx == 0:
            continue  # header
        subject_id, temp, hr = line.split(",")
        rows.append((subject_id, float(temp), int(hr)))
    return rows


# ---------------------------------------------------------------------------#
# Tests
# ---------------------------------------------------------------------------#
def test_raw_measurements_unmodified():
    """
    The original raw_measurements.csv must still exist and be identical to the
    starter data provided to the student.
    """
    actual = read_text(RAW_FILE)
    assert (
        actual == EXPECTED_RAW_CONTENT
    ), (
        "raw_measurements.csv has been modified.\n"
        "Expected content:\n"
        "------------------\n"
        f"{EXPECTED_RAW_CONTENT}"
        "------------------\n"
        "Found:\n"
        "------------------\n"
        f"{actual}"
        "------------------"
    )


def test_summary_stats_contents():
    """
    Validate summary_stats.txt:
        • Exactly two lines
        • Correct numeric values and formatting
        • File ends with a single trailing newline
    """
    txt = read_text(SUMMARY_STATS)
    assert txt.endswith(
        "\n"
    ), f"{SUMMARY_STATS} must end with a single trailing newline (\\n)."

    # Split preserving internal newline characters for detailed checks
    lines = txt.splitlines()
    assert (
        len(lines) == 2
    ), f"{SUMMARY_STATS} must contain exactly two lines, found {len(lines)}."

    # Compute expected values from the raw CSV
    rows = parse_raw_csv()
    avg_temp = sum(r[1] for r in rows) / len(rows)
    avg_hr = round(sum(r[2] for r in rows) / len(rows))

    expected_first = f"Average Temperature: {avg_temp:.2f}"
    expected_second = f"Average Heart Rate: {avg_hr}"

    assert (
        lines[0] == expected_first
    ), f"First line incorrect.\nExpected: {expected_first!r}\nFound:    {lines[0]!r}"
    assert (
        lines[1] == expected_second
    ), f"Second line incorrect.\nExpected: {expected_second!r}\nFound:    {lines[1]!r}"


def test_raw_measurements_space_file():
    """
    Validate raw_measurements_space.txt:
        • Content identical to the CSV but with commas replaced by single spaces
        • Same number/order of lines
        • Final newline behaviour identical to the source file
    """
    src = read_text(RAW_FILE)
    expected = src.replace(",", " ")
    actual = read_text(RAW_SPACE)
    assert (
        actual == expected
    ), (
        f"Content of {RAW_SPACE} is incorrect.\n"
        f"Expected:\n------------------\n{expected}"
        f"------------------\nFound:\n------------------\n{actual}"
        "------------------"
    )


def test_temperature_only_tsv():
    """
    Validate temperature_only.tsv:
        • Tab-separated
        • Header + one line per record (in original order)
        • Each line ends with \\n, including the last
    """
    actual = read_text(TEMP_ONLY)

    # Ensure final newline
    assert actual.endswith(
        "\n"
    ), f"{TEMP_ONLY} must terminate with a single newline (\\n)."

    lines = actual.splitlines()
    rows = parse_raw_csv()

    expected_lines = ["subject_id\ttemperature"]
    expected_lines += [f"{sid}\t{temp:.1f}" for sid, temp, _ in rows]

    assert (
        lines == expected_lines
    ), (
        f"{TEMP_ONLY} content mismatch.\n"
        f"Expected lines:\n{expected_lines}\n"
        f"Found lines:\n{lines}"
    )


TIMESTAMP_RE = re.compile(
    r"""
    ^\[
        (?P<date>\d{4}-\d{2}-\d{2})\             # YYYY-MM-DD
        (?P<time>\d{2}:\d{2}:\d{2})              # HH:MM:SS
    \]\                                          # closing bracket + space
     (?P<cmd>.+)$
    """,
    re.VERBOSE,
)


def test_process_log():
    """
    Validate process.log:
        • At least three lines
        • Each line matches "[YYYY-MM-DD HH:MM:SS] command"
        • Each line contains 'awk' or 'sed'
        • Timestamps are within the last 10 minutes (test execution window)
        • File ends with a newline
    """
    now = datetime.now()
    txt = read_text(PROCESS_LOG)

    # final newline
    assert txt.endswith(
        "\n"
    ), f"{PROCESS_LOG} must end with a single trailing newline (\\n)."

    lines = txt.rstrip("\n").split("\n")  # preserve all but final sentinel
    assert (
        len(lines) >= 3
    ), f"{PROCESS_LOG} must contain at least 3 log entries, found {len(lines)}."

    for idx, line in enumerate(lines, start=1):
        m = TIMESTAMP_RE.match(line)
        assert m, f"Line {idx} in {PROCESS_LOG} has incorrect format: {line!r}"

        cmd = m.group("cmd")
        assert (
            "awk" in cmd or "sed" in cmd
        ), f"Line {idx} must contain 'awk' or 'sed': {line!r}"

        # Timestamp window check (within 10 minutes of current system time)
        ts_str = f"{m.group('date')} {m.group('time')}"
        try:
            ts = datetime.strptime(ts_str, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            pytest.fail(f"Invalid timestamp on line {idx}: {ts_str}")  # pragma: no cover

        delta = abs(now - ts)
        assert (
            delta <= timedelta(minutes=10)
        ), (
            f"Timestamp on line {idx} ({ts_str}) is not within 10 minutes of "
            f"current time ({now.strftime('%Y-%m-%d %H:%M:%S')})."
        )