# test_final_state.py
#
# Pytest suite that validates the *FINAL* OS / filesystem state
# AFTER the student has carried out the rollout task.
#
# The checks prove that:
#   1. A working Python virtual-environment exists at the required path.
#   2. The venv’s Python interpreter is functional.
#   3. The setup log exists, has sane permissions, contains exactly two
#      newline-terminated lines, and that the second line matches the
#      actual version string reported by the venv’s Python.
#
# If any test fails it will explain precisely what is still wrong.
#
# The tests rely ONLY on the Python standard library and pytest.
# No third-party dependencies are used.

import os
import stat
import subprocess
import re
import sys
import pytest

HOME = "/home/user"
ROLLOUT_DIR = os.path.join(HOME, "rollout")
VENV_PATH = os.path.join(ROLLOUT_DIR, "rollout-env")
VENV_BIN = os.path.join(VENV_PATH, "bin")
PYTHON_EXE = os.path.join(VENV_BIN, "python")
ACTIVATE_SCRIPT = os.path.join(VENV_BIN, "activate")
PYVENV_CFG = os.path.join(VENV_PATH, "pyvenv.cfg")
LOG_PATH = os.path.join(ROLLOUT_DIR, "setup.log")


# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------

def _human_readable_mode(path: str) -> str:
    """Return a file mode in octal (e.g. 0o755) or '<missing>'."""
    if not os.path.exists(path):
        return "<missing>"
    return oct(os.stat(path).st_mode & 0o777)


def _run_python_version(executable: str) -> str:
    """
    Run `<executable> --version` and return the version string.

    Historically `python --version` can write to stderr or stdout;
    we therefore capture both and use whichever is non-empty.
    """
    completed = subprocess.run(
        [executable, "--version"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    # Make sure the interpreter ran successfully
    assert completed.returncode == 0, (
        f"Running {executable!r} exited with non-zero status "
        f"{completed.returncode}.\nstdout: {completed.stdout}\nstderr: {completed.stderr}"
    )
    output = completed.stdout.strip() or completed.stderr.strip()
    # Sanity check on the output
    assert output.startswith("Python"), (
        f"Unexpected output from '{executable} --version': {output!r}"
    )
    return output


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.describe("Virtual environment exists and looks sane")
def test_venv_directory_structure():
    # venv root directory
    assert os.path.isdir(VENV_PATH), (
        f"Virtual-environment directory {VENV_PATH!r} is missing or not a directory."
    )

    # bin/activate script
    assert os.path.isfile(ACTIVATE_SCRIPT), (
        f"Expected activation script at {ACTIVATE_SCRIPT!r}, "
        f"but it is missing (mode: {_human_readable_mode(ACTIVATE_SCRIPT)})."
    )

    # pyvenv.cfg file
    assert os.path.isfile(PYVENV_CFG), (
        f"{PYVENV_CFG!r} is missing; the directory does not look like a "
        f"valid venv created with the standard library's 'venv' module."
    )


def test_venv_python_is_executable_and_reports_version():
    # File exists and is executable
    assert os.path.isfile(PYTHON_EXE), (
        f"Python interpreter not found at {PYTHON_EXE!r}."
    )
    assert os.access(PYTHON_EXE, os.X_OK), (
        f"Python interpreter at {PYTHON_EXE!r} is not executable "
        f"(mode: {_human_readable_mode(PYTHON_EXE)})."
    )

    # Interpreter actually runs
    version_string = _run_python_version(PYTHON_EXE)

    # Must be Python 3.x
    assert re.match(r"^Python 3\.\d+(\.\d+)?$", version_string), (
        f"Python interpreter in the venv reported an unexpected version string: "
        f"{version_string!r}.  Expected something like 'Python 3.11.4'."
    )


@pytest.mark.describe("setup.log file is present, well-formed and matches venv python --version output")
def test_setup_log_content_and_permissions():
    # ------------------------------------------------------------------
    # 1.  Existence & type
    # ------------------------------------------------------------------
    assert os.path.isfile(LOG_PATH), (
        f"setup.log file not found at {LOG_PATH!r}."
    )

    # ------------------------------------------------------------------
    # 2.  Permissions: must NOT be world-writable (others-write bit set)
    #     i.e. 0o666, 0o777 etc. are disallowed.  0664 or stricter is OK.
    # ------------------------------------------------------------------
    mode = os.stat(LOG_PATH).st_mode & 0o777
    assert mode & stat.S_IWOTH == 0, (
        f"setup.log is world-writable (mode {_human_readable_mode(LOG_PATH)}); "
        f"it must have permissions 0664 or stricter."
    )

    # ------------------------------------------------------------------
    # 3.  Content checks
    # ------------------------------------------------------------------
    with open(LOG_PATH, "rb") as fh:
        binary_content = fh.read()

    # The file must end with a newline so that both lines are terminated.
    assert binary_content.endswith(b"\n"), (
        "setup.log must end with a newline (\\n)."
    )

    # Decode as UTF-8; splitlines() strips the newline characters.
    text_lines = binary_content.decode("utf-8").splitlines()

    # Exactly two lines
    assert len(text_lines) == 2, (
        f"setup.log must contain exactly two lines, but it has {len(text_lines)} line(s)."
    )

    # Line 1: exact match
    assert text_lines[0] == "SETUP_OK", (
        f"First line of setup.log is {text_lines[0]!r}; expected 'SETUP_OK'."
    )

    # Line 2: must start with 'Python 3.'
    assert re.match(r"^Python 3\..*", text_lines[1]), (
        f"Second line of setup.log is {text_lines[1]!r}; "
        "expected it to start with the literal string 'Python 3.'."
    )

    # ------------------------------------------------------------------
    # 4.  Cross-check: the version in the log must match what the venv
    #     interpreter actually reports _right now_.
    # ------------------------------------------------------------------
    current_version = _run_python_version(PYTHON_EXE)
    assert text_lines[1] == current_version, (
        "The second line of setup.log does not match the version string "
        "reported by the venv’s Python interpreter.\n"
        f"setup.log line 2: {text_lines[1]!r}\n"
        f"venv python  : {current_version!r}"
    )