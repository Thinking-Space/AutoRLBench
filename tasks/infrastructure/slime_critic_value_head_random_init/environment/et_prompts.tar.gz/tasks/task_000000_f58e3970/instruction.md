You are a deployment engineer who has just received a green-light to roll out the latest Python-based micro-service.

The requirements are:

• Create an isolated virtual environment using Python’s built-in **venv** module. The environment must live at  
  /home/user/rollout/rollout-env

• After creating the environment you must **activate** it and run the command  
  python --version

• Create a text log file at  
  /home/user/rollout/setup.log

  The log file must be exactly two lines long, using Unix line-endings:

  Line 1  →  SETUP_OK  
  Line 2  →  (whatever string is printed by the python --version command you ran **inside** the virtual environment)

  Example of a correctly formatted file (version will vary):

      SETUP_OK
      Python 3.10.12

Notes & constraints:

• Do NOT hard-code the version; just capture whatever python --version prints after activating the venv.  
• Keep the existing directory structure clean—create any missing directories yourself.  
• You do **not** have to install any third-party packages.  
• When you are done, the CI system will inspect two things only:  
    1. The presence of the virtual-environment directory tree at /home/user/rollout/rollout-env  
    2. The exact two-line content of /home/user/rollout/setup.log as specified above.

You may use any standard shell commands available on a typical Debian/Ubuntu environment, but you do NOT have root access.

Goal recap: a working venv and a properly formatted setup.log file.  Once both exist exactly as specified, the task is complete.