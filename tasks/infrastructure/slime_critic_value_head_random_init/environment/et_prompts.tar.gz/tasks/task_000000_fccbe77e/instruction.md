You are a container-platform specialist who has just inherited a legacy stack definition kept under:

`/home/user/stack/`

Inside that directory there are exactly three docker-compose YAML files whose names all follow the pattern `<something>.yml`.

### Goal

Create a single text file called `/home/user/stack/images.list` that contains an alphabetically-sorted, duplicate-free list of every container image referenced by an `image:` key in all `*.yml` files inside `/home/user/stack/`.

### Output format requirements

The automated tests will check for an exact match:
1. Every line must contain only the image reference text, exactly as it appears in the YAML file (case-preserved, no leading or trailing spaces).
2. The list must be sorted in ascending (ASCII) order.
3. Each distinct image may appear only once in the file.
4. The very last character in the file must be a single trailing newline (Unix LF).
5. No extra blank lines are allowed.

Once the `images.list` file is written, print its contents to the terminal so that the evaluator can see the final result.

### Constraints

*   You do NOT need root privileges and must not install additional packages.

### Success criteria

The automated test will verify two things:
1.  `/home/user/stack/images.list` exists and matches exactly the format described above.
2.  The console output you display matches the file content, proving the command ran correctly.

You may use any temporary commands you like, but the final state described above must be reached.