# test_final_state.py
#
# Pytest suite that validates the FINAL on-disk state after the student’s
# solution has run.
#
# It checks that:
#   • /home/user/incidents/checksum_report.log exists
#   • The file obeys every byte-level formatting rule described in the task
#   • The hashes shown for each payload are correct for the *current* files
#   • The “STATUS” column is logically consistent (OK vs MISMATCH)
#
# Only Python’s standard library and pytest are used.

import os
import hashlib
import stat
import pytest


INCIDENT_DIR = "/home/user/incidents"
REPORT_PATH = os.path.join(INCIDENT_DIR, "checksum_report.log")

# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def _read_bytes(path):
    """Read a file in binary mode and return its raw bytes."""
    with open(path, "rb") as fh:
        return fh.read()


def _read_text(path):
    """Read a file as UTF-8 text and return its contents (including newlines)."""
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


def _sha256_of_file(path):
    """Return the lowercase hex SHA-256 digest of the file at *path*."""
    h = hashlib.sha256()
    h.update(_read_bytes(path))
    return h.hexdigest()


def _expected_hash_from_sidecar(payload):
    """
    Return the hash string contained in the vendor-supplied “*.sha256” sidecar
    that accompanies *payload*.
    """
    sidecar_path = os.path.join(INCIDENT_DIR, f"{payload}.sha256")
    text = _read_text(sidecar_path)
    # Each sidecar is exactly: "<hash>  <filename>\n"
    return text.split()[0]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_report_file_exists_and_is_regular():
    assert os.path.isfile(
        REPORT_PATH
    ), f"Required log file {REPORT_PATH!r} does not exist or is not a regular file."


def test_report_file_format_and_content():
    """
    Validate the checksum_report.log content line-by-line against the detailed
    specification given in the task description.
    """
    # ---------- Read and basic newline checks ----------
    content = _read_text(REPORT_PATH)

    # The file must end with a single trailing NL.
    assert content.endswith(
        "\n"
    ), "checksum_report.log must end with exactly one '\\n' newline."

    # There must be exactly three newline characters ==> three lines.
    nl_count = content.count("\n")
    assert (
        nl_count == 3
    ), f"checksum_report.log must contain exactly 3 lines (3 newline characters). Found {nl_count}."

    # Split WITHOUT removing newline characters for precise length check later
    lines = content.splitlines()
    assert (
        len(lines) == 3
    ), f"checksum_report.log must have exactly 3 lines. Found {len(lines)} lines."

    header, line1, line2 = lines

    # ---------- Header line ----------
    expected_header = "FILE,COMPUTED,EXPECTED,STATUS"
    assert (
        header == expected_header
    ), f"First line must be the exact header {expected_header!r}. Found {header!r}."

    # ---------- Data lines ----------
    for idx, line in enumerate([line1, line2], start=2):
        # No leading/trailing whitespace
        assert line == line.strip(), (
            f"Line {idx} in checksum_report.log contains leading/trailing whitespace. "
            f"Line content: {line!r}"
        )

        # Exactly four comma-separated fields
        fields = line.split(",")
        assert (
            len(fields) == 4
        ), f"Line {idx} must have exactly 4 comma-separated fields. Got {len(fields)}: {fields!r}"

        # No empty fields
        assert all(
            fields
        ), f"Line {idx} contains empty field(s). Each of the 4 fields must be non-empty."

    # ---------- Per-file semantic checks ----------
    records = [line1.split(","), line2.split(",")]

    # They must be in the order update1.txt, update2.txt
    filenames = [rec[0] for rec in records]
    assert filenames == [
        "update1.txt",
        "update2.txt",
    ], f"Data lines must be in the order update1.txt then update2.txt. Found {filenames}."

    # Map for easier assertions
    rec_map = {rec[0]: rec for rec in records}

    # Specifications for both payloads
    expectations = {
        "update1.txt": {"status": "OK"},
        "update2.txt": {"status": "MISMATCH"},
    }

    for payload, spec in expectations.items():
        rec = rec_map[payload]
        _, computed, expected_hash, status = rec

        # ---------- Hash string checks ----------
        for hash_str, label in [
            (computed, "COMPUTED"),
            (expected_hash, "EXPECTED"),
        ]:
            assert len(hash_str) == 64 and all(
                c in "0123456789abcdef" for c in hash_str
            ), (
                f"{label} hash for {payload} must be a 64-character lowercase "
                f"hex string. Found {hash_str!r}"
            )

        # ---------- Verify COMPUTED field is correct ----------
        real_computed = _sha256_of_file(os.path.join(INCIDENT_DIR, payload))
        assert (
            computed == real_computed
        ), f"Incorrect COMPUTED hash for {payload}. Expected actual file digest {real_computed}, found {computed}."

        # ---------- Verify EXPECTED field comes from sidecar ----------
        real_expected = _expected_hash_from_sidecar(payload)
        assert (
            expected_hash == real_expected
        ), f"Incorrect EXPECTED hash for {payload}. Should come from its *.sha256 file ({real_expected}), found {expected_hash}."

        # ---------- Verify STATUS logic ----------
        correct_status = "OK" if computed == expected_hash else "MISMATCH"
        assert status == correct_status, (
            f"STATUS for {payload} is wrong. Based on the hashes it should be "
            f"{correct_status!r}, found {status!r}."
        )

        # ---------- Match overall specification for this payload ----------
        assert (
            status == spec["status"]
        ), f"STATUS for {payload} must be {spec['status']}, found {status}."