You are an on–call operations engineer. Two hot-fix payloads have just been copied into

    /home/user/incidents/

together with the vendor-supplied checksum files. Your job is to prove (in writing) whether the files you received are intact.

Verify the SHA-256 checksum of BOTH of the following payloads, using only the reference “*.sha256” files that are already present in the same directory.

    /home/user/incidents/update1.txt
    /home/user/incidents/update2.txt

Create a **single, comma-separated verification log** named

    /home/user/incidents/checksum_report.log

The log **must** contain exactly three lines in the order shown below:

    FILE,COMPUTED,EXPECTED,STATUS
    update1.txt,<computed-hash-1>,<expected-hash-1>,OK
    update2.txt,<computed-hash-2>,<expected-hash-2>,MISMATCH

Formatting rules that the automated grader will check:

*   The very first line is the header: the four literal words  
    “FILE,COMPUTED,EXPECTED,STATUS” (all caps, no spaces).  
*   Each of the two data lines starts with the bare filename (no path), followed by  
    three further fields:  
        1. the SHA-256 you actually calculated;  
        2. the SHA-256 string read from the corresponding “.sha256” file;  
        3. the word “OK” if they are identical or “MISMATCH” if they differ.  
*   All four fields on every line are separated by a single comma “,” and **nothing else**
    (no surrounding spaces, tabs, or quotation marks).  
*   All hexadecimal hashes must be written in **lower-case** exactly 64 characters long.  
*   The file must end with a single trailing newline (i.e. the usual UNIX line ending).

A correctly completed checksum_report.log that obeys every rule above is the only thing the automated tests will look for, so double-check spelling, byte-perfect punctuation, and the correct use of upper/lower case.