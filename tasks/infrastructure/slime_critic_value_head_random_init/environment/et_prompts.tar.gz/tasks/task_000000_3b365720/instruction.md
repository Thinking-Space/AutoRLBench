A data-analysis script you are about to run has been behaving oddly.
Before you launch the heavy crunching job, you want to:

1.  Capture a **concise system-snapshot** so you can prove the machine was healthy at the start.
2.  Produce a **quick CSV-driven business summary** that your manager asked for.

The system already contains a sample dataset located at
/home/user/data/transactions.csv

Your job is to create two plainly-formatted log files, using any standard
Linux command-line tools you like:

------------------------------------------------------------------------

A) `/home/user/diagnostics/system_snapshot.log`
*   Create the parent directory if it does not exist.
*   The file **must contain exactly six lines** in the **order shown below**.
*   Each line must follow the strict KEY=VALUE pattern with **no leading/trailing spaces**.
*   Keys are fixed, but values come from live commands:

    1.  `DATE=YYYY-MM-DD` (output of: `date +%F`)
    2.  `HOSTNAME=<hostname>` (output of: `hostname`)
    3.  `OS=<uname-s>` (output of: `uname -s`)
    4.  `KERNEL=<uname-r>` (output of: `uname -r`)
    5.  `TOTAL_MEM_MB=<integer>` (second column of “`free -m | grep Mem`”)
    6.  `HOME_DISK_USED_PCT=<integer>` (5th column, without ‘%’, of “`df -h /home/user | tail -1`”)

    Example (values will differ on your machine):
        DATE=2024-03-19
        HOSTNAME=training-box
        OS=Linux
        KERNEL=5.15.0-86-generic
        TOTAL_MEM_MB=7829
        HOME_DISK_USED_PCT=37

    The automated checker will re-run those same six commands and compare
    values; therefore, extract the numbers exactly as shown above.

------------------------------------------------------------------------

B) `/home/user/analysis/transactions_summary.log`
*   Create the parent directory if it does not exist.
*   Parse `/home/user/data/transactions.csv`, which has a header row and
    five transaction lines.
*   Compute:
    – `TOTAL_TRANSACTIONS` (count of data rows)
    – `TOTAL_AMOUNT` (sum of “amount” column, as an integer)
    – `AVERAGE_AMOUNT` (mean of “amount” column, rounded to two
      decimals; always show exactly two digits
      after the decimal point)
*   The summary file **must contain exactly three lines** in the **order shown below**, each again in KEY=VALUE format:

        TOTAL_TRANSACTIONS=<integer>
        TOTAL_AMOUNT=<integer>
        AVERAGE_AMOUNT=<number with 2 decimals>

    For the bundled dataset, the correct content is:
        TOTAL_TRANSACTIONS=5
        TOTAL_AMOUNT=875
        AVERAGE_AMOUNT=175.00

------------------------------------------------------------------------

When everything is done, list the two absolute file paths you created so
the human reviewer can open them quickly.

Do NOT write or modify anything outside `/home/user`.