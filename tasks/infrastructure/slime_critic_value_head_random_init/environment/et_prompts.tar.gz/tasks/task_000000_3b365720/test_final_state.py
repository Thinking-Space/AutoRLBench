# test_final_state.py
#
# Pytest suite that validates the *final* state of the OS/container
# AFTER the student has completed the “system-snapshot & CSV business
# summary” task.
#
# The checks performed are:
#
#   1. /home/user/diagnostics/system_snapshot.log
#        * File exists.
#        * Has exactly six KEY=VALUE lines, in the mandated order.
#        * Each value exactly matches the *current* live command output.
#
#   2. /home/user/analysis/transactions_summary.log
#        * File exists.
#        * Has exactly three KEY=VALUE lines, in the mandated order.
#        * Values match the reference statistics for the bundled dataset.
#
# If any assertion fails, the message explains precisely what is wrong.
#
# Uses only the Python standard library and pytest.

import csv
import pathlib
import subprocess
import sys
from typing import List

import pytest

HOME = pathlib.Path("/home/user").expanduser().resolve()

# --------------------------------------------------------------------------- #
# Paths the student had to create
# --------------------------------------------------------------------------- #
DIAGNOSTICS_DIR = HOME / "diagnostics"
SNAPSHOT_FILE = DIAGNOSTICS_DIR / "system_snapshot.log"

ANALYSIS_DIR = HOME / "analysis"
SUMMARY_FILE = ANALYSIS_DIR / "transactions_summary.log"

DATASET = HOME / "data" / "transactions.csv"

# --------------------------------------------------------------------------- #
# Helper functions for the snapshot reference
# --------------------------------------------------------------------------- #
def get_live_system_snapshot_values() -> List[str]:
    """
    Run the same six commands the student was instructed to run and
    return the expected snapshot values (strings, *already* in KEY=VALUE form,
    order preserved).
    """
    # DATE
    date_val = subprocess.check_output(["date", "+%F"], text=True).strip()

    # HOSTNAME
    hostname_val = subprocess.check_output(["hostname"], text=True).strip()

    # OS (uname -s)
    os_val = subprocess.check_output(["uname", "-s"], text=True).strip()

    # KERNEL (uname -r)
    kernel_val = subprocess.check_output(["uname", "-r"], text=True).strip()

    # TOTAL_MEM_MB
    free_output = subprocess.check_output(["free", "-m"], text=True)
    mem_line = next((ln for ln in free_output.splitlines() if ln.lower().startswith("mem")), None)
    if mem_line is None:
        pytest.fail(
            "`free -m` did not produce a line that starts with 'Mem'. "
            "Cannot determine reference TOTAL_MEM_MB."
        )
    mem_total_mb = mem_line.split()[1]

    # HOME_DISK_USED_PCT
    df_output = subprocess.check_output(["df", "-h", str(HOME)], text=True).splitlines()
    if len(df_output) < 2:
        pytest.fail("`df -h /home/user` output did not contain a data line.")
    df_data_line = df_output[-1]
    used_pct_raw = df_data_line.split()[4]  # e.g. '37%'
    used_pct = used_pct_raw.rstrip("%")

    return [
        f"DATE={date_val}",
        f"HOSTNAME={hostname_val}",
        f"OS={os_val}",
        f"KERNEL={kernel_val}",
        f"TOTAL_MEM_MB={mem_total_mb}",
        f"HOME_DISK_USED_PCT={used_pct}",
    ]


def read_file_lines(path: pathlib.Path) -> List[str]:
    """Return the file content as a list of *stripped* lines (no trailing newlines)."""
    with path.open("r", encoding="utf-8") as fh:
        # .rstrip('\n') keeps other whitespace (e.g. spaces) which we must test against
        return [ln.rstrip("\n") for ln in fh.readlines()]


# --------------------------------------------------------------------------- #
# Tests for system_snapshot.log
# --------------------------------------------------------------------------- #
def test_system_snapshot_file_exists():
    assert SNAPSHOT_FILE.is_file(), (
        f"Missing diagnostics file: {SNAPSHOT_FILE}\n"
        "It must be created by the student's script."
    )


def test_system_snapshot_format_and_values():
    lines = read_file_lines(SNAPSHOT_FILE)

    # ---------- Length ----------
    assert len(lines) == 6, (
        f"{SNAPSHOT_FILE} must contain exactly 6 lines.\n"
        f"Found {len(lines)} line(s):\n{lines}"
    )

    # ---------- Whitespace ----------
    for idx, ln in enumerate(lines, 1):
        assert ln == ln.strip(), (
            f"Line {idx} in {SNAPSHOT_FILE} has leading/trailing whitespace:\n"
            f"'{ln}'"
        )

    # ---------- KEY=VALUE structure ----------
    expected_keys = [
        "DATE",
        "HOSTNAME",
        "OS",
        "KERNEL",
        "TOTAL_MEM_MB",
        "HOME_DISK_USED_PCT",
    ]
    for idx, (ln, key) in enumerate(zip(lines, expected_keys), 1):
        parts = ln.split("=", 1)
        assert len(parts) == 2 and parts[0] == key and parts[1], (
            f"Line {idx} in {SNAPSHOT_FILE} must be '{key}=<value>' with no "
            "extra '=' characters.\n"
            f"Found: '{ln}'"
        )

    # ---------- Values ----------
    live_reference = get_live_system_snapshot_values()
    mismatches = [
        (idx + 1, ln, ref)
        for idx, (ln, ref) in enumerate(zip(lines, live_reference))
        if ln != ref
    ]
    assert not mismatches, _format_snapshot_mismatch_message(mismatches, lines, live_reference)


def _format_snapshot_mismatch_message(
    mismatches: List[tuple], actual: List[str], expected: List[str]
) -> str:
    """Return a helpful assertion message for snapshot mismatches."""
    msg_lines = [
        "system_snapshot.log content does not match the live system values."
    ]
    msg_lines.append("Differences:")
    for idx, got, exp in mismatches:
        msg_lines.append(f"  Line {idx}: expected '{exp}', found '{got}'")
    msg_lines.append("\nComplete expected snapshot:")
    for ln in expected:
        msg_lines.append("  " + ln)
    msg_lines.append("\nComplete actual snapshot:")
    for ln in actual:
        msg_lines.append("  " + ln)
    return "\n".join(msg_lines)


# --------------------------------------------------------------------------- #
# Tests for transactions_summary.log
# --------------------------------------------------------------------------- #
def test_transactions_summary_file_exists():
    assert SUMMARY_FILE.is_file(), (
        f"Missing analysis file: {SUMMARY_FILE}\n"
        "It must be created by the student's script."
    )


def test_transactions_summary_content():
    # ---------- Read student's file ----------
    lines = read_file_lines(SUMMARY_FILE)

    assert len(lines) == 3, (
        f"{SUMMARY_FILE} must contain exactly 3 lines.\n"
        f"Found {len(lines)} line(s):\n{lines}"
    )

    # ---------- Ensure no leading/trailing whitespace ----------
    for idx, ln in enumerate(lines, 1):
        assert ln == ln.strip(), (
            f"Line {idx} in {SUMMARY_FILE} has leading/trailing whitespace:\n"
            f"'{ln}'"
        )

    # ---------- Compute reference stats ----------
    with DATASET.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        rows = list(reader)

    amounts = [int(r["amount"]) for r in rows]
    total_transactions = len(rows)
    total_amount = sum(amounts)
    average_amount = round(total_amount / total_transactions, 2) if amounts else 0.00

    expected_lines = [
        f"TOTAL_TRANSACTIONS={total_transactions}",
        f"TOTAL_AMOUNT={total_amount}",
        f"AVERAGE_AMOUNT={average_amount:.2f}",
    ]

    # ---------- Key order & values ----------
    mismatches = [
        (idx + 1, ln, ref)
        for idx, (ln, ref) in enumerate(zip(lines, expected_lines))
        if ln != ref
    ]
    assert not mismatches, _format_summary_mismatch_message(mismatches, lines, expected_lines)


def _format_summary_mismatch_message(
    mismatches: List[tuple], actual: List[str], expected: List[str]
) -> str:
    """Return a helpful assertion message for summary mismatches."""
    msg_lines = ["transactions_summary.log content is incorrect."]
    msg_lines.append("Differences:")
    for idx, got, exp in mismatches:
        msg_lines.append(f"  Line {idx}: expected '{exp}', found '{got}'")
    msg_lines.append("\nComplete expected summary:")
    for ln in expected:
        msg_lines.append("  " + ln)
    msg_lines.append("\nComplete actual summary:")
    for ln in actual:
        msg_lines.append("  " + ln)
    return "\n".join(msg_lines)