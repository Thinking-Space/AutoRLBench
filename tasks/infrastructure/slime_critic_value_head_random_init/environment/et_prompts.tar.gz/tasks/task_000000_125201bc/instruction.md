You are helping a developer clean-up and reorganize some loose project assets that are currently sitting in the downloads area.

**GOAL**  
Create a well-structured project tree called “alpha_app” under /home/user/dev and then migrate the files that are in /home/user/downloads/alpha_assets into their proper places.  
After every move, you must record the operation in a CSV-formatted log so that an automated grading script can later verify that every file went exactly where it belongs.

**STARTING MATERIAL**  
1.  Directory: /home/user/downloads/alpha_assets/  
    It already exists and contains exactly the eight files shown here (no other regular files or sub-directories are present):  
        • app.py  
        • helpers.py  
        • test_app.py  
        • test_helpers.py  
        • overview.md  
        • CHANGELOG.md  
        • Dockerfile  
        • LICENSE  

**TARGET STRUCTURE (all paths are absolute)**  
A new directory tree must end up looking like this:

    /home/user/dev/alpha_app/                       ← main project directory
    │
    ├── 1_src/                                      ← source code
    │       app.py
    │       helpers.py
    │
    ├── 2_tests/                                    ← automated tests
    │       test_app.py
    │       test_helpers.py
    │
    ├── 3_docs/                                     ← general documentation
    │       overview.md
    │
    ├── 4_build/                                    ← build-related artefacts
    │       CHANGELOG.md
    │       Dockerfile
    │
    ├── LICENSE                                     ← (stays at project root)
    │
    ├── organization.log                            ← CSV log file (see below)
    └── summary_statistics.txt                      ← human-readable summary (see below)

**MIGRATION RULES**  
• All “regular” *.py modules that do NOT start with “test_” → 1_src/  
• Any Python file whose basename starts with “test_” → 2_tests/  
• All *.md files EXCEPT “CHANGELOG.md” → 3_docs/  
• “CHANGELOG.md” and “Dockerfile” → 4_build/  
• “LICENSE” must remain directly in the project root (do NOT move it into a numbered sub-directory).  

After the moves are finished the original directory /home/user/downloads/alpha_assets/ must be empty (you may delete it entirely or leave it empty).  

**LOG REQUIREMENTS**  
Create /home/user/dev/alpha_app/organization.log  
The file must be plain text, UTF-8, **comma-separated values with NO spaces**.  
The very first line is a header that must read exactly:  

    original_path,new_path,action,timestamp  

For every file that you physically moved (i.e., every file except LICENSE), append one data line.  
Field order:  
1. original_path – absolute path before the move  
2. new_path      – absolute path after the move  
3. action        – always the literal word “moved” (lower-case)  
4. timestamp     – always the literal string “STATIC” (all caps, without quotes)  

The seven data lines must appear in **alphabetical order by the basename of the moved file** (Dockerfile comes before app.py, etc.).  
Example (the paths here are just an illustration of the required CSV shape):

    original_path,new_path,action,timestamp
    /old/path/Dockerfile,/new/path/Dockerfile,moved,STATIC
    ...

**SUMMARY FILE**  
Create /home/user/dev/alpha_app/summary_statistics.txt (plain UTF-8 text).  
It must contain exactly five newline-terminated lines, spelled and capitalised exactly like this:

    Total files moved: 7
    Src files: 2
    Test files: 2
    Docs files: 1
    Build files: 2

**VERIFICATION HINTS**  
• The automated tests will first check that the directory tree and file placements match the TARGET STRUCTURE.  
• They will then read organization.log and validate: correct header, seven lines, alphabetical order by filename, correct literal “STATIC” timestamps, and that original_path/new_path values reflect the real move operations that occurred.  
• Finally, they will read summary_statistics.txt to ensure the five lines contain the exact numbers shown above.