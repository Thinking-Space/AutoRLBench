# test_final_state.py
#
# This test-suite validates the *end* state of the operating-system / container
# after the learner has completed the “alpha_app” clean-up and migration task.
#
# It must be executed *after* the learner’s orchestration script / manual steps
# have supposedly finished.  Any failure pin-points exactly what is still wrong.
#
# The checks performed mirror the grading rubric:
#
#   1. Correct directory tree exists under /home/user/dev/alpha_app/
#   2. All eight files are present in their required locations
#   3. /home/user/downloads/alpha_assets/ is now empty (or gone)
#   4. organization.log exists and has the exact, canonical CSV contents
#   5. summary_statistics.txt exists and holds the required five lines
#
# No third-party libraries are used; only the Python stdlib and pytest.

import os
import stat
from pathlib import Path
from typing import List, Tuple

import pytest

# ---------------------------------------------------------------------------
# Constants describing the *expected* final state
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path("/home/user/dev/alpha_app")
DOWNLOADS_DIR = Path("/home/user/downloads/alpha_assets")

# Mapping sub-dir  -> set of expected file basenames therein
EXPECTED_TREE = {
    "1_src": {"app.py", "helpers.py"},
    "2_tests": {"test_app.py", "test_helpers.py"},
    "3_docs": {"overview.md"},
    "4_build": {"CHANGELOG.md", "Dockerfile"},
    ".": {"LICENSE", "organization.log", "summary_statistics.txt"},
}

# Expected organisation.log (order matters; trailing newline required)
EXPECTED_LOG_LINES: List[str] = [
    "original_path,new_path,action,timestamp",
    "/home/user/downloads/alpha_assets/CHANGELOG.md,"
    "/home/user/dev/alpha_app/4_build/CHANGELOG.md,moved,STATIC",
    "/home/user/downloads/alpha_assets/Dockerfile,"
    "/home/user/dev/alpha_app/4_build/Dockerfile,moved,STATIC",
    "/home/user/downloads/alpha_assets/app.py,"
    "/home/user/dev/alpha_app/1_src/app.py,moved,STATIC",
    "/home/user/downloads/alpha_assets/helpers.py,"
    "/home/user/dev/alpha_app/1_src/helpers.py,moved,STATIC",
    "/home/user/downloads/alpha_assets/overview.md,"
    "/home/user/dev/alpha_app/3_docs/overview.md,moved,STATIC",
    "/home/user/downloads/alpha_assets/test_app.py,"
    "/home/user/dev/alpha_app/2_tests/test_app.py,moved,STATIC",
    "/home/user/downloads/alpha_assets/test_helpers.py,"
    "/home/user/dev/alpha_app/2_tests/test_helpers.py,moved,STATIC",
]

EXPECTED_SUMMARY_LINES = [
    "Total files moved: 7",
    "Src files: 2",
    "Test files: 2",
    "Docs files: 1",
    "Build files: 2",
]

# Helper paths
LOG_PATH = PROJECT_ROOT / "organization.log"
SUMMARY_PATH = PROJECT_ROOT / "summary_statistics.txt"

# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------


def _assert_is_regular_file(path: Path):
    assert path.exists(), f"Expected file {path} is missing."
    st_mode = path.stat().st_mode
    assert stat.S_ISREG(st_mode), f"{path} exists but is not a regular file."
    assert not path.is_symlink(), f"{path} must be a regular file, not a symlink."


def _dir_listing_without_dotfiles(directory: Path):
    """Return the set of entry names present in *directory* excluding hidden ones."""
    return {entry.name for entry in directory.iterdir() if not entry.name.startswith(".")}


def _read_text_lines(path: Path) -> List[str]:
    """Return text file lines *without* retaining trailing newline characters."""
    content = path.read_text(encoding="utf-8")
    # Preserve evidence of final newline
    assert content.endswith(
        "\n"
    ), f"{path} must end with a newline character (required by spec)."
    # rstrip final newline before splitting to avoid empty element
    return content.rstrip("\n").split("\n")


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_project_root_exists_and_is_directory():
    assert PROJECT_ROOT.exists(), f"{PROJECT_ROOT} does not exist."
    assert PROJECT_ROOT.is_dir(), f"{PROJECT_ROOT} exists but is not a directory."


@pytest.mark.parametrize("subdir", ["1_src", "2_tests", "3_docs", "4_build"])
def test_required_subdirectories_exist(subdir):
    p = PROJECT_ROOT / subdir
    assert p.exists(), f"Required subdirectory {p} is missing."
    assert p.is_dir(), f"{p} exists but is not a directory."
    assert not p.is_symlink(), f"{p} must be a real directory, not a symlink."


def test_expected_files_exist_in_correct_locations():
    for subdir, files in EXPECTED_TREE.items():
        base_dir = PROJECT_ROOT if subdir == "." else PROJECT_ROOT / subdir
        for filename in files:
            _assert_is_regular_file(base_dir / filename)


def test_no_unexpected_regular_files_in_subdirectories():
    """
    Ensure that each numbered sub-directory contains *exactly* the expected files
    (dot-files are ignored).  Extra stray files would indicate an incorrect move.
    The project root itself may legitimately contain tooling artefacts we don’t
    control, so we restrict this check to the numbered folders only.
    """
    for subdir, expected_files in EXPECTED_TREE.items():
        if subdir == ".":
            continue  # skip project root
        dir_path = PROJECT_ROOT / subdir
        actual_files = _dir_listing_without_dotfiles(dir_path)
        assert actual_files == expected_files, (
            f"Contents of {dir_path} do not match expected set.\n"
            f"Expected: {sorted(expected_files)}\n"
            f"Actual  : {sorted(actual_files)}"
        )


def test_downloads_dir_is_empty_or_removed():
    if DOWNLOADS_DIR.exists():
        assert DOWNLOADS_DIR.is_dir(), (
            f"{DOWNLOADS_DIR} still exists but is not a directory."
        )
        leftover = _dir_listing_without_dotfiles(DOWNLOADS_DIR)
        assert (
            not leftover
        ), f"{DOWNLOADS_DIR} should be empty after migration but contains: {sorted(leftover)}"
    else:
        # Directory fully removed is acceptable
        assert not DOWNLOADS_DIR.exists(), (
            f"{DOWNLOADS_DIR} should either be empty or removed."
        )


# ---------------------------------------------------------------------------
# organization.log validation
# ---------------------------------------------------------------------------

def test_organization_log_exists_and_is_regular_file():
    _assert_is_regular_file(LOG_PATH)


def test_organization_log_contents_exact_match():
    lines = _read_text_lines(LOG_PATH)
    assert (
        lines == EXPECTED_LOG_LINES
    ), "organization.log content does not match the required canonical CSV.\n" \
       "Differences detected:\n" \
       f"Expected:\n{os.linesep.join(EXPECTED_LOG_LINES)}\n" \
       f"Actual:\n{os.linesep.join(lines)}"


def test_organization_log_has_no_spaces():
    with LOG_PATH.open(encoding="utf-8") as fp:
        for idx, line in enumerate(fp, start=1):
            assert " " not in line, (
                f"organization.log line {idx} contains spaces; "
                "CSV must be comma-separated with **no spaces**."
            )


# ---------------------------------------------------------------------------
# summary_statistics.txt validation
# ---------------------------------------------------------------------------

def test_summary_statistics_exists_and_is_regular_file():
    _assert_is_regular_file(SUMMARY_PATH)


def test_summary_statistics_contents_exact_match():
    lines = _read_text_lines(SUMMARY_PATH)
    assert (
        lines == EXPECTED_SUMMARY_LINES
    ), "summary_statistics.txt content is incorrect.\n" \
       f"Expected lines:\n{os.linesep.join(EXPECTED_SUMMARY_LINES)}\n" \
       f"Actual lines:\n{os.linesep.join(lines)}"