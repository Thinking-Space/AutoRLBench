# test_final_state.py
#
# Pytest suite that validates the **FINAL** state of the filesystem
# after the migration task is completed.
#
# It asserts the presence of the new directories, the correct
# symbolic links, and the exact contents of the log file.
#
# If any test fails, the assertion messages are written so the
# student immediately knows **what is still wrong**.

import os
from pathlib import Path

# ---------
# Constants
# ---------
API_TARGET: Path = Path("/home/user/services/api")
WEB_TARGET: Path = Path("/home/user/services/web")

RELEASE_DIR: Path = Path("/home/user/current_release")
MIGRATION_LOGS_DIR: Path = Path("/home/user/migration_logs")

API_LINK: Path = RELEASE_DIR / "api"
WEB_LINK: Path = RELEASE_DIR / "web"

LOG_FILE: Path = MIGRATION_LOGS_DIR / "symlink_report.log"

# Expected log file content (exact, including trailing newline)
EXPECTED_LOG_CONTENT: str = (
    "/home/user/current_release/api -> /home/user/services/api : linked\n"
    "/home/user/current_release/web -> /home/user/services/web : linked\n"
)


# ---------------
# Helper methods
# ---------------
def _assert_real_directory(path: Path):
    """
    Assert that a path exists and is a real directory (not a symlink).
    """
    assert path.exists(), f"Directory '{path}' is missing."
    assert path.is_dir(), f"'{path}' exists but is not a directory."
    assert not path.is_symlink(), f"'{path}' should be a real directory, not a symlink."


def _assert_symlink(link_path: Path, expected_target: Path):
    """
    Assert that link_path is a symlink pointing exactly to expected_target.
    """
    assert link_path.exists(), f"Symlink '{link_path}' is missing."
    assert link_path.is_symlink(), f"'{link_path}' exists but is not a symbolic link."

    # os.readlink gives the raw link target as stored (may be relative or absolute)
    raw_target = Path(os.readlink(link_path)).expanduser()

    # For user feedback we want to show both
    assert raw_target == expected_target, (
        f"Symlink '{link_path}' points to '{raw_target}', "
        f"but it should point to '{expected_target}'."
    )

    # Double-check the resolved path for completeness
    resolved = link_path.resolve(strict=True)
    assert resolved == expected_target, (
        f"Symlink '{link_path}' resolves to '{resolved}', "
        f"but expected to resolve to '{expected_target}'."
    )


def _assert_file_contents_exact(path: Path, expected_text: str):
    """
    Assert that a regular file exists and its contents match expected_text exactly.
    """
    assert path.exists(), f"Log file '{path}' is missing."
    assert path.is_file(), f"'{path}' exists but is not a regular file."

    with path.open("r", encoding="utf-8") as fh:
        contents = fh.read()

    assert contents == expected_text, (
        "Log file contents are incorrect.\n"
        "----- Expected -----\n"
        f"{expected_text!r}\n"
        "------ Got ---------\n"
        f"{contents!r}\n"
        "--------------------"
    )


# --------------
# Actual tests
# --------------
def test_release_directory_exists():
    """
    The new parent directory /home/user/current_release must exist
    and be a real directory.
    """
    _assert_real_directory(RELEASE_DIR)


def test_migration_logs_directory_exists():
    """
    The migration log directory /home/user/migration_logs must exist
    and be a real directory.
    """
    _assert_real_directory(MIGRATION_LOGS_DIR)


def test_api_symlink():
    """
    Verify /home/user/current_release/api is a symlink
    pointing to /home/user/services/api.
    """
    _assert_symlink(API_LINK, API_TARGET)


def test_web_symlink():
    """
    Verify /home/user/current_release/web is a symlink
    pointing to /home/user/services/web.
    """
    _assert_symlink(WEB_LINK, WEB_TARGET)


def test_log_file_contents():
    """
    Validate that the log file exists and its contents are **exactly**
    the two required lines with a trailing newline on the second line.
    """
    _assert_file_contents_exact(LOG_FILE, EXPECTED_LOG_CONTENT)