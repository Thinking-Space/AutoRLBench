You are helping a cloud-migration architect rationalise the legacy folder layout of a small web stack.
The legacy code lives in two **real directories** that already exist on disk:

    1. /home/user/services/api
    2. /home/user/services/web

### Goal

1.  Create a new parent directory called /home/user/current_release
    (create it if it does not yet exist).
2.  Inside /home/user/current_release create **symbolic links** named `api` and `web` that point to the real directories listed above.
3.  Generate one plain-text log file recording the success of the operation.

### Exact log file specification

*   Full path of the log file: `/home/user/migration_logs/symlink_report.log`
*   One line **per** symbolic link, in the following exact format (including spaces and the word “linked” with a lowercase “l”):

        <LINK_PATH> -> <TARGET_PATH> : linked

    – No additional fields, timestamps, or blank lines.
    – Lines must appear in this exact order:

          /home/user/current_release/api -> /home/user/services/api : linked
          /home/user/current_release/web -> /home/user/services/web : linked

4.  Make sure the log file’s directory (`/home/user/migration_logs`) exists; create it if needed.
5.  When you are finished, you should be able to run the following command and obtain the **exact** output shown here (two lines, no trailing spaces):

        cat /home/user/migration_logs/symlink_report.log
        /home/user/current_release/api -> /home/user/services/api : linked
        /home/user/current_release/web -> /home/user/services/web : linked

### Constraints

*   You have normal user privileges (no sudo).
*   Do not remove or move the original `/home/user/services/*` directories; just create symlinks that reference them.

### Success criteria (checked automatically)

1.  `/home/user/current_release/api` is a symbolic link that resolves to `/home/user/services/api`
2.  `/home/user/current_release/web` is a symbolic link that resolves to `/home/user/services/web`
3.  `/home/user/migration_logs/symlink_report.log` exists and contains precisely the two lines shown above, with no extra whitespace or blank lines.