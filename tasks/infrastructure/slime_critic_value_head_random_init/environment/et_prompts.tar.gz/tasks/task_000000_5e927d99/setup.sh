#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    apt-get install -y --no-install-recommends python3 python3-pip && \
    true && \
    pip3 install --no-cache-dir pytest

mkdir -p /home/user/logs && \
    chmod 0777 /home/user

cat > /home/user/logs/service-auth.log <<'EOF'
[2024-06-01 10:00:00] INFO User login successful
[2024-06-01 10:01:00] ERROR Invalid credentials
[2024-06-01 10:02:00] INFO Token issued
[2024-06-01 10:03:00] ERROR Session expired
[2024-06-01 10:04:00] ERROR Invalid credentials
EOF

cat > /home/user/logs/service-payment.log <<'EOF'
[2024-06-01 10:05:00] INFO Payment initiated
[2024-06-01 10:06:00] ERROR Card declined
[2024-06-01 10:07:00] ERROR Timeout contacting bank
[2024-06-01 10:08:00] INFO Payment retried
[2024-06-01 10:09:00] ERROR Card declined
EOF

cat > /home/user/logs/service-order.log <<'EOF'
[2024-06-01 10:10:00] INFO Order placed
[2024-06-01 10:11:00] ERROR Inventory shortage
[2024-06-01 10:12:00] ERROR Inventory shortage
[2024-06-01 10:13:00] INFO Order cancelled
[2024-06-01 10:14:00] ERROR Payment pending
EOF

chmod 0644 /home/user/logs/service-*.log

chmod 755 /home/user

export PYTHONUNBUFFERED=1
