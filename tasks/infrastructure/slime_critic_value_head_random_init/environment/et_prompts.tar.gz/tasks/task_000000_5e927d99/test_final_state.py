# test_final_state.py
#
# Pytest suite that validates the **FINAL** state of the filesystem after the
# student has completed the assignment.  The checks are performed against the
# authoritative “truth” data embedded in this test file.
#
# If any assertion fails the student has not met (part of) the specification.
#
# Only stdlib + pytest are used.

import csv
import json
import os
import re
from pathlib import Path
from textwrap import dedent

import pytest

# --------------------------------------------------------------------------- #
# Generic paths used throughout the tests
# --------------------------------------------------------------------------- #
LOG_DIR = Path("/home/user/logs")
OUT_DIR = Path("/home/user/output")
CSV_FILE = OUT_DIR / "error_summary.csv"
JSON_FILE = OUT_DIR / "top_errors.json"
PROC_FILE = OUT_DIR / "process.log"

# --------------------------------------------------------------------------- #
# Truth-data: the initial log files that *must* still be present and unchanged
# --------------------------------------------------------------------------- #
TRUTH_LOG_CONTENTS = {
    "service-auth.log": [
        "[2024-06-01 10:00:00] INFO User login successful",
        "[2024-06-01 10:01:00] ERROR Invalid credentials",
        "[2024-06-01 10:02:00] INFO Token issued",
        "[2024-06-01 10:03:00] ERROR Session expired",
        "[2024-06-01 10:04:00] ERROR Invalid credentials",
    ],
    "service-payment.log": [
        "[2024-06-01 10:05:00] INFO Payment initiated",
        "[2024-06-01 10:06:00] ERROR Card declined",
        "[2024-06-01 10:07:00] ERROR Timeout contacting bank",
        "[2024-06-01 10:08:00] INFO Payment retried",
        "[2024-06-01 10:09:00] ERROR Card declined",
    ],
    "service-order.log": [
        "[2024-06-01 10:10:00] INFO Order placed",
        "[2024-06-01 10:11:00] ERROR Inventory shortage",
        "[2024-06-01 10:12:00] ERROR Inventory shortage",
        "[2024-06-01 10:13:00] INFO Order cancelled",
        "[2024-06-01 10:14:00] ERROR Payment pending",
    ],
}

# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def read_lines(path: Path):
    """Return *all* lines without trailing LF."""
    with path.open(encoding="utf-8") as fp:
        return [l.rstrip("\n") for l in fp.readlines()]


def calc_expected_csv_and_json():
    """
    Derive the *exact* expected CSV and JSON strings (including final LF)
    directly from the truth-data above.  This guarantees the grader and the
    reference are always in sync.
    """
    # Per-service stats -------------------------------------------------------
    rows = []
    for fname in sorted(TRUTH_LOG_CONTENTS):
        service = fname.split("service-")[1].split(".log")[0]
        lines = TRUTH_LOG_CONTENTS[fname]
        total = len(lines)
        errors = sum(" ERROR " in ln for ln in lines)
        pct = f"{(errors / total) * 100:.2f}"
        rows.append([service, str(total), str(errors), pct])

    csv_lines = ["service_name,total_lines,error_lines,error_percentage"]
    csv_lines.extend(",".join(r) for r in rows)
    csv_data = "\n".join(csv_lines) + "\n"

    # Global error aggregation -----------------------------------------------
    error_counts = {}
    for lines in TRUTH_LOG_CONTENTS.values():
        for ln in lines:
            if " ERROR " in ln:
                # msg is everything after the first space following ERROR
                _, msg = ln.split(" ERROR ", 1)
                error_counts[msg] = error_counts.get(msg, 0) + 1

    # Top-3 based on rules
    top = sorted(
        error_counts.items(),
        key=lambda kv: (-kv[1], kv[0])
    )[:3]

    json_obj = [
        {"message": msg, "count": cnt}
        for msg, cnt in top
    ]

    # Pretty-print with *exact* formatting (2-space indent, one space after
    # colon / comma between fields, etc.)
    json_lines = ["["]
    for idx, item in enumerate(json_obj):
        comma = "," if idx < len(json_obj) - 1 else ""
        json_lines.append(
            f'  {{ "message": "{item["message"]}", "count": {item["count"]} }}{comma}'
        )
    json_lines.append("]")
    json_data = "\n".join(json_lines) + "\n"

    return csv_data, json_data


EXPECTED_CSV, EXPECTED_JSON = calc_expected_csv_and_json()

# --------------------------------------------------------------------------- #
# Tests for the *output* directory and artefacts
# --------------------------------------------------------------------------- #
def test_output_directory_exists_and_contains_only_expected_files():
    assert OUT_DIR.exists(), "Directory /home/user/output/ is missing."
    assert OUT_DIR.is_dir(), "/home/user/output/ exists but is not a directory."

    expected_files = {CSV_FILE.name, JSON_FILE.name, PROC_FILE.name}
    actual_files = {p.name for p in OUT_DIR.iterdir() if p.is_file()}

    extra = actual_files - expected_files
    missing = expected_files - actual_files

    assert not missing, (
        f"The following required file(s) are missing from {OUT_DIR}: {', '.join(sorted(missing))}"
    )
    assert not extra, (
        f"Unexpected file(s) found in {OUT_DIR}: {', '.join(sorted(extra))}. "
        "Only error_summary.csv, top_errors.json and process.log are allowed."
    )


def _assert_single_trailing_lf(path: Path, contents: str):
    assert contents.endswith("\n"), f"{path}: file must end with a single LF newline."
    assert not contents.endswith("\n\n"), (
        f"{path}: file must end with *exactly one* newline, "
        "but two consecutive LFs were found at the end."
    )


def test_error_summary_csv_exact_content():
    assert CSV_FILE.exists(), f"Expected file {CSV_FILE} is missing."
    data = CSV_FILE.read_text(encoding="utf-8")
    _assert_single_trailing_lf(CSV_FILE, data)

    if data != EXPECTED_CSV:
        # Produce a compact diff for easier debugging
        expected_lines = EXPECTED_CSV.splitlines(keepends=False)
        actual_lines = data.splitlines(keepends=False)

        diff = ["CSV content mismatch:"]
        max_len = max(len(expected_lines), len(actual_lines))
        for idx in range(max_len):
            exp = expected_lines[idx] if idx < len(expected_lines) else "<no line>"
            act = actual_lines[idx] if idx < len(actual_lines) else "<no line>"
            mark = "✔" if exp == act else "✖"
            diff.append(f"{idx:02d} {mark} expected: {exp!r} | actual: {act!r}")
        pytest.fail("\n".join(diff))


def test_top_errors_json_exact_content():
    assert JSON_FILE.exists(), f"Expected file {JSON_FILE} is missing."
    data = JSON_FILE.read_text(encoding="utf-8")
    _assert_single_trailing_lf(JSON_FILE, data)

    assert (
        data == EXPECTED_JSON
    ), dedent(
        f"""
        {JSON_FILE} content does not match the expected output.

        --- Expected ---
        {EXPECTED_JSON}
        --- Actual ---
        {data}
        """
    )


# --------------------------------------------------------------------------- #
# process.log verification
# --------------------------------------------------------------------------- #
LINE_RE = re.compile(
    r"^"
    r"service=(?P<service>[a-z]+) "
    r"pid=(?P<pid>[1-9]\d*) "
    r"start=(?P<start>[1-9]\d*) "
    r"end=(?P<end>[1-9]\d*) "
    r"duration_ms=(?P<dur>[1-9]\d*)"
    r"$"
)


def test_process_log_structure_and_values():
    assert PROC_FILE.exists(), f"Expected file {PROC_FILE} is missing."

    raw = PROC_FILE.read_bytes()
    assert raw.endswith(b"\n"), f"{PROC_FILE} must end with a single LF newline."
    assert not raw.endswith(b"\n\n"), f"{PROC_FILE} must end with exactly one trailing LF."

    lines = raw.decode("utf-8").rstrip("\n").split("\n")
    assert len(lines) == 3, (
        f"{PROC_FILE} must contain exactly 3 lines (one per input log file). "
        f"Found {len(lines)} line(s)."
    )

    seen_services = set()
    seen_pids = set()

    for idx, line in enumerate(lines, 1):
        m = LINE_RE.match(line)
        assert m, f"{PROC_FILE}, line {idx}: malformed format -> {line!r}"

        service = m.group("service")
        pid = int(m.group("pid"))
        start = int(m.group("start"))
        end = int(m.group("end"))
        dur = int(m.group("dur"))

        # Service checks ------------------------------------------------------
        assert service in {"auth", "order", "payment"}, (
            f"{PROC_FILE}, line {idx}: unknown service '{service}'."
        )
        assert service not in seen_services, (
            f"{PROC_FILE}: duplicate entry for service '{service}'."
        )
        seen_services.add(service)

        # PID checks ----------------------------------------------------------
        assert pid > 0, f"{PROC_FILE}, line {idx}: PID must be > 0."
        assert pid not in seen_pids, (
            f"{PROC_FILE}: PID {pid} appears more than once."
        )
        seen_pids.add(pid)

        # Timing checks -------------------------------------------------------
        assert start < end, (
            f"{PROC_FILE}, line {idx}: start ({start}) must be < end ({end})."
        )
        assert (end - start) == dur, (
            f"{PROC_FILE}, line {idx}: duration_ms ({dur}) does not equal end-start "
            f"({end-start})."
        )

    # All three services present?
    missing = {"auth", "order", "payment"} - seen_services
    assert not missing, f"{PROC_FILE}: missing log lines for service(s): {', '.join(missing)}"