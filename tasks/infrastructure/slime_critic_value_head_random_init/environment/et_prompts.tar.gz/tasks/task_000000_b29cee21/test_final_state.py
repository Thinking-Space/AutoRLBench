# test_final_state.py
"""
Pytest suite that validates the REQUIRED **final** operating-system /
filesystem state for the outbound-sync exercise, *after* the student
has completed all tasks.

If any of these tests fail, the student’s solution did *not* satisfy
one or more of the stated requirements.

The checks performed are taken directly from the “verification” block
in the exercise instructions:

1. /home/user/workspace/sync-exclude.txt
   • must exist and contain exactly two lines:
         Line-1: *.tmp
         Line-2: secrets.yaml

2. /home/user/remote_host/project_backup/
   • must contain the four expected files (and utils/ dir)
   • must *not* contain any “*.tmp” file nor any “secrets.yaml”
   • must not contain any *additional* files beyond the expected set

3. /home/user/sync_reports/initial_sync.log
   • must exist
   • line-1: “SYNC REPORT - <ISO-8601-UTC-timestamp>”
   • line-2: blank
   • line-3 starts with “Number of files:”
   • last line contains the string “speedup is”
"""

from __future__ import annotations

import re
import os
from pathlib import Path
from datetime import datetime

import pytest

# --------------------------------------------------------------------------- #
# CONSTANTS – full, absolute paths as required by the grading rules
# --------------------------------------------------------------------------- #
HOME = Path("/home/user")

WORKSPACE_DIR      = HOME / "workspace"
PROJECT_DIR        = WORKSPACE_DIR / "project"
EXCLUDE_FILE       = WORKSPACE_DIR / "sync-exclude.txt"

REMOTE_ROOT        = HOME / "remote_host"
REMOTE_BACKUP_DIR  = REMOTE_ROOT / "project_backup"

REPORTS_DIR        = HOME / "sync_reports"
SYNC_LOG_FILE      = REPORTS_DIR / "initial_sync.log"

# Expected files relative to REMOTE_BACKUP_DIR
EXPECTED_REMOTE_FILES = {
    "app.py",
    "config.yaml",
    "README.md",
    "utils/helper.py",
}

# --------------------------------------------------------------------------- #
# HELPER ASSERTIONS
# --------------------------------------------------------------------------- #
def _assert_path_exists(path: Path, is_dir: bool | None = None) -> None:
    """
    Assert that *path* exists.  If *is_dir* is True, the path must be a
    directory; if False, it must be a regular file; if None, type is ignored.
    """
    assert path.exists(), f"Expected '{path}' to exist."
    if is_dir is True:
        assert path.is_dir(), f"Expected '{path}' to be a directory."
    elif is_dir is False:
        assert path.is_file(), f"Expected '{path}' to be a regular file."


# --------------------------------------------------------------------------- #
# TESTS
# --------------------------------------------------------------------------- #
def test_exclude_file_contents():
    """
    The exclude file must exist and contain exactly the two required lines,
    with no extra whitespace or blank lines.
    """
    _assert_path_exists(EXCLUDE_FILE, is_dir=False)

    # Read file *as-is* (strip only trailing newline characters to avoid
    # platform-specific line endings interfering with the comparison).
    with EXCLUDE_FILE.open("r", encoding="utf-8") as fh:
        lines = [ln.rstrip("\n") for ln in fh.readlines()]

    assert lines == ["*.tmp", "secrets.yaml"], (
        f"'{EXCLUDE_FILE}' must contain exactly two lines:\n"
        "Line-1: '*.tmp'\n"
        "Line-2: 'secrets.yaml'\n"
        f"Current contents: {lines!r}"
    )


def test_remote_backup_expected_files_exist():
    """
    All required files (and utils/ sub-directory) must be present in the backup.
    """
    _assert_path_exists(REMOTE_BACKUP_DIR, is_dir=True)

    # utils directory
    utils_dir = REMOTE_BACKUP_DIR / "utils"
    _assert_path_exists(utils_dir, is_dir=True)

    # Individual files
    for rel_path in EXPECTED_REMOTE_FILES:
        _assert_path_exists(REMOTE_BACKUP_DIR / rel_path, is_dir=False)


def test_remote_backup_no_tmp_or_secrets():
    """
    The backup directory must not contain any *.tmp files or secrets.yaml
    anywhere within its tree.
    """
    tmp_files     = list(REMOTE_BACKUP_DIR.rglob("*.tmp"))
    secrets_files = list(REMOTE_BACKUP_DIR.rglob("secrets.yaml"))

    assert not tmp_files, (
        "The backup directory must not contain any '*.tmp' files. "
        f"Found: {', '.join(str(p) for p in tmp_files)}"
    )
    assert not secrets_files, (
        "The backup directory must not contain any 'secrets.yaml' files. "
        f"Found: {', '.join(str(p) for p in secrets_files)}"
    )


def test_remote_backup_no_unexpected_files():
    """
    After excluded files are removed, the backup should contain *exactly*
    the expected set of regular files (directories are allowed so long as they
    contain no additional regular files).
    """
    actual_files: set[str] = {
        p.relative_to(REMOTE_BACKUP_DIR).as_posix()
        for p in REMOTE_BACKUP_DIR.rglob("*")
        if p.is_file()
    }

    assert actual_files == EXPECTED_REMOTE_FILES, (
        "Unexpected file set in remote backup directory.\n"
        f"Expected: {sorted(EXPECTED_REMOTE_FILES)}\n"
        f"Actual:   {sorted(actual_files)}"
    )


def test_sync_log_file_structure_and_contents():
    """
    Validate that the synchronisation log exists and follows the required
    formatting rules.
    """
    _assert_path_exists(SYNC_LOG_FILE, is_dir=False)

    with SYNC_LOG_FILE.open("r", encoding="utf-8") as fh:
        # Strip only trailing '\n'; keep other whitespace for exactness.
        lines = [ln.rstrip("\n") for ln in fh.readlines()]

    assert len(lines) >= 4, (
        f"Synchronisation log should contain at least 4 lines "
        f"(found {len(lines)} line(s))."
    )

    # --- Line 1: "SYNC REPORT - <ISO-8601>"
    line_1 = lines[0]
    prefix = "SYNC REPORT - "
    assert line_1.startswith(prefix), (
        "First line of sync log must start with 'SYNC REPORT - '. "
        f"Found: {line_1!r}"
    )
    timestamp_str = line_1[len(prefix):]

    # Validate ISO-8601 UTC timestamp YYYY-MM-DDTHH:MM:SSZ
    iso_regex = r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$"
    assert re.fullmatch(iso_regex, timestamp_str), (
        "Timestamp in first line is not in required ISO-8601 UTC format "
        "'YYYY-MM-DDTHH:MM:SSZ'. "
        f"Found: {timestamp_str!r}"
    )

    # Parse to ensure it is a valid date/time
    try:
        datetime.strptime(timestamp_str, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError as exc:
        pytest.fail(f"Timestamp '{timestamp_str}' is not a valid ISO-8601 UTC timestamp: {exc}")

    # --- Line 2: blank
    assert lines[1] == "", "Second line of sync log must be blank."

    # --- Line 3: starts with "Number of files:"
    assert lines[2].startswith("Number of files:"), (
        "Third line of sync log must start with 'Number of files:'. "
        f"Found: {lines[2]!r}"
    )

    # --- Last line: contains "speedup is"
    assert "speedup is" in lines[-1], (
        "Last line of sync log must contain the string 'speedup is'. "
        f"Found last line: {lines[-1]!r}"
    )

    # No extra content after the summary block (i.e., last line is the one
    # containing 'speedup is').  Ensures human-readability and adherence to
    # instructions.
    if len(lines) >= 2 and "speedup is" in lines[-2]:
        pytest.fail(
            "Log appears to contain extra blank line(s) or content after the "
            "rsync summary block; last valid line should contain 'speedup is'."
        )