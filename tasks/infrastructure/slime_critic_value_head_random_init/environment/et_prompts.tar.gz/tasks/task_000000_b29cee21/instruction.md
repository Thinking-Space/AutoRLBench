You are the DevSecOps engineer responsible for implementing “policy-as-code” for outbound
    file synchronisation.  
    The company rule is simple:
        1. Everything under /home/user/workspace/project/ must be copied to the
           staging server’s directory /home/user/remote_host/project_backup/
        2. BUT any “*.tmp” file and any file named “secrets.yaml” must be kept
           out of the backup.

    A skeleton project already exists on disk (see file list in the next
    paragraph).  Your job is to:
        • Create an rsync exclude list file called
          /home/user/workspace/sync-exclude.txt that encodes the above policy.
        • Run rsync to push the data to
          /home/user/remote_host/project_backup/ using that exclude list.  
          The options must guarantee that:
              – permissions, timestamps, and symlinks (if any) are preserved
                (i.e. archival mode)  
              – files deleted from the source are also deleted from the
                destination on subsequent runs (i.e. “--delete” behaviour)  
        • Store a human-readable synchronisation report in
          /home/user/sync_reports/initial_sync.log

    VERY IMPORTANT — automated tests will inspect the
    /home/user/sync_reports/initial_sync.log file and the contents of
    /home/user/remote_host/project_backup/ after you finish.
    The exact requirements that will be checked are:

    1. /home/user/workspace/sync-exclude.txt
       • Must exist.
       • Must contain exactly two non-empty lines:
             Line-1: *.tmp
             Line-2: secrets.yaml
       • No additional lines or whitespace.

    2. /home/user/remote_host/project_backup/  (after your rsync run)
       • MUST contain these regular files:
             app.py
             config.yaml
             README.md
             utils/helper.py      (inside an existing utils/ sub-directory)
       • MUST NOT contain any file whose name ends in “.tmp”.
       • MUST NOT contain any file named “secrets.yaml”.
       • Directory structure must mirror the source (so utils/ exists).

    3. /home/user/sync_reports/initial_sync.log
       • Must exist and be plain-text.
       • First line EXACTLY:  
             SYNC REPORT - &lt;ISO-8601-timestamp&gt;
         where &lt;ISO-8601-timestamp&gt; is in the form
             YYYY-MM-DDTHH:MM:SSZ  (UTC “Zulu” time).  
         Example:  SYNC REPORT - 2024-05-17T14:22:39Z
       • Second line is blank.
       • Starting from the third line, paste the **summary section** that
         rsync prints to stdout/stderr (the block of lines that begins with
         “Number of files:” and ends with “speedup is …”).  
         Do **not** alter those lines; the tester will only check that
         at least one of them begins with “Number of files:” and that every
         subsequent line is identical to rsync’s original output order.

    Remember: do NOT reveal any secret test data.  Work entirely in
    /home/user.  You do not have root access.