You are a capacity-planner who has just been given access to a a fresh Linux machine (your interactive shell starts in /home/user).
Set up a *very small* capacity-planning workspace and store one initial resource-usage snapshot so that it can be inspected later by an automated tool.

Required end-state of the system
--------------------------------
1.  A directory named “capacity_planning” must exist directly under /home/user
    *   Absolute path: /home/user/capacity_planning

2.  Inside that directory there must be one log file that captures the current CPU load, memory usage, and root-filesystem usage.
    *   Absolute path: /home/user/capacity_planning/snapshot_001.log

    The file must contain **exactly three section-header lines** (the automated grader will look for *those* literal marker lines, nothing else):
    ```
    === CPU_LOAD ===
    === MEMORY_USAGE ===
    === DISK_ROOT ===
    ```

    The command outputs should be placed **immediately after** their respective marker lines (one or more lines each), but the grader will only verify that the marker lines themselves are present and in that exact order.
    *   Under “CPU_LOAD” put the output of the shell command normally used to inspect load average.
    *   Under “MEMORY_USAGE” put the output of the shell command that reports memory usage in megabytes.
    *   Under “DISK_ROOT” put the output of the shell command that reports human-readable disk usage for “/”.

    Example of the exact skeleton that the grader will look for (the actual numeric values may differ):
    ```
    === CPU_LOAD ===
    20:33:10 up  3:00,  1 user,  load average: 0.05, 0.02, 0.00
    === MEMORY_USAGE ===
                   total        used        free      shared  buff/cache   available
    Mem:           3900         800         500          70        2600        2800
    Swap:             0           0           0
    === DISK_ROOT ===
    Filesystem     Type  Size  Used Avail Use% Mounted on
    /dev/sda1      ext4   30G  6.0G   22G  22% /
    ```

    The automated tests check only for:
    *   existence of /home/user/capacity_planning/snapshot_001.log
    *   presence of the three marker lines *in the above order*.
    The exact command output lines that follow each marker are **not** graded, so you do not have to worry about their runtime values.

3.  Still inside /home/user/capacity_planning, create a tiny status file so that a supervisor script can quickly confirm the snapshot was produced.
    *   Absolute path: /home/user/capacity_planning/verification.log
    *   The file must contain **one single line** (no extra spaces, no extra blank lines):
        `snapshot_001.log created`

Permissions & constraints
-------------------------
*   All files must be owned by the current unprivileged user (you do not have sudo).
*   The directory and both files must be readable by any user (mode 644 for files, 755 for the directory is sufficient).
*   Do not place the workspace anywhere outside /home/user.
*   Only standard GNU/Linux user-land tools found in a minimal distribution should be needed.

Deliverable summary for the grader
----------------------------------
After you are finished, the grader will verify:

1.  Directory exists: /home/user/capacity_planning
2.  Log file exists: /home/user/capacity_planning/snapshot_001.log
3.  Snapshot log includes, in order:
    *   line 1: === CPU_LOAD ===
    *   somewhere after: === MEMORY_USAGE ===
    *   somewhere after: === DISK_ROOT ===
4.  Verification file exists with *exact* content “snapshot_001.log created”.

Provide no additional output files or directories.