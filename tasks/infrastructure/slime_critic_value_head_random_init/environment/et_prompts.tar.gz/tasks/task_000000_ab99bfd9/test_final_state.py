# test_final_state.py
#
# This pytest suite validates the **end state** of the operating system
# after the student has completed the capacity-planning exercise.
#
# The tests check that:
#   1. The workspace directory exists in /home/user.
#   2. The snapshot file exists and contains the three required marker lines
#      in the correct order.
#   3. The verification file exists and contains exactly the expected text.
#   4. Directory and files are world-readable so another (automated) user can
#      inspect them.
#
# Only Python’s standard library and pytest are used.

import pathlib
import stat
import pytest

HOME = pathlib.Path("/home/user")
WS_DIR = HOME / "capacity_planning"
SNAPSHOT_FILE = WS_DIR / "snapshot_001.log"
VERIFICATION_FILE = WS_DIR / "verification.log"

# --------------------------------------------------------------------------- #
# Helper utilities
# --------------------------------------------------------------------------- #
def _assert_world_readable(path: pathlib.Path):
    """
    Assert that 'others' have at least read permission on the given path —
    this is the minimal requirement so automated tools can read the artefacts.
    """
    mode = path.stat().st_mode
    is_readable = bool(mode & stat.S_IROTH)
    assert is_readable, (
        f"{path} is not world-readable (permission bit 0o004 missing). "
        "It must be readable by any user."
    )

    # Directories additionally need the execute bit for traversal.
    if path.is_dir():
        is_executable = bool(mode & stat.S_IXOTH)
        assert is_executable, (
            f"{path} is a directory but lacks the world-executable bit (0o001). "
            "Without it, other users cannot traverse the directory."
        )


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #
def test_workspace_directory_exists_and_is_accessible():
    """
    The directory /home/user/capacity_planning must exist and be accessible.
    """
    assert WS_DIR.exists(), "Directory /home/user/capacity_planning is missing."
    assert WS_DIR.is_dir(), "/home/user/capacity_planning exists but is not a directory."
    _assert_world_readable(WS_DIR)


def test_snapshot_file_exists_and_is_readable():
    """
    The snapshot log file must exist and be world-readable.
    """
    assert SNAPSHOT_FILE.exists(), "Snapshot file snapshot_001.log is missing."
    assert SNAPSHOT_FILE.is_file(), "snapshot_001.log exists but is not a regular file."
    _assert_world_readable(SNAPSHOT_FILE)


def test_snapshot_file_contains_required_markers_in_order():
    """
    The snapshot log must contain the three required marker lines in the
    exact order:
        === CPU_LOAD ===
        === MEMORY_USAGE ===
        === DISK_ROOT ===
    The content between the markers is not graded.
    """
    required_markers = [
        "=== CPU_LOAD ===",
        "=== MEMORY_USAGE ===",
        "=== DISK_ROOT ===",
    ]

    with SNAPSHOT_FILE.open("r", encoding="utf-8", errors="replace") as fh:
        lines = [line.rstrip("\n") for line in fh]

    # Build a simple state machine that walks through markers in order.
    marker_idx = 0
    for line in lines:
        if line == required_markers[marker_idx]:
            marker_idx += 1
            if marker_idx == len(required_markers):
                break  # All markers seen in correct order.

    assert marker_idx == len(
        required_markers
    ), (
        "snapshot_001.log does not contain the required marker lines in the "
        "correct order. Expected order:\n"
        "  1. === CPU_LOAD ===\n"
        "  2. === MEMORY_USAGE ===\n"
        "  3. === DISK_ROOT ==="
    )


def test_verification_file_exists_and_has_correct_content():
    """
    The verification file must contain exactly one line:
        snapshot_001.log created
    No leading/trailing spaces or extra lines are allowed.
    """
    assert VERIFICATION_FILE.exists(), "verification.log file is missing."
    assert VERIFICATION_FILE.is_file(), "verification.log exists but is not a regular file."
    _assert_world_readable(VERIFICATION_FILE)

    with VERIFICATION_FILE.open("r", encoding="utf-8") as fh:
        lines = fh.read().splitlines()

    assert lines == ["snapshot_001.log created"], (
        "verification.log content is incorrect.\n"
        "Expected exactly:\n"
        "  snapshot_001.log created\n"
        f"Got:\n  {lines}"
    )