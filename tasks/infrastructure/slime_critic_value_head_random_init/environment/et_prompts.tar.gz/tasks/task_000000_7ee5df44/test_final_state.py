# test_final_state.py
#
# This pytest suite validates the **final** operating-system / filesystem
# state *after* the learner has completed the “legacy utility” task.
#
# The required post-task state is:
#   1. Directory  /home/user/logs                         exists.
#   2. File       /home/user/logs/greet_run.log           exists.
#   3. The log file contains EXACTLY two LF-terminated lines:
#        Line-1: greet.sh version 1.0
#        Line-2: Hello, LinuxLearner!
#      (No additional bytes, spaces or blank lines.)
#   4. No *other* files are present in /home/user/logs.
#   5. /home/user/legacy_utils/greet.sh is now executable by its owner.
#
# If any assertion fails, the error message will explain precisely what still
# needs to be fixed.

import os
import stat
import pytest

LEGACY_DIR = "/home/user/legacy_utils"
SCRIPT_PATH = os.path.join(LEGACY_DIR, "greet.sh")

LOG_DIR = "/home/user/logs"
LOG_FILE = os.path.join(LOG_DIR, "greet_run.log")

EXPECTED_LOG_BYTES = b"greet.sh version 1.0\nHello, LinuxLearner!\n"


# ---------------------------------------------------------------------------#
# Helper functions
# ---------------------------------------------------------------------------#
def _is_executable(path):
    """Return True if 'path' has the owner-executable bit set."""
    st_mode = os.stat(path).st_mode
    return bool(st_mode & stat.S_IXUSR)


# ---------------------------------------------------------------------------#
# Tests
# ---------------------------------------------------------------------------#
def test_logs_directory_exists():
    assert os.path.isdir(LOG_DIR), (
        f"Directory '{LOG_DIR}' is missing. It must be created by the solution."
    )


def test_only_expected_file_inside_logs_directory():
    entries = os.listdir(LOG_DIR)
    assert entries == ["greet_run.log"], (
        f"Directory '{LOG_DIR}' must contain *only* 'greet_run.log'. "
        f"Found: {entries!r}"
    )


def test_log_file_exists_and_is_regular_file():
    assert os.path.exists(LOG_FILE), (
        f"File '{LOG_FILE}' is missing."
    )
    assert os.path.isfile(LOG_FILE), (
        f"'{LOG_FILE}' exists but is not a regular file."
    )


def test_log_file_exact_content():
    # Read raw bytes to catch every newline or stray space.
    with open(LOG_FILE, "rb") as fh:
        data = fh.read()

    assert data == EXPECTED_LOG_BYTES, (
        "The content of '{LOG_FILE}' is incorrect.\n\n"
        "Expected (repr):\n"
        f"{EXPECTED_LOG_BYTES!r}\n\n"
        "Found (repr):\n"
        f"{data!r}"
    )

    # Additional sanity check: exactly two LF characters -> two lines.
    newline_count = data.count(b"\n")
    assert newline_count == 2, (
        f"'{LOG_FILE}' should contain exactly two newline characters "
        f"(one at the end of each line). Found {newline_count}."
    )


def test_greet_sh_is_now_executable():
    assert os.path.exists(SCRIPT_PATH), (
        f"Script '{SCRIPT_PATH}' has disappeared. It must still be present."
    )
    assert _is_executable(SCRIPT_PATH), (
        f"'{SCRIPT_PATH}' must be executable by its owner (chmod +x), "
        "but it is still non-executable."
    )