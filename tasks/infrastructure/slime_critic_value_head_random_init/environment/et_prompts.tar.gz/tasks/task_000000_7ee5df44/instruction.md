A script developer has left you a tiny “legacy utility” to test.
    1. Inside the directory “/home/user/legacy_utils” there is an old-school Bourne-again shell script named “greet.sh”.
    2. Your goal is to run the script once, passing the single argument “LinuxLearner”, and capture everything it prints into a new log file.

    Required end-state after you are finished:
      • A *new* directory “/home/user/logs” must exist.
      • A *new* file “/home/user/logs/greet_run.log” must exist.
      • The log file must contain **exactly two lines** and nothing else:
            Line-1:  greet.sh version 1.0
            Line-2:  Hello, LinuxLearner!
        (No extra whitespace before or after the lines; include the exclamation mark; use a single newline character after each line.)

    Hints and constraints:
      • You do not need root or sudo.
      • If the script is not yet executable, make it so.
      • The automated grader will strictly compare the content of “/home/user/logs/greet_run.log” against the two-line format shown above, so be precise.
      • Produce no other files in “/home/user/logs”.