# test_final_state.py
#
# Pytest suite that validates the *final* filesystem state
# *after* the student has completed the clean-up and analysis
# task described in the assignment.
#
# The checks below rely only on Python’s standard library and
# pytest.  They make no assumptions about the implementation
# used by the student – only the observable, final state of the
# container.  Every failure message pin-points exactly *what is
# still wrong* so the student knows what to fix.

import os
import re
import csv
from collections import Counter, defaultdict
import pytest

HOME = "/home/user"
PROJECT_DIR = os.path.join(HOME, "project")
LOG_DIR = os.path.join(PROJECT_DIR, "logs")
ARCHIVE_DIR = os.path.join(LOG_DIR, "archive")
SUMMARY_CSV = os.path.join(LOG_DIR, "summary_2024-05-10_to_2024-05-12.csv")
ACTION_LOG = os.path.join(LOG_DIR, "action.log")

# ---------------------------------------------------------------------------
# Hard facts from the specification / truth set
# ---------------------------------------------------------------------------

OLD_DATES = ["2024-05-08", "2024-05-09"]
CURRENT_DATES = ["2024-05-10", "2024-05-11", "2024-05-12"]

OLD_LOG_FILES = [f"app_{d}.log" for d in OLD_DATES]
CURRENT_LOG_FILES = [f"app_{d}.log" for d in CURRENT_DATES]

EXPECTED_ACTION_LOG = (
    "MOVED: app_2024-05-08.log => logs/archive/app_2024-05-08.log\n"
    "MOVED: app_2024-05-09.log => logs/archive/app_2024-05-09.log\n"
)

EXPECTED_CSV_HEADER = [
    "date",
    "total_lines",
    "info_count",
    "warn_count",
    "error_count",
]

LOG_LEVELS = ("INFO", "WARN", "ERROR")  # exact tokens, case-sensitive

# Regex to extract the YYYY-MM-DD component from a log filename.
LOG_RE = re.compile(r"^app_(\d{4}-\d{2}-\d{2})\.log\Z")


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def _listdir_abs(path):
    """Return *absolute* entry names (no '.', '..') for the directory."""
    return [entry for entry in os.listdir(path)]


def _compute_log_counts(path):
    """
    Parse a single *.log file and return:
        total_lines, info_count, warn_count, error_count
    following the exact counting rules of the specification.
    """
    totals = Counter()
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            # Count any *line*, including blank lines, towards total_lines
            totals["total_lines"] += 1

            # Only count log-level occurrences that start *exactly* with
            # the token – no leading whitespace allowed.
            for level in LOG_LEVELS:
                if line.startswith(level):
                    totals[level] += 1
                    break
    return (
        totals["total_lines"],
        totals["INFO"],
        totals["WARN"],
        totals["ERROR"],
    )


def _expected_csv_lines_from_current_logs():
    """
    Derive the *expected* CSV rows by scanning whatever log files still
    live in /home/user/project/logs after the student’s clean-up.
    This makes the test future-proof if source logs change.
    """
    rows = []
    grand_totals = defaultdict(int)

    for date in CURRENT_DATES:
        fname = f"app_{date}.log"
        path = os.path.join(LOG_DIR, fname)
        assert os.path.isfile(
            path
        ), f"Expected current log file {path} to still exist."

        total_lines, info, warn, error = _compute_log_counts(path)

        rows.append(
            [
                date,
                str(total_lines),
                str(info),
                str(warn),
                str(error),
            ]
        )

        grand_totals["total_lines"] += total_lines
        grand_totals["info"] += info
        grand_totals["warn"] += warn
        grand_totals["error"] += error

    # Add the aggregate TOTAL row
    rows.append(
        [
            "TOTAL",
            str(grand_totals["total_lines"]),
            str(grand_totals["info"]),
            str(grand_totals["warn"]),
            str(grand_totals["error"]),
        ]
    )

    return rows


def _read_csv_as_rows(path):
    """
    Read the CSV file verbatim and return list(rows_as_list_of_strings).
    Keeps the exact order without casting to int.
    """
    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.reader(fh)
        return list(reader)


# ---------------------------------------------------------------------------
# Actual tests
# ---------------------------------------------------------------------------

def test_archive_directory_exists():
    assert os.path.isdir(ARCHIVE_DIR), (
        f"Archive directory {ARCHIVE_DIR} does not exist."
    )


def test_old_files_are_in_archive_and_not_in_logs():
    """
    • old logs must have been moved into logs/archive/  
    • they must no longer be present directly under logs/
    """
    missing_in_archive = []
    still_in_logs = []

    for fname in OLD_LOG_FILES:
        if not os.path.isfile(os.path.join(ARCHIVE_DIR, fname)):
            missing_in_archive.append(fname)
        if os.path.exists(os.path.join(LOG_DIR, fname)):
            still_in_logs.append(fname)

    assert not missing_in_archive, (
        "The following old log files are NOT inside the archive directory "
        f"{ARCHIVE_DIR}: {missing_in_archive}"
    )
    assert not still_in_logs, (
        "The following old log files are still present directly in "
        f"{LOG_DIR} when they should have been moved: {still_in_logs}"
    )


def test_archive_contains_no_unexpected_files():
    """
    The archive directory should contain exactly the two old log files –
    nothing else.
    """
    entries = _listdir_abs(ARCHIVE_DIR)
    extra = sorted(set(entries) - set(OLD_LOG_FILES))
    missing = sorted(set(OLD_LOG_FILES) - set(entries))

    assert not missing and not extra, (
        f"Archive directory entries mismatch.\n"
        f"Missing: {missing}\n"
        f"Unexpected: {extra}"
    )


def test_summary_csv_exists():
    assert os.path.isfile(SUMMARY_CSV), (
        f"Expected summary CSV {SUMMARY_CSV} to exist."
    )


def test_summary_csv_content_is_correct():
    """
    Re-calculate the expected CSV rows and compare them to the student’s
    file.  This guarantees that even if the source logs change, the CSV
    must still reflect reality.
    """
    expected_rows = [EXPECTED_CSV_HEADER] + _expected_csv_lines_from_current_logs()
    actual_rows = _read_csv_as_rows(SUMMARY_CSV)

    assert expected_rows == actual_rows, (
        "CSV summary content does not match expectations.\n"
        f"--- expected\n{expected_rows}\n"
        f"---   actual\n{actual_rows}"
    )


def test_action_log_exists():
    assert os.path.isfile(ACTION_LOG), (
        f"Expected action log {ACTION_LOG} to exist."
    )


def test_action_log_content_exact():
    """
    The operational log must list the two move operations exactly
    as specified – one per line, in chronological order.
    """
    with open(ACTION_LOG, "r", encoding="utf-8") as fh:
        content = fh.read()

    # Accept files that either include or omit the very final newline
    # but otherwise must match *exactly*.
    if not content.endswith("\n"):
        content += "\n"

    expected = EXPECTED_ACTION_LOG
    assert content == expected, (
        "action.log content is incorrect.\n"
        f"--- expected\n{expected!r}\n"
        f"---   actual\n{content!r}"
    )


def test_no_unexpected_files_left_in_logs_dir():
    """
    After the clean-up the logs directory should contain exactly:
      • the three ‘current’ *.log files
      • summary_*.csv
      • action.log
      • archive/ (directory)
    Nothing else.
    """
    expected_entries = set(CURRENT_LOG_FILES + ["archive", "action.log", os.path.basename(SUMMARY_CSV)])
    actual_entries = set(_listdir_abs(LOG_DIR))

    extra = sorted(actual_entries - expected_entries)
    missing = sorted(expected_entries - actual_entries)

    assert not missing and not extra, (
        f"Unexpected directory contents in {LOG_DIR}.\n"
        f"Missing: {missing}\n"
        f"Unexpected: {extra}"
    )