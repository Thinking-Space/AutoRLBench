You are helping a developer tidy-up and analyse the project log files that live under 
  /home/user/project. Follow the exact specification below so an automated
  test can deterministically verify your work.

  STARTING SITUATION
  ------------------
  /home/user/project already exists and currently contains a sub-directory
  named “logs” with five application log files:

      /home/user/project/logs/app_2024-05-08.log
      /home/user/project/logs/app_2024-05-09.log
      /home/user/project/logs/app_2024-05-10.log
      /home/user/project/logs/app_2024-05-11.log
      /home/user/project/logs/app_2024-05-12.log

  The files dated 2024-05-08 and 2024-05-09 are considered “old”, everything
  from 2024-05-10 onward is considered “current”.

  WHAT YOU MUST DO
  ----------------
  - Create a new directory called
         /home/user/project/logs/archive
     if it does not already exist.

  - Move every file whose name matches the pattern
        app_YYYY-MM-DD.log
     where the date is strictly **earlier than 2024-05-10**
     into that new archive directory.  
     (For the supplied data this means the files
     app_2024-05-08.log and app_2024-05-09.log.)

  - Parse every remaining *.log file that is still in
        /home/user/project/logs/
     (that will be the 2024-05-10, 2024-05-11 and 2024-05-12 files)
     and produce a CSV summary that counts log-level occurrences.

     - Only count lines that start, **without leading whitespace**, with one
         of the exact, case-sensitive tokens:
             INFO
             WARN
             ERROR

     - For each file gather:
           • total number of lines in the file  
           • number of lines starting with INFO  
           • number of lines starting with WARN  
           • number of lines starting with ERROR  

     - Write the results, plus a final aggregate row, to a file named
          /home/user/project/logs/summary_2024-05-10_to_2024-05-12.csv

         The CSV **must use exactly** the following header and column order,
         separated by literal commas “,” with *no* extra spaces:

             date,total_lines,info_count,warn_count,error_count

         After the header create one data row per analysed log file in
         chronological (ascending date) order, followed by a final row whose
         first field is the literal string TOTAL containing the grand totals.

         Example layout (values are examples; your script must derive them):

             date,total_lines,info_count,warn_count,error_count
             2024-05-10,5,3,1,1
             2024-05-11,7,3,2,2
             2024-05-12,2,2,0,0
             TOTAL,14,8,3,3

  - **Operational log**  
     For transparency, create a plain-text file
        /home/user/project/logs/action.log
     that lists every file you physically moved to the archive directory.  
     Use one line per move, in the exact format:

         MOVED: <original-filename> => logs/archive/<original-filename>

     where <original-filename> is just the base name (e.g. app_2024-05-08.log).

  SUCCESS CRITERIA
  ----------------
  • Directory /home/user/project/logs/archive exists.  
  • The two “old” log files now live in that archive directory and are no
    longer present in /home/user/project/logs.  
  • /home/user/project/logs/summary_2024-05-10_to_2024-05-12.csv exists and
    exactly follows the header, ordering and counting rules above.  
  • /home/user/project/logs/action.log exists and correctly lists the two moves,
    one per line, in the format specified.  

  Do NOT hard-code the answer; derive the counts from the current files so the
  solution would still work if the source logs changed.