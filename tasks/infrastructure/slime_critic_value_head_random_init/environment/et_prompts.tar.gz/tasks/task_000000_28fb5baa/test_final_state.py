# test_final_state.py
#
# This pytest suite validates the **FINAL** state of the filesystem
# after the student has completed the task.  It asserts that the
# reports directory and the required artefacts exist and have the
# exact expected content.
#
# NOTE:  These tests purposefully use absolute paths only.  Do not
#        convert them to relative paths or otherwise modify them.

import re
from pathlib import Path

import pytest

REPORTS_DIR = Path("/home/user/project/reports")
ERROR_SUMMARY = REPORTS_DIR / "error_summary.txt"
ACTIONS_LOG = REPORTS_DIR / "actions.log"

# The exact content that **must** be present in error_summary.txt,
# including the single trailing newline.
EXPECTED_ERROR_SUMMARY_CONTENT = (
    "1: 2023-08-01 10:15:22 ERROR Could not connect to database\n"
    "2: 2023-08-01 10:15:30 ERROR Connection timeout\n"
)

# Regex that checks the presence of both “ERROR” and “app.log”
# on the same line, in any order.
ACTIONS_LOG_REQUIRED_REGEX = re.compile(r"ERROR.*app\.log|app\.log.*ERROR")


def test_reports_directory_exists_and_is_directory():
    """
    The directory /home/user/project/reports must exist and be a directory.
    """
    assert REPORTS_DIR.exists(), (
        f"The required directory {REPORTS_DIR} is missing. "
        "Create it and place your report files inside it."
    )
    assert REPORTS_DIR.is_dir(), (
        f"{REPORTS_DIR} exists but is not a directory. "
        "It must be a directory containing the report artefacts."
    )


def test_error_summary_exists_and_content_is_exact():
    """
    error_summary.txt must exist and match the expected content exactly,
    including newline characters and numbering.  Any deviation—extra/missing
    spaces, wrong numbering, missing trailing newline, etc.—must fail.
    """
    # --- Existence checks -------------------------------------------------
    assert ERROR_SUMMARY.exists(), (
        f"The file {ERROR_SUMMARY} is missing. "
        "Generate it by extracting ERROR lines from app.log."
    )
    assert ERROR_SUMMARY.is_file(), (
        f"{ERROR_SUMMARY} exists but is not a regular file."
    )

    # --- Content checks ---------------------------------------------------
    actual_content = ERROR_SUMMARY.read_text(encoding="utf-8")

    # 1. Exact content match (includes the mandatory single trailing newline).
    assert (
        actual_content == EXPECTED_ERROR_SUMMARY_CONTENT
    ), (
        "The contents of error_summary.txt do not match the expected output.\n"
        "Differences may include:\n"
        "  • Missing or extra lines\n"
        "  • Incorrect numbering\n"
        "  • Leading/trailing spaces or tabs\n"
        "  • Missing final newline\n"
        "\n"
        "Expected:\n"
        f"{EXPECTED_ERROR_SUMMARY_CONTENT!r}\n"
        "Actual:\n"
        f"{actual_content!r}"
    )

    # 2. EXTRA SAFETY: ensure no duplicate trailing newlines or extra blank lines.
    lines = actual_content.splitlines(keepends=False)
    assert len(lines) == 2, (
        "error_summary.txt should contain exactly 2 non-blank lines—"
        "one for each ERROR entry found in app.log."
    )


def test_actions_log_exists_and_contains_required_command():
    """
    actions.log must exist, be non-empty, and include at least one line
    that contains both substrings “ERROR” and “app.log”.
    """
    # --- Existence & basic sanity ----------------------------------------
    assert ACTIONS_LOG.exists(), (
        f"The file {ACTIONS_LOG} is missing. "
        "Append the command you used to create the summary to this file."
    )
    assert ACTIONS_LOG.is_file(), (
        f"{ACTIONS_LOG} exists but is not a regular file."
    )

    log_content = ACTIONS_LOG.read_text(encoding="utf-8")
    assert log_content.strip(), f"{ACTIONS_LOG} is empty. It must contain the command you ran."

    # --- Regex check for required substrings -----------------------------
    lines = log_content.splitlines()
    if not any(ACTIONS_LOG_REQUIRED_REGEX.search(line) for line in lines):
        pytest.fail(
            "actions.log does not contain a line with both “ERROR” and “app.log”.\n"
            "Example of an acceptable line:\n"
            "    grep 'ERROR' /home/user/project/logs/app.log > /home/user/project/reports/error_summary.txt"
        )