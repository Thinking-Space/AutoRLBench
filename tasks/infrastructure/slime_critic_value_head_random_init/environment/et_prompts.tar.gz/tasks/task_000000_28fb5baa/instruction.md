Context:
You are a QA engineer preparing a very small reporting utility for developers.
A sample application log has already been placed at:

    /home/user/project/logs/app.log

Your goal is to create a concise “ERROR only” report that developers can glance at.

Your task is to generate an ERROR-only summary file with the following specifications:
*   Read `/home/user/project/logs/app.log`.
*   Extract every log line that contains the exact uppercase string “ERROR” (case-sensitive).
*   Keep the original order of those lines.
*   Pre-pend a 1-based running index, followed by a colon and one space.
    Example of the required format (do **not** add extra spaces or tabs):
        1: 2023-08-01 10:15:22 ERROR Could not connect to database
        2: 2023-08-01 10:15:30 ERROR Connection timeout
*   Write the result to:

        /home/user/project/reports/error_summary.txt

*   Ensure the file ends with a single trailing newline.

Additionally, you must log the command used to generate the report:
*   Append (not overwrite) the full shell command line you executed to generate the summary file to:

        /home/user/project/reports/actions.log

*   Write it as one line, exactly as you typed it, followed by a newline.
    (This lets another engineer reproduce your action.)

Verification the automated test will perform:
a. `/home/user/project/reports/error_summary.txt` must exist and contain only the
   correctly numbered “ERROR” lines in the precise format shown above.
b. `/home/user/project/reports/actions.log` must exist, must be non-empty, and the
   recorded command line must contain both the substrings “ERROR” and “app.log”.

Notes:
*   Everything required is under `/home/user`; no root privileges are needed.
*   Create the `/home/user/project/reports` directory yourself if it does not yet exist.