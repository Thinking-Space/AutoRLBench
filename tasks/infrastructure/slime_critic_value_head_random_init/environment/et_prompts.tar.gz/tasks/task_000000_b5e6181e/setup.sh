#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


export LANG=C

export LC_ALL=C

set -e && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3 \
        python3-pip \
        gzip \
        ca-certificates && \
    apt-get clean && \
    true

pip3 install --no-cache-dir pytest pandas numpy scipy

mkdir -p /home/user/data/traffic_logs && \
    chmod 755 /home/user && \
    chmod 755 /home/user/data && \
    chmod 755 /home/user/data/traffic_logs

cat > /tmp/region1.log <<'EOF'
[2023-05-01 08:15:23] 120
[2023-05-01 09:12:11] 110
[2023-05-02 10:03:42] 140
[2023-05-02 11:33:08] 150
[2023-05-03 08:01:55] 200
EOF

gzip -c /tmp/region1.log > /home/user/data/traffic_logs/region1.log.gz

cat > /tmp/region2.log <<'EOF'
[2023-05-01 07:55:03] 100
[2023-05-01 12:34:55] 130
[2023-05-02 13:22:11] 160
[2023-05-03 09:45:31] 190
[2023-05-03 19:25:00] 210
EOF

gzip -c /tmp/region2.log > /home/user/data/traffic_logs/region2.log.gz

cat > /tmp/region3.log <<'EOF'
[2023-05-01 06:45:13] 115
[2023-05-02 14:11:09] 155
[2023-05-02 15:22:05] 165
[2023-05-03 10:33:59] 205
[2023-05-03 11:00:22] 195
EOF

gzip -c /tmp/region3.log > /home/user/data/traffic_logs/region3.log.gz

rm /tmp/region1.log /tmp/region2.log /tmp/region3.log

chmod 644 /home/user/data/traffic_logs/*.log.gz

mkdir -p /home/user && cd /home/user
