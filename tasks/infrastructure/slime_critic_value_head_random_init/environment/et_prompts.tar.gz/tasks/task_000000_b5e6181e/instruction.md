You are a data-center log analyst who has just obtained three compressed latency logs – one per geographical
region – and you must determine an appropriate global
“daily latency cap” for the whole platform.

1.  INPUT LOCATION  
    *   All input files are already present under  
        `/home/user/data/traffic_logs/`  
        They are named:  
        - `region1.log.gz`  
        - `region2.log.gz`  
        - `region3.log.gz`  

2.  RAW-LOG FORMAT (inside every `*.log.gz`)  
    One entry per line, exactly in this form (no extra spaces):  
    `[YYYY-MM-DD HH:MM:SS] <latency_in_ms>`  
    Example:  
    `[2023-05-01 08:15:23] 120`  

3.  WHAT YOU MUST DELIVER  
    Create a new directory exactly named `/home/user/output/`  
    and inside it generate ALL THREE of the following artefacts:

    A)  `/home/user/output/latency_summary.csv`  
        CSV header must be the first line, literal text:  
        `Date,TotalRequests,MeanLatencyMs,95thPercentileLatencyMs`  
        One subsequent line per calendar date in chronological order (ascending),
        values comma-separated, **no whitespace other than the commas**.  
        Example layout (values will, of course, differ):  
        ```
        Date,TotalRequests,MeanLatencyMs,95thPercentileLatencyMs  
        2023-05-01,42,113,150  
        2023-05-02,37,120,155
        ```

    B)  `/home/user/output/latency_cap.json`  
        Strict JSON, single object, two numeric keys:  
        ```json
        {
          "optimal_cap_ms": <integer>,
          "objective_value": <float_rounded_to_2_decimal_places>
        }
        ```
        –  `optimal_cap_ms` must be an integer between **100** and **160** (inclusive).  
        –  `objective_value` must be the final value of the objective
           defined below, rounded to exactly two decimal places.  

    C)  `/home/user/output/process.log`  
        A plain-text chronological record of what you did.
        Each line must start with an RFC-3339 timestamp,
        followed by “ – ” (space, en-dash, space) and a short message.  
        The log must contain at least the three milestones:  
        *   “Extraction completed”  
        *   “Summary created”  
        *   “Optimization done”  

4.  OPTIMISATION TASK  
    For every calendar date, let μ_d be the `MeanLatencyMs` from your CSV.  
    You must choose an integer cap C (100 ≤ C ≤ 160) that minimises

        Σ_d  max(0, μ_d − C)²

    (sum of squared exceedances).  
    The final answer must be written exactly as described in 3B.

5.  CONCURRENCY REQUIREMENT  
    The `process.log` must provide evidence that the decompression of at least two of the `*.log.gz` files overlapped in time.

6.  VERIFICATION  
    *   Do **not** hard-code any numbers in advance—derive everything from the logs.  
    *   The evaluator will:  
        – Check that `/home/user/output/` exists.  
        – Verify the exact filenames.  
        – Parse your CSV and recompute means & percentiles.  
        – Recompute the objective with your chosen cap.  
        – Inspect `process.log` for the required milestone texts and overlapping
          decompression timestamps.  

7.  PERMISSIONS  
    The `/home/user/output/` directory and all files within it must be world-readable.

8.  WHEN YOU ARE FINISHED  
    Make sure all three deliverables are in place and
    display their paths (one per line) to the console so the reviewer can spot-check quickly.