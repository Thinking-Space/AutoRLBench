# test_final_state.py
#
# Pytest suite that validates the **FINAL** state of the operating system /
# container *after* the student has completed the “daily-latency-cap” task.
#
# What we assert (using privileged ground-truth data):
#   1.  /home/user/output/ exists and has the correct permissions.
#   2.  latency_summary.csv is present, world-readable, has the exact   expected
#       header & rows, is in chronological order and contains strictly numeric
#       values where required.
#   3.  latency_cap.json exists, is world-readable, is valid JSON and matches
#       the optimal solution (cap = 160, objective = 1600.00).  We independently
#       recompute the objective for **all** caps in the range 100–160 to confirm
#       that 160 is indeed optimal *and* that the stored objective value is
#       correctly rounded to two decimal places.
#   4.  process.log exists, is world-readable, contains the three milestone
#       phrases and shows evidence that at least two decompressions overlapped
#       in real time.
#
# Any failure explains **exactly** what is still wrong.

import csv
import json
import os
import re
from datetime import datetime
from pathlib import Path

import pytest

# --------------------------------------------------------------------------- #
# CONSTANTS – “privileged truth”                                              #
# --------------------------------------------------------------------------- #
OUTPUT_DIR = Path("/home/user/output")

SUMMARY_CSV = OUTPUT_DIR / "latency_summary.csv"
CAP_JSON = OUTPUT_DIR / "latency_cap.json"
PROCESS_LOG = OUTPUT_DIR / "process.log"

EXPECTED_CSV_LINES = [
    "Date,TotalRequests,MeanLatencyMs,95thPercentileLatencyMs",
    "2023-05-01,5,115,130",
    "2023-05-02,5,154,165",
    "2023-05-03,5,200,210",
]

EXPECTED_CAP        = 160          # optimal_cap_ms
EXPECTED_OBJECTIVE  = 1600.00      # objective_value (already rounded)

DIR_MODE_EXPECTED   = 0o755
FILE_MODE_EXPECTED  = 0o644


# --------------------------------------------------------------------------- #
# HELPERS                                                                     #
# --------------------------------------------------------------------------- #
RFC3339_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})"
)


def _mode(path: Path) -> int:
    """Return the permissions bits (e.g., 0o644) for *path*."""
    return path.stat().st_mode & 0o777


def _load_csv_rows(csv_path: Path):
    with csv_path.open(newline="") as fh:
        return [line.rstrip("\n") for line in fh.readlines()]


def _parse_summary_csv(csv_path: Path):
    """Return list of tuples: (date_str, total_requests, mean, perc95)"""
    rows = []
    with csv_path.open() as fh:
        reader = csv.reader(fh)
        header = next(reader, None)
        for line_num, row in enumerate(reader, start=2):
            if len(row) != 4:
                pytest.fail(f"{csv_path}: expected 4 columns on line {line_num}, got {len(row)}")
            date, total, mean, perc = row
            rows.append((date, int(total), int(mean), int(perc)))
    return rows


def _compute_objective(means, cap):
    """Σ (max(0, μ_d − C))²  for all mean values"""
    return sum((max(0, m - cap) ** 2 for m in means))


def _extract_iso_timestamp(line: str):
    """Return datetime object if the line starts with an RFC-3339 timestamp."""
    ts_part = line.split(" ", 1)[0]
    if RFC3339_RE.match(ts_part):
        try:
            # fromisoformat handles RFC-3339 except the 'Z' suffix, we normalise
            iso = ts_part.replace("Z", "+00:00")
            return datetime.fromisoformat(iso)
        except ValueError:
            pass
    return None


# --------------------------------------------------------------------------- #
# TESTS                                                                       #
# --------------------------------------------------------------------------- #

def test_output_directory_exists_and_permissions():
    assert OUTPUT_DIR.is_dir(), f"Output directory {OUTPUT_DIR} is missing."
    assert _mode(OUTPUT_DIR) == DIR_MODE_EXPECTED, (
        f"{OUTPUT_DIR} must have permissions {oct(DIR_MODE_EXPECTED)}, "
        f"found {oct(_mode(OUTPUT_DIR))}."
    )


@pytest.mark.parametrize("file_path", [SUMMARY_CSV, CAP_JSON, PROCESS_LOG])
def test_output_files_exist_and_permissions(file_path: Path):
    assert file_path.is_file(), f"Required file {file_path} is missing."
    mode = _mode(file_path)
    assert mode == FILE_MODE_EXPECTED, (
        f"{file_path} must have permissions {oct(FILE_MODE_EXPECTED)}, "
        f"found {oct(mode)}."
    )
    # File must not be empty
    assert file_path.stat().st_size > 0, f"{file_path} exists but is empty."


def test_latency_summary_csv_content_exact():
    lines = _load_csv_rows(SUMMARY_CSV)
    assert lines == EXPECTED_CSV_LINES, (
        f"{SUMMARY_CSV} content is not exactly as expected.\n"
        "Expected:\n" + "\n".join(EXPECTED_CSV_LINES) + "\n\n"
        "Found:\n" + "\n".join(lines)
    )


def test_latency_cap_json_optimal_and_correct():
    with CAP_JSON.open() as fh:
        try:
            data = json.load(fh)
        except json.JSONDecodeError as exc:
            pytest.fail(f"{CAP_JSON} is not valid JSON: {exc}")

    # ------- Schema / keys -------
    assert set(data.keys()) == {"optimal_cap_ms", "objective_value"}, (
        f"{CAP_JSON} must contain exactly the keys "
        "'optimal_cap_ms' and 'objective_value'.  Found: {list(data.keys())}"
    )
    cap   = data["optimal_cap_ms"]
    obj_v = data["objective_value"]

    # ------- Value types -------
    assert isinstance(cap, int),           "'optimal_cap_ms' must be an integer."
    assert isinstance(obj_v, (float, int)), "'objective_value' must be numeric."

    # ------- Value ranges & exact truth -------
    assert cap == EXPECTED_CAP, (
        f"optimal_cap_ms should be {EXPECTED_CAP}, found {cap}."
    )

    # Using round( ., 2) to guard against serialisation artefacts (e.g. 1600.0)
    assert round(float(obj_v), 2) == EXPECTED_OBJECTIVE, (
        f"objective_value should be {EXPECTED_OBJECTIVE:.2f}, found {obj_v}."
    )

    # ------- Independently verify optimality -------
    means = [row[2] for row in _parse_summary_csv(SUMMARY_CSV)]
    objectives = {
        c: _compute_objective(means, c)
        for c in range(100, 161)
    }
    min_obj = min(objectives.values())
    assert objectives[cap] == min_obj, (
        f"The chosen cap ({cap}) does not minimise the objective.  "
        f"Minimum objective {min_obj} is achieved at cap(s): "
        f"{[c for c, v in objectives.items() if v == min_obj]}"
    )
    # Confirm stored objective matches recomputed one (to 2 d.p.)
    recomputed_obj = objectives[cap]
    assert round(recomputed_obj, 2) == round(float(obj_v), 2), (
        "objective_value in JSON does not match recomputed value "
        f"({recomputed_obj}) for the same cap."
    )


def test_process_log_contains_milestones_and_parallelism():
    milestones = [
        "Extraction completed",
        "Summary created",
        "Optimization done",
    ]
    with PROCESS_LOG.open() as fh:
        lines = [ln.rstrip("\n") for ln in fh]

    # --- Milestones ---
    for phrase in milestones:
        assert any(phrase in ln for ln in lines), (
            f"{PROCESS_LOG} does not contain the required milestone phrase "
            f"'{phrase}'."
        )

    # --- Basic RFC-3339 format check for every line ---
    for idx, ln in enumerate(lines, start=1):
        assert RFC3339_RE.match(ln), (
            f"Line {idx} of {PROCESS_LOG} does not start with a valid "
            "RFC-3339 timestamp."
        )

    # --- Evidence of parallel decompression ---
    # Heuristic: find all lines that mention .log.gz (start of decompression).
    # If at least two such lines share the **same second**, we treat that as
    # evidence that jobs overlapped in wall-clock time.
    decompress_times = []
    for ln in lines:
        if ".log.gz" in ln or "Decompression" in ln or "Extracting" in ln:
            ts = _extract_iso_timestamp(ln)
            if ts is not None:
                decompress_times.append(ts.replace(microsecond=0))

    assert len(decompress_times) >= 2, (
        f"{PROCESS_LOG} does not appear to contain timestamped decompression "
        "events; cannot verify parallelism."
    )

    # Count how many decompression events occurred in the same second
    seconds_seen = {}
    for ts in decompress_times:
        seconds_seen.setdefault(ts, 0)
        seconds_seen[ts] += 1

    overlap_found = any(count >= 2 for count in seconds_seen.values())
    assert overlap_found, (
        "No evidence of overlapping decompressions was found in process.log. "
        "Ensure that at least two .log.gz files were decompressed in parallel "
        "and that corresponding log lines share the same timestamp (within one second)."
    )