# test_final_state.py
#
# Pytest suite that validates the FINAL state of the operating system
# after the student has completed the optimisation-solver configuration
# task.
#
# The tests assert:
#   • The new directory  /home/user/optimization_solvers/experiment_01  exists.
#   • All three *.conf files exist and contain EXACTLY the five expected
#     lines with correct values (including a single trailing LF).
#   • change_log.csv exists and its content is an exact, byte-for-byte
#     match to the required specification (including line order and the
#     single trailing LF).
#   • The original template file under
#     /home/user/templates/optimization/solver_template.conf  is still
#     present and unmodified.
#
# Only Python’s stdlib and pytest are used.


import os
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Constant paths
# ---------------------------------------------------------------------------

EXP_DIR = Path("/home/user/optimization_solvers/experiment_01")

CONF_FILES = {
    "lbfgs.conf":  ("lbfgs",       "0.03"),
    "cg.conf":     ("cg",          "0.02"),
    "nelder_mead.conf": ("nelder_mead", "0.05"),
}

CHANGE_LOG = EXP_DIR / "change_log.csv"

TEMPLATE_FILE = Path(
    "/home/user/templates/optimization/solver_template.conf"
)

EXPECTED_TEMPLATE_CONTENT = (
    "# Solver Configuration Template\n"
    "algorithm=template\n"
    "learning_rate=0.01\n"
    "max_iterations=200\n"
    "tolerance=1e-6\n"
)

# Pre-computed expected content for the change log CSV (with final LF)
EXPECTED_CHANGE_LOG_CONTENT = (
    "file,old_algorithm,new_algorithm,old_learning_rate,new_learning_rate,timestamp\n"
    "lbfgs.conf,template,lbfgs,0.01,0.03,2023-04-01T00:00:00Z\n"
    "cg.conf,template,cg,0.01,0.02,2023-04-01T00:00:00Z\n"
    "nelder_mead.conf,template,nelder_mead,0.01,0.05,2023-04-01T00:00:00Z\n"
)


# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------

def _expected_conf_content(algorithm: str, learning_rate: str) -> str:
    """
    Build the exact expected file content for a *.conf* file, including the
    single trailing newline character.
    """
    return (
        "# config-version: v1.0\n"
        f"algorithm={algorithm}\n"
        f"learning_rate={learning_rate}\n"
        "max_iterations=200\n"
        "tolerance=1e-6\n"
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_experiment_directory_exists():
    assert EXP_DIR.exists(), (
        f"Directory {EXP_DIR} does not exist. You must create it as specified."
    )
    assert EXP_DIR.is_dir(), (
        f"{EXP_DIR} exists but is not a directory."
    )


@pytest.mark.parametrize("filename,algorithm,learning_rate", [
    (fname, algo, lr) for fname, (algo, lr) in CONF_FILES.items()
])
def test_conf_files_exist_with_correct_contents(filename, algorithm, learning_rate):
    file_path = EXP_DIR / filename

    # 1. Presence checks
    assert file_path.exists(), (
        f"Expected configuration file {file_path} is missing."
    )
    assert file_path.is_file(), (
        f"{file_path} exists but is not a regular file."
    )

    # 2. Content check
    expected_content = _expected_conf_content(algorithm, learning_rate)
    actual_content = file_path.read_text(encoding="utf-8")

    # Helpful failure message explaining difference
    assert actual_content == expected_content, (
        f"Content mismatch in {file_path}.\n\n"
        "Expected:\n"
        "----------------\n"
        f"{expected_content}"
        "----------------\n\n"
        "Actual:\n"
        "----------------\n"
        f"{actual_content}"
        "----------------"
    )


def test_change_log_exists_and_is_correct():
    assert CHANGE_LOG.exists(), (
        f"change_log.csv is missing: {CHANGE_LOG}"
    )
    assert CHANGE_LOG.is_file(), (
        f"{CHANGE_LOG} exists but is not a regular file."
    )

    actual_content = CHANGE_LOG.read_text(encoding="utf-8")

    # Ensure Unix newlines only
    assert "\r" not in actual_content, (
        f"change_log.csv contains CR (\\r) characters. Use LF newlines only."
    )

    assert actual_content == EXPECTED_CHANGE_LOG_CONTENT, (
        "change_log.csv content does not match the required specification.\n\n"
        "Expected:\n"
        "----------------\n"
        f"{EXPECTED_CHANGE_LOG_CONTENT}"
        "----------------\n\n"
        "Actual:\n"
        "----------------\n"
        f"{actual_content}"
        "----------------"
    )


def test_template_file_still_unmodified():
    """
    Verify that the original template file still exists and has not been changed.
    """
    assert TEMPLATE_FILE.exists(), (
        f"Original template file is missing: {TEMPLATE_FILE}"
    )
    assert TEMPLATE_FILE.is_file(), (
        f"{TEMPLATE_FILE} exists but is not a regular file."
    )

    actual_content = TEMPLATE_FILE.read_text(encoding="utf-8")
    assert actual_content == EXPECTED_TEMPLATE_CONTENT, (
        "The original template file has been modified. It must remain "
        "untouched.\n\n"
        "Expected content:\n"
        "----------------\n"
        f"{EXPECTED_TEMPLATE_CONTENT}"
        "----------------\n\n"
        "Actual content:\n"
        "----------------\n"
        f"{actual_content}"
        "----------------"
    )