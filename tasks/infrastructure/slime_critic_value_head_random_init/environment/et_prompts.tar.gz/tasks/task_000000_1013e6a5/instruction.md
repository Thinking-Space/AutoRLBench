Your team maintains a collection of optimisation-solver configuration files.
A new “experiment_01” run is about to start and you, as the configuration manager, have to:

*   Create a **new directory** called
    `/home/user/optimization_solvers/experiment_01`

*   Use the *single* template that already exists at
    `/home/user/templates/optimization/solver_template.conf`

    Content of the template **before you touch it** (for reference only – do NOT modify this original file):
    ```
    # Solver Configuration Template
    algorithm=template
    learning_rate=0.01
    max_iterations=200
    tolerance=1e-6
    ```

*   Inside `/home/user/optimization_solvers/experiment_01` create three concrete
    configuration files, one for each algorithm listed below.
    *   `/home/user/optimization_solvers/experiment_01/lbfgs.conf`
    *   `/home/user/optimization_solvers/experiment_01/cg.conf`
    *   `/home/user/optimization_solvers/experiment_01/nelder_mead.conf`

    Rules for every new `*.conf` file:
    a.  It must start with **exactly** this line (including trailing space):
        `# config-version: v1.0`
    b.  The remainder of the file must match the template except for the two
        key–value pairs you have to change:
        *   `algorithm`        → set to the file’s algorithm name
        *   `learning_rate`    → use the value listed below
    c.  All other key–value pairs from the template must stay untouched and
        keep their original order.

    Required `learning_rate` values:
    *   `lbfgs.conf`       → 0.03
    *   `cg.conf`          → 0.02
    *   `nelder_mead.conf` → 0.05

    When finished, every file must therefore contain **exactly five** lines:
    1.  `# config-version: v1.0`
    2.  `algorithm=<ALGORITHM>`
    3.  `learning_rate=<NEW_RATE>`
    4.  `max_iterations=200`
    5.  `tolerance=1e-6`

*   Produce a change-tracking CSV file called
    `/home/user/optimization_solvers/experiment_01/change_log.csv`

    Format specification (strictly enforced):

    *   The first row is the header *verbatim*:
        `file,old_algorithm,new_algorithm,old_learning_rate,new_learning_rate,timestamp`
    *   One data row per `*.conf` file in the order: lbfgs, cg, nelder_mead.
    *   Each data row uses **exactly** the following literal values for the
        `old_*` columns (because that is what is in the unmodified template):
        *   `old_algorithm`        → template
        *   `old_learning_rate`    → 0.01
    *   The `timestamp` column must be the identical, fixed value:
        `2023-04-01T00:00:00Z`

    Therefore, after you are done, `change_log.csv` must look **exactly** like
    this (make sure to keep the newline at the end of the last line):
    ```
    file,old_algorithm,new_algorithm,old_learning_rate,new_learning_rate,timestamp
    lbfgs.conf,template,lbfgs,0.01,0.03,2023-04-01T00:00:00Z
    cg.conf,template,cg,0.01,0.02,2023-04-01T00:00:00Z
    nelder_mead.conf,template,nelder_mead,0.01,0.05,2023-04-01T00:00:00Z
    ```

    *   The CSV must use a **single trailing newline** (LF) after the last row.
    *   No extra spaces, tabs or blank lines are allowed anywhere.

Do **not** move, delete or alter the original
`/home/user/templates/optimization/solver_template.conf` file.

In summary, once the task is complete the automated checker will assert:

*   Directory `/home/user/optimization_solvers/experiment_01` exists.
*   The three `*.conf` files exist and contain exactly the five lines
    described above with correct values.
*   `change_log.csv` exists, has four lines, matches the exact text block
    given above including ordering, commas and newline rules.
*   The template file under `/home/user/templates/optimization` remains
    untouched.

You do not need sudo privileges. The default user (`/home/user`) already owns
all parent directories you will work in.

Produce console output only as needed to show normal command results; the
final artefacts themselves are what will be graded.