# test_final_state.py
#
# Pytest suite that validates the *final* operating-system / filesystem
# state after the student has completed the ETL pipeline.
#
# Requirements verified:
#   * the three new directories exist and have at least rw-r--r-- (0644) style
#     permissions (world-readable, owner-writable);
#   * byte-for-byte content of all_sales_2020_enriched.csv,
#     quarterly_sales_2020_summary.csv and etl_2020.log is exactly as specified;
#   * the four original raw CSV files are still present and unmodified;
#   * helpful assertion messages explain precisely what is wrong if any check
#     fails.
#
# Only the Python standard library and pytest are used.

import os
from pathlib import Path

# --------------------------------------------------------------------------- #
# Paths
# --------------------------------------------------------------------------- #

HOME = Path("/home/user")

RAW_DIR = HOME / "data" / "raw"
STAGING_DIR = HOME / "data" / "staging"
OUTPUT_DIR = HOME / "data" / "output"
LOGS_DIR = HOME / "logs"

ENRICHED_FILE = STAGING_DIR / "all_sales_2020_enriched.csv"
SUMMARY_FILE = OUTPUT_DIR / "quarterly_sales_2020_summary.csv"
LOG_FILE = LOGS_DIR / "etl_2020.log"

# --------------------------------------------------------------------------- #
# Ground-truth content
# --------------------------------------------------------------------------- #

RAW_FILES_EXPECTED = {
    RAW_DIR / "sales_q1_2020.csv": (
        "Region,Country,SalesPerson,Product,Units,UnitPrice\n"
        "EMEA,Germany,Anna Schmidt,Widget A,120,25.50\n"
        "APAC,Japan,Kenji Ito,Widget B,85,30.00\n"
    ),
    RAW_DIR / "sales_q2_2020.csv": (
        "Region,Country,SalesPerson,Product,Units,UnitPrice\n"
        "EMEA,France,Jean Dupont,Widget A,95,25.50\n"
        "AMER,USA,Maria Garcia,Widget C,150,45.00\n"
    ),
    RAW_DIR / "sales_q3_2020.csv": (
        "Region,Country,SalesPerson,Product,Units,UnitPrice\n"
        "APAC,Australia,Liam Brown,Widget B,130,30.00\n"
        "AMER,Canada,Noah Wilson,Widget A,110,25.50\n"
    ),
    RAW_DIR / "sales_q4_2020.csv": (
        "Region,Country,SalesPerson,Product,Units,UnitPrice\n"
        "EMEA,Italy,Luca Rossi,Widget C,140,45.00\n"
        "APAC,China,Wei Zhang,Widget A,200,25.50\n"
    ),
}

# Expected enriched data (header + 8 rows, each terminated by '\n')
EXPECTED_ENRICHED = (
    "Region,Country,SalesPerson,Product,Units,UnitPrice,Revenue\n"
    "EMEA,Germany,Anna Schmidt,Widget A,120,25.50,3060.00\n"
    "APAC,Japan,Kenji Ito,Widget B,85,30.00,2550.00\n"
    "EMEA,France,Jean Dupont,Widget A,95,25.50,2422.50\n"
    "AMER,USA,Maria Garcia,Widget C,150,45.00,6750.00\n"
    "APAC,Australia,Liam Brown,Widget B,130,30.00,3900.00\n"
    "AMER,Canada,Noah Wilson,Widget A,110,25.50,2805.00\n"
    "EMEA,Italy,Luca Rossi,Widget C,140,45.00,6300.00\n"
    "APAC,China,Wei Zhang,Widget A,200,25.50,5100.00\n"
)

# Expected regional summary (header + 3 rows)
EXPECTED_SUMMARY = (
    "Region,TotalUnits,TotalRevenue\n"
    "AMER,260,9555.00\n"
    "APAC,415,11550.00\n"
    "EMEA,355,11782.50\n"
)

# Expected 5-line log file
EXPECTED_LOG = (
    "CREATE_STAGING OK\n"
    "ADD_REVENUE_COLUMN OK\n"
    "CONCATENATE OK\n"
    "AGGREGATE OK\n"
    "COMPLETE OK\n"
)

# --------------------------------------------------------------------------- #
# Helper utilities
# --------------------------------------------------------------------------- #


def _read_file_text(path: Path) -> str:
    """
    Return file content as UTF-8 text.  If file is missing raise an AssertionError
    with a clear message (so we get a single, helpful failure instead of many).
    """
    assert path.exists(), f"Required file missing: {path}"
    assert path.is_file(), f"Path exists but is not a regular file: {path}"
    with path.open("r", encoding="utf-8") as fh:
        return fh.read()


def _check_min_permissions(path: Path):
    """
    Ensure the filesystem object at *path* is at least world-readable and
    owner-writable: rw-r--r-- (0644) or more permissive.
    For directories we do not insist on the execute bit (the spec only mentions
    0644 or more permissive).
    """
    mode = path.stat().st_mode & 0o777
    # Owner must have read & write
    assert mode & 0o400, f"{path}: owner lacks read permission"
    assert mode & 0o200, f"{path}: owner lacks write permission"
    # Group & others must have read
    assert mode & 0o040, f"{path}: group lacks read permission"
    assert mode & 0o004, f"{path}: others lack read permission"


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #


def test_created_directories_exist_with_correct_permissions():
    """
    The ETL job must have created /home/user/data/staging,
    /home/user/data/output and /home/user/logs and given them at least
    rw-r--r-- permissions.
    """
    for directory in (STAGING_DIR, OUTPUT_DIR, LOGS_DIR):
        assert directory.exists(), f"Directory {directory} has not been created."
        assert directory.is_dir(), f"{directory} exists but is not a directory."
        _check_min_permissions(directory)


def test_enriched_file_content_exact_match():
    """
    all_sales_2020_enriched.csv must exist with byte-for-byte content exactly
    as specified in the task description.
    """
    actual = _read_file_text(ENRICHED_FILE)
    assert (
        actual == EXPECTED_ENRICHED
    ), (
        f"{ENRICHED_FILE} content differs from expected final state.\n"
        "Hint: check header, column order, revenue formatting, line order and "
        "trailing newlines."
    )


def test_summary_file_content_exact_match():
    """
    quarterly_sales_2020_summary.csv must match the expected regional totals.
    """
    actual = _read_file_text(SUMMARY_FILE)
    assert (
        actual == EXPECTED_SUMMARY
    ), (
        f"{SUMMARY_FILE} content differs from expected final state.\n"
        "Hint: check totals, ordering by region, number formatting and "
        "trailing newline."
    )


def test_log_file_content_and_length():
    """
    Log file must contain exactly the five required lines, in order,
    each terminated by a UNIX newline.
    """
    actual = _read_file_text(LOG_FILE)
    assert (
        actual == EXPECTED_LOG
    ), (
        f"{LOG_FILE} content differs from expected final state.\n"
        "Hint: the file must contain exactly five lines with the specified "
        "messages and UNIX newlines (\\n)."
    )


def test_raw_files_remain_untouched():
    """
    The four raw input CSV files must still exist and must be byte-for-byte
    identical to the originals – the ETL job must never modify them.
    """
    for path, expected in RAW_FILES_EXPECTED.items():
        actual = _read_file_text(path)
        assert (
            actual == expected
        ), (
            f"Raw input file {path} has been modified.\n"
            "The ETL process must leave the original source data untouched."
        )