#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3 \
        python3-pip \
        ca-certificates && \
    pip3 install --no-cache-dir pytest

mkdir -p /home/user/data/raw

cat <<'EOF' > /home/user/data/raw/sales_q1_2020.csv
Region,Country,SalesPerson,Product,Units,UnitPrice
EMEA,Germany,Anna Schmidt,Widget A,120,25.50
APAC,Japan,Kenji Ito,Widget B,85,30.00
EOF

cat <<'EOF' > /home/user/data/raw/sales_q2_2020.csv
Region,Country,SalesPerson,Product,Units,UnitPrice
EMEA,France,Jean Dupont,Widget A,95,25.50
AMER,USA,Maria Garcia,Widget C,150,45.00
EOF

cat <<'EOF' > /home/user/data/raw/sales_q3_2020.csv
Region,Country,SalesPerson,Product,Units,UnitPrice
APAC,Australia,Liam Brown,Widget B,130,30.00
AMER,Canada,Noah Wilson,Widget A,110,25.50
EOF

cat <<'EOF' > /home/user/data/raw/sales_q4_2020.csv
Region,Country,SalesPerson,Product,Units,UnitPrice
EMEA,Italy,Luca Rossi,Widget C,140,45.00
APAC,China,Wei Zhang,Widget A,200,25.50
EOF

chmod 0644 /home/user/data/raw/sales_q?_2020.csv && \
    chmod -R a+rX /home/user

apt-get clean && true

chmod 755 /home/user

export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"
