You are a data-engineer building a tiny proof-of-concept ETL pipeline for 2020 quarterly sales data that already exists on disk.
Work only in the user’s home directory: /home/user

1.  Input files
    Four CSV files are already present inside /home/user/data/raw/

    *   /home/user/data/raw/sales_q1_2020.csv
    *   /home/user/data/raw/sales_q2_2020.csv
    *   /home/user/data/raw/sales_q3_2020.csv
    *   /home/user/data/raw/sales_q4_2020.csv

    They all share the exact same header:

        Region,Country,SalesPerson,Product,Units,UnitPrice

    The rows in every file are comma-separated, UTF-8, UNIX-newline (\n) terminated, with no trailing blank lines and no double quotes around the fields.
    DO NOT edit the four original files.

2.  Transformation requirements
    a.  Create a working directory /home/user/data/staging/ (if it does not exist).
    b.  Copy each raw file into that staging directory and, while copying, add a new final column named Revenue whose value is Units × UnitPrice.
        *   The new column header must be exactly Revenue (capital R, no spaces).
        *   The revenue value must be rendered with two decimal digits after the decimal point (e.g. 3060.00).
        *   Preserve the original column order; Revenue becomes column 7.
    c.  Combine (vertically concatenate) the four transformed files into a single file
        /home/user/data/staging/all_sales_2020_enriched.csv
        The combined file must contain a single header row followed by the eight data rows, in the order Q1 → Q2 → Q3 → Q4, each keeping the order they had in their respective source files.

3.  Aggregation requirements
    a.  Create /home/user/data/output/ (if it does not exist).
    b.  From all_sales_2020_enriched.csv calculate a regional summary: total units and total revenue per Region.
        *   Output file path: /home/user/data/output/quarterly_sales_2020_summary.csv
        *   Output format (comma-separated, UNIX-newline, UTF-8, no surrounding quotes):

                Region,TotalUnits,TotalRevenue
                AMER,260,9555.00
                APAC,415,11550.00
                EMEA,355,11782.50

        *   The file must be sorted alphabetically by the Region column (AMER, APAC, EMEA).
        *   TotalRevenue must be formatted with exactly two digits after the decimal point.

4.  Logging requirements
    a.  Create /home/user/logs/ if necessary.
    b.  Write a plain-text log file /home/user/logs/etl_2020.log that contains exactly five lines, each terminated with a UNIX newline.
        Required content and order (case-sensitive):

            CREATE_STAGING OK
            ADD_REVENUE_COLUMN OK
            CONCATENATE OK
            AGGREGATE OK
            COMPLETE OK

5.  Verification hints
    Automated tests will check:
    *   Existence and permissions (0644 or more permissive) of the three directories you might create.
    *   Exact byte-for-byte content of /home/user/data/staging/all_sales_2020_enriched.csv, /home/user/data/output/quarterly_sales_2020_summary.csv and /home/user/logs/etl_2020.log.
    *   That the four original raw files remain untouched.

Your goal: make the system match everything described above. Do NOT delete or rename any pre-existing files. You do not have root access.