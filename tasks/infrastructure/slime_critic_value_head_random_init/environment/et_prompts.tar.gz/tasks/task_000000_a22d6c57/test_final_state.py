# test_final_state.py
#
# Pytest suite that validates the **final** filesystem state after the
# student has finished the CSV-cleaning task.
#
# What we assert:
#   1.  The two cleaned CSV files exist at the exact required paths.
#   2.  Each cleaned file
#         • keeps the original header,
#         • has all rows containing the literal string “NA” removed,
#         • has duplicate rows removed (first occurrence kept),
#         • is newline-terminated,
#         • contains *no* extra rows or columns.
#   3.  /home/user/data/processed/ contains **only** the two “_clean.csv”
#      files (no junk artefacts).
#   4.  The benchmark log exists, has exactly three lines, is
#      newline-terminated, and its numeric values match the deterministic
#      formula in the brief.
#   5.  The original raw CSV files are still present and unmodified.
#
# Only the Python standard library and pytest are used.

import os
from pathlib import Path
from typing import List, Tuple

import pytest

HOME = Path("/home/user")

RAW_DIR = HOME / "data" / "raw"
PROCESSED_DIR = HOME / "data" / "processed"
BENCHMARK_DIR = HOME / "benchmark"

DATASET1_RAW_PATH = RAW_DIR / "dataset1.csv"
DATASET2_RAW_PATH = RAW_DIR / "dataset2.csv"

DATASET1_CLEAN_PATH = PROCESSED_DIR / "dataset1_clean.csv"
DATASET2_CLEAN_PATH = PROCESSED_DIR / "dataset2_clean.csv"
BENCHMARK_LOG_PATH = BENCHMARK_DIR / "cleaning_benchmark.log"

# ---------------------------------------------------------------------------
# Ground-truth *raw* file content (must stay untouched)
# ---------------------------------------------------------------------------
DATASET1_RAW_CONTENT = (
    "id,name,value\n"
    "1,Alice,10\n"
    "2,Bob,NA\n"
    "3,Charlie,30\n"
    "3,Charlie,30\n"
)

DATASET2_RAW_CONTENT = (
    "id,score\n"
    "1,95\n"
    "2,88\n"
    "2,88\n"
    "3,NA\n"
    "4,76\n"
)

RAW_CONTENT_MAP = {
    DATASET1_RAW_PATH: DATASET1_RAW_CONTENT,
    DATASET2_RAW_PATH: DATASET2_RAW_CONTENT,
}

# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------


def read_file_text(path: Path) -> str:
    """Return file content as UTF-8 text."""
    return path.read_text(encoding="utf-8")


def newline_terminated(text: str) -> bool:
    """True if *exactly* one trailing newline is present."""
    return text.endswith("\n") and not text.endswith("\n\n")


def compute_expected_clean_content(raw_content: str) -> Tuple[str, int]:
    """
    Apply the cleaning rules to the given raw CSV content.

    Returns
    -------
    cleaned_text : str
        The full cleaned CSV (including trailing newline).

    rows_after : int
        Number of data rows in the cleaned CSV (header excluded).
    """
    # Split into rows without keeping the newline characters.
    raw_rows: List[str] = raw_content.rstrip("\n").split("\n")

    header = raw_rows[0]
    data_rows = raw_rows[1:]

    cleaned_rows: List[str] = []
    seen_rows = set()

    for row in data_rows:
        if "NA" in row:
            continue  # Rule 1a
        if row in seen_rows:
            continue  # Rule 1b – duplicate
        seen_rows.add(row)
        cleaned_rows.append(row)

    cleaned_text = "\n".join([header] + cleaned_rows) + "\n"
    return cleaned_text, len(cleaned_rows)


def parse_benchmark_line(line: str) -> Tuple[str, int, int, str]:
    """
    Parse a single benchmark CSV line.

    Returns tuple: (dataset_name, rows_before, rows_after, runtime_string)
    """
    parts = line.split(",")
    assert (
        len(parts) == 4
    ), f"Benchmark line must have 4 comma-separated fields, got: {line!r}"
    dataset_name, rows_before_str, rows_after_str, runtime_str = parts
    assert rows_before_str.isdigit(), f"rows_before is not an integer: {line!r}"
    assert rows_after_str.isdigit(), f"rows_after is not an integer: {line!r}"
    return dataset_name, int(rows_before_str), int(rows_after_str), runtime_str


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_cleaned_files_exist():
    """
    The two cleaned CSVs must exist exactly where required.
    """
    for path in (DATASET1_CLEAN_PATH, DATASET2_CLEAN_PATH):
        assert path.exists(), f"Expected cleaned file is missing: {path}"
        assert path.is_file(), f"Cleaned path exists but is not a file: {path}"


@pytest.mark.parametrize(
    "raw_path,clean_path",
    [
        (DATASET1_RAW_PATH, DATASET1_CLEAN_PATH),
        (DATASET2_RAW_PATH, DATASET2_CLEAN_PATH),
    ],
)
def test_cleaned_files_content(raw_path: Path, clean_path: Path):
    """
    Validate that each cleaned CSV matches the task specification:
      * header untouched
      * 'NA' rows removed
      * duplicates removed (first occurrence kept)
      * newline-terminated
    """
    raw_content = RAW_CONTENT_MAP[raw_path]
    expected_clean_text, _rows_after = compute_expected_clean_content(raw_content)

    actual_clean_text = read_file_text(clean_path)

    # Check newline termination first to provide clearer error messages.
    assert newline_terminated(
        actual_clean_text
    ), f"{clean_path} must end with exactly one newline character."

    assert (
        actual_clean_text == expected_clean_text
    ), (
        f"Content mismatch for cleaned file {clean_path}.\n"
        "Make sure you removed all rows containing 'NA', removed duplicates "
        "while keeping the first occurrence, and preserved the header.\n\n"
        "Expected:\n"
        f"{expected_clean_text!r}\n\n"
        "Got:\n"
        f"{actual_clean_text!r}"
    )


def test_processed_directory_contains_only_cleaned_files():
    """
    No extra artefacts should be present in /home/user/data/processed/.
    """
    expected_names = {DATASET1_CLEAN_PATH.name, DATASET2_CLEAN_PATH.name}
    actual_names = {p.name for p in PROCESSED_DIR.iterdir() if p.is_file()}

    missing = expected_names - actual_names
    extras = actual_names - expected_names

    assert (
        not missing
    ), f"Missing cleaned files in {PROCESSED_DIR}: {', '.join(sorted(missing))}"
    assert (
        not extras
    ), f"Unexpected files found in {PROCESSED_DIR}: {', '.join(sorted(extras))}"


def test_benchmark_log():
    """
    Validate the benchmark log file for presence, format, and correct numbers.
    """
    assert BENCHMARK_LOG_PATH.exists(), "Benchmark log is missing."
    assert BENCHMARK_LOG_PATH.is_file(), "Benchmark log path exists but is not a file."

    log_text = read_file_text(BENCHMARK_LOG_PATH)
    assert newline_terminated(
        log_text
    ), "Benchmark log must end with exactly one trailing newline."

    lines = log_text.rstrip("\n").split("\n")
    assert (
        len(lines) == 3
    ), f"Benchmark log must contain exactly 3 lines (header + 2 data lines). Found {len(lines)}."

    # 1. Header line
    header_expected = "dataset_name,rows_before,rows_after,runtime_seconds"
    assert (
        lines[0] == header_expected
    ), f"Benchmark header line incorrect.\nExpected: {header_expected!r}\nGot:      {lines[0]!r}"

    # Helper: build expected stats from raw and cleaned data
    expected_stats = []
    for raw_path, clean_path in [
        (DATASET1_RAW_PATH, DATASET1_CLEAN_PATH),
        (DATASET2_RAW_PATH, DATASET2_CLEAN_PATH),
    ]:
        raw_content = RAW_CONTENT_MAP[raw_path]
        rows_before = len(raw_content.rstrip("\n").split("\n")) - 1
        clean_content = read_file_text(clean_path)
        rows_after = len(clean_content.rstrip("\n").split("\n")) - 1
        runtime_seconds = rows_before * 0.005
        runtime_str = f"{runtime_seconds:.3f}"
        expected_stats.append(
            (
                raw_path.name,  # e.g., dataset1.csv
                rows_before,
                rows_after,
                runtime_str,
            )
        )

    # 2. & 3. Data lines (must be in the same order as in the spec: dataset1 then dataset2)
    for i, expected in enumerate(expected_stats, start=1):
        dataset_name, rows_before, rows_after, runtime_str = parse_benchmark_line(lines[i])

        exp_dataset_name, exp_rows_before, exp_rows_after, exp_runtime_str = expected

        assert (
            dataset_name == exp_dataset_name
        ), f"Line {i+1}: dataset_name incorrect: expected {exp_dataset_name}, got {dataset_name}"

        assert (
            rows_before == exp_rows_before
        ), f"Line {i+1}: rows_before incorrect: expected {exp_rows_before}, got {rows_before}"

        assert (
            rows_after == exp_rows_after
        ), f"Line {i+1}: rows_after incorrect: expected {exp_rows_after}, got {rows_after}"

        # Ensure runtime is formatted with exactly 3 decimal places (zero-padded).
        assert (
            runtime_str == exp_runtime_str
        ), f"Line {i+1}: runtime_seconds incorrect: expected {exp_runtime_str}, got {runtime_str}"


def test_raw_files_unmodified():
    """
    The task rules forbid editing anything inside /home/user/data/raw/.
    Re-check that the raw files are still byte-for-byte identical to
    the starter files.
    """
    for raw_path, expected_content in RAW_CONTENT_MAP.items():
        assert raw_path.exists(), f"Raw file missing: {raw_path}"
        actual_content = read_file_text(raw_path)
        assert (
            actual_content == expected_content
        ), (
            f"Raw file {raw_path} has been modified.\n"
            "You must leave the original data untouched."
        )

        assert newline_terminated(
            actual_content
        ), f"Raw file {raw_path} must be newline-terminated."