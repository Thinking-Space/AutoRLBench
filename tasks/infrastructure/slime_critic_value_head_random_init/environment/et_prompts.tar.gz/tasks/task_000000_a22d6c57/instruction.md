You are helping a data-science team that has just received two messy CSV
    files.  
    Your assignment is to (1) clean those files and (2) produce a simple
    “performance” benchmark log that the QA department can automatically
    validate.

    Important directory layout (already present):
      /home/user/data/raw/              → holds the unmodified **source** CSVs
      /home/user/data/processed/        → must hold the **cleaned** CSVs you create
      /home/user/benchmark/             → must hold the benchmark log you create

    1.  Cleaning rules (apply to *each* CSV file independently)
        a.  Remove every row that contains the literal string “NA”
            (case-sensitive, without quotes) in **any** column.
        b.  Remove duplicated rows.  
            • The first appearance is kept.  
            • Comparison is performed on the *entire* row (all columns).  
        c.  Preserve the original header line exactly as it is.

    2.  File-naming rules for cleaned files
        • A file originally called “dataset1.csv” must become
          “dataset1_clean.csv”.  
        • Place all cleaned files inside /home/user/data/processed/.

    3.  Benchmark log
        After cleaning each file, you must append a line to a single text
        file called
            /home/user/benchmark/cleaning_benchmark.log
        The file must be **exactly** 3 lines long:
            1. A fixed header
            2. A line for dataset1.csv
            3. A line for dataset2.csv

        3.1 Header line (copy verbatim — no spaces before/after commas):
            `dataset_name,rows_before,rows_after,runtime_seconds`

        3.2 Data lines
            • rows_before = number of data rows **excluding** the header
              in the *raw* file.  
            • rows_after  = number of data rows **excluding** the header
              in the *cleaned* file.  
            • runtime_seconds is a synthetic benchmark that must be computed
              using this deterministic formula so the QA system can check it
              reliably:  

                  runtime_seconds = rows_before × 0.005

              The value must be rendered with exactly three
              digits after the decimal point (zero-padded if necessary).

            Example format (the numbers are illustrative, do **not**
            copy them directly):

                dataset_name,rows_before,rows_after,runtime_seconds
                dataset1.csv,12,7,0.060
                dataset2.csv,8,8,0.040

            • Fields are comma-separated, no extra whitespace.
            • End the file with a single trailing newline (i.e., the file’s
              last byte is “\n”).

    4.  Additional constraints
        • Do NOT modify or delete anything inside /home/user/data/raw/.  
        • Create any missing directories you need, but **never** require
          elevated (root) privileges.  
        • When you finish, there must be only the two new “_clean.csv” files
          (with correct content) and exactly one benchmark log whose format
          matches the rules above.

    The automated test will check:
        • The two cleaned CSV files exist at the correct paths and contain
          precisely the expected rows (header + cleaned data, newline-terminated).
        • /home/user/benchmark/cleaning_benchmark.log exists, has 3 lines,
          is newline-terminated, and its numeric values conform to the
          formula above.
        • The raw files remain unaltered.