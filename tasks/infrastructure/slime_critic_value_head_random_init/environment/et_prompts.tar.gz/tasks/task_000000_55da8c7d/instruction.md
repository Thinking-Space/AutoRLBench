You are a localization engineer who has just received a request to add a missing “thanks” translation and bump the build version.

Current project layout  
/home/user/project  
├── locales  
│   ├── en.yaml  
│   └── es.yaml  
└── settings.toml  

1. YAML files  
   Path:  
   • /home/user/project/locales/en.yaml  
   • /home/user/project/locales/es.yaml  

   Current content of en.yaml (2 lines):  
   greeting: "Hello"  
   farewell: "Goodbye"  

   Current content of es.yaml (2 lines):  
   greeting: "Hola"  
   farewell: "Adiós"  

   Task: append one **exactly-formatted** line to each file so that, after the change, their full contents are:  

   en.yaml (3 lines total, same newline endings as the original file):  
   greeting: "Hello"  
   farewell: "Goodbye"  
   thanks: "Thank you"  

   es.yaml (3 lines total, same newline endings as the original file):  
   greeting: "Hola"  
   farewell: "Adiós"  
   thanks: "Gracias"  

   • The key must be written in lower-case, exactly thanks:.  
   • Values must stay double-quoted.  
   • Do not reorder or re-indent existing lines. Just add the new line at the end.

2. TOML file  
   Path: /home/user/project/settings.toml  

   Current content (3 lines):  
   [build]  
   version = "1.0.0"  
   lang_support = ["en", "es"]  

   Task: change only the version field to "1.0.1".  Leave every other character (including spaces and the trailing newline) untouched.

3. Create a plain-text log file named /home/user/translation_update.log that **must contain exactly** the four lines shown below, nothing more, nothing less, with the same punctuation and spacing:  

   Update summary:  
   - en.yaml: added key 'thanks' with value 'Thank you'  
   - es.yaml: added key 'thanks' with value 'Gracias'  
   - settings.toml: version bumped to 1.0.1  

   Do NOT include leading/trailing blank lines.

Paths are absolute; you do not have root privileges.

The automated tests will confirm:  
• The YAML files now have exactly three lines and end with thanks: lines shown above.  
• settings.toml has version = "1.0.1" and is otherwise unchanged.  
• /home/user/translation_update.log exists and matches the four-line specification verbatim.