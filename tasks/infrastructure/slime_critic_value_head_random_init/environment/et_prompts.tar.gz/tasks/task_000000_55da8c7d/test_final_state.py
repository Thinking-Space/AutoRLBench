# test_final_state.py
"""
Pytest suite that validates the FINAL state of the filesystem
*after* the student has finished the task.

It asserts that:
1. All required files still exist in their correct absolute paths.
2. Their contents EXACTLY match the expected post-task state,
   byte-for-byte (including newlines).
3. No stray Windows CR characters were introduced.
4. The log file exists and is verbatim per the specification.

Only the Python stdlib and pytest are used.
"""

from pathlib import Path
import pytest

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

HOME = Path("/home/user")
PROJECT_ROOT = HOME / "project"
LOCALES_DIR = PROJECT_ROOT / "locales"

EN_FILE = LOCALES_DIR / "en.yaml"
ES_FILE = LOCALES_DIR / "es.yaml"
SETTINGS_FILE = PROJECT_ROOT / "settings.toml"
LOG_FILE = HOME / "translation_update.log"

EXPECTED_EN = (
    'greeting: "Hello"\n'
    'farewell: "Goodbye"\n'
    'thanks: "Thank you"\n'
)

EXPECTED_ES = (
    'greeting: "Hola"\n'
    'farewell: "Adiós"\n'
    'thanks: "Gracias"\n'
)

EXPECTED_SETTINGS = (
    "[build]\n"
    'version = "1.0.1"\n'
    'lang_support = ["en", "es"]\n'
)

EXPECTED_LOG = (
    "Update summary:\n"
    "- en.yaml: added key 'thanks' with value 'Thank you'\n"
    "- es.yaml: added key 'thanks' with value 'Gracias'\n"
    "- settings.toml: version bumped to 1.0.1\n"
)

# ---------------------------------------------------------------------------
# Helper fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session", params=[EN_FILE, ES_FILE, SETTINGS_FILE, LOG_FILE])
def target_file(request):
    return request.param


@pytest.fixture(scope="session")
def en_content():
    return EN_FILE.read_text(encoding="utf-8")


@pytest.fixture(scope="session")
def es_content():
    return ES_FILE.read_text(encoding="utf-8")


@pytest.fixture(scope="session")
def settings_content():
    return SETTINGS_FILE.read_text(encoding="utf-8")


@pytest.fixture(scope="session")
def log_content():
    return LOG_FILE.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Generic existence checks
# ---------------------------------------------------------------------------

def test_required_directories_exist():
    assert PROJECT_ROOT.is_dir(), f"Missing project root directory {PROJECT_ROOT}"
    assert LOCALES_DIR.is_dir(), f"Missing locales directory {LOCALES_DIR}"


def test_required_files_exist(target_file):
    assert target_file.is_file(), f"Expected required file {target_file} to exist"


# ---------------------------------------------------------------------------
# Content checks
# ---------------------------------------------------------------------------

def _assert_no_cr_characters(data: str, path: Path):
    assert "\r" not in data, (
        f"Windows style CR characters (\\r) detected in {path}. "
        "Files must use single UNIX LF newlines."
    )


def test_en_yaml_final_content(en_content):
    _assert_no_cr_characters(en_content, EN_FILE)
    assert en_content == EXPECTED_EN, (
        f"Content of {EN_FILE} is not exactly as expected.\n"
        f"Expected (repr): {repr(EXPECTED_EN)}\n"
        f"Got      (repr): {repr(en_content)}"
    )


def test_es_yaml_final_content(es_content):
    _assert_no_cr_characters(es_content, ES_FILE)
    assert es_content == EXPECTED_ES, (
        f"Content of {ES_FILE} is not exactly as expected.\n"
        f"Expected (repr): {repr(EXPECTED_ES)}\n"
        f"Got      (repr): {repr(es_content)}"
    )


def test_settings_toml_final_content(settings_content):
    _assert_no_cr_characters(settings_content, SETTINGS_FILE)
    assert settings_content == EXPECTED_SETTINGS, (
        f"Content of {SETTINGS_FILE} differs from expected.\n"
        f"Expected (repr): {repr(EXPECTED_SETTINGS)}\n"
        f"Got      (repr): {repr(settings_content)}"
    )


def test_translation_update_log_content(log_content):
    _assert_no_cr_characters(log_content, LOG_FILE)
    assert log_content == EXPECTED_LOG, (
        f"Content of {LOG_FILE} is incorrect.\n"
        f"Expected (repr): {repr(EXPECTED_LOG)}\n"
        f"Got      (repr): {repr(log_content)}"
    )