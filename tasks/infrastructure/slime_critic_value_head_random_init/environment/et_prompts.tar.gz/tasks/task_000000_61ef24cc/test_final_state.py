# test_final_state.py
#
# Pytest suite that validates the *final* operating-system / filesystem
# state for the “mock_api” DevOps exercise – i.e. after the student’s
# solution has run.
#
# The suite focuses exclusively on the artefacts that the assignment
# requires the student to create under /home/user/logs.
#
# What we test:
#   1. /home/user/logs exists and is a directory.
#   2. /home/user/logs/api_debug.log exists and is a regular file.
#   3. File permissions are sane: owner is able to read & write, nobody
#      has execute bits, and group/other are *not* allowed to write.
#   4. The log file contains *exactly* three lines, each terminated by a
#      single LF, and no extra blank line at EOF.
#   5. Every line matches the precise, machine-parseable format dictated
#      by the spec:
#
#         TIMESTAMP | ENDPOINT | STATUS_CODE | DETAIL
#
#      For this exercise the timestamp is the literal string “N/A”.
#
# If any assertion fails, the test output will clearly describe what is
# still wrong so the student can correct it.

import difflib
import stat
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

HOME = Path("/home/user")
LOG_DIR = HOME / "logs"
LOG_FILE = LOG_DIR / "api_debug.log"

# Expected lines – **exact bytes**, *no* trailing spaces on any line.
EXPECTED_LINES = (
    "N/A | inventory | 200 | total_items=3",
    "N/A | user      | 200 | first_user=alice",
    "N/A | health    | 200 | message=OK",
)

# Convenience: join with LF _and_ final LF so we can do a strict byte
# comparison if desired.
EXPECTED_CONTENT = "\n".join(EXPECTED_LINES) + "\n"


# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------

def _read_log_bytes():
    """Read the log file as bytes, raising a helpful assertion if missing."""
    try:
        return LOG_FILE.read_bytes()
    except FileNotFoundError:
        pytest.fail(
            f"Expected log file does not exist: {LOG_FILE}\n"
            "Did you create it at the correct absolute path?"
        )


def _diff(expected: str, actual: str) -> str:
    """Return a unified diff string for easier debugging."""
    diff = difflib.unified_diff(
        expected.splitlines(keepends=True),
        actual.splitlines(keepends=True),
        fromfile="expected",
        tofile="actual",
    )
    return "".join(diff)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_log_directory_exists():
    assert LOG_DIR.is_dir(), (
        f"Directory {LOG_DIR} must exist. "
        "Create it with `mkdir -p /home/user/logs`."
    )


def test_log_file_exists_and_is_regular():
    assert LOG_FILE.exists(), (
        f"Missing required log file: {LOG_FILE}"
    )
    assert LOG_FILE.is_file(), (
        f"{LOG_FILE} exists but is not a regular file."
    )


def test_log_file_permissions():
    """0644 is explicitly acceptable; be lenient but enforce the spirit."""
    mode = LOG_FILE.stat().st_mode & 0o777

    # Owner must have write permission
    assert mode & stat.S_IWUSR, (
        f"{LOG_FILE} must be writable by its owner (user write bit missing)."
    )

    # Nobody should have any execute bits
    assert mode & 0o111 == 0, (
        f"{LOG_FILE} should not be executable by anyone "
        "(execute bits are set). Current mode: {oct(mode)}"
    )

    # Group/other write bits are not allowed
    assert mode & (stat.S_IWGRP | stat.S_IWOTH) == 0, (
        f"{LOG_FILE} must not be world-writable. "
        f"Current mode is {oct(mode)}, but group/other write bits are set."
    )


def test_log_file_content_exact():
    data = _read_log_bytes()
    text = data.decode("utf-8", errors="replace")

    # 1. Ensure the file *ends* with a single LF
    assert text.endswith("\n"), (
        f"{LOG_FILE} must terminate with a single LF (newline)."
    )

    # 2. No extra blank line at EOF
    assert not text.endswith("\n\n"), (
        f"{LOG_FILE} contains an extra blank line at the end."
    )

    # 3. Split into logical lines and validate count
    lines = text.splitlines()
    assert len(lines) == 3, (
        f"{LOG_FILE} must contain exactly 3 lines – found {len(lines)}."
    )

    # 4. Compare each line verbatim against the rubric
    mismatches = []
    for idx, (expected, actual) in enumerate(zip(EXPECTED_LINES, lines), start=1):
        if actual != expected:
            diff = _diff(expected, actual)
            mismatches.append(
                f"Line {idx} does not match the expected content.\n"
                f"Diff:\n{diff}"
            )

    if mismatches:
        pytest.fail("\n\n".join(mismatches))