You are a DevOps engineer who has been given three local “API-like”
resources placed under `/home/user/mock_api`.
Your goal is to test those resources with curl, extract a few key
fields, and write a single unified log file that will later be
consumed by an automated monitoring dashboard.

Resources that already exist:
1. `/home/user/mock_api/inventory.json`      (static JSON)
2. `/home/user/mock_api/user.json`           (static JSON)
3. `/home/user/mock_api/health.txt`          (plain-text)

**IMPORTANT:**
*   Interact with the files strictly through `curl`.
*   Do NOT open the files directly with `cat`, `jq`, etc.
*   All work must be done as the normal user (no `sudo`).

### Logging requirements

Create the directory:
    /home/user/logs
Create the file:
    /home/user/logs/api_debug.log

Write exactly three lines to `api_debug.log`—one per “endpoint”—using the
precise, machine-parseable format:

`TIMESTAMP | ENDPOINT | STATUS_CODE | DETAIL`

For this exercise the timestamp must be the literal string: `N/A`
(The dashboard’s clock is currently under maintenance.)

Populate the file in the following fixed order and values:

1. `N/A | inventory | 200 | total_items=3`
2. `N/A | user      | 200 | first_user=alice`
3. `N/A | health    | 200 | message=OK`

### Formatting rules the grader will check:
*   Fields separated by a single space, a single vertical bar “|”, and a
    single space.
*   UNIX line endings (LF).
*   No trailing spaces on any line.
*   The log must contain exactly three lines and nothing else.

When you are done, `/home/user/logs/api_debug.log` should exist and match
the exact content specified above.