# test_final_state.py
#
# This pytest file validates the **FINAL** operating-system / container state
# after the student has executed their (single) compound shell command for the
# “cron file” exercise.
#
# Truth data (expected end state)
# -------------------------------
# 1) Directory  : /home/user/docs          must exist and be a directory
# 2) File       : /home/user/docs/doc_build.cron  must exist and contain **exactly**
#                the three lines shown below, each terminated with one Unix LF.
#
#    # Documentation build automation␊
#    # Runs every day at 02:15␊
#    15 2 * * * /home/user/scripts/build_docs.sh␊
#
#    Notes:
#      • “␊” represents the single LF byte (0x0A).
#      • No CR characters (0x0D) are allowed.
#      • No trailing blanks (spaces or TABs) are allowed before each LF.
#
# Any deviation from this state will cause the tests to fail with a clear,
# actionable message.
#
# Only the Python standard library and pytest are used.

import os
from pathlib import Path

import pytest

HOME_DIR = Path("/home/user")
DOCS_DIR = HOME_DIR / "docs"
CRON_FILE = DOCS_DIR / "doc_build.cron"

# Expected byte-perfect file content (note the final \n)
EXPECTED_CONTENT_BYTES = (
    b"# Documentation build automation\n"
    b"# Runs every day at 02:15\n"
    b"15 2 * * * /home/user/scripts/build_docs.sh\n"
)


def _read_file_bytes(path: Path) -> bytes:
    """Helper that returns the full byte content of *path*."""
    with path.open("rb") as f:
        return f.read()


@pytest.mark.order(after="test_cron_file_absent_before_task")
def test_docs_directory_now_exists_and_is_dir():
    """
    After task completion the directory /home/user/docs must exist and be a
    directory.  Anything else (missing or file instead of dir) is wrong.
    """
    assert DOCS_DIR.exists(), (
        f"Expected directory {DOCS_DIR} to exist, but it is missing. "
        "Did you create it?"
    )
    assert DOCS_DIR.is_dir(), (
        f"{DOCS_DIR} exists but is not a directory. "
        "Check what you created."
    )


@pytest.mark.order(after="test_docs_directory_now_exists_and_is_dir")
def test_cron_file_exists_and_is_regular():
    """
    Verify that /home/user/docs/doc_build.cron now exists and is a regular
    file (not a directory, symlink, etc.).
    """
    assert CRON_FILE.exists(), (
        f"Expected file {CRON_FILE} to exist, but it is missing."
    )
    assert CRON_FILE.is_file(), (
        f"{CRON_FILE} exists but is not a regular file."
    )


@pytest.mark.order(after="test_cron_file_exists_and_is_regular")
def test_file_content_matches_exact_truth():
    """
    The cron file must match the expected truth byte-for-byte.
    This simultaneously guarantees:
      • Exactly three lines.
      • Each line ends with a single LF.
      • No CR characters (Windows line endings).
      • No extra blank lines or trailing spaces/tabs.
    """
    actual_bytes = _read_file_bytes(CRON_FILE)
    # Quick CR detection for a helpful error message
    assert b"\r" not in actual_bytes, (
        f"{CRON_FILE} contains carriage-return characters (CR / 0x0D). "
        "Use Unix line endings (LF) only."
    )

    if actual_bytes != EXPECTED_CONTENT_BYTES:
        # Provide a diff-like explanation without external libs.
        expected_str = EXPECTED_CONTENT_BYTES.decode("utf-8", errors="replace")
        actual_str = actual_bytes.decode("utf-8", errors="replace")
        msg_lines = [
            f"Content of {CRON_FILE} does not match the expected text.",
            "",
            "----- Expected -----",
            expected_str.replace("\n", "\\n\n"),
            "--------------------",
            "------ Found -------",
            actual_str.replace("\n", "\\n\n"),
            "--------------------",
        ]
        pytest.fail("\n".join(msg_lines))