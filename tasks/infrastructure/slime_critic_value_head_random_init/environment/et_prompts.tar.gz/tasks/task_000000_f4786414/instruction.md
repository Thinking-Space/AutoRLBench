You are a technical writer who is putting together internal documentation about 
how the company’s docs are automatically regenerated every night.  
For this purpose, you need a **plain-text cron file** saved on disk that
can be copied verbatim into the official operations guide.

### Goal
1. Make sure the directory “/home/user/docs” exists (create it if it is missing).
2. Inside that directory create a text file named exactly  
   “/home/user/docs/doc_build.cron”.

#### Required file contents (3 lines, each ending with a single UNIX LF):
```
# Documentation build automation
# Runs every day at 02:15
15 2 * * * /home/user/scripts/build_docs.sh
```

### Constraints
*   Do **not** run “crontab” – you are only writing a documentation file.
*   Do not use sudo or assume root privileges.

### What the grader will verify
1. A file exists at “/home/user/docs/doc_build.cron”.
2. The file contains exactly the three lines shown above, in that order,  
   each terminated by a single LF (no carriage returns, no trailing blanks).
3. There is no extra output to stdout/stderr that would indicate an error.

If everything is correct, you are done.