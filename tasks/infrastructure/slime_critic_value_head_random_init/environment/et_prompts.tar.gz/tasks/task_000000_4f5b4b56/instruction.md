You are an IT support technician who has just been given a fresh CSV export of the company’s help-desk system.
Your goal is to process this data to produce specific outputs.

Initial material that already exists in the system
*   CSV file: `/home/user/data/support_tickets.csv`
    *   It contains a header line followed by exactly ten ticket records (see below for the precise column order).
*   Directory: `/home/user/output/` (already created and writeable by you)

The CSV structure (already correct, do NOT alter its header):
`ticket_id,created_date,assignee,status`

TASKS TO PERFORM
1.  Determine how many tickets are currently in status “OPEN” and print that single number to the terminal **exactly** in this format (including the keyword and the equals sign, no extra spaces or lines):
    `OPEN_TICKETS=<number>`

2.  From `/home/user/data/support_tickets.csv`, extract ONLY the open tickets and create a new file named
    `/home/user/output/open_tickets.list`
    Requirements for that file:
    *   One ticket per line.
    *   For each ticket write only “ticket\_id,assignee” (comma-separated, no spaces).
    *   No header line.
    *   The file must end with a trailing newline.

3.  Normalise the dates for CLOSED tickets and write them into a second file named
    `/home/user/output/closed_tickets_normalized.csv`
    Requirements for that file:
    *   Retain the original header line unchanged.
    *   Include ONLY the tickets whose status is CLOSED.
    *   Change the `created_date` field format from `MM/DD/YYYY` to `YYYY-MM-DD`.
    *   Append one summary line at the very end of the file (after the closed tickets) in the exact form:
        `TOTAL_CLOSED=<number>`
    *   The file must end with one trailing newline.

CONSTRAINTS
*   No manual editing; everything must be done via the shell.
*   Do NOT modify the original `/home/user/data/support_tickets.csv` file.

The automated grader will check:
a) Your terminal output contains exactly one line matching “OPEN\_TICKETS=5”.
b) `/home/user/output/open_tickets.list` exists and its contents strictly match the specification.
c) `/home/user/output/closed_tickets_normalized.csv` exists and its header, ticket lines, date format, summary line and final newline all match the specification.