#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y python3-pip && \
    pip3 install --no-cache-dir pytest && \
    mkdir -p /home/user/data && \
    mkdir -p /home/user/output

cat > /home/user/data/support_tickets.csv <<'EOF'
ticket_id,created_date,assignee,status
TCK-1001,01/13/2022,alice,OPEN
TCK-1002,01/20/2022,bob,CLOSED
TCK-1003,02/05/2022,charlie,OPEN
TCK-1004,03/14/2022,dan,CLOSED
TCK-1005,03/18/2022,alice,CLOSED
TCK-1006,04/07/2023,bob,OPEN
TCK-1007,05/11/2023,charlie,CLOSED
TCK-1008,06/22/2023,dan,OPEN
TCK-1009,07/19/2023,alice,CLOSED
TCK-1010,08/01/2023,bob,OPEN
EOF

chmod 644 /home/user/data/support_tickets.csv

chmod 777 /home/user/output

chmod -R a+rX /home/user
