# test_final_state.py
#
# Robust pytest suite that validates the **FINAL** state of the
# operating-system / container after the student has completed the
# awk/sed shell task.
#
# The suite verifies that:
#   1. The original CSV file is still intact and unaltered.
#   2. /home/user/output/open_tickets.list exists and is exactly correct.
#   3. /home/user/output/closed_tickets_normalized.csv exists and is
#      exactly correct (header, date format, summary line, trailing newline).
#
# The assertions give very explicit failure messages so the student
# immediately sees what is still wrong.
#
# Only the Python standard library and pytest are used.

import re
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# CONSTANTS – expected truth data
# ---------------------------------------------------------------------------

CSV_PATH = Path("/home/user/data/support_tickets.csv")
OPEN_LIST_PATH = Path("/home/user/output/open_tickets.list")
CLOSED_CSV_PATH = Path("/home/user/output/closed_tickets_normalized.csv")

# Full, immutable contents of the original CSV file
ORIGINAL_CSV_LINES = [
    "ticket_id,created_date,assignee,status",
    "TCK-1001,01/13/2022,alice,OPEN",
    "TCK-1002,01/20/2022,bob,CLOSED",
    "TCK-1003,02/05/2022,charlie,OPEN",
    "TCK-1004,03/14/2022,dan,CLOSED",
    "TCK-1005,03/18/2022,alice,CLOSED",
    "TCK-1006,04/07/2023,bob,OPEN",
    "TCK-1007,05/11/2023,charlie,CLOSED",
    "TCK-1008,06/22/2023,dan,OPEN",
    "TCK-1009,07/19/2023,alice,CLOSED",
    "TCK-1010,08/01/2023,bob,OPEN",
]

# Expected contents for /home/user/output/open_tickets.list
OPEN_LIST_LINES = [
    "TCK-1001,alice",
    "TCK-1003,charlie",
    "TCK-1006,bob",
    "TCK-1008,dan",
    "TCK-1010,bob",
]

# Expected contents for /home/user/output/closed_tickets_normalized.csv
CLOSED_CSV_LINES = [
    "ticket_id,created_date,assignee,status",
    "TCK-1002,2022-01-20,bob,CLOSED",
    "TCK-1004,2022-03-14,dan,CLOSED",
    "TCK-1005,2022-03-18,alice,CLOSED",
    "TCK-1007,2023-05-11,charlie,CLOSED",
    "TCK-1009,2023-07-19,alice,CLOSED",
    "TOTAL_CLOSED=5",
]

# Regex used to validate ISO-style date strings YYYY-MM-DD
ISO_DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}$")

# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def _read_text_lines(path: Path):
    """
    Read the file, return a list produced by str.splitlines().
    Newline characters are stripped so we can compare lists directly.
    """
    return path.read_text(encoding="utf-8").splitlines()


def _assert_single_trailing_newline(path: Path):
    """
    Ensure the file ends with exactly ONE trailing '\n'.
    """
    raw = path.read_bytes()
    assert raw.endswith(b"\n"), f"{path} is missing the required trailing newline."
    assert not raw.endswith(
        b"\n\n"
    ), f"{path} has more than one trailing newline – only one is allowed."


# ---------------------------------------------------------------------------
# TESTS
# ---------------------------------------------------------------------------


def test_original_csv_intact():
    """
    The source CSV must remain absolutely untouched after the student's work.
    """
    assert CSV_PATH.exists() and CSV_PATH.is_file(), (
        "The original CSV file is missing or not a regular file. "
        "It must remain exactly where it was."
    )
    lines = _read_text_lines(CSV_PATH)
    assert lines == ORIGINAL_CSV_LINES, (
        "The source CSV file /home/user/data/support_tickets.csv has been altered.\n"
        "It must stay exactly as originally provided."
    )
    _assert_single_trailing_newline(CSV_PATH)


# ---------------------------------------------------------------------------
# OPEN  T I C K E T S   L I S T
# ---------------------------------------------------------------------------


def test_open_tickets_list_exists():
    """
    The open tickets list must exist and be a regular file.
    """
    assert OPEN_LIST_PATH.exists(), (
        f"{OPEN_LIST_PATH} does not exist. "
        "Did you create the file in the correct directory?"
    )
    assert OPEN_LIST_PATH.is_file(), f"{OPEN_LIST_PATH} exists but is not a file."


def test_open_tickets_list_contents():
    """
    File must contain the correct tickets, in the correct order, and nothing else.
    """
    _assert_single_trailing_newline(OPEN_LIST_PATH)
    lines = _read_text_lines(OPEN_LIST_PATH)
    assert (
        lines == OPEN_LIST_LINES
    ), f"Contents of {OPEN_LIST_PATH} are incorrect.\nExpected:\n{OPEN_LIST_LINES}\nFound:\n{lines}"


# ---------------------------------------------------------------------------
# C L O S E D   T I C K E T S   N O R M A L I S E D   C S V
# ---------------------------------------------------------------------------


def test_closed_tickets_csv_exists():
    """
    The closed tickets CSV must exist and be a regular file.
    """
    assert CLOSED_CSV_PATH.exists(), (
        f"{CLOSED_CSV_PATH} does not exist. "
        "Did you create the file in the correct directory?"
    )
    assert CLOSED_CSV_PATH.is_file(), f"{CLOSED_CSV_PATH} exists but is not a file."


def test_closed_tickets_csv_contents():
    """
    Verify header line, closed ticket lines with ISO date conversion,
    and the summary line TOTAL_CLOSED=<n>.
    """
    _assert_single_trailing_newline(CLOSED_CSV_PATH)
    lines = _read_text_lines(CLOSED_CSV_PATH)

    # 1. Overall correctness
    assert (
        lines == CLOSED_CSV_LINES
    ), f"Contents of {CLOSED_CSV_PATH} are incorrect.\nExpected:\n{CLOSED_CSV_LINES}\nFound:\n{lines}"

    # 2. Header line unchanged
    assert (
        lines[0] == ORIGINAL_CSV_LINES[0]
    ), "Header line in closed_tickets_normalized.csv must be identical to the original CSV header."

    # 3. Date format check for each CLOSED ticket line (skip header & summary)
    for line in lines[1:-1]:
        parts = line.split(",")
        assert len(parts) == 4, (
            f"Line '{line}' is malformed – expected 4 comma-separated fields."
        )
        created_date = parts[1]
        assert ISO_DATE_RE.fullmatch(
            created_date
        ), f"Date '{created_date}' is not in required YYYY-MM-DD format."

    # 4. Summary line format
    summary = lines[-1]
    assert summary.startswith(
        "TOTAL_CLOSED="
    ), "The final line must start exactly with 'TOTAL_CLOSED='."
    try:
        n_closed_in_summary = int(summary.split("=", 1)[1])
    except Exception as exc:  # noqa: BLE001
        raise AssertionError(
            f"Unable to parse integer from summary line '{summary}'."
        ) from exc

    # 5. Summary count must match the number of CLOSED ticket lines we found
    n_ticket_lines = len(lines) - 2  # subtract header and summary
    assert (
        n_closed_in_summary == n_ticket_lines
    ), f"TOTAL_CLOSED={n_closed_in_summary} does not match the actual number of closed tickets ({n_ticket_lines})."


# ---------------------------------------------------------------------------
# HIGH-LEVEL CONSISTENCY CHECKS
# ---------------------------------------------------------------------------


def test_consistency_between_open_and_closed_files():
    """
    Ensure there is no overlap and that the counts add up to the original
    ten records.
    """
    open_ids = {ln.split(",")[0] for ln in OPEN_LIST_LINES}
    closed_ids = {ln.split(",")[0] for ln in CLOSED_CSV_LINES[1:-1]}  # skip header/summary

    intersection = open_ids & closed_ids
    assert (
        not intersection
    ), f"The same ticket(s) appear in both open and closed files: {sorted(intersection)}"

    # 10 data records total were provided initially.
    total_records_accounted_for = len(open_ids) + len(closed_ids)
    assert (
        total_records_accounted_for == 10
    ), f"Expected to account for 10 tickets in total, but found {total_records_accounted_for}."