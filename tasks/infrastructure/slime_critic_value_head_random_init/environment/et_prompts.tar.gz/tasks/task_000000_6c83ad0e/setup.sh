#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3 python3-pip && \
    pip3 install --no-cache-dir pytest && \
    true

mkdir -p /home/user/network/logs && \
    chmod 0777 /home/user /home/user/network /home/user/network/logs

python3 - <<'PY'
import os, codecs

dir_path = "/home/user/network/logs"
file_path = os.path.join(dir_path, "connection_report_utf16le.txt")

lines = [
    "2023-07-21 10:12:05 192.168.1.10 OK\r\n",
    "2023-07-21 10:14:27 192.168.1.11 FAILED\r\n",
    "2023-07-21 10:15:32 192.168.1.12 OK\r\n",
    "2023-07-21 10:17:43 192.168.1.13 FAILED\r\n",
]

with open(file_path, "wb") as fb:
    # Write UTF-16 LE BOM
    fb.write(codecs.BOM_UTF16_LE)
    # Encode each line as UTF-16 LE and write them
    for line in lines:
        fb.write(line.encode("utf-16-le"))

# Permissions: 0644 (rw-r--r--) — accepted by the tests
os.chmod(file_path, 0o644)
PY

chmod 755 /home/user
