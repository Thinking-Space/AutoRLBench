# test_final_state.py
#
# Pytest suite that validates the FINAL operating-system / filesystem state
# after the student has completed the “connection-health report” task.
#
# We assert that:
#   A. /home/user/network/logs/connection_report_utf8.txt
#        • exists
#        • permissions are 0644 or stricter
#        • encoded in plain UTF-8 (NO BOM)
#        • contains exactly four lines, each terminated by a single LF (0x0A)
#          with NO carriage-return characters (0x0D) anywhere in the file
#        • text matches the expected order and content
#
#   B. /home/user/network/logs/failed_connections.log
#        • exists
#        • permissions are 0644 or stricter
#        • encoded in plain UTF-8 (NO BOM)
#        • contains exactly two lines, each terminated by a single LF (0x0A)
#          with NO carriage-return characters (0x0D)
#        • text matches the expected order and content
#
# Any deviation from the required state will cause a test failure that
# explicitly explains what is still wrong.
#
# Only the Python standard library and pytest are used.

import os
import stat
import pytest

DIR_PATH = "/home/user/network/logs"

UTF8_REPORT = os.path.join(DIR_PATH, "connection_report_utf8.txt")
FAILED_ONLY  = os.path.join(DIR_PATH, "failed_connections.log")

# ---------------------------------------------------------------------------
# Expected textual content (each string already includes its terminating '\n')
# ---------------------------------------------------------------------------

_EXPECTED_REPORT_LINES = [
    "2023-07-21 10:12:05 192.168.1.10 OK\n",
    "2023-07-21 10:14:27 192.168.1.11 FAILED\n",
    "2023-07-21 10:15:32 192.168.1.12 OK\n",
    "2023-07-21 10:17:43 192.168.1.13 FAILED\n",
]

_EXPECTED_FAILED_LINES = [
    "2023-07-21 10:14:27 192.168.1.11 FAILED\n",
    "2023-07-21 10:17:43 192.168.1.13 FAILED\n",
]

# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------

def _mode_is_no_more_permissive_than(path: str, reference: int) -> bool:
    """
    Return True if *path* has permissions that are the same as, or stricter
    than, *reference* (octal).  E.g. 0600 is stricter than 0644.
    """
    st_mode = os.stat(path).st_mode
    return (st_mode & 0o777) <= reference


def _check_utf8_file(path: str, expected_lines: list[str]) -> None:
    """
    Common validator for the two required UTF-8 files.
      • Ensures file exists & has proper permissions
      • Ensures no BOM and no CR characters
      • Ensures text decodes as UTF-8
      • Ensures *exact* line content and count
    """
    assert os.path.isfile(path), f"Required file {path!r} is missing."

    assert _mode_is_no_more_permissive_than(path, 0o644), (
        f"File {path!r} permissions are too permissive. "
        "They must be 0644 or stricter."
    )

    # Read raw bytes so we can look for BOMs and carriage returns.
    with open(path, "rb") as fb:
        raw = fb.read()

    # 1. BOM checks ─ the first bytes must NOT match any common BOM.
    assert not raw.startswith(b"\xef\xbb\xbf"), (
        f"File {path!r} must NOT contain a UTF-8 BOM (EF BB BF)."
    )
    assert not raw.startswith(b"\xff\xfe") and not raw.startswith(b"\xfe\xff"), (
        f"File {path!r} appears to be UTF-16 encoded; it must be plain UTF-8."
    )

    # 2. No carriage-return characters anywhere in the file.
    assert b"\r" not in raw, (
        f"File {path!r} contains one or more carriage-return characters (0x0D). "
        "All lines must be terminated by LF only."
    )

    # 3. Decode as UTF-8; will raise UnicodeDecodeError automatically if bad.
    text = raw.decode("utf-8")

    # 4. Split into lines keeping the terminators so we can compare precisely.
    lines = text.splitlines(keepends=True)

    assert lines == expected_lines, (
        f"Content of {path!r} is incorrect.\n"
        f"Expected lines:\n{expected_lines!r}\n"
        f"Found lines:\n{lines!r}"
    )

# ---------------------------------------------------------------------------
# Actual tests
# ---------------------------------------------------------------------------

def test_connection_report_utf8_file_is_correct():
    """
    Validate /home/user/network/logs/connection_report_utf8.txt
    """
    _check_utf8_file(UTF8_REPORT, _EXPECTED_REPORT_LINES)


def test_failed_connections_log_is_correct():
    """
    Validate /home/user/network/logs/failed_connections.log
    """
    _check_utf8_file(FAILED_ONLY, _EXPECTED_FAILED_LINES)