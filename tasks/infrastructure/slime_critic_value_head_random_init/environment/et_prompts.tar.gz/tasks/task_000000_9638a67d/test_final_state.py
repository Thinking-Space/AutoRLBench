# test_final_state.py
#
# This pytest suite validates the REQUIRED END-STATE after the learner has
# completed the “log-analysis exercise”.
#
# It checks that /home/user/app/logs/test_summary.txt exists and matches
# EXACTLY the content and formatting rules described in the public task
# description.  Any deviation – wrong counts, wrong ordering, extra / missing
# whitespace, etc. – will fail the tests with a clear explanation.
#
# Only the standard library and pytest are used.

import os
import re
import datetime
import pytest

# ---------------------------------------------------------------------------
# Static paths used by both the task instructions and these tests
# ---------------------------------------------------------------------------

LOG_DIR = "/home/user/app/logs"
LOG_PATH = os.path.join(LOG_DIR, "app.log")
SUMMARY_PATH = os.path.join(LOG_DIR, "test_summary.txt")

# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------

def _read_file_lines(path):
    """
    Return the file’s lines with their trailing newlines stripped.
    splitlines() is deliberately used so NO empty sentinel is added when the
    file ends with a trailing “\n”.
    """
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read().splitlines()


def _counts_from_log():
    """Return a dict with the INFO/WARN/ERROR line counts in app.log."""
    lines = _read_file_lines(LOG_PATH)
    return {
        "ERROR": sum("[ERROR]" in ln for ln in lines),
        "WARN":  sum("[WARN]"  in ln for ln in lines),
        "INFO":  sum("[INFO]"  in ln for ln in lines),
        "lines": lines,  # keep the raw lines for further inspection
    }


def _last_n_error_lines(lines, n=3):
    """
    Return the last `n` ERROR lines (newest first) from the full log `lines`.
    The file is already chronological, so we can walk backwards.
    """
    error_lines = [ln for ln in lines if "[ERROR]" in ln]
    # Reverse-chronological order ⇒ reverse the list and slice.
    return list(reversed(error_lines))[:n]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_summary_file_exists_and_is_file():
    assert os.path.isfile(SUMMARY_PATH), (
        "Required summary file is missing: "
        f"{SUMMARY_PATH!r}."
    )


@pytest.fixture(scope="module")
def summary_lines():
    """Provide the list of lines from test_summary.txt to all tests."""
    return _read_file_lines(SUMMARY_PATH)


def test_summary_has_exactly_8_nonblank_lines(summary_lines):
    assert len(summary_lines) == 8, (
        "test_summary.txt must contain EXACTLY 8 lines "
        f"(found {len(summary_lines)})."
    )
    blank_lines = [idx + 1 for idx, ln in enumerate(summary_lines) if ln == ""]
    assert not blank_lines, (
        "test_summary.txt contains blank line(s) at: "
        + ", ".join(map(str, blank_lines))
    )


def test_no_leading_or_trailing_whitespace(summary_lines):
    offenders = [
        (idx + 1, ln)
        for idx, ln in enumerate(summary_lines)
        if ln != ln.strip()
    ]
    assert not offenders, (
        "The following line(s) have unexpected leading/trailing whitespace:\n"
        + "\n".join(f"Line {lnum}: {repr(text)}" for lnum, text in offenders)
    )


def test_line_1_report_generated_date(summary_lines):
    """
    Line 1 must be:  REPORT_GENERATED=YYYY-MM-DD
    – Date must be *today* in the container’s local time.
    """
    line = summary_lines[0]
    msg_prefix = "Line 1 must follow the format 'REPORT_GENERATED=YYYY-MM-DD'.\n"
    assert line.startswith("REPORT_GENERATED="), msg_prefix + f"Found: {line!r}"

    # Extract & validate the date
    date_part = line[len("REPORT_GENERATED="):]
    date_re = re.compile(r"^\d{4}-\d{2}-\d{2}$")
    assert date_re.match(date_part), (
        msg_prefix + f"Date portion malformed: {date_part!r}"
    )

    # Check it is today's date (local clock)
    today = datetime.datetime.now().astimezone().date()
    expected = today.strftime("%Y-%m-%d")
    assert date_part == expected, (
        "REPORT_GENERATED date is incorrect – should be today's date.\n"
        f"Expected: {expected}\n"
        f"Found   : {date_part}"
    )


def test_lines_2_to_4_contain_correct_counts(summary_lines):
    """
    Validate:
      Line 2: ERROR_COUNT=<int>
      Line 3: WARN_COUNT=<int>
      Line 4: INFO_COUNT=<int>
    Values must match the real counts inside app.log.
    """
    counts = _counts_from_log()

    # Expected mappings: field name -> expected value
    expected_map = {
        "ERROR_COUNT": counts["ERROR"],
        "WARN_COUNT": counts["WARN"],
        "INFO_COUNT": counts["INFO"],
    }

    for idx, (field, expected_value) in enumerate(expected_map.items(), start=2):
        line = summary_lines[idx - 1]  # lines are 0-based index
        prefix = f"{field}="
        assert line.startswith(prefix), (
            f"Line {idx} must start with {prefix!r}.\nFound: {line!r}"
        )
        value_part = line[len(prefix):]
        assert value_part.isdigit(), (
            f"Line {idx} value for {field} must be an integer.\nFound: {line!r}"
        )
        value_int = int(value_part)
        assert value_int == expected_value, (
            f"Line {idx} {field} is incorrect.\n"
            f"Expected: {expected_value}\nFound   : {value_int}"
        )


def test_line_5_is_correct_separator(summary_lines):
    expected = "--LAST_3_ERRORS--"
    assert summary_lines[4] == expected, (
        f"Line 5 must be exactly {expected!r} (no additional spaces).\n"
        f"Found: {summary_lines[4]!r}"
    )


def test_lines_6_to_8_match_last_three_error_lines(summary_lines):
    """
    Lines 6-8 must be:
      1. <latest-error-line>
      2. <2nd-latest-error-line>
      3. <3rd-latest-error-line>
    The log lines must match *exactly* what appears in app.log, only prefixed
    with '1. ', '2. ', '3. ' respectively.
    """
    log_info = _counts_from_log()
    expected_errors = _last_n_error_lines(log_info["lines"], n=3)

    for i in range(3):
        line_number_in_file = 6 + i     # human-readable line number (starts at 1)
        expected_prefix = f"{i + 1}. "
        summary_line = summary_lines[5 + i]  # 0-based index

        assert summary_line.startswith(expected_prefix), (
            f"Line {line_number_in_file} must start with {expected_prefix!r}.\n"
            f"Found: {summary_line!r}"
        )

        expected_full_line = expected_prefix + expected_errors[i]
        assert summary_line == expected_full_line, (
            f"Line {line_number_in_file} does not match the required error line.\n"
            f"Expected: {expected_full_line!r}\n"
            f"Found   : {summary_line!r}"
        )