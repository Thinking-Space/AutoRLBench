#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    echo "Updating package lists and installing Python tooling..." && \
    apt-get update -qq && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends python3-pip && \
    true && \
    echo "Installing pytest so that test suites can run inside the container..." && \
    pip3 install --no-cache-dir pytest && \
    mkdir -p /home/user/app/logs

cat > /home/user/app/logs/app.log <<'EOF'
2023-09-15 10:15:21 [INFO] Application started
2023-09-15 10:15:22 [INFO] Loading configuration
2023-09-15 10:15:23 [WARN] Deprecated config option used
2023-09-15 10:15:24 [ERROR] Failed to connect to database
2023-09-15 10:15:25 [INFO] Retrying connection
2023-09-15 10:15:26 [ERROR] Failed to connect to database
2023-09-15 10:15:27 [WARN] Using fallback settings
2023-09-15 10:15:28 [INFO] Starting processing loop
2023-09-15 10:16:00 [INFO] Processed 100 records
2023-09-15 10:16:05 [ERROR] Unexpected null pointer
2023-09-15 10:16:10 [INFO] Shutting down
2023-09-15 10:16:11 [INFO] Application stopped
2023-09-16 09:00:00 [INFO] Application started
2023-09-16 09:00:01 [WARN] Low disk space
2023-09-16 09:00:02 [ERROR] Disk write failed
2023-09-16 09:00:03 [INFO] Cleanup complete
EOF

chmod 0777 /home/user/app/logs && \
    chmod 0644 /home/user/app/logs/app.log && \
    mkdir -p /home/user && chmod 755 /home/user

export PATH="/usr/local/bin:$PATH"
