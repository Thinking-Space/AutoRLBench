You are a QA engineer preparing a very small proof-of-concept log-analysis exercise for a new junior teammate.
A sample application log already exists on the machine; you only need to analyse it and produce a concise summary file for verification.

### 1. Log location
*   **Full path**: `/home/user/app/logs/app.log`
*   The file already exists; do **not** edit it.

### 2. What you must create
*   A new text file called **test_summary.txt** in the same directory:
    `/home/user/app/logs/test_summary.txt`

### 3. What the summary file must contain
*   Exactly 8 lines, no extra blank lines or spaces at the start/end of any line.
*   Fixed order and spelling shown below.

    ```
    Line 1  REPORT_GENERATED=YYYY-MM-DD
    Line 2  ERROR_COUNT=<number>
    Line 3  WARN_COUNT=<number>
    Line 4  INFO_COUNT=<number>
    Line 5  --LAST_3_ERRORS--
    Line 6  1. <full log line of the most recent ERROR>
    Line 7  2. <full log line of the 2nd most recent ERROR>
    Line 8  3. <full log line of the 3rd most recent ERROR>
    ```
    *   **Line 1**: Replace `YYYY-MM-DD` with today’s date in the container’s local time, using four-digit year, two-digit month, two-digit day (e.g. `2024-04-07`).
    *   “Most recent” is determined purely by timestamp order in `app.log` (the file is already sorted by time).
    *   Keep the exact text of each error line, including the leading index (“1. ”, “2. ”, “3. ”).

### 4. Verification expectations (what the script will check)
*   Line 2 must show the total count of lines in `app.log` containing `[ERROR]`.
*   Line 3 must show the total count of lines containing `[WARN]`.
*   Line 4 must show the total count of lines containing `[INFO]`.
*   Lines 6-8 must list the latest three error lines in reverse-chronological order (newest first).
    All spacing and characters must be identical to the corresponding lines found in `app.log`, except for the prefixed “1. ”, “2. ”, “3. ”.

When you are done, `/home/user/app/logs/test_summary.txt` must exist and conform exactly to the 8-line layout above so that the automated grader can validate it.