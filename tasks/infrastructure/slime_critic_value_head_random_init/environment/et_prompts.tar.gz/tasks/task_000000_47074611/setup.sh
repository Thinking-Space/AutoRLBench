#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update -y && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3 \
        python3-pip \
        ca-certificates \
        locales \
        sed \
        gawk && \
    pip3 install --no-cache-dir pytest && \
    mkdir -p /home/user/qa_logs

cat <<'EOF' > /home/user/qa_logs/suite1.log
[2023-08-12 10:12:01] TEST test_login ..... PASS
[2023-08-12 10:12:02] TEST test_logout ..... FAIL
[2023-08-12 10:12:03] TEST test_signup ..... SKIP
[2023-08-12 10:12:04] TEST test_profile_update ..... PASS
[2023-08-12 10:12:05] TEST test_password_reset ..... PASS
EOF

cat <<'EOF' > /home/user/qa_logs/suite2.log
[2023-08-12 11:15:11] TEST api_fetch_user ..... PASS
[2023-08-12 11:15:12] TEST api_create_user ..... FAIL
[2023-08-12 11:15:13] TEST api_delete_user ..... FAIL
[2023-08-12 11:15:14] TEST api_update_user ..... PASS
EOF

chmod -R a+rX /home/user && \
    chmod 0777 /home/user/qa_logs && \
    apt-get clean && \
    true

export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"
