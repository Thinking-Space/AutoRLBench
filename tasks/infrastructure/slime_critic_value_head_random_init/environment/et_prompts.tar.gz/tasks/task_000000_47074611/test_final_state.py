# test_final_state.py
#
# Pytest suite that validates the **state of the OS/container AFTER** the
# student has finished the exercise.  It checks that the two “clean” log
# files and the CSV summary report exist and match the specification exactly.
#
# Only the Python standard library and pytest are used.

from pathlib import Path
import csv
import pytest

QA_DIR = Path("/home/user/qa_logs")

# --------------------------------------------------------------------------- #
# “Ground-truth” strings for the two expected clean log files.
# Each line *must* end with a single '\n'.
# --------------------------------------------------------------------------- #

EXPECTED_SUITE1_CLEAN = (
    "TEST test_login ..... PASS\n"
    "TEST test_logout ..... FAIL\n"
    "TEST test_signup ..... SKIP\n"
    "TEST test_profile_update ..... PASS\n"
    "TEST test_password_reset ..... PASS\n"
)

EXPECTED_SUITE2_CLEAN = (
    "TEST api_fetch_user ..... PASS\n"
    "TEST api_create_user ..... FAIL\n"
    "TEST api_delete_user ..... FAIL\n"
    "TEST api_update_user ..... PASS\n"
)

CLEAN_LOGS = {
    "suite1_clean.log": EXPECTED_SUITE1_CLEAN,
    "suite2_clean.log": EXPECTED_SUITE2_CLEAN,
}

SUMMARY_CSV = QA_DIR / "summary_report.csv"


# --------------------------------------------------------------------------- #
# Helper functions
# --------------------------------------------------------------------------- #

def _compute_status_counts(clean_log_text: str):
    """
    Given the full text of a clean log file, return a dictionary with counts of
    PASS / FAIL / SKIP and the total number of lines.
    """
    counts = {"PASS": 0, "FAIL": 0, "SKIP": 0}
    lines = [ln for ln in clean_log_text.splitlines() if ln]  # ignore empty
    for ln in lines:
        # Status is expected to be the very last token in the line.
        status = ln.rsplit(maxsplit=1)[-1]
        assert status in counts, (
            f"Unexpected status '{status}' encountered in line:\n{ln!r}"
        )
        counts[status] += 1
    counts["TOTAL"] = len(lines)
    return counts


def _load_csv_rows(csv_path: Path):
    """
    Load the CSV file into a list of rows (each row is a list of strings).
    The CSV **must** be comma-separated with no spurious spaces.
    """
    with csv_path.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.reader(fh)
        rows = list(reader)
    return rows


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize("filename,expected_content", CLEAN_LOGS.items())
def test_clean_log_exists_and_is_exact(filename, expected_content):
    """
    1. The *_clean.log files must exist.
    2. Their contents must exactly equal the expected, byte-for-byte.
       - Every line must start with the literal 'TEST'.
       - No leading timestamps or stray whitespace may be present.
       - Line ordering must be preserved.
    """
    path = QA_DIR / filename
    assert path.is_file(), f"Missing clean log: {path}"

    actual = path.read_bytes()
    expected = expected_content.encode("utf-8")

    assert actual == expected, (
        f"Contents of {path} do not match the required sanitized output.\n"
        "--- Expected (truth) -------------------------\n"
        f"{expected_content!r}\n"
        "---- Got -------------------------------------\n"
        f"{actual.decode('utf-8', errors='replace')!r}\n"
        "Fix the sed/awk command so the timestamp is stripped *exactly* as "
        "specified and no additional whitespace is introduced."
    )

    # Additional sanity: ensure each line really begins with 'TEST'.
    for idx, line in enumerate(expected_content.splitlines(), start=1):
        assert line.startswith("TEST"), (
            f"Line {idx} in {filename} does not start with 'TEST': {line!r}"
        )


def test_summary_csv_exists_and_has_exact_three_lines():
    """The summary_report.csv must exist and contain exactly three LF-terminated lines."""
    assert SUMMARY_CSV.is_file(), f"CSV summary report {SUMMARY_CSV} is missing."

    raw_text = SUMMARY_CSV.read_text(encoding="utf-8")
    # Every line must end with '\n', so the file must end with it as well.
    assert raw_text.endswith("\n"), (
        "summary_report.csv is not LF-terminated (last character must be '\\n')."
    )

    lines = raw_text.splitlines()
    assert len(lines) == 3, (
        f"summary_report.csv must contain exactly 3 lines "
        f"(header + 2 suites). Found: {len(lines)} line(s)."
    )


def test_summary_csv_header_is_correct():
    rows = _load_csv_rows(SUMMARY_CSV)
    header = rows[0]
    expected_header = ["suite", "total", "passed", "failed", "skipped"]
    assert header == expected_header, (
        "CSV header row is incorrect.\n"
        f"Expected: {','.join(expected_header)}\n"
        f"Got:      {','.join(header)}"
    )


def test_summary_csv_counts_match_clean_logs():
    """
    Cross-validate the numeric values in summary_report.csv against the counts
    obtained by actually parsing the clean log files.
    """
    # Compute counts from the truth data (we already verified clean logs).
    counts = {
        "suite1": _compute_status_counts(EXPECTED_SUITE1_CLEAN),
        "suite2": _compute_status_counts(EXPECTED_SUITE2_CLEAN),
    }

    rows = _load_csv_rows(SUMMARY_CSV)

    # We already validated header row separately.
    data_rows = rows[1:]

    # Build a dictionary of suite -> row for easy lookup.
    csv_data = {}
    for row in data_rows:
        assert len(row) == 5, (
            "Each CSV data row must have exactly 5 comma-separated fields.\n"
            f"Problematic row: {row}"
        )
        suite, total, passed, failed, skipped = row
        csv_data[suite] = {
            "TOTAL": int(total),
            "PASS": int(passed),
            "FAIL": int(failed),
            "SKIP": int(skipped),
        }

    # Ensure both suite1 and suite2 rows are present.
    for suite_key in ("suite1", "suite2"):
        assert suite_key in csv_data, (
            f"Missing row for {suite_key} in summary_report.csv."
        )
        expected = counts[suite_key]
        got = csv_data[suite_key]

        # Detailed per-column comparison with clear failure messages.
        assert got["TOTAL"] == expected["TOTAL"], (
            f"{suite_key}: total count incorrect. "
            f"Expected {expected['TOTAL']}, got {got['TOTAL']}."
        )
        assert got["PASS"] == expected["PASS"], (
            f"{suite_key}: passed count incorrect. "
            f"Expected {expected['PASS']}, got {got['PASS']}."
        )
        assert got["FAIL"] == expected["FAIL"], (
            f"{suite_key}: failed count incorrect. "
            f"Expected {expected['FAIL']}, got {got['FAIL']}."
        )
        assert got["SKIP"] == expected["SKIP"], (
            f"{suite_key}: skipped count incorrect. "
            f"Expected {expected['SKIP']}, got {got['SKIP']}."
        )