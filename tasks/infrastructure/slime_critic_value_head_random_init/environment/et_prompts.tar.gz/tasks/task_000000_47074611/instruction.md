You are a QA engineer preparing a lightweight analysis of two test-suite logs that already exist on the system.

1.  **Location & initial data**
    *   Directory: `/home/user/qa_logs`
    *   Pre-existing files:
        a) `/home/user/qa_logs/suite1.log`
        b) `/home/user/qa_logs/suite2.log`
    Both logs follow *exactly* the same line format:
    `[YYYY-MM-DD HH:MM:SS] TEST <test-name> ..... <STATUS>`
    where STATUS ∈ {PASS, FAIL, SKIP}.

2.  **Goal**
    Create two “sanitized” log files that are stripped of their leading timestamp (the part enclosed in square brackets plus the trailing space) and then generate a concise CSV summary report that counts results per suite.

3.  **Required artefacts & precise formats**
    *   Sanitized logs
        - `/home/user/qa_logs/suite1_clean.log`
        - `/home/user/qa_logs/suite2_clean.log`
        Each line must keep exactly the substring starting with the literal word “TEST”; everything before “TEST” (including the brackets and the following space) must be removed. **Do not change the ordering of lines or alter white-space that appears after “TEST &lt;test-name&gt;”.**
    *   Summary report
        - `/home/user/qa_logs/summary_report.csv`
        The file must contain three lines in plain UTF-8, line-feed terminated (Unix LF), in the following strict format:
        Line-1 (header):
        ```
        suite,total,passed,failed,skipped
        ```
        Line-2 (suite1 statistics):
        ```
        suite1,<TOTAL1>,<PASSED1>,<FAILED1>,<SKIPPED1>
        ```
        Line-3 (suite2 statistics):
        ```
        suite2,<TOTAL2>,<PASSED2>,<FAILED2>,<SKIPPED2>
        ```
        Replace the angle-bracketed placeholders with the numeric counts computed from the *sanitized* logs. The order of columns and rows must match the example exactly; no additional spaces are allowed.

4.  **Constraints**
    *   Do not move or rename any files except as specified above.
    *   Do not manually type the final numbers; they must be produced programmatically.

5.  **Verification hint**
    Automated grading will confirm:
    *   Existence of both `*_clean.log` files.
    *   That each `*_clean.log` line begins with the literal “TEST”.
    *   Correct numerical values and exact CSV formatting of `/home/user/qa_logs/summary_report.csv`.

When you are done, list the contents of `/home/user/qa_logs/summary_report.csv` to show the final result.