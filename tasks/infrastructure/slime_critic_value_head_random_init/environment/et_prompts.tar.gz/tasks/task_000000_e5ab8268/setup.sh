#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3 \
        python3-pip && \
    pip3 install --no-cache-dir pytest

mkdir -p /home/user/sample_logs

cat > /home/user/sample_logs/system.log <<'EOF'
Jul 10 11:23:56 server sshd[2345]: Failed password for invalid user admin from 10.0.0.55 port 54322 ssh2
Jul 10 11:23:58 server sshd[2346]: Failed password for invalid user admin from 10.0.0.55 port 54323 ssh2
Jul 10 11:24:02 server sshd[2347]: Accepted password for user1 from 192.168.1.10 port 54411 ssh2
Jul 10 11:25:01 server sshd[2348]: Failed password for invalid user root from 203.0.113.99 port 51720 ssh2
Jul 10 11:25:13 server sshd[2351]: Failed password for root from 203.0.113.99 port 51721 ssh2
Jul 10 11:26:30 server sshd[2355]: Failed password for invalid user admin from 10.0.0.55 port 54324 ssh2
Jul 10 11:27:00 server cron[1111]: pam_unix(cron:session): session opened for user root(uid=0) by (uid=0)
Jul 10 11:28:45 server sshd[2359]: Failed password for root from 198.51.100.77 port 51800 ssh2
EOF

chmod 0644 /home/user/sample_logs/system.log && \
    chmod 0755 /home/user/sample_logs && \
    chmod 755 /home/user
