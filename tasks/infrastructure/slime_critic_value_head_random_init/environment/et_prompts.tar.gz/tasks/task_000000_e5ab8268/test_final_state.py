# test_final_state.py
#
# Pytest suite that validates the **final** operating-system / filesystem
# state **after** the student has completed the incident-summary task.
#
# What we verify (and nothing more):
# 1. /home/user/incident_scan exists and is a directory.
# 2. /home/user/incident_scan/summary.log exists, is a regular file, is
#    world-readable (0644 is fine) and non-empty.
# 3. The file content follows the exact template:
#       # Incident Summary
#       FAILED_ATTEMPTS: <int>
#       SUSPICIOUS_IPS:
#       - <ip1>
#       - <ip2>
#       TOP_OFFENDER: <ip>
#    with the values mathematically correct when compared to
#    /home/user/sample_logs/system.log.
# 4. No extra/missing keys, no extra blank lines, no trailing spaces,
#    the ordering is exactly as above, and the list of IPs is lexically
#    sorted.
#
# Failures clearly state what is still wrong so the student can correct it.

import pathlib
import stat
import re
import pytest
from typing import List, Dict

HOME = pathlib.Path("/home/user")
SAMPLE_DIR = HOME / "sample_logs"
SYSTEM_LOG = SAMPLE_DIR / "system.log"

INCIDENT_DIR = HOME / "incident_scan"
SUMMARY_LOG = INCIDENT_DIR / "summary.log"


# --------------------------------------------------------------------------- #
# Helpers                                                                     #
# --------------------------------------------------------------------------- #
FAILED_RE = re.compile(r"Failed password .* from (?P<ip>\d+\.\d+\.\d+\.\d+)\b")


def _extract_failed_auth_statistics() -> Dict[str, int]:
    """
    Parse /home/user/sample_logs/system.log and return a dictionary
    mapping ip -> number_of_failures for all lines that contain the
    exact substring 'Failed password'.
    """
    if not SYSTEM_LOG.exists():
        pytest.skip(f"Cannot compute expected values; {SYSTEM_LOG} is missing.")

    text = SYSTEM_LOG.read_text(encoding="utf-8")
    ip_counts: Dict[str, int] = {}
    for line in text.splitlines():
        if "Failed password" not in line:
            continue
        match = FAILED_RE.search(line)
        assert (
            match is not None
        ), f"Regex failed to extract IP from line:\n{line!r}. "\
           "Update the regex in the test suite."
        ip = match.group("ip")
        ip_counts[ip] = ip_counts.get(ip, 0) + 1
    return ip_counts


def _expected_summary_lines() -> List[str]:
    """
    Build the list of *exact* lines (without trailing newline characters)
    that we expect to find in summary.log, based on the ground-truth
    statistics extracted from system.log.
    """
    ip_counts = _extract_failed_auth_statistics()
    total_failed = sum(ip_counts.values())

    suspicious_ips = sorted(ip for ip, cnt in ip_counts.items() if cnt > 1)

    # Determine the top offender.  On ties pick the lexically first IP.
    if not ip_counts:
        top_offender = ""
    else:
        # Sort by (-count, ip) so that highest count comes first and ties
        # are resolved by lexical order.
        top_offender = sorted(
            ip_counts.items(), key=lambda t: (-t[1], t[0])
        )[0][0]

    lines: List[str] = [
        "# Incident Summary",
        f"FAILED_ATTEMPTS: {total_failed}",
        "SUSPICIOUS_IPS:",
    ]
    lines.extend(f"- {ip}" for ip in suspicious_ips)
    lines.append(f"TOP_OFFENDER: {top_offender}")
    return lines


# --------------------------------------------------------------------------- #
# Real tests                                                                  #
# --------------------------------------------------------------------------- #
def test_incident_dir_exists():
    assert INCIDENT_DIR.exists(), (
        f"Directory {INCIDENT_DIR} is missing. "
        "Create it to store the incident summary."
    )
    assert INCIDENT_DIR.is_dir(), (
        f"{INCIDENT_DIR} exists but is not a directory."
    )


def test_summary_log_exists_and_permissions():
    assert SUMMARY_LOG.exists(), (
        f"Expected summary file {SUMMARY_LOG} is missing."
    )
    assert SUMMARY_LOG.is_file(), f"{SUMMARY_LOG} exists but is not a regular file."
    # The file must be world-readable and not world-writable/executable
    mode = stat.S_IMODE(SUMMARY_LOG.stat().st_mode)
    assert mode & stat.S_IROTH, (
        f"{SUMMARY_LOG} is not world-readable (mode {oct(mode)}). "
        "Ensure permissions are at least 0644."
    )
    assert not (mode & stat.S_IWOTH), (
        f"{SUMMARY_LOG} must not be world-writable (mode {oct(mode)})."
    )
    assert not (mode & stat.S_IXOTH), (
        f"{SUMMARY_LOG} must not be world-executable (mode {oct(mode)})."
    )
    assert SUMMARY_LOG.stat().st_size > 0, f"{SUMMARY_LOG} is empty."


def test_summary_log_format_and_contents():
    content = SUMMARY_LOG.read_text(encoding="utf-8")
    assert content.endswith(
        "\n"
    ), f"{SUMMARY_LOG} must end with exactly one trailing newline."

    # Split into lines, discard the trailing newline character.
    lines = content.rstrip("\n").split("\n")

    expected_lines = _expected_summary_lines()

    # ------------------------------------------------------------------- #
    # 1. Template structure & order                                       #
    # ------------------------------------------------------------------- #
    assert (
        lines == expected_lines
    ), (
        f"{SUMMARY_LOG} does not match the required format or values.\n\n"
        "Expected:\n"
        + "\n".join(expected_lines)
        + "\n\nActual:\n"
        + "\n".join(lines)
    )

    # ------------------------------------------------------------------- #
    # 2. No trailing spaces on any line                                   #
    # ------------------------------------------------------------------- #
    for idx, line in enumerate(lines, start=1):
        assert not line.endswith(" "), (
            f"Line {idx} in {SUMMARY_LOG!s} has trailing spaces: {line!r}"
        )

    # ------------------------------------------------------------------- #
    # 3. No extra blank lines                                             #
    # ------------------------------------------------------------------- #
    # By definition of splitting with rstrip, any blank line would appear
    # as an empty string in `lines`.
    blank_lines = [i for i, l in enumerate(lines, start=1) if l == ""]
    assert (
        not blank_lines
    ), (
        f"{SUMMARY_LOG} contains unexpected blank lines at "
        f"line numbers: {blank_lines}."
    )