You are an on-call operations engineer who has just received an alert about repeated, possibly malicious SSH authentication failures.  
Your goal is to perform a very quick triage by examining the provided log file and writing a single, clearly-structured incident summary that another engineer (or an automated system) can immediately act upon.

Environment already present:
1. Directory: /home/user/sample_logs/  
   • File: /home/user/sample_logs/system.log – a typical, small SSH/cron excerpt that contains both successful and failed login lines.

Desired deliverable:
Create a new directory called /home/user/incident_scan and, inside it, create a UTF-8 text file named summary.log whose contents follow *exactly* the template shown below (same order, capitalisation and punctuation, no extra blank lines, no trailing spaces):

```
# Incident Summary
FAILED_ATTEMPTS: <TOTAL_NUMBER_OF_FAILED_SSH_ATTEMPTS>
SUSPICIOUS_IPS:
- <IP_WITH_MORE_THAN_ONE_FAILURE_1>
- <IP_WITH_MORE_THAN_ONE_FAILURE_2>
TOP_OFFENDER: <IP_ADDRESS_WITH_HIGHEST_NUMBER_OF_FAILURES>
```

Detailed specification of each field the automated test will check:

• FAILED_ATTEMPTS  
  – The integer count of lines in /home/user/sample_logs/system.log that contain the exact substring “Failed password”.

• SUSPICIOUS_IPS  
  – A dash-prefixed YAML-style list of every **unique** source IP address that appears in “Failed password” lines **more than once**.  
  – One IP per line, in ascending lexical order.

• TOP_OFFENDER  
  – The single IP address with the greatest number of “Failed password” occurrences.  
  – If there is a tie, choose the lexically first IP among the tied addresses.

Formatting rules:
1. The first line must be exactly “# Incident Summary”.
2. All other keys must appear in the order shown.  
3. There must be **one** space after every colon (:).  
4. No extra blank lines anywhere in the file.

Operational constraints:
• Work entirely in the user’s home directory tree; you do **not** need elevated privileges.  

Success criteria (what the automated test will look for):
1. /home/user/incident_scan exists and is a directory.
2. /home/user/incident_scan/summary.log exists, is non-empty, and is world-readable (0644 is fine).  
3. The content of summary.log is exactly as specified above and the numeric/IP values are correct according to /home/user/sample_logs/system.log.