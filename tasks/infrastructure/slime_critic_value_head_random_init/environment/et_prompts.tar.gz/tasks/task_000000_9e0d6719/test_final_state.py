# test_final_state.py
#
# This pytest suite validates the **final** state of the workstation _after_
# the student has completed the configuration-editing task.
#
# Success criteria enforced here:
#   • /home/user/project/config/app.yaml        matches the required final text
#   • /home/user/project/config/database.toml   matches the required final text
#   • /home/user/project/config/change_log.txt  exists and matches the required
#     9-line (verbatim) change-log specification
#   • The config directory now contains **exactly** the three files above
#     (no surprises, no backups, no editors’ temp files, etc.)
#   • Every file is a regular file owned by the current user and has 0o644
#     permissions (-rw-r--r--).
#
# Only the Python standard library and pytest are used.

import difflib
import os
import stat
from pathlib import Path
import pwd

import pytest

CONFIG_DIR = Path("/home/user/project/config")
APP_YAML   = CONFIG_DIR / "app.yaml"
DB_TOML    = CONFIG_DIR / "database.toml"
CHANGE_LOG = CONFIG_DIR / "change_log.txt"

###############################################################################
# Truth data – the exact byte-for-byte expectations for the two edited files
# and the newly-created change log.
###############################################################################

EXPECTED_APP_YAML = (
    "name: SampleApp\n"
    "version: 1.2.3\n"
    "settings:\n"
    "  debug: true\n"
    "  max_connections: 100\n"
    "  feature_flag: beta\n"
)

EXPECTED_DB_TOML = (
    "[database]\n"
    "host = \"db.internal.local\"\n"
    "port = 5432\n"
    "user = \"appuser\"\n"
    "password = \"secret\"\n"
    "timeout = 45\n"
    "\n"
    "[replica]\n"
    "host = \"db-replica.internal.local\"\n"
    "port = 5433\n"
)

# NOTE: The specification claims “exactly 12 lines” but only nine non-empty
# lines are shown.  We therefore trust the explicit example and require those
# nine lines verbatim (with a single trailing newline).
EXPECTED_CHANGE_LOG = (
    "app.yaml:\n"
    "  settings.debug: false -> true\n"
    "  settings.max_connections: 50 -> 100\n"
    "  settings.feature_flag: (added) -> beta\n"
    "database.toml:\n"
    "  database.host: localhost -> db.internal.local\n"
    "  database.timeout: 30 -> 45\n"
    "  replica.host: (added) -> db-replica.internal.local\n"
    "  replica.port: (added) -> 5433\n"
)

###############################################################################
# Helper functions
###############################################################################


def _read_text(path: Path) -> str:
    """
    Read *path* using UTF-8, failing the test with a descriptive message if the
    file is missing or unreadable.
    """
    assert path.exists(), f"Required file {path} is missing."
    assert path.is_file(), f"{path} exists but is not a regular file."
    try:
        return path.read_text(encoding="utf-8")
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"Could not read {path}: {exc}")


def _assert_exact_content(actual: str, expected: str, path: Path) -> None:
    """
    Assert that *actual* equals *expected* **exactly**.  On mismatch, show a
    unified diff so the student sees what is still wrong.
    """
    if actual != expected:
        diff = "".join(
            difflib.unified_diff(
                expected.splitlines(keepends=True),
                actual.splitlines(keepends=True),
                fromfile="expected",
                tofile=str(path),
            )
        )
        pytest.fail(
            f"File {path} does not match the required final contents. "
            f"Differences (expected → actual):\n{diff}"
        )


###############################################################################
# Tests
###############################################################################


def test_config_directory_intact():
    assert CONFIG_DIR.exists(), f"Directory {CONFIG_DIR} is missing."
    assert CONFIG_DIR.is_dir(), f"{CONFIG_DIR} exists but is not a directory."


@pytest.mark.parametrize(
    ("path_obj", "expected_contents"),
    [
        (APP_YAML, EXPECTED_APP_YAML),
        (DB_TOML, EXPECTED_DB_TOML),
        (CHANGE_LOG, EXPECTED_CHANGE_LOG),
    ],
    ids=lambda x: x.name if isinstance(x, Path) else "contents",
)
def test_file_contents_are_final(path_obj: Path, expected_contents: str):
    """
    Verify that each file’s byte-for-byte contents match the exact final
    specification.
    """
    actual = _read_text(path_obj)
    _assert_exact_content(actual, expected_contents, path_obj)


def test_no_extra_files():
    """
    The config directory must now contain ONLY the three expected files.
    Extra artefacts (backup files, temp files, etc.) are forbidden.
    """
    expected_files = {APP_YAML.name, DB_TOML.name, CHANGE_LOG.name}
    actual_files   = {p.name for p in CONFIG_DIR.iterdir() if p.is_file()}

    unexpected = actual_files - expected_files
    missing    = expected_files - actual_files

    assert not missing, (
        f"The following required file(s) are missing from {CONFIG_DIR}: "
        f"{', '.join(sorted(missing))}"
    )
    assert not unexpected, (
        f"Unexpected file(s) found in {CONFIG_DIR}: "
        f"{', '.join(sorted(unexpected))}"
    )


def _assert_permissions(path: Path) -> None:
    mode = path.stat().st_mode & 0o777
    assert mode == 0o644, (
        f"{path} permissions are {oct(mode)}, expected 0o644 (-rw-r--r--)."
    )


def _assert_ownership(path: Path) -> None:
    """
    Confirm that *path* is owned by the current (non-root) user.
    """
    st = path.stat()
    current_uid = os.getuid()
    assert st.st_uid == current_uid, (
        f"{path} is owned by UID {st.st_uid}, "
        f"but the current user’s UID is {current_uid}."
    )
    # For completeness, also ensure the username matches if resolvable
    try:
        file_owner = pwd.getpwuid(st.st_uid).pw_name
        current_user = pwd.getpwuid(current_uid).pw_name
        assert file_owner == current_user, (
            f"{path} is owned by '{file_owner}', expected '{current_user}'."
        )
    except KeyError:
        # Username resolution not available inside container; ignore.
        pass


def test_permissions_and_ownership():
    """
    All three files must remain regular files, owned by the current user and
    with 0o644 permissions.
    """
    for path_obj in (APP_YAML, DB_TOML, CHANGE_LOG):
        assert path_obj.is_file(), f"{path_obj} is not a regular file."
        _assert_permissions(path_obj)
        _assert_ownership(path_obj)