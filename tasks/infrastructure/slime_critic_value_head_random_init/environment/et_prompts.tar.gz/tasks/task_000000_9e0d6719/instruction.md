A junior configuration manager left two basic config files under 
/home/user/project/config/ that need quick edits and documentation.

1. Verify that the two **already-existing** files have the exact initial
   contents shown below before you start.  
   • /home/user/project/config/app.yaml  
   • /home/user/project/config/database.toml

2. Apply the specific changes listed in “Required edits”.

3. After the edits, create a human-readable text change log called  
   /home/user/project/config/change_log.txt that captures every change you
   made.  The automated test will read this file verbatim, so make sure the
   formatting rules are followed **exactly**.

────────────────────────────────────────────────────────────────────────

### Initial file contents
---------------------
**/home/user/project/config/app.yaml**
```
name: SampleApp
version: 1.2.3
settings:
  debug: false
  max_connections: 50
```

**/home/user/project/config/database.toml**
```
[database]
host = "localhost"
port = 5432
user = "appuser"
password = "secret"
timeout = 30
```

────────────────────────────────────────────────────────────────────────

### Required edits
--------------
1. **app.yaml**  
   • Change `settings.debug` from `false` to `true`  
   • Change `settings.max_connections` from `50` to `100`  
   • Add a new key `settings.feature_flag` with the value `beta`

2. **database.toml**  
   • Change `database.host` from `"localhost"` to `"db.internal.local"`  
   • Change `database.timeout` from `30` to `45`  
   • Append an entirely new table:  
       ```
       [replica]  
       host = "db-replica.internal.local"  
       port = 5433
       ```

────────────────────────────────────────────────────────────────────────

### Exact final file expectations
-----------------------------
After you are done, **the files must look precisely like this** (indentation,
quotes and spacing count):

**/home/user/project/config/app.yaml**
```
name: SampleApp
version: 1.2.3
settings:
  debug: true
  max_connections: 100
  feature_flag: beta
```

**/home/user/project/config/database.toml**
```
[database]
host = "db.internal.local"
port = 5432
user = "appuser"
password = "secret"
timeout = 45

[replica]
host = "db-replica.internal.local"
port = 5433
```

────────────────────────────────────────────────────────────────────────

### Mandatory change_log.txt format
-------------------------------
Create `/home/user/project/config/change_log.txt` with **exactly** the 12 lines
shown below (no extra spaces, no trailing whitespace).  Each edited file is
listed once, followed by indented bullet lines for every individual field
you touched.  New keys/tables count as `(added)`.  Use arrows (`->`) surrounded
by single spaces.

```
app.yaml:
  settings.debug: false -> true
  settings.max_connections: 50 -> 100
  settings.feature_flag: (added) -> beta
database.toml:
  database.host: localhost -> db.internal.local
  database.timeout: 30 -> 45
  replica.host: (added) -> db-replica.internal.local
  replica.port: (added) -> 5433
```

────────────────────────────────────────────────────────────────────────

### Success criteria
----------------
*   `app.yaml` and `database.toml` exactly match the “Exact final file expectations”
  block (verified byte-for-byte).  
*   `change_log.txt` exists at the stated path and consists of exactly the 12
  lines specified above.  
*   No additional files are created inside `/home/user/project/config/`.  
*   All operations are run without sudo.
*   Keep file permissions unchanged (they should remain regular user-writable).