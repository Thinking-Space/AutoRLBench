You are a release-manager who needs to hand off a concise error report to the ops team before tonight’s deployment.

Context already present on the system:
*   The directory `/home/user/build-logs/` exists.
*   Inside it there is a file named `release_2023-05-18.log` that contains a mixed stream of INFO, WARN and ERROR lines for several build-pipeline modules (compile, test, deploy, etc.).

Your goal
1.  Create a new file called `/home/user/build-logs/release_2023-05-18-deploy-errors.log`.
2.  This new file must contain **only** the lines that simultaneously meet BOTH of the following conditions:
    a) The log-level field is exactly `[ERROR]`.
    b) The module field is exactly `[deploy]`.
    (Both fields are surrounded by square brackets and appear exactly once in every log line.)
3.  Preserve the original chronological order of the matching lines; do not add, reorder, or delete characters within a line.
4.  Do not modify `release_2023-05-18.log`. Only read from it.
5.  No other files should be created or modified.

Output format the automated test will verify
*   `/home/user/build-logs/release_2023-05-18-deploy-errors.log` must exist.
*   It must contain exactly 3 lines (newline-terminated) whose verbatim text is:
      [2023-05-18 14:22:20] [ERROR] [deploy] Cannot connect to production server
      [2023-05-18 14:22:30] [ERROR] [deploy] Deployment aborted due to previous errors
      [2023-05-18 14:22:45] [ERROR] [deploy] Retry failed, manual intervention required

(A trailing newline after the third line is required; no extra blank lines before or after.)

Once you have created the file, you’re done—no additional console output is necessary, but feel free to display the resulting file’s contents to confirm.