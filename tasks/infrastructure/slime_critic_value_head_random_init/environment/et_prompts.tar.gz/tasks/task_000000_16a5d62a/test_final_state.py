# test_final_state.py
#
# This pytest suite validates the **end state** of the filesystem
# after the student has completed the task.
#
# It asserts that
#   1) The original source log file is still present and **un-modified**.
#   2) A new file called
#        /home/user/build-logs/release_2023-05-18-deploy-errors.log
#      exists and contains **exactly** the expected three lines,
#      in order, each terminated with a single '\n'.
#   3) No extra blank lines are present before, between, or after the
#      required lines.
#
# Any failure will report a clear, actionable message.

import os
import hashlib
import pytest

BUILD_LOG_DIR = "/home/user/build-logs"
SOURCE_LOG = os.path.join(BUILD_LOG_DIR, "release_2023-05-18.log")
FILTERED_LOG = os.path.join(
    BUILD_LOG_DIR, "release_2023-05-18-deploy-errors.log"
)

# ---------------------------------------------------------------------------
# Helper data identical to the truth data from the task description
# ---------------------------------------------------------------------------

SOURCE_LOG_EXPECTED_CONTENT = (
    "[2023-05-18 14:22:01] [INFO]  [compile] Compilation successful\n"
    "[2023-05-18 14:22:05] [WARN]  [test]    Unit test took longer than expected\n"
    "[2023-05-18 14:22:10] [ERROR] [compile] Missing semicolon in source/foo.c\n"
    "[2023-05-18 14:22:15] [INFO]  [package] Packaging artifacts\n"
    "[2023-05-18 14:22:20] [ERROR] [deploy]  Cannot connect to production server\n"
    "[2023-05-18 14:22:25] [INFO]  [deploy]  Connection re-established\n"
    "[2023-05-18 14:22:30] [ERROR] [deploy]  Deployment aborted due to previous errors\n"
    "[2023-05-18 14:22:35] [INFO]  [cleanup] Temporary files removed\n"
    "[2023-05-18 14:22:40] [WARN]  [deploy]  Retrying deployment\n"
    "[2023-05-18 14:22:45] [ERROR] [deploy]  Retry failed, manual intervention required\n"
)

FILTERED_EXPECTED_LINES = [
    "[2023-05-18 14:22:20] [ERROR] [deploy]  Cannot connect to production server",
    "[2023-05-18 14:22:30] [ERROR] [deploy]  Deployment aborted due to previous errors",
    "[2023-05-18 14:22:45] [ERROR] [deploy]  Retry failed, manual intervention required",
]

# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------


def sha256_of_file(path: str) -> str:
    """Return the SHA-256 hex digest of the file at *path*."""
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_source_log_unmodified():
    """
    The original log file must still be present and byte-for-byte identical
    to the initial truth data.  Any accidental edits will be caught.
    """
    assert os.path.isfile(
        SOURCE_LOG
    ), f"Original log file {SOURCE_LOG!r} is missing."

    with open(SOURCE_LOG, "r", encoding="utf-8") as fh:
        actual_content = fh.read()

    assert (
        actual_content == SOURCE_LOG_EXPECTED_CONTENT
    ), "Original log file was modified; its content no longer matches the expected truth data."


def test_filtered_log_exists():
    """
    The filtered log file with deploy-error lines must exist and be a regular file.
    """
    assert os.path.exists(
        FILTERED_LOG
    ), f"Filtered log file {FILTERED_LOG!r} was not created."
    assert os.path.isfile(
        FILTERED_LOG
    ), f"Path {FILTERED_LOG!r} exists but is not a regular file."


def test_filtered_log_content_exact():
    """
    The filtered log file must contain exactly the three expected lines,
    each terminated with a single '\\n' and in the correct chronological order.
    """
    with open(FILTERED_LOG, "r", encoding="utf-8") as fh:
        data = fh.read()

    # 1. Must end with exactly one newline (required trailing newline, but no blank line after)
    assert data.endswith(
        "\n"
    ), "Filtered log does not end with a trailing newline (\\n)."
    assert not data.endswith(
        "\n\n"
    ), "Filtered log ends with more than one trailing newline (extra blank line detected)."

    # 2. Split lines (strip final newline so splitlines works cleanly)
    lines = data.splitlines()
    assert (
        lines == FILTERED_EXPECTED_LINES
    ), (
        "Filtered log content is incorrect.\n"
        "Expected lines:\n"
        + "\n".join(FILTERED_EXPECTED_LINES)
        + "\n\nActual lines:\n"
        + "\n".join(lines)
    )

    # 3. Ensure exactly 3 lines
    assert (
        len(lines) == 3
    ), f"Filtered log should contain exactly 3 lines, found {len(lines)}."


def test_build_directory_not_polluted():
    """
    Only the original log and the new filtered log should be present.
    If additional files are present, flag them so the student can clean up.
    """
    expected_files = {"release_2023-05-18.log", "release_2023-05-18-deploy-errors.log"}
    actual_files = {f for f in os.listdir(BUILD_LOG_DIR) if os.path.isfile(os.path.join(BUILD_LOG_DIR, f))}

    extra_files = actual_files - expected_files
    missing_files = expected_files - actual_files

    assert (
        not missing_files
    ), f"The following required file(s) are missing from {BUILD_LOG_DIR!r}: {', '.join(sorted(missing_files))}"

    assert (
        not extra_files
    ), (
        "Unexpected extra file(s) found in the build-logs directory: "
        + ", ".join(sorted(extra_files))
        + ". Only the two specified log files should exist."
    )