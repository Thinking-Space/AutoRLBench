#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3 \
        python3-pip \
        ca-certificates && \
    true

pip3 install --no-cache-dir pytest

mkdir -p /home/user/build-logs

cat > /home/user/build-logs/release_2023-05-18.log <<'EOF'
[2023-05-18 14:22:01] [INFO]  [compile] Compilation successful
[2023-05-18 14:22:05] [WARN]  [test]    Unit test took longer than expected
[2023-05-18 14:22:10] [ERROR] [compile] Missing semicolon in source/foo.c
[2023-05-18 14:22:15] [INFO]  [package] Packaging artifacts
[2023-05-18 14:22:20] [ERROR] [deploy]  Cannot connect to production server
[2023-05-18 14:22:25] [INFO]  [deploy]  Connection re-established
[2023-05-18 14:22:30] [ERROR] [deploy]  Deployment aborted due to previous errors
[2023-05-18 14:22:35] [INFO]  [cleanup] Temporary files removed
[2023-05-18 14:22:40] [WARN]  [deploy]  Retrying deployment
[2023-05-18 14:22:45] [ERROR] [deploy]  Retry failed, manual intervention required
EOF

chmod 755 /home/user /home/user/build-logs && \
    chmod 644 /home/user/build-logs/release_2023-05-18.log

export PATH="/usr/bin:$PATH"
