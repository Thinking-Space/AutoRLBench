# test_final_state.py
#
# Pytest suite that validates the **FINAL** operating-system / filesystem
# state for the “MyApp” configuration-management exercise.
#
# These tests must be executed **after** the student has finished the task.
# If any of them fails, the student’s solution did not bring the machine
# into the required end state.
#
# Only Python’s stdlib and pytest are used.

import os
import stat
from pathlib import Path

import pytest

HOME = Path("/home/user")
MYAPP_DIR = HOME / "myapp"
BIN_DIR = HOME / "bin"
ENV_DIR = HOME / "env-configs"

BASHRC = HOME / ".bashrc"
CHANGE_LOG = ENV_DIR / "change_log.txt"
DONE_FLAG = ENV_DIR / "done.flag"
MYAPP_SYMLINK = BIN_DIR / "myapp"
APP_CONF = MYAPP_DIR / "conf" / "app.conf"


# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------

def read_file_lines(path: Path):
    """
    Return the file’s contents as a list of lines *without* trailing '\n' chars.
    """
    with path.open("r", encoding="utf-8") as f:
        return [line.rstrip("\n") for line in f.readlines()]


def assert_mode_is_one_of(path: Path, allowed):
    """
    Assert that `path`’s unix permission bits (st_mode & 0o777) are contained
    in iterable `allowed`.  Give a clear error otherwise.
    """
    mode = path.stat().st_mode & 0o777
    assert mode in allowed, (
        f"{path} must have permissions {', '.join(oct(m) for m in allowed)}, "
        f"but has {oct(mode)}."
    )


def is_symlink_pointing_to(symlink: Path, target: Path) -> bool:
    """
    Return True iff `symlink` is a symlink that resolves to `target`
    (after following the symlink chain).
    """
    if not symlink.is_symlink():
        return False
    try:
        resolved = symlink.resolve(strict=True)
    except FileNotFoundError:
        return False
    return resolved == target


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_env_configs_directory_exists_with_correct_permissions():
    """ /home/user/env-configs must exist as a directory with mode 0700 or 0755. """
    assert ENV_DIR.is_dir(), f"Directory {ENV_DIR} must exist."
    assert_mode_is_one_of(ENV_DIR, {0o700, 0o755})


def test_done_flag_exists_and_is_empty_with_reasonable_permissions():
    """ The flag file must exist, be empty, and have mode 0600 or 0644. """
    assert DONE_FLAG.is_file(), f"Expected file {DONE_FLAG} to exist."
    size = DONE_FLAG.stat().st_size
    assert size == 0, f"{DONE_FLAG} must be empty, but size is {size} bytes."
    assert_mode_is_one_of(DONE_FLAG, {0o600, 0o644})


def test_change_log_exact_content():
    """
    change_log.txt must contain exactly the four required lines in order,
    with no extra or blank lines.
    """
    assert CHANGE_LOG.is_file(), f"Expected file {CHANGE_LOG} to exist."

    expected_lines = [
        "MODIFY|/home/user/.bashrc",
        "LINK|/home/user/bin/myapp",
        "MODIFY|/home/user/myapp/conf/app.conf",
        "CREATE|/home/user/env-configs/done.flag",
    ]

    actual_lines = read_file_lines(CHANGE_LOG)

    assert actual_lines == expected_lines, (
        f"{CHANGE_LOG} content is incorrect.\n"
        f"Expected EXACTLY:\n{expected_lines}\nFound:\n{actual_lines}"
    )


def test_bashrc_last_two_non_blank_lines_are_exports():
    """
    The very last two *non-blank* lines of .bashrc must be the exact export statements.
    """
    assert BASHRC.is_file(), f"{BASHRC} must exist."

    lines = read_file_lines(BASHRC)

    # Filter out lines that are blank or contain only whitespace
    non_blank = [ln for ln in lines if ln.strip() != ""]

    assert len(non_blank) >= 2, (
        f"{BASHRC} should have at least two non-blank lines, found {len(non_blank)}."
    )

    last_two = non_blank[-2:]

    expected_two = [
        "export MYAPP_HOME=/home/user/myapp",
        'export PATH="$PATH:$MYAPP_HOME/bin"',
    ]

    assert last_two == expected_two, (
        f"The last two non-blank lines in {BASHRC} are incorrect.\n"
        f"Expected:\n{expected_two}\nFound:\n{last_two}"
    )


def test_myapp_symlink_exists_and_points_correctly():
    """ /home/user/bin/myapp must be a symlink pointing to /home/user/myapp/bin/start.sh. """
    target = MYAPP_DIR / "bin" / "start.sh"
    assert MYAPP_SYMLINK.exists(), f"Symlink {MYAPP_SYMLINK} must exist."
    assert MYAPP_SYMLINK.is_symlink(), f"{MYAPP_SYMLINK} must be a symbolic link."
    assert is_symlink_pointing_to(MYAPP_SYMLINK, target), (
        f"{MYAPP_SYMLINK} must point to {target}, "
        f"but instead points to {MYAPP_SYMLINK.resolve(strict=False)}."
    )


def test_app_conf_content_final():
    """
    /home/user/myapp/conf/app.conf must contain exactly four lines in order,
    with log_level corrected and enable_cache=true appended.
    """
    assert APP_CONF.is_file(), f"Expected file {APP_CONF} to exist."

    expected_lines = [
        "# MyApp Main configuration",
        "log_level=DEBUG",
        "max_threads=4",
        "enable_cache=true",
    ]

    actual_lines = read_file_lines(APP_CONF)

    assert actual_lines == expected_lines, (
        f"{APP_CONF} content is incorrect.\n"
        f"Expected EXACTLY:\n{expected_lines}\nFound:\n{actual_lines}"
    )


def test_env_configs_contains_only_expected_files():
    """
    env-configs directory should contain at least change_log.txt and done.flag.
    Other files/directories are allowed but must not shadow these names.
    This test mainly ensures the expected files are present.
    """
    contents = {p.name for p in ENV_DIR.iterdir()}
    for name in {"change_log.txt", "done.flag"}:
        assert name in contents, f"{name} is missing from {ENV_DIR}."