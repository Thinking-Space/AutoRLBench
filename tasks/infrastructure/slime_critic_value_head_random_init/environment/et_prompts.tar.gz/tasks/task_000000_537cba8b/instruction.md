You are acting as a configuration-manager that must make, track and log a small group of environment changes for the “MyApp” application that already lives in your home directory.

1.  Create the directory “/home/user/env-configs”.
2.  Append EXACTLY the two lines shown below (no extra spaces) to the end of “/home/user/.bashrc”. They must be the very last two non-blank lines.

    ```
    export MYAPP_HOME=/home/user/myapp
    export PATH="$PATH:$MYAPP_HOME/bin"
    ```

3.  Make sure “/home/user/bin” exists and then create a symbolic link named “/home/user/bin/myapp” that points to “/home/user/myapp/bin/start.sh”.
4.  Edit the file “/home/user/myapp/conf/app.conf” so that:
    *   The existing setting `log_level=INFO` becomes `log_level=DEBUG`
    *   A NEW setting line `enable_cache=true` is added as the very last line of the file. (Do NOT disturb any other lines.)
5.  Touch an empty file called “/home/user/env-configs/done.flag”.
6.  Produce a plain-text log called “/home/user/env-configs/change_log.txt” containing EXACTLY four log lines, in the precise order below, and with NO blank lines before or after:

    ```
    MODIFY|/home/user/.bashrc
    LINK|/home/user/bin/myapp
    MODIFY|/home/user/myapp/conf/app.conf
    CREATE|/home/user/env-configs/done.flag
    ```

Constraints & Verification Rules
*   Do not run any command that requires root privileges.
*   Make sure file paths, file names and the case of every character match the specifications exactly; automated tests are case-sensitive.
*   “change_log.txt” must contain **only** the four lines above. Automated tests will verify an exact byte-for-byte match.
*   The two environment-variable lines must appear as the final two non-blank lines in “/home/user/.bashrc”.