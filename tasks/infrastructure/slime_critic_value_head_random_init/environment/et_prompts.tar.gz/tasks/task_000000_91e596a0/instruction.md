Your goal is to prepare a small “sandbox” for a web-developer and to document the permissions you create.

What you must accomplish:

1.  Create a directory named “webapp” directly inside `/home/user`.
2.  Inside that directory create the following sub-directories EXACTLY as named:
    *   public
    *   config
    *   scripts
3.  Place one configuration file inside the `config` directory called “settings.json” containing the following **exact JSON** (make sure the file ends with a trailing newline):

    ```json
    {
      "env": "development",
      "debug": true
    }
    ```

4.  Place one shell script inside the `scripts` directory called “backup.sh” with this **exact three-line content** (also ending with a trailing newline):

    ```bash
    #!/usr/bin/env bash
    # Simple backup script
    tar -czf /home/user/webapp_backup_$(date +%F).tar.gz /home/user/webapp
    ```

5.  Apply these octal permissions so that the automated grader can check them without resolving symbolic strings:

    *   `/home/user/webapp` → `755`
    *   `/home/user/webapp/public` → `755`
    *   `/home/user/webapp/config` → `750`
    *   `/home/user/webapp/config/settings.json` → `640`
    *   `/home/user/webapp/scripts` → `750`
    *   `/home/user/webapp/scripts/backup.sh` → `700`

    (Make sure “backup.sh” keeps its executable bit.)

6.  Create a plain-text log file called `/home/user/permission_report.txt` that lists the final permissions you set. The file MUST contain exactly six lines, one path per line, in the precise order shown below and **nothing else** (no extra spaces, no comments):

    ```
    /home/user/webapp 755
    /home/user/webapp/public 755
    /home/user/webapp/config 750
    /home/user/webapp/config/settings.json 640
    /home/user/webapp/scripts 750
    /home/user/webapp/scripts/backup.sh 700
    ```

The grader will validate:

*   existence of every directory and file
*   the exact octal permission bits
*   the exact contents of `settings.json` and `backup.sh` (including newlines)
*   the exact six-line `permission_report.txt`, byte for byte

You do NOT need root privileges; all the work happens inside `/home/user`.