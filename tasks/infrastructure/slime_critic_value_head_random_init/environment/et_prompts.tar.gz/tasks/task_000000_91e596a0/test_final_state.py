# test_final_state.py
#
# Pytest-suite that validates the *final* state after the
# “web-developer sandbox” task has been finished.
#
# It asserts
#   • existence and type (file/dir) of every required path
#   • the exact octal permission bits (with the one documented exception)
#   • byte-exact content of all files that must contain specific text
#
# If any assertion fails the test will explain *exactly* what is still
# wrong so the student can fix it quickly.

import os
import stat
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Hard-coded absolute paths – DO NOT CHANGE
# ---------------------------------------------------------------------------
HOME = Path("/home/user").expanduser().resolve()

WEBAPP_DIR      = HOME / "webapp"
PUBLIC_DIR      = WEBAPP_DIR / "public"
CONFIG_DIR      = WEBAPP_DIR / "config"
SCRIPTS_DIR     = WEBAPP_DIR / "scripts"

SETTINGS_JSON   = CONFIG_DIR  / "settings.json"
BACKUP_SH       = SCRIPTS_DIR / "backup.sh"
PERM_REPORT_TXT = HOME / "permission_report.txt"

# Expected permissions (octal, as int) --------------------------------------
EXPECTED_MODES = {
    WEBAPP_DIR:    0o755,
    PUBLIC_DIR:    0o755,
    CONFIG_DIR:    0o750,
    SETTINGS_JSON: 0o640,
    SCRIPTS_DIR:   0o750,
    BACKUP_SH:     0o700,
}

# Expected file contents (must end with a single newline) --------------------
EXPECTED_SETTINGS_JSON = (
    '{\n'
    '  "env": "development",\n'
    '  "debug": true\n'
    '}\n'
)

EXPECTED_BACKUP_SH = (
    '#!/usr/bin/env bash\n'
    '# Simple backup script\n'
    'tar -czf /home/user/webapp_backup_$(date +%F).tar.gz /home/user/webapp\n'
)

EXPECTED_PERMISSION_REPORT = (
    '/home/user/webapp 755\n'
    '/home/user/webapp/public 755\n'
    '/home/user/webapp/config 750\n'
    '/home/user/webapp/config/settings.json 640\n'
    '/home/user/webapp/scripts 750\n'
    '/home/user/webapp/scripts/backup.sh 700\n'
)

# ---------------------------------------------------------------------------


# -----------------------  Existence & type  --------------------------------
@pytest.mark.parametrize(
    "path,is_dir",
    [
        (WEBAPP_DIR,    True),
        (PUBLIC_DIR,    True),
        (CONFIG_DIR,    True),
        (SCRIPTS_DIR,   True),
        (SETTINGS_JSON, False),
        (BACKUP_SH,     False),
        (PERM_REPORT_TXT, False),
    ],
)
def test_path_exists_with_correct_type(path: Path, is_dir: bool):
    assert path.exists(), f"Expected {path} to exist, but it does not."
    if is_dir:
        assert path.is_dir(), f"Expected {path} to be a directory."
    else:
        assert path.is_file(), f"Expected {path} to be a regular file."


# -----------------------  Permission bits  ---------------------------------
@pytest.mark.parametrize("path, expected_mode", EXPECTED_MODES.items())
def test_exact_modes(path: Path, expected_mode: int):
    mode = path.stat().st_mode & 0o777
    assert mode == expected_mode, (
        f"{path}: expected mode {oct(expected_mode)[2:]}, "
        f"but found {oct(mode)[2:]}"
    )


def test_permission_report_mode():
    """
    The spec says: permission_report.txt must be 0664 or 'stricter'
    (i.e. may remove, but not add, permission bits).  We therefore
    accept any mode <= 664.
    """
    mode = PERM_REPORT_TXT.stat().st_mode & 0o777
    assert mode <= 0o664, (
        f"{PERM_REPORT_TXT}: expected mode 664 or stricter, "
        f"but found {oct(mode)[2:]}"
    )


# -----------------------  File contents  -----------------------------------
@pytest.mark.parametrize(
    "path, expected_content, description",
    [
        (SETTINGS_JSON, EXPECTED_SETTINGS_JSON, "settings.json"),
        (BACKUP_SH, EXPECTED_BACKUP_SH, "backup.sh"),
        (PERM_REPORT_TXT, EXPECTED_PERMISSION_REPORT, "permission_report.txt"),
    ],
)
def test_file_content_exact(path: Path, expected_content: str, description: str):
    data = path.read_bytes()
    expected_bytes = expected_content.encode()
    assert data == expected_bytes, (
        f"The contents of {description} are incorrect.\n\n"
        f"Expected (repr):\n{repr(expected_content)}\n\n"
        f"Found (repr):\n{repr(data.decode(errors='replace'))}"
    )


# -----------------------  Extra logical checks  ----------------------------
def test_backup_sh_is_executable():
    st = BACKUP_SH.stat()
    mode = st.st_mode & 0o777
    is_executable = bool(mode & stat.S_IXUSR)
    assert is_executable, (
        f"{BACKUP_SH} must be executable (owner execute bit set). "
        f"Current mode is {oct(mode)[2:]}."
    )


def test_permission_report_matches_actual_modes():
    """
    As an additional safeguard, verify that the six lines in
    permission_report.txt actually reflect the real modes currently
    present on disk.  This is NOT part of the original grading spec,
    but helps students spot mismatches early.
    """
    lines = EXPECTED_PERMISSION_REPORT.strip().split("\n")
    for line in lines:
        path_str, mode_str = line.split()
        path = Path(path_str)
        expected_mode = int(mode_str, 8)
        actual_mode = path.stat().st_mode & 0o777
        assert actual_mode == expected_mode, (
            f"permission_report.txt claims {path_str} has mode {mode_str}, "
            f"but filesystem shows {oct(actual_mode)[2:]}."
        )