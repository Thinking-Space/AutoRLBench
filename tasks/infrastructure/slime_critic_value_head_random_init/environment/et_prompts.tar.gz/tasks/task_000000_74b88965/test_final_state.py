# test_final_state.py
"""
Pytest suite that validates the **FINAL** state of the OS / container _after_
the student has finished the “network-diagnostics summary” task.

The checks performed:

1. The raw diagnostic files are still present and unmodified.
2. The summary directory now exists.
3. Both summary artefacts (CSV & JSON) exist and are regular files.
4. summary.csv:
   • exactly 8 non-empty lines  
   • header line is “metric,value” (exact match)  
   • subsequent 7 data lines match the required order and values.  
5. summary.json:
   • valid JSON object  
   • exactly the 7 required keys, no extras  
   • values are numerics, not strings  
   • values match those in summary.csv  
6. Cross-check: values in both summary files _also_ match the metrics that can
   be parsed directly from the original raw files – guards against hard-coded
   output.

Any failure explains **what is still wrong** so that the student can quickly
pin-point the discrepancy.
"""
import json
import os
import re
from pathlib import Path

import pytest

# --------------------------------------------------------------------------- #
# Fixed absolute paths (MUST NOT use relatives)                               #
# --------------------------------------------------------------------------- #
HOME = Path("/home/user")
RAW_DIR = HOME / "network_diagnostics" / "raw"
PING_FILE = RAW_DIR / "ping_localhost.txt"
TRACEROUTE_FILE = RAW_DIR / "traceroute_localhost.txt"
SS_FILE = RAW_DIR / "ss_output.txt"

SUMMARY_DIR = HOME / "network_diagnostics" / "2023-obs-summary"
CSV_FILE = SUMMARY_DIR / "summary.csv"
JSON_FILE = SUMMARY_DIR / "summary.json"

# Expected literal order & values for CSV (whitespace sensitive except newline)
EXPECTED_CSV_LINES = [
    "metric,value",
    "packets_transmitted,4",
    "packets_received,4",
    "packet_loss_percent,0",
    "rtt_min_ms,0.025",
    "rtt_avg_ms,0.029",
    "rtt_max_ms,0.035",
    "tcp_listening_sockets,2",
]

EXPECTED_KEYS = [
    "packets_transmitted",
    "packets_received",
    "packet_loss_percent",
    "rtt_min_ms",
    "rtt_avg_ms",
    "rtt_max_ms",
    "tcp_listening_sockets",
]


# --------------------------------------------------------------------------- #
# Helper functions                                                            #
# --------------------------------------------------------------------------- #
def parse_ping_stats(text: str) -> dict:
    """
    Parses the statistics section of a typical GNU/Linux 'ping' output.
    Returns a dict with numeric values already converted to int / float.
    """
    # Example stats line: "4 packets transmitted, 4 received, 0% packet loss, time 3058ms"
    pkt_match = re.search(
        r"(?P<tx>\d+)\s+packets transmitted,\s+"
        r"(?P<rx>\d+)\s+received,\s+"
        r"(?P<loss>\d+)%\s+packet loss",
        text,
    )
    if not pkt_match:
        raise ValueError("Unable to locate packet statistics line in ping output.")

    # Example rtt line: "rtt min/avg/max/mdev = 0.025/0.029/0.035/0.004 ms"
    rtt_match = re.search(
        r"rtt min/avg/max/\w+\s*=\s*"
        r"(?P<min>[0-9.]+)/(?P<avg>[0-9.]+)/(?P<max>[0-9.]+)/",
        text,
    )
    if not rtt_match:
        raise ValueError("Unable to locate rtt statistics line in ping output.")

    return {
        "packets_transmitted": int(pkt_match.group("tx")),
        "packets_received": int(pkt_match.group("rx")),
        "packet_loss_percent": int(pkt_match.group("loss")),
        "rtt_min_ms": float(rtt_match.group("min")),
        "rtt_avg_ms": float(rtt_match.group("avg")),
        "rtt_max_ms": float(rtt_match.group("max")),
    }


def count_tcp_listen_sockets(text: str) -> int:
    """
    Returns the number of TCP LISTEN sockets shown in a typical `ss -ltn`
    output (or the fixture provided by the exercise).
    """
    count = 0
    for line in text.splitlines():
        parts = line.split()
        # Expect at least Netid & State columns
        if len(parts) >= 2 and parts[0] == "tcp" and parts[1].upper() == "LISTEN":
            count += 1
    return count


def load_csv_lines(path: Path) -> list:
    """
    Reads a CSV file and returns a list of lines stripped of the trailing '\n'.
    Empty lines are discarded.
    """
    return [ln.rstrip("\n") for ln in path.read_text().splitlines() if ln.strip() != ""]


# --------------------------------------------------------------------------- #
# Tests – raw files still present                                             #
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize(
    "path",
    [RAW_DIR, PING_FILE, TRACEROUTE_FILE, SS_FILE],
    ids=lambda p: str(p),
)
def test_raw_paths_still_exist(path: Path):
    if path == RAW_DIR:
        assert path.is_dir(), f"Expected raw directory {path} is missing."
    else:
        assert path.is_file(), f"Expected raw file {path} is missing."


# --------------------------------------------------------------------------- #
# Tests – summary directory & artefacts                                       #
# --------------------------------------------------------------------------- #
def test_summary_directory_exists():
    assert SUMMARY_DIR.is_dir(), (
        f"Required directory {SUMMARY_DIR} does not exist. "
        "Did you create it with the correct absolute path?"
    )


@pytest.mark.parametrize("artifact", [CSV_FILE, JSON_FILE], ids=lambda p: p.name)
def test_summary_files_exist(artifact: Path):
    assert artifact.is_file(), f"Expected summary file {artifact} is missing."


# --------------------------------------------------------------------------- #
# Tests – summary.csv content                                                 #
# --------------------------------------------------------------------------- #
def test_summary_csv_exact_contents():
    lines = load_csv_lines(CSV_FILE)
    assert len(lines) == 8, (
        f"{CSV_FILE} must contain exactly 8 non-empty lines "
        f"but contains {len(lines)} lines."
    )

    # Compare line-by-line
    for idx, (got, expected) in enumerate(zip(lines, EXPECTED_CSV_LINES), start=1):
        assert got == expected, (
            f"Line {idx} in {CSV_FILE} is incorrect.\n"
            f"Expected: {expected!r}\n"
            f"Got     : {got!r}"
        )


# --------------------------------------------------------------------------- #
# Tests – summary.json content                                                #
# --------------------------------------------------------------------------- #
def test_summary_json_exact_contents_and_types():
    try:
        data = json.loads(JSON_FILE.read_text())
    except json.JSONDecodeError as exc:
        pytest.fail(f"{JSON_FILE} is not valid JSON: {exc}")

    # Must be a JSON object / dict
    assert isinstance(data, dict), f"{JSON_FILE} must contain a JSON object."

    # Keys set equality
    got_keys = set(data.keys())
    expected_keys = set(EXPECTED_KEYS)
    missing = expected_keys - got_keys
    extra = got_keys - expected_keys
    assert not missing and not extra, (
        f"{JSON_FILE} must contain exactly the keys:\n"
        f"{sorted(expected_keys)}\n"
        f"Missing: {sorted(missing)}\n"
        f"Extra  : {sorted(extra)}"
    )

    # Type checks
    for k in EXPECTED_KEYS:
        assert isinstance(
            data[k], (int, float)
        ), f"Value for key '{k}' in {JSON_FILE} must be numeric, got {type(data[k]).__name__}"

    # Values must match CSV expectation
    csv_map = {ln.split(",")[0]: ln.split(",")[1] for ln in EXPECTED_CSV_LINES[1:]}
    for k in EXPECTED_KEYS:
        expected_val = json.loads(csv_map[k]) if "." in csv_map[k] else int(csv_map[k])
        assert data[k] == expected_val, (
            f"Value mismatch for key '{k}' in {JSON_FILE}.\n"
            f"Expected: {expected_val}\n"
            f"Got     : {data[k]}"
        )


# --------------------------------------------------------------------------- #
# Tests – Summary values cross-checked against raw files                      #
# (Guards against hard-coded outputs)                                         #
# --------------------------------------------------------------------------- #
def test_summary_values_match_raw_files():
    # Re-derive expected metrics from the raw files ------------------------- #
    ping_stats = parse_ping_stats(PING_FILE.read_text())
    tcp_listen = count_tcp_listen_sockets(SS_FILE.read_text())
    ping_stats["tcp_listening_sockets"] = tcp_listen

    # Load student JSON output --------------------------------------------- #
    student_data = json.loads(JSON_FILE.read_text())

    mismatches = {}
    for key, expected_val in ping_stats.items():
        got_val = student_data.get(key, None)
        if got_val != expected_val:
            mismatches[key] = {"expected": expected_val, "got": got_val}

    assert not mismatches, (
        "The values in your summary files do not match what can be parsed "
        "from the provided raw diagnostic outputs:\n"
        f"{json.dumps(mismatches, indent=2)}"
    )