You are an observability engineer reviewing a set of **already-collected** network-diagnostic command dumps that live on the host.
Your goal is to create a pair of easily-ingestible summary artefacts for a dashboarding system.

### Starting state
1.  A directory named `/home/user/network_diagnostics/raw` already exists.
2.  It contains three plain-text files that hold the verbatim outputs of common network-diagnostic tools:
    *   `/home/user/network_diagnostics/raw/ping_localhost.txt`
    *   `/home/user/network_diagnostics/raw/traceroute_localhost.txt`
    *   `/home/user/network_diagnostics/raw/ss_output.txt`

(These files are supplied for you – **do NOT edit them**.)

### Task – create a summarised view
*   Make a new directory called `/home/user/network_diagnostics/2023-obs-summary` (create any missing leading directories as needed).
*   Read `/home/user/network_diagnostics/raw/ping_localhost.txt` and extract the following numeric items:
    *   packets transmitted
    *   packets received
    *   packet-loss percentage (exclude the ‘%’ sign in the numeric value)
    *   rtt minimum in ms
    *   rtt average in ms
    *   rtt maximum in ms
*   Read `/home/user/network_diagnostics/raw/ss_output.txt` and count how many **LISTEN** TCP sockets are shown (i.e. lines whose “State” column is “LISTEN” and whose “Netid” column is “tcp”).
*   Produce TWO new files inside `/home/user/network_diagnostics/2023-obs-summary`

    **a) summary.csv**
    *   MUST be exactly eight (8) lines long.
    *   Line-1 is a header: `metric,value`
    *   Lines 2-8 hold the extracted values in this order (each on its own line, no extra whitespace):
        *   `packets_transmitted,<integer>`
        *   `packets_received,<integer>`
        *   `packet_loss_percent,<integer>`
        *   `rtt_min_ms,<float with 3 decimal places>`
        *   `rtt_avg_ms,<float with 3 decimal places>`
        *   `rtt_max_ms,<float with 3 decimal places>`
        *   `tcp_listening_sockets,<integer>`

    **b) summary.json**
    *   MUST be valid JSON (no trailing commas).
    *   The JSON object must contain exactly the seven keys shown above, using the identical spellings.
    *   Numbers must appear as numbers, not strings.
    *   Keys may appear in any order.

*   Once the summary files are created, recursively list the contents of the entire `/home/user/network_diagnostics` directory. Then, display the contents of the two new summary files so they are visible in the console log of your session.

### Notes / rules
*   Do NOT hardcode the numerical answers; they must be parsed from the raw files.
*   Do NOT delete, rename or move the three raw files.
*   You do not need root privileges for this task.
*   Absolute reproducibility is required: the grader will compare the two summary files byte-for-byte against the specification above.