# test_final_state.py
"""
Pytest suite that validates the **final** filesystem/OS state **after**
the student has performed the IoT-rollout validation task.

The suite asserts:

1. /home/user/deployment still exists, is a directory, and keeps mode >= 0755.
2. /home/user/deployment/edge_device_config.json is *unchanged* byte-for-byte.
3. /home/user/deployment/validation_report.txt now EXISTS and
   a. is a regular file with mode >= 0644 (i.e. world-readable).
   b. contains EXACTLY the three required lines, terminated by a single '\n':
        TOTAL_DEVICES=5
        VALID_OBJECTS=4
        INVALID_OBJECTS=1
   c. contains no extra blank lines or whitespace.
4. The numerical values in the report are internally consistent with the JSON
   content of edge_device_config.json.
"""

import json
import os
import stat
from pathlib import Path

import pytest

DEPLOY_DIR = Path("/home/user/deployment")
CONFIG_PATH = DEPLOY_DIR / "edge_device_config.json"
REPORT_PATH = DEPLOY_DIR / "validation_report.txt"

# Ground-truth JSON text (must remain unchanged).
EXPECTED_JSON_TEXT = (
    "[\n"
    "  {\"id\":\"dev-001\",\"location\":\"NYC\",\"status\":\"active\"},\n"
    "  {\"id\":\"dev-002\",\"location\":\"Berlin\",\"status\":\"inactive\"},\n"
    "  {\"id\":\"dev-003\",\"location\":\"London\",\"status\":\"active\"},\n"
    "  {\"location\":\"Tokyo\",\"status\":\"inactive\"},\n"
    "  {\"id\":\"dev-005\",\"location\":\"Paris\",\"status\":\"inactive\"}\n"
    "]\n"
)

EXPECTED_REPORT_TEXT = (
    "TOTAL_DEVICES=5\n"
    "VALID_OBJECTS=4\n"
    "INVALID_OBJECTS=1\n"
)


def _octal_mode(path: Path) -> int:
    """Return the file’s permission bits in octal, e.g. 0o755."""
    return stat.S_IMODE(path.stat().st_mode)


# --------------------------------------------------------------------------- #
# Basic sanity checks on directory and original JSON file
# --------------------------------------------------------------------------- #
def test_deployment_directory_still_present_and_accessible():
    assert DEPLOY_DIR.exists(), f"Required directory {DEPLOY_DIR} has disappeared."
    assert DEPLOY_DIR.is_dir(), f"{DEPLOY_DIR} exists but is no longer a directory."
    mode = _octal_mode(DEPLOY_DIR)
    assert mode >= 0o755, (
        f"Directory {DEPLOY_DIR} permissions downgraded to {oct(mode)}; "
        "must be at least 0o755."
    )


def test_edge_device_config_json_unchanged_and_readable():
    assert CONFIG_PATH.exists(), f"{CONFIG_PATH} is missing."
    assert CONFIG_PATH.is_file(), f"{CONFIG_PATH} exists but is not a regular file."

    actual_text = CONFIG_PATH.read_text(encoding="utf-8")
    assert (
        actual_text == EXPECTED_JSON_TEXT
    ), f"Content of {CONFIG_PATH} was modified; it must remain exactly as provided."

    mode = _octal_mode(CONFIG_PATH)
    assert mode & stat.S_IRUSR, f"{CONFIG_PATH} is no longer readable by the owner."


# --------------------------------------------------------------------------- #
# Validation report checks
# --------------------------------------------------------------------------- #
def test_report_file_exists_and_has_correct_permissions():
    assert REPORT_PATH.exists(), (
        f"{REPORT_PATH} is missing. The validation command must redirect its "
        "output to this file."
    )
    assert REPORT_PATH.is_file(), f"{REPORT_PATH} exists but is not a regular file."

    mode = _octal_mode(REPORT_PATH)
    assert mode >= 0o644, (
        f"{REPORT_PATH} permissions are {oct(mode)}; expected at least 0o644 "
        "(readable by grader)."
    )


def test_report_file_content_exact_match():
    """
    The report must contain EXACTLY the expected three lines followed by a single
    newline at EOF — nothing more, nothing less.
    """
    actual_bytes = REPORT_PATH.read_bytes()
    expected_bytes = EXPECTED_REPORT_TEXT.encode("utf-8")
    assert (
        actual_bytes == expected_bytes
    ), (
        f"{REPORT_PATH} content is not exactly as expected.\n"
        "Expected:\n"
        f"{EXPECTED_REPORT_TEXT!r}\n"
        "Found:\n"
        f"{actual_bytes.decode('utf-8', errors='replace')!r}"
    )


def test_report_numbers_logically_consistent_with_json():
    """
    Even if the exact text matches, double-check that the numeric values reported
    actually correspond to the JSON data. This guards against hard-coding.
    """
    # Parse numbers from report
    totals = {}
    for line in EXPECTED_REPORT_TEXT.strip().splitlines():
        key, value = line.split("=", 1)
        totals[key] = int(value)

    # Derive values from JSON
    json_data = json.loads(EXPECTED_JSON_TEXT)
    total_devices = len(json_data)
    valid_objects = sum(
        1
        for obj in json_data
        if isinstance(obj, dict)
        and {"id", "location", "status"}.issubset(obj.keys())
    )
    invalid_objects = total_devices - valid_objects

    assert (
        totals["TOTAL_DEVICES"] == total_devices
    ), "TOTAL_DEVICES count in report does not match JSON array length."
    assert (
        totals["VALID_OBJECTS"] == valid_objects
    ), "VALID_OBJECTS count in report does not match number of valid device objects."
    assert (
        totals["INVALID_OBJECTS"] == invalid_objects
    ), "INVALID_OBJECTS count in report is incorrect (should be total - valid)."