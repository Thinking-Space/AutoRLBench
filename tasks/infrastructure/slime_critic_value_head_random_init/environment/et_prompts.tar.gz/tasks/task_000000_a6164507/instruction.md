You are an edge–computing engineer preparing an IoT rollout.  
Inside the workspace the following configuration file is already present:

• /home/user/deployment/edge_device_config.json

Your objective is to perform a JSON-schema-style check on the configuration file and to capture a compact, human-readable report.

Validation rules (they are intentionally simple and must all hold for an object to be considered valid):
1. The JSON file is a top-level array whose elements are individual device objects.
2. Every device object must have **all three** of the following keys:  
   • id  
   • location  
   • status  

Expected report format (this is what the automated grader will parse; keep it exact, including capitalisation, the equal signs, and the terminating newline at the end of the file):

TOTAL_DEVICES=&lt;integer&gt;
VALID_OBJECTS=&lt;integer&gt;
INVALID_OBJECTS=&lt;integer&gt;

Where  
• &lt;integer&gt; on line 1 is the total number of elements in the array,  
• &lt;integer&gt; on line 2 is the count of objects that satisfy **all** validation rules,  
• &lt;integer&gt; on line 3 is the count of objects that fail **any** rule.

Your task is to generate the three-line summary described above and save it to the file `/home/user/deployment/validation_report.txt`.

The file must contain nothing except the three lines described and finish with a newline character.

Notes & constraints:
• Do not move or rename any supplied files.  
• Do not manually edit /home/user/deployment/edge_device_config.json.  
• No extra explanatory text may be printed to the report file—only the three required lines.  
• If you need to inspect intermediate results, feel free to issue other diagnostic commands, but the graded deliverable is the final content of validation_report.txt.

When finished, you can cat the report to the terminal so a human operator sees the outcome, but the automated test will examine the file on disk.