#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3 \
        python3-pip && \
    pip3 install --no-cache-dir pytest && \
    true

useradd -m -s /bin/bash user

mkdir -p /home/user/experiments/exp_alpha \
             /home/user/experiments/exp_beta \
             /home/user/experiments/exp_gamma

cat > /home/user/experiments/exp_alpha/metrics.csv <<'EOF'
epoch,loss,accuracy
1,0.65,0.70
2,0.60,0.75
3,0.58,0.78
EOF

cat > /home/user/experiments/exp_beta/metrics.csv <<'EOF'
epoch,loss,accuracy
1,0.55,0.72
2,0.50,0.80
3,0.48,0.82
4,0.47,0.83
5,0.46,0.84
EOF

cat > /home/user/experiments/exp_gamma/metrics.csv <<'EOF'
epoch,loss,accuracy
1,0.70,0.68
2,0.65,0.70
3,0.63,0.72
4,0.62,0.74
EOF

chmod -R a+rX /home/user/experiments && \
    chmod a+w /home/user/experiments && \
    chmod 755 /home/user

export PATH=/home/user/.local/bin:$PATH
