# test_final_state.py
#
# Pytest suite that validates the **end state** of the container
# after the student has created the summary dashboard for the
# three experiments exp_alpha, exp_beta and exp_gamma.
#
# The checks focus on:
#   •  Presence of /home/user/experiments/summary/
#   •  Exact contents of final_accuracy_report.tsv
#   •  Sanity/format checks for actions.log
#
# No third-party libraries are used – only the Python stdlib and pytest.

import csv
import re
from datetime import datetime
from pathlib import Path

import pytest

BASE_DIR = Path("/home/user/experiments")
SUMMARY_DIR = BASE_DIR / "summary"
REPORT_PATH = SUMMARY_DIR / "final_accuracy_report.tsv"
LOG_PATH = SUMMARY_DIR / "actions.log"

EXPERIMENT_IDS = ["exp_alpha", "exp_beta", "exp_gamma"]

###############################################################################
# Helper functions
###############################################################################


def read_metrics_final_accuracy(csv_path: Path) -> str:
    """
    Return the accuracy value (3rd column) of the last data row in metrics.csv.
    The value is returned *exactly as found* (string, no re-formatting).
    """
    with csv_path.open(newline="") as fh:
        rows = list(csv.reader(fh))
        assert len(rows) >= 2, f"{csv_path} should have at least a header and one data row."
        return rows[-1][2]  # accuracy column of the last row


def expected_report_lines():
    """
    Build and return the list of expected lines (without the trailing newline)
    for final_accuracy_report.tsv by re-parsing the source metrics files.
    """
    # First collect final accuracies
    final_acc = {}
    for exp_id in EXPERIMENT_IDS:
        csv_path = BASE_DIR / exp_id / "metrics.csv"
        final_acc[exp_id] = read_metrics_final_accuracy(csv_path)

    # Determine the best experiment (highest accuracy; ties broken by lexicographic id)
    best_exp = max(
        sorted(EXPERIMENT_IDS),  # sort first for deterministic tie-breaking
        key=lambda k: float(final_acc[k]),
    )

    lines = ["experiment_id\tfinal_accuracy"]
    for exp_id in sorted(EXPERIMENT_IDS):  # alphabetical order
        lines.append(f"{exp_id}\t{final_acc[exp_id]}")
    lines.append(f"BEST\t{best_exp}")
    return lines


###############################################################################
# Tests
###############################################################################


def test_summary_directory_exists_and_is_directory():
    assert SUMMARY_DIR.exists(), f"Missing directory: {SUMMARY_DIR}"
    assert SUMMARY_DIR.is_dir(), f"{SUMMARY_DIR} exists but is not a directory."


def test_report_file_exists_and_is_file():
    assert REPORT_PATH.exists(), f"Missing report file: {REPORT_PATH}"
    assert REPORT_PATH.is_file(), f"{REPORT_PATH} exists but is not a regular file."


def test_report_file_exact_contents():
    expected_lines = expected_report_lines()
    expected_content = "\n".join(expected_lines) + "\n"  # terminating newline

    with REPORT_PATH.open("r", newline="") as fh:
        actual_content = fh.read()

    # 1. Check for single trailing newline
    assert actual_content.endswith("\n"), (
        f"{REPORT_PATH} must end with a single newline character."
    )
    assert not actual_content.endswith("\n\n"), (
        f"{REPORT_PATH} has more than one trailing newline."
    )

    # 2. Exact content match
    assert (
        actual_content == expected_content
    ), f"{REPORT_PATH} contents differ from expected.\n\nExpected:\n{expected_content!r}\n\nFound:\n{actual_content!r}"


def test_report_lines_have_exact_two_tab_separated_fields():
    """
    Guard against accidental spaces or additional tabs in each line.
    """
    with REPORT_PATH.open("r", newline="") as fh:
        for idx, line in enumerate(fh, start=1):
            stripped = line.rstrip("\n")
            parts = stripped.split("\t")
            assert len(parts) == 2, (
                f"{REPORT_PATH} line {idx} should contain exactly one TAB "
                f"separating two fields but found {len(parts) - 1} TABS."
            )
            for p in parts:
                assert p == p.strip(), (
                    f"{REPORT_PATH} line {idx} field '{p}' has unexpected "
                    f"leading/trailing whitespace."
                )


def test_actions_log_exists_and_is_non_empty():
    assert LOG_PATH.exists(), f"Missing actions log: {LOG_PATH}"
    assert LOG_PATH.is_file(), f"{LOG_PATH} exists but is not a regular file."
    assert LOG_PATH.stat().st_size > 0, f"{LOG_PATH} is empty."


def test_actions_log_format_and_chronology():
    """
    Validate that every line starts with an ISO-8601 timestamp and that the
    timestamps are in non-decreasing chronological order.
    """
    iso_regex = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}")

    timestamps = []
    with LOG_PATH.open("r", newline="") as fh:
        lines = fh.readlines()

    assert lines[-1].endswith("\n"), f"{LOG_PATH} must end with a newline."

    for idx, line in enumerate(lines, start=1):
        assert iso_regex.match(
            line
        ), f"{LOG_PATH} line {idx} does not start with an ISO-8601 timestamp: {line!r}"
        ts_string = line[:19]  # YYYY-MM-DDTHH:MM:SS
        try:
            ts = datetime.fromisoformat(ts_string)
        except ValueError:
            pytest.fail(
                f"{LOG_PATH} line {idx} has an invalid ISO-8601 timestamp: '{ts_string}'"
            )
        timestamps.append(ts)

    # Ensure non-decreasing chronological order
    for earlier, later in zip(timestamps, timestamps[1:]):
        assert earlier <= later, (
            f"Timestamps in {LOG_PATH} are not in chronological order: "
            f"{earlier.isoformat()} comes before {later.isoformat()}."
        )