You are an MLOps engineer who just inherited three finished deep-learning runs that live under:

```
/home/user/experiments/exp_alpha/metrics.csv  
/home/user/experiments/exp_beta/metrics.csv  
/home/user/experiments/exp_gamma/metrics.csv  
```

1.  Each `metrics.csv` file is already on disk and **has exactly the same column layout**:

    ```
    epoch,loss,accuracy
    <int>,<float>,<float>
    …
    ```

    *   Fields are comma-separated.
    *   The header line is always present.
    *   Every subsequent line corresponds to one training epoch.
    *   The **last data row (i.e. the one with the highest epoch value)** is the run’s final metric that we care about.

2.  Your task is to produce a concise, machine-readable dashboard that can be consumed by CI jobs.

    a)  Create a new directory
        `/home/user/experiments/summary`

    b)  Inside that directory write the file
        `/home/user/experiments/summary/final_accuracy_report.tsv`

        Exact format (tab-separated, no spaces):

        ```
        experiment_id<TAB>final_accuracy
        exp_alpha<TAB><α>
        exp_beta<TAB><β>
        exp_gamma<TAB><γ>
        BEST<TAB><best_experiment_id>
        ```

        where
        *   `<α>`, `<β>`, `<γ>` are the **accuracy values from the last line** of the corresponding `metrics.csv`.
        *   Lines **must be ordered alphabetically by experiment_id** (i.e., exp_alpha, exp_beta, exp_gamma) and the special “BEST” line must always be last.
        *   “BEST” is the literal word BEST (all caps) and `<best_experiment_id>` is the id that achieved the numerically highest final_accuracy.
        *   Accuracy values must be written exactly as they appear in the source file (do not re-format or round).
        *   The file must contain a terminating newline.

    c)  Also create a human readable operations log called
        `/home/user/experiments/summary/actions.log`

        Minimum requirements for `actions.log`:
        *   One line per high-level step you carried out (e.g., “Parsed exp_alpha metrics.csv”).
        *   Lines must be in chronological order.
        *   Prepend each line with an ISO-8601 timestamp (YYYY-MM-DDTHH:MM:SS).
        *   End the file with a newline.

3.  All paths are relative to `/home/user` (the container user).
    You do not have sudo. Make sure the summary directory and its files are created with default user permissions.

When you are done, you should be able to run

```
cat /home/user/experiments/summary/final_accuracy_report.tsv
```

and see the exact contents described above, followed by exactly one newline character.