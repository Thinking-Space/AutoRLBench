You are acting as a Site Reliability Engineer who has just received a small sample of raw uptime data in CSV format.
Your job is to create a concise incident-readiness report consisting of two derivative files that will later be shipped to the on-call dashboard.

There is exactly one input file:

• /home/user/data/uptime_sample.csv – A comma-separated file that already exists on disk.
  (Do NOT rename or alter this source file. Work only on copies/derivatives in the new directory described below.)

Required final state (all paths are absolute):

1.  Directory
    /home/user/sre_reports
    • Must exist when you are done.
    • Must contain only the three files listed below (nothing else).

2.  /home/user/sre_reports/downtime_events.csv
    • CSV, UTF-8, Unix line endings (LF only).
    • First line (header) must be:
      timestamp,service,status
    • Must contain ONLY the rows from the original uptime_sample.csv where the status column equals the literal string “DOWN”.
    • Row order must be preserved exactly as it appeared in the source file.
    • There must be a final newline (line-feed) after the last row.

3.  /home/user/sre_reports/downtime_summary.json
    • JSON object, pretty-printed with 2-space indentation.
    • Keys are the distinct service names found in the downtime_events.csv file, sorted lexicographically (ASCIIbetical).
    • Values are integers representing the total number of DOWN minutes for that service (each row in the input represents one minute).
    • The file must end with exactly one trailing newline.
    • Example format (do not rely on the exact numbers here—your script must calculate them from the data):
      ```json
      {
        "api-gateway": 42,
        "auth-service": 17
      }
      ```

4.  /home/user/sre_reports/action_log.txt
    • Plain-text log of the high-level shell commands or one-sentence descriptions you executed or scripted, one line per entry, in the order you performed them.
    • A minimum of 5 and a maximum of 10 non-empty lines.
    • Each line must begin with an ISO-8601 timestamp (YYYY-MM-DDTHH:MM:SSZ) followed by a single space and then your note.
    • Example (illustrative only):
      2023-09-15T08:45:01Z Created sre_reports directory

Constraints:

• Work entirely with standard command-line tools available on an up-to-date Debian/Ubuntu environment.
• You do NOT have sudo access.
• Ensure file permissions allow read/write for the current user (default umask is fine).
• Keep everything idempotent so the task can be re-run without manual cleanup.

The automated tests will confirm that:
• The directory /home/user/sre_reports exists.
• downtime_events.csv exactly matches the specification (header, correct rows, correct order, correct newline style).
• downtime_summary.json is syntactically valid, 2-space indented, keys sorted, correct counts, and ends with a single newline.
• action_log.txt contains 5–10 well-formed timestamped lines.

Produce no additional files anywhere else on the filesystem.