# test_final_state.py
"""
Final-state validation for the SRE reporting exercise.

This test-suite is executed *after* the student’s solution has run and is
responsible for asserting that the operating-system / container state matches
the specification exactly.

It verifies:

1. The directory /home/user/sre_reports exists and contains **only** the three
   required files.

2. /home/user/sre_reports/downtime_events.csv
   • LF-only line endings, UTF-8 text, trailing LF.
   • Header is exactly “timestamp,service,status”.
   • Contains *only* the rows from the original uptime_sample.csv whose
     status == "DOWN", in the same order.

3. /home/user/sre_reports/downtime_summary.json
   • 2-space indented, pretty-printed JSON with keys sorted.
   • Counts correctly represent total DOWN minutes per service.
   • File ends with exactly one LF and has no CR characters.

4. /home/user/sre_reports/action_log.txt
   • Between 5 and 10 non-empty lines.
   • Each line starts with an ISO-8601 UTC timestamp
     “YYYY-MM-DDTHH:MM:SSZ ” followed by free text.
   • LF-only line endings.

Only Python’s standard library and pytest are used.
"""

import json
import os
import re
from pathlib import Path
from datetime import datetime

import pytest

# --------------------------------------------------------------------------- #
# Paths
# --------------------------------------------------------------------------- #

RAW_FILE_PATH = Path("/home/user/data/uptime_sample.csv")
REPORTS_DIR = Path("/home/user/sre_reports")

DOWNTIME_EVENTS_CSV = REPORTS_DIR / "downtime_events.csv"
DOWNTIME_SUMMARY_JSON = REPORTS_DIR / "downtime_summary.json"
ACTION_LOG = REPORTS_DIR / "action_log.txt"

REQUIRED_FILES = {
    DOWNTIME_EVENTS_CSV.name,
    DOWNTIME_SUMMARY_JSON.name,
    ACTION_LOG.name,
}


# --------------------------------------------------------------------------- #
# Helper functions
# --------------------------------------------------------------------------- #
def read_lf_only(path: Path) -> bytes:
    """
    Read a file in binary mode and ensure it contains LF but *no* CR characters.
    Returns the file's raw bytes.
    """
    data = path.read_bytes()
    assert b"\r" not in data, f"{path} contains CR characters; expected LF only."
    return data


def parse_csv_rows(csv_text: str):
    """
    Very small CSV helper suited for the known, well-behaved sample:
    splits on LF, ignores empty trailing line, and returns list of rows,
    where each row is a list of fields split on ','.
    """
    lines = csv_text.splitlines()
    rows = [line.split(",") for line in lines if line]
    return rows


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #

def test_reports_directory_structure():
    """Directory exists and contains exactly the required files."""
    assert REPORTS_DIR.exists(), "Directory /home/user/sre_reports does not exist."
    assert REPORTS_DIR.is_dir(), "/home/user/sre_reports exists but is not a directory."

    dir_contents = {p.name for p in REPORTS_DIR.iterdir()}
    extra = dir_contents - REQUIRED_FILES
    missing = REQUIRED_FILES - dir_contents

    assert not extra, (
        "/home/user/sre_reports contains unexpected extra files or "
        f"sub-directories: {sorted(extra)}"
    )
    assert not missing, (
        "/home/user/sre_reports is missing required files: "
        f"{sorted(missing)}"
    )


def test_downtime_events_csv_exact():
    """downtime_events.csv must perfectly match the DOWN rows in the raw CSV."""
    # Read and validate file for LF only + trailing LF
    data = read_lf_only(DOWNTIME_EVENTS_CSV)
    assert data.endswith(b"\n"), (
        f"{DOWNTIME_EVENTS_CSV} must end with exactly one newline."
    )

    csv_text = data.decode("utf-8")
    rows = parse_csv_rows(csv_text)

    # ------------------------------------------------------------------ #
    # Validate header
    # ------------------------------------------------------------------ #
    assert rows, f"{DOWNTIME_EVENTS_CSV} is empty."
    header = rows[0]
    assert header == ["timestamp", "service", "status"], (
        "Header of downtime_events.csv is incorrect. "
        "Expected exactly: timestamp,service,status"
    )

    # ------------------------------------------------------------------ #
    # Build expectation from the raw CSV
    # ------------------------------------------------------------------ #
    raw_rows = parse_csv_rows(RAW_FILE_PATH.read_text(encoding="utf-8"))
    raw_header = raw_rows[0]
    assert raw_header == header, "Header mismatch between raw and downtime CSV."

    expected_rows = [
        row for row in raw_rows[1:]  # skip header
        if row[2] == "DOWN"
    ]

    # ------------------------------------------------------------------ #
    # Validate body
    # ------------------------------------------------------------------ #
    actual_body = rows[1:]  # skip header
    assert actual_body == expected_rows, (
        "downtime_events.csv does not contain the correct DOWN rows. "
        "Differences detected between expected and actual content."
    )

    # Ensure each body line's status column is literally "DOWN"
    for row in actual_body:
        assert row[2] == "DOWN", (
            "Found a row in downtime_events.csv whose status is not 'DOWN': "
            f"{','.join(row)}"
        )


def test_downtime_summary_json():
    """
    downtime_summary.json content, formatting, ordering, and trailing newline.
    """
    raw_bytes = read_lf_only(DOWNTIME_SUMMARY_JSON)
    assert raw_bytes.endswith(b"\n"), (
        f"{DOWNTIME_SUMMARY_JSON} must end with exactly one newline."
    )

    # Remove that single trailing LF for JSON parsing / text comparison
    json_text = raw_bytes[:-1].decode("utf-8")

    # ------------------------------------------------------------------ #
    # Parse & logical correctness
    # ------------------------------------------------------------------ #
    try:
        summary_obj = json.loads(json_text)
    except json.JSONDecodeError as exc:
        pytest.fail(f"downtime_summary.json is not valid JSON: {exc}")

    # Construct expected counts from downtime_events.csv
    event_rows = parse_csv_rows(DOWNTIME_EVENTS_CSV.read_text(encoding="utf-8"))
    counts = {}
    for row in event_rows[1:]:  # skip header
        service = row[1]
        counts[service] = counts.get(service, 0) + 1

    assert summary_obj == counts, (
        "Counts in downtime_summary.json are incorrect.\n"
        f"Expected: {counts!r}\nGot:      {summary_obj!r}"
    )

    # ------------------------------------------------------------------ #
    # Formatting correctness (2-space indent, sorted keys)
    # ------------------------------------------------------------------ #
    expected_json_text = json.dumps(
        counts,
        indent=2,
        sort_keys=True,
        ensure_ascii=False,
    )
    assert json_text == expected_json_text, (
        "Formatting of downtime_summary.json is incorrect.\n"
        "Expected exactly (including spaces and newlines):\n\n"
        f"{expected_json_text}\n\nGot:\n\n{json_text}"
    )


# Pre-compiled regular expression for ISO-8601 UTC timestamps
ISO_8601_UTC_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z .+$"
)


def test_action_log_format():
    """action_log.txt must follow line-format and size constraints."""
    data = read_lf_only(ACTION_LOG)
    # Optional: it's perfectly acceptable for this file to end or not end with LF,
    # but we still accept both. Use splitlines(keepends=False)
    lines = data.decode("utf-8").splitlines()

    # ------------------------------------------------------------------ #
    # Line count
    # ------------------------------------------------------------------ #
    assert 5 <= len(lines) <= 10, (
        "action_log.txt must contain between 5 and 10 non-empty lines "
        f"(found {len(lines)})."
    )

    # ------------------------------------------------------------------ #
    # Validate each line’s format
    # ------------------------------------------------------------------ #
    for idx, line in enumerate(lines, 1):
        assert ISO_8601_UTC_RE.match(line), (
            f"Line {idx} of action_log.txt does not start with a valid "
            "ISO-8601 UTC timestamp followed by a space and message:\n"
            f"{line!r}"
        )

        # Validate that the timestamp portion is a real date-time
        timestamp_part = line.split(" ", 1)[0]
        try:
            datetime.strptime(timestamp_part, "%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            pytest.fail(
                f"Line {idx} of action_log.txt contains an invalid timestamp: "
                f"{timestamp_part}"
            )