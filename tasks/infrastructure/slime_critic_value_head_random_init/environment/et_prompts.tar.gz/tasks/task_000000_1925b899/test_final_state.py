# test_final_state.py
"""
Pytest suite that validates the FINAL state of the operating-system / container
after the student has completed the deployment-prep task.

The assertions here use the privileged *truth* data supplied with the exercise.
If any check fails, the accompanying message will explain **exactly** what is
still wrong so the learner can correct it quickly.
"""

import os
import re
import time
from datetime import datetime, timezone, timedelta

import pytest


# ---------- Truth constants ---------------------------------------------------

DEPLOY_DIR = "/home/user/deployment_configs"
PROD_ENV_FILE = os.path.join(DEPLOY_DIR, "prod.env")
LOG_FILE = "/home/user/deployment_setup.log"

# Byte-exact content expected in prod.env (including the final newline)
EXPECTED_PROD_ENV = (
    "APP_ENV=production\n"
    "APP_DEBUG=false\n"
    "DB_HOST=db.prod.internal\n"
    "DB_PORT=5432\n"
)

# Regex for the single log line
LOG_LINE_REGEX = re.compile(
    r"^(?P<ts>[0-9]{4}-[0-9]{2}-[0-9]{2}T"
    r"[0-9]{2}:[0-9]{2}:[0-9]{2})Z  \|  deployment_configs prepared$"
)

# -----------------------------------------------------------------------------


def _read_file_bytes(path):
    with open(path, "rb") as fh:
        return fh.read()


def _read_file_text(path):
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


# ---------- Tests -------------------------------------------------------------


def test_deployment_configs_directory_exists_and_is_directory():
    assert os.path.exists(DEPLOY_DIR), (
        f"Directory {DEPLOY_DIR} does not exist. "
        "Create it with `mkdir -p /home/user/deployment_configs`."
    )
    assert os.path.isdir(DEPLOY_DIR), (
        f"{DEPLOY_DIR} exists but is not a directory."
    )


def test_prod_env_file_contents_are_exact():
    assert os.path.exists(PROD_ENV_FILE), (
        f"Expected file {PROD_ENV_FILE} to exist but it does not."
    )

    actual_bytes = _read_file_bytes(PROD_ENV_FILE)
    expected_bytes = EXPECTED_PROD_ENV.encode()

    assert actual_bytes == expected_bytes, (
        f"Contents of {PROD_ENV_FILE} are incorrect.\n\n"
        "Expected (byte-for-byte):\n"
        f"{EXPECTED_PROD_ENV!r}\n\n"
        "Actual:\n"
        f"{actual_bytes.decode(errors='replace')!r}"
    )


def test_log_file_exists_and_has_one_correct_line():
    assert os.path.exists(LOG_FILE), (
        f"Log file {LOG_FILE} does not exist."
    )

    content = _read_file_text(LOG_FILE)

    # Ensure there is exactly one newline which must be at EOF.
    newline_count = content.count("\n")
    assert newline_count == 1, (
        f"{LOG_FILE} must contain exactly one newline at the end of the single "
        f"line (found {newline_count})."
    )
    assert content.endswith("\n"), (
        f"{LOG_FILE} must end with a newline character."
    )

    # Strip the trailing newline for regex matching
    single_line = content.rstrip("\n")

    m = LOG_LINE_REGEX.match(single_line)
    assert m, (
        f"The log line does not match the required pattern:\n"
        "YYYY-MM-DDThh:mm:ssZ⎵⎵|⎵⎵deployment_configs prepared\n\n"
        f"Actual line:\n{single_line}"
    )

    # Validate timestamp is within the last 10 minutes
    ts_str = m.group("ts")
    try:
        ts_dt = datetime.strptime(ts_str, "%Y-%m-%dT%H:%M:%S").replace(
            tzinfo=timezone.utc
        )
    except ValueError:
        pytest.fail(
            f"Timestamp '{ts_str}' could not be parsed with format "
            "YYYY-MM-DDThh:mm:ss"
        )

    now_utc = datetime.now(timezone.utc)
    delta_seconds = abs((now_utc - ts_dt).total_seconds())
    assert delta_seconds <= 600, (
        f"Timestamp {ts_str}Z in {LOG_FILE} is not within the last 10 minutes "
        f"(difference is {int(delta_seconds)} seconds)."
    )