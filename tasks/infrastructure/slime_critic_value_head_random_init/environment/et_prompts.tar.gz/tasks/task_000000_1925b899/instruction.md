You are the release manager on a small team.
Before today’s deployment window opens you must create a dedicated configuration directory and drop in a production-specific “.env” file.
Once that is done, record a very small status log so that the build pipeline can automatically verify your work.

### REQUIREMENTS
1.  Create the directory
    `/home/user/deployment_configs`

2.  Inside that directory create the file
    `/home/user/deployment_configs/prod.env`
    with EXACTLY the four lines shown below (Unix line-feeds, no trailing spaces):
    ─────────────────────────────────────────
    APP_ENV=production
    APP_DEBUG=false
    DB_HOST=db.prod.internal
    DB_PORT=5432
    ─────────────────────────────────────────

3.  Create a single-line log file
    `/home/user/deployment_setup.log`
    whose only line must read (including the leading timestamp in ISO-8601 format down to seconds):
    `YYYY-MM-DDThh:mm:ssZ  |  deployment_configs prepared`
    *   Use the current UTC time when you run the command.
    *   Keep exactly two spaces before and after the pipe symbol (`  |  `).
    *   The automated test will accept any valid timestamp as long as it follows that precise “YYYY-MM-DDThh:mm:ssZ” pattern and is within the last 10 minutes at verification time.

### CONSTRAINTS
*   Do NOT modify any other files.
*   The log file must contain only that single line—no extra blank lines.