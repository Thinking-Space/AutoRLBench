You are acting as the storage-administrator for a small research lab.
The Principal Investigator has asked you to prepare two shared work areas
inside your home directory, assign the correct permissions,
populate them with placeholder data
and finally publish a **disk-quota report** that other scripts can parse.

Follow these functional requirements exactly:

1.  Directory layout  
    a. Create the parent folder  
       /home/user/data  
       if it does not yet exist.  
    b. Under that parent, create **exactly** these two sub-directories  
       • /home/user/data/long_term_archive  
       • /home/user/data/scratch_space  

2.  POSIX permissions  
    a. /home/user/data/long_term_archive  
       • chmod must be 750 (rwx r-x ---)  
    b. /home/user/data/scratch_space  
       • chmod must be 770 (rwx rwx ---)  

    Automated tests look at the **octal value** reported by  
    `stat -c %a <directory>` so do not rely on symbolic
    output.

3.  Seed files (to guarantee reproducible usage numbers)  
    a. Inside long_term_archive create one file named  
       backup_2023-logs.tar.gz with a size of **exactly 1 536 KB**  
       (that is 1 536 blocks of 1 024 bytes → 1 572 864 bytes).
    b. Inside scratch_space create one file named  
       test_disk_fill.img with a size of **exactly 5 120 KB**  
       (5 120 blocks of 1 024 bytes → 5 242 880 bytes).

4.  Disk-quota report  
    After the directories and files are ready, produce a single CSV file  
    /home/user/storage_quota_report.csv  
    with **three lines total** (one header + two data lines) in this
    machine-readable format (include the commas, no extra spaces):

        directory,soft_quota_mb,hard_quota_mb,current_usage_kb
        /home/user/data/long_term_archive,500,700,1536
        /home/user/data/scratch_space,1000,1200,5120

    Notes:  
    • The header must be exactly as shown (all lowercase).  
    • “current_usage_kb” values are what `du -sk` would report if run
      on the two directories after you have created the seed files.  
    • End the file with a single newline character.

When everything is complete, the automated grader will confirm:

   • The two directories exist under /home/user/data  
   • Their octal permission modes are 750 and 770, respectively  
   • The seed files exist with the exact byte sizes specified  
   • /home/user/storage_quota_report.csv exists and its
     contents match the three-line template above **exactly**.

Do not place any extra files inside /home/user/data or modify
any other part of the filesystem.
Console output is fine, but the only artefact the grader will read
is /home/user/storage_quota_report.csv.