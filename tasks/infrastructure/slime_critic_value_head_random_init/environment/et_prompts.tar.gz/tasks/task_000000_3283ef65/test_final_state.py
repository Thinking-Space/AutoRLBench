# test_final_state.py
#
# Pytest suite that verifies the **final** operating-system state after the
# student has performed the storage-administration task.
#
# The assertions are derived from the “truth” section of the challenge and
# intentionally fail with clear, actionable messages if anything is still
# wrong.

import os
import stat
from pathlib import Path

import pytest

# ----- CONSTANTS -------------------------------------------------------------

DATA_PARENT              = Path("/home/user/data")
LONG_TERM_ARCHIVE_DIR    = DATA_PARENT / "long_term_archive"
SCRATCH_SPACE_DIR        = DATA_PARENT / "scratch_space"

BACKUP_FILE              = LONG_TERM_ARCHIVE_DIR / "backup_2023-logs.tar.gz"
TEST_DISK_FILL_FILE      = SCRATCH_SPACE_DIR / "test_disk_fill.img"

QUOTA_REPORT             = Path("/home/user/storage_quota_report.csv")

# Expected octal permission modes (owner-group-other)
MODE_LONG_TERM_ARCHIVE   = 0o750  # rwx r-x ---
MODE_SCRATCH_SPACE       = 0o770  # rwx rwx ---

# Expected file sizes in **bytes**
SIZE_BACKUP_FILE_BYTES   = 1_572_864   # 1 536 × 1 024
SIZE_DISK_FILL_FILE_BYTES= 5_242_880   # 5 120 × 1 024

# Expected quota-report contents (must end with a *single* newline)
EXPECTED_QUOTA_CSV = (
    "directory,soft_quota_mb,hard_quota_mb,current_usage_kb\n"
    "/home/user/data/long_term_archive,500,700,1536\n"
    "/home/user/data/scratch_space,1000,1200,5120\n"
)


# ----- HELPER ----------------------------------------------------------------

def _octal_permissions(path: Path) -> int:
    """
    Return permission bits (e.g. 0o750) of *path*.
    """
    return stat.S_IMODE(path.stat().st_mode)


# ----- TESTS -----------------------------------------------------------------

def test_parent_directory_exists_and_has_only_expected_children():
    """
    /home/user/data must exist and contain *exactly* the two required
    sub-directories (no more, no less).
    """
    assert DATA_PARENT.exists(), f"Directory {DATA_PARENT} is missing."
    assert DATA_PARENT.is_dir(), f"{DATA_PARENT} exists but is not a directory."

    # Collect non-hidden entries (ignore things like '.DS_Store' if any).
    children = [
        entry.name
        for entry in DATA_PARENT.iterdir()
        if not entry.name.startswith(".")
    ]
    expected_children = {"long_term_archive", "scratch_space"}
    assert set(children) == expected_children, (
        f"{DATA_PARENT} should contain ONLY {sorted(expected_children)} but "
        f"currently contains {sorted(children)}."
    )


@pytest.mark.parametrize(
    "directory, expected_mode",
    [
        (LONG_TERM_ARCHIVE_DIR, MODE_LONG_TERM_ARCHIVE),
        (SCRATCH_SPACE_DIR,     MODE_SCRATCH_SPACE),
    ],
)
def test_required_directories_exist_with_correct_permissions(directory: Path, expected_mode: int):
    """
    Confirm that each required directory exists with the exact octal mode.
    """
    assert directory.exists(), f"Required directory {directory} is missing."
    assert directory.is_dir(), f"{directory} exists but is not a directory."

    actual_mode = _octal_permissions(directory)
    assert actual_mode == expected_mode, (
        f"Incorrect permissions on {directory}. "
        f"Expected mode {oct(expected_mode)}, got {oct(actual_mode)}."
    )


@pytest.mark.parametrize(
    "file_path, expected_size",
    [
        (BACKUP_FILE,         SIZE_BACKUP_FILE_BYTES),
        (TEST_DISK_FILL_FILE, SIZE_DISK_FILL_FILE_BYTES),
    ],
)
def test_seed_files_exist_with_exact_size(file_path: Path, expected_size: int):
    """
    Ensure each seed file exists and has the exact byte size requested.
    """
    assert file_path.exists(), f"Seed file {file_path} is missing."
    assert file_path.is_file(), f"{file_path} exists but is not a regular file."

    actual_size = file_path.stat().st_size
    assert actual_size == expected_size, (
        f"Incorrect size for {file_path}. Expected {expected_size} bytes, got {actual_size}."
    )


def test_quota_report_exists_and_is_exactly_correct():
    """
    /home/user/storage_quota_report.csv must exist and its contents must match
    the specification *exactly*, including the trailing newline.
    """
    assert QUOTA_REPORT.exists(), f"Quota report {QUOTA_REPORT} is missing."
    assert QUOTA_REPORT.is_file(), f"{QUOTA_REPORT} exists but is not a regular file."

    # Read file in binary to check for trailing newline accurately, then decode.
    content_bytes = QUOTA_REPORT.read_bytes()
    assert content_bytes.endswith(b"\n"), (
        f"{QUOTA_REPORT} must end with exactly one newline character."
    )

    content = content_bytes.decode("utf-8")
    assert content == EXPECTED_QUOTA_CSV, (
        f"Contents of {QUOTA_REPORT} are incorrect.\n\n"
        "EXPECTED:\n"
        f"{EXPECTED_QUOTA_CSV!r}\n\n"
        "FOUND:\n"
        f"{content!r}"
    )


def test_quota_report_has_three_lines_only():
    """
    The CSV must contain a header plus two data lines (total: 3).
    This separate test provides a clearer error if extra lines are present.
    """
    lines = QUOTA_REPORT.read_text().splitlines()
    assert len(lines) == 3, (
        f"{QUOTA_REPORT} should contain exactly 3 lines "
        f"(1 header + 2 data). Found {len(lines)} lines."
    )