# test_final_state.py
#
# Pytest suite that validates the **final** operating-system state for the
# “security-audit virtual-env” exercise.  The tests confirm that:
#
# 1. /home/user/sec_audit exists;
# 2. a valid virtual-environment directory /home/user/sec_audit/audit_env
#    exists and contains bin/activate;
# 3. /home/user/sec_audit/activate_permission.log exists, contains exactly
#    the single line “755\n”, and that this value matches the actual
#    permission bits of bin/activate.
#
# The suite provides clear, actionable failure messages whenever a check
# does not pass.
#
# Only the Python standard library and pytest are used.

import os
import stat
from pathlib import Path

import pytest

HOME = Path("/home/user")
SEC_AUDIT_DIR = HOME / "sec_audit"
VENV_DIR = SEC_AUDIT_DIR / "audit_env"
BIN_DIR = VENV_DIR / "bin"
ACTIVATE_FILE = BIN_DIR / "activate"
PYVENV_CFG = VENV_DIR / "pyvenv.cfg"
PERM_LOG = SEC_AUDIT_DIR / "activate_permission.log"


def _octal_perm(path: Path) -> str:
    """
    Return the file's permission bits as a zero-stripped octal string
    (e.g. 0o755 -> "755").
    """
    mode = path.stat().st_mode & 0o777
    return f"{mode:o}"


def test_sec_audit_directory_exists() -> None:
    """
    The top-level directory /home/user/sec_audit must exist and be a directory.
    """
    assert SEC_AUDIT_DIR.exists(), (
        f"Expected directory {SEC_AUDIT_DIR} to exist, but it is missing."
    )
    assert SEC_AUDIT_DIR.is_dir(), (
        f"{SEC_AUDIT_DIR} exists but is not a directory."
    )


def test_virtualenv_structure() -> None:
    """
    /home/user/sec_audit/audit_env should look like a Python venv:
    – root directory exists
    – contains a 'bin' subdirectory
    – that subdirectory contains an 'activate' file
    – pyvenv.cfg exists in the venv root (strong indicator of a venv)
    """
    assert VENV_DIR.exists(), (
        f"Virtual-environment directory {VENV_DIR} is missing."
    )
    assert VENV_DIR.is_dir(), (
        f"{VENV_DIR} exists but is not a directory."
    )

    assert BIN_DIR.exists(), (
        f"Expected subdirectory {BIN_DIR} inside the virtual environment, "
        "but it is missing."
    )
    assert BIN_DIR.is_dir(), (
        f"{BIN_DIR} exists but is not a directory."
    )

    assert ACTIVATE_FILE.exists(), (
        f"activate script {ACTIVATE_FILE} is missing."
    )
    assert ACTIVATE_FILE.is_file(), (
        f"{ACTIVATE_FILE} exists but is not a regular file."
    )

    # pyvenv.cfg is created by the stdlib venv module; its presence supports
    # that a proper venv was made.
    assert PYVENV_CFG.exists(), (
        f"{PYVENV_CFG} is missing. The directory does not look like a "
        "standard venv created by python -m venv."
    )


def test_activate_file_permissions_are_755() -> None:
    """
    The activate script must have permission bits 755.
    """
    perms = _octal_perm(ACTIVATE_FILE)
    assert perms == "755", (
        f"activate script has permissions {perms}, expected 755."
    )


def test_permission_log_file_exists() -> None:
    """
    The permission-log file must exist and be a regular file.
    """
    assert PERM_LOG.exists(), (
        f"Permission-log file {PERM_LOG} is missing."
    )
    assert PERM_LOG.is_file(), (
        f"{PERM_LOG} exists but is not a regular file."
    )


def test_permission_log_content_exact() -> None:
    """
    The log file must contain exactly one line: '755\\n'
    – No extra spaces.
    – No extra lines.
    – Must end with a newline.
    """
    content = PERM_LOG.read_text(encoding="utf-8", errors="strict")

    # Exact match test gives the most precise feedback
    assert content == "755\n", (
        f"{PERM_LOG} has unexpected content.\n"
        "Expected exactly:\n"
        "  755\\n\n"
        f"Got ({len(content)} bytes):\n"
        f"  {repr(content)}"
    )

    # Secondary sanity checks (reach only if the exact-match passed).
    lines = content.splitlines(keepends=False)
    assert len(lines) == 1, (
        f"{PERM_LOG} should contain exactly one line, found {len(lines)} lines."
    )
    assert lines[0] == "755", (
        f"The single line in {PERM_LOG} should read '755', found '{lines[0]}'."
    )


def test_log_matches_actual_permissions() -> None:
    """
    Cross-check: the value recorded in the log must match the actual
    permission bits of bin/activate.
    """
    logged_perms = PERM_LOG.read_text().strip()
    actual_perms = _octal_perm(ACTIVATE_FILE)
    assert logged_perms == actual_perms, (
        f"The permissions recorded in {PERM_LOG} ({logged_perms}) do not match "
        f"the actual permissions of {ACTIVATE_FILE} ({actual_perms})."
    )