You are acting as a security auditor who must make a quick spot-check on the file permissions of a freshly created Python virtual environment.
Follow these requirements exactly:

1.  In your home directory create a sub-directory named
    /home/user/sec_audit

2.  Inside that directory create a Python virtual environment (using the standard library module venv) whose root directory must be named
    /home/user/sec_audit/audit_env

3.  Without activating the virtual environment or running any extra commands, collect the **numeric** permission bits of the file
    /home/user/sec_audit/audit_env/bin/activate
    and save them to a log file located at
    /home/user/sec_audit/activate_permission.log

4.  The log file must contain **exactly** one line, with no leading or trailing spaces, no additional text, and a terminating newline.
    Format (what the automated checker will look for):

    755

    In other words, the file should consist solely of the three digits representing the permission bits followed by a newline (Unix line-ending).

Constraint:
*   Do not use sudo or touch any location outside /home/user/sec_audit.

When you are done, the automated test will confirm that:
*   /home/user/sec_audit/audit_env exists and looks like a valid venv (i.e., contains bin/activate)
*   /home/user/sec_audit/activate_permission.log exists with the exact content described above.