You are an edge-computing engineer who has just finished deploying a lightweight monitoring agent to a fleet of IoT devices.  
To confirm that the device you are logged into is alive and able to write to disk, you want to drop a single-line heartbeat log.

**Goal**
*   Make sure that a directory called `/home/user/iot_metrics` exists.
*   Create (or overwrite if it already exists) the file `/home/user/iot_metrics/heartbeat.log` so that its entire contents are exactly the single line shown below ─ no extra characters, no extra spaces, no trailing blank lines:

    `heartbeat: alive`

**Output format that the automated grader will check**
*   The file `/home/user/iot_metrics/heartbeat.log` must exist.
*   The file must contain exactly 15 bytes: the 14 printable characters “heartbeat: alive” followed by a single UNIX newline (ASCII 0x0A).
*   There must be nothing else in the file.
*   The parent directory `/home/user/iot_metrics` must be present and accessible by the current user (an automated test will attempt to cd into it and read the file).

Once the file exists with the exact content described above, the task is complete.