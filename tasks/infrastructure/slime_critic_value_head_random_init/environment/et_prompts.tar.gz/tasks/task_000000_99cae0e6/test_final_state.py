# test_final_state.py
#
# Pytest suite that validates the *final* state of the system **after**
# the learner has completed the “heartbeat” task.
#
# Truth requirements (summarised):
#   1. Directory  /home/user/iot_metrics            must exist and be a directory.
#   2. File       /home/user/iot_metrics/heartbeat.log
#        • must exist and be a regular file.
#        • must be owner-readable (at least mode 0644 ― more permissive is fine).
#   3. File contents: exactly 15 bytes:
#        b"heartbeat: alive\n"
#      No extra bytes, no CR (0x0D), no additional newlines.
#
# Any deviation from the above MUST raise a clear, actionable assertion
# error so the learner can immediately see what still needs fixing.
#
# The tests intentionally use *absolute* paths, per the rubric, and rely
# solely on the Python standard library and `pytest`.

import os
import pathlib
import stat
import pytest

DIR_PATH = pathlib.Path("/home/user/iot_metrics")
FILE_PATH = DIR_PATH / "heartbeat.log"
EXPECTED_BYTES = b"heartbeat: alive\n"
EXPECTED_LEN = len(EXPECTED_BYTES)  # Should be 15


def _mode_str(mode: int) -> str:
    """Return human-readable octal string of a file-mode integer, e.g. '0644'."""
    return f"{mode & 0o777:04o}"


def test_metrics_directory_exists_and_is_directory():
    assert DIR_PATH.exists(), (
        f"Required directory '{DIR_PATH}' is missing."
    )
    assert DIR_PATH.is_dir(), (
        f"Expected '{DIR_PATH}' to be a directory, but it exists and is not a directory."
    )

    # Make sure we can actually enter the directory (directory is 'accessible').
    try:
        os.chdir(DIR_PATH)
    except Exception as exc:
        pytest.fail(
            f"Unable to access directory '{DIR_PATH}': {exc}\n"
            "Check directory permissions (should allow the current user to traverse)."
        )


def test_heartbeat_log_exists_and_is_regular_file():
    assert FILE_PATH.exists(), (
        f"File '{FILE_PATH}' is missing."
    )
    assert FILE_PATH.is_file(), (
        f"'{FILE_PATH}' exists but is not a regular file."
    )


def test_file_mode_is_at_least_0644():
    """
    The specification requires the file to be owner-readable; the reference
    text says “mode 0644 or more permissive”.  That means the following bits
    must be *set* at minimum:

        owner: read & write
        group: read
        other: read

    If any of those mandatory bits are missing, we fail.  We do *not* forbid
    additional permissive bits (e.g. executable or writable by group/other).
    """
    st_mode = FILE_PATH.stat().st_mode
    missing_bits = []

    if not (st_mode & stat.S_IRUSR):
        missing_bits.append("owner-read (0400)")
    if not (st_mode & stat.S_IWUSR):
        missing_bits.append("owner-write (0200)")
    if not (st_mode & stat.S_IRGRP):
        missing_bits.append("group-read (0040)")
    if not (st_mode & stat.S_IROTH):
        missing_bits.append("other-read (0004)")

    assert not missing_bits, (
        "File permissions for '{file}' are too restrictive.\n"
        "Current mode: {current}\n"
        "Missing mandatory permission bits: {missing}\n"
        "The mode must be at least 0644 (rw-r--r--) or more permissive."
    ).format(
        file=FILE_PATH,
        current=_mode_str(st_mode),
        missing=", ".join(missing_bits),
    )


def test_file_contents_are_exact():
    try:
        data = FILE_PATH.read_bytes()
    except Exception as exc:
        pytest.fail(
            f"Unable to read '{FILE_PATH}': {exc}"
        )

    assert len(data) == EXPECTED_LEN, (
        f"'{FILE_PATH}' has incorrect length: expected {EXPECTED_LEN} bytes, "
        f"found {len(data)} bytes."
    )

    assert data == EXPECTED_BYTES, (
        f"'{FILE_PATH}' contents do not match the required payload.\n"
        "Expected (hex): "
        f"{EXPECTED_BYTES.hex(' ')}\n"
        "Found    (hex): "
        f"{data.hex(' ')}\n\n"
        "The file must contain exactly the ASCII text 'heartbeat: alive' "
        "followed by a single UNIX newline (0x0A) and nothing else."
    )