You are a compliance analyst who must produce a repeatable audit trail that demonstrates how two critical host names resolve on the current Linux system.

A data-file already exists that lists the host names along with the IP address that **MUST** be returned by the resolver:

*   File path: `/home/user/dns_testset/expected_hosts.txt`
*   File mode: 0644
*   Exact file contents (two lines, no extra blank line at the end):
    ```
    localhost=127.0.0.1
    ip6-localhost=::1
    ```

Your assignment:

*   Create the directory `/home/user/audit` if it does not already exist.
*   Using the information in `/home/user/dns_testset/expected_hosts.txt`, test every host name with the system resolver.
    – Use the first field (the address) of the command “`getent hosts <hostname>`” as the resolved IP.
*   Create the file `/home/user/audit/dns_resolution_audit.log` (overwriting the file if it exists). For every host name tested, the file must contain one CSV line. The required CSV format is strictly:

        hostname,resolved_ip,status

    *   `hostname` – exactly as it appears (case-sensitive) in `expected_hosts.txt`
    *   `resolved_ip` – exactly the first field returned by “`getent hosts …`”
    *   `status` – the literal string `PASS` if `resolved_ip` matches the IP that appears to the right of “`=`” in `expected_hosts.txt`, otherwise `FAIL`

    The audit file must contain no header row, no extra spaces, and preserve the same host-order as in `expected_hosts.txt`.

    Example of correct formatting (actual IPs must match your system):

        localhost,127.0.0.1,PASS
        ip6-localhost,::1,PASS

*   Capture a separate, ordered command trail. Create `/home/user/audit/command_history.log` containing one line per command you ran to accomplish this task, numbered sequentially starting with “`#1 `”.
    Example line format (do **not** copy literally):

        #1 getent hosts localhost

    The hash-sign and the number must be followed by exactly one space, then the command that was issued.
    Every command that contributes to the final result must appear here, including any background (`&`) commands and any explicit waits you perform. The log must show commands in the order you typed them.
    Do **not** include commands that you typed but later edited out or that failed without contributing to the solution.

When your work is complete, the two required files must exist:

*   `/home/user/audit/dns_resolution_audit.log`
*   `/home/user/audit/command_history.log`

The automated test suite will verify:

*   `/home/user/audit/dns_resolution_audit.log` exists, is readable, has exactly two non-empty lines and each line follows the precise CSV pattern described above.
*   The first line must concern “`localhost`”; the second must concern “`ip6-localhost`”.
*   The status field must read `PASS` for both lines.
*   `/home/user/audit/command_history.log` exists, is non-empty, and every line starts with “`#<number> `” where `<number>` forms a contiguous ascending sequence starting at 1.

Make sure all paths, filenames, line-formats and ordering are **exactly** as specified, because the tests are fully automated and strict.