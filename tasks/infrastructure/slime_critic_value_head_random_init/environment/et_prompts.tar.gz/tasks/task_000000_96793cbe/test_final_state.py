# test_final_state.py
#
# Pytest suite that validates the FINAL state of the operating-system /
# container after the student has completed the DNS audit task.
#
# The suite verifies, with strict precision, that:
#
# 1. /home/user/audit/dns_resolution_audit.log
#       * exists, is a regular file, mode 0644
#       * contains exactly two non-empty lines
#       * each line follows the CSV pattern:
#             hostname,resolved_ip,status
#       * the lines are ordered:
#             1. localhost,127.0.0.1,PASS
#             2. ip6-localhost,::1,PASS
#
# 2. /home/user/audit/command_history.log
#       * exists, is a regular file, mode 0644
#       * contains ≥ 2 lines
#       * every line matches regex  ^#[1-9][0-9]*\s.+$
#       * numbers start at 1 and form a contiguous ascending sequence
#
# Any deviation from the truth data will raise an assertion with a clear
# explanation of what is still wrong.

import os
import re
import stat
from pathlib import Path

import pytest

# ---------- Constants --------------------------------------------------------

AUDIT_DIR = Path("/home/user/audit")
DNS_LOG = AUDIT_DIR / "dns_resolution_audit.log"
CMD_LOG = AUDIT_DIR / "command_history.log"

FILE_MODE_EXPECTED = 0o644

EXPECTED_DNS_LINES = [
    "localhost,127.0.0.1,PASS",
    "ip6-localhost,::1,PASS",
]

COMMAND_LINE_RE = re.compile(r"^#[1-9][0-9]*\s.+$")

# ---------- Helper functions -------------------------------------------------


def _mode(path: Path) -> int:
    """
    Return Unix permission bits (e.g. 0o644) for *path*.
    """
    return stat.S_IMODE(path.stat().st_mode)


def _read_lines(path: Path) -> list[str]:
    """
    Read *path* and return a list of lines **without** trailing newline
    characters.
    Uses universal newlines to be robust to '\n' or '\r\n' endings.
    """
    return path.read_text(encoding="utf-8").splitlines()


# ---------- Tests ------------------------------------------------------------


@pytest.fixture(scope="module")
def dns_lines():
    """Return the list of lines in dns_resolution_audit.log."""
    assert DNS_LOG.exists(), (
        f"Required file '{DNS_LOG}' is missing."
    )
    assert DNS_LOG.is_file(), (
        f"Expected '{DNS_LOG}' to be a regular file, but it is not."
    )

    mode = _mode(DNS_LOG)
    assert mode == FILE_MODE_EXPECTED, (
        f"File '{DNS_LOG}' must have permissions "
        f"{oct(FILE_MODE_EXPECTED)}, found {oct(mode)}."
    )

    lines = _read_lines(DNS_LOG)
    return lines


def test_dns_log_line_count_and_exact_content(dns_lines):
    """
    dns_resolution_audit.log must contain exactly the two expected lines.
    """
    assert len(dns_lines) == 2, (
        f"File '{DNS_LOG}' must contain exactly 2 lines; "
        f"found {len(dns_lines)}."
    )

    # Check each line individually to give precise feedback
    for idx, (expected, actual) in enumerate(zip(EXPECTED_DNS_LINES, dns_lines), 1):
        assert actual == expected, (
            f"Line {idx} of '{DNS_LOG}' is incorrect.\n"
            f"Expected: '{expected}'\n"
            f"Found:    '{actual}'"
        )


def test_dns_log_field_structure(dns_lines):
    """
    Verify each CSV line has exactly three fields with no extra whitespace.
    """
    for idx, line in enumerate(dns_lines, 1):
        parts = line.split(",")
        assert len(parts) == 3, (
            f"Line {idx} of '{DNS_LOG}' must have exactly 3 comma-separated "
            f"fields; found {len(parts)} field(s): '{line}'"
        )
        # No leading/trailing whitespace allowed in any part
        for p in parts:
            assert p == p.strip(), (
                f"Field '{p}' in line {idx} of '{DNS_LOG}' contains "
                f"unexpected leading or trailing whitespace."
            )


@pytest.fixture(scope="module")
def command_lines():
    """Return the list of lines in command_history.log."""
    assert CMD_LOG.exists(), (
        f"Required file '{CMD_LOG}' is missing."
    )
    assert CMD_LOG.is_file(), (
        f"Expected '{CMD_LOG}' to be a regular file, but it is not."
    )

    mode = _mode(CMD_LOG)
    assert mode == FILE_MODE_EXPECTED, (
        f"File '{CMD_LOG}' must have permissions "
        f"{oct(FILE_MODE_EXPECTED)}, found {oct(mode)}."
    )

    lines = _read_lines(CMD_LOG)
    assert lines, (
        f"File '{CMD_LOG}' must not be empty."
    )
    return lines


def test_command_history_format(command_lines):
    """
    Ensure every line in command_history.log follows the required pattern
    and numbering is contiguous starting at 1.
    """
    for idx, line in enumerate(command_lines, 1):
        assert COMMAND_LINE_RE.match(line), (
            f"Line {idx} of '{CMD_LOG}' does not match the required pattern "
            f"\"#<number> <command>\".\n"
            f"Offending line: '{line}'"
        )

    # Extract numbers and validate sequence
    numbers = [int(line.split(" ", 1)[0][1:]) for line in command_lines]
    expected_sequence = list(range(1, len(numbers) + 1))
    assert numbers == expected_sequence, (
        f"The numbering in '{CMD_LOG}' is not a contiguous ascending sequence "
        f"starting at 1.\nExpected: {expected_sequence}\nFound:    {numbers}"
    )