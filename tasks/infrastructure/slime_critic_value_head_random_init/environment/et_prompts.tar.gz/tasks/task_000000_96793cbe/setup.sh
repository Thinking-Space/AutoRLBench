#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


set -e && \
    apt-get update && \
    apt-get install -y --no-install-recommends \
        python3 \
        python3-pip && \
    pip3 install --no-cache-dir pytest

if ! id -u user >/dev/null 2>&1; then \
        useradd -m -u 1000 -s /bin/bash user; \
    fi

chmod 0755 /home/user

install -d -m 0755 /home/user/dns_testset

printf 'localhost=127.0.0.1\nip6-localhost=::1' \
        > /home/user/dns_testset/expected_hosts.txt && \
    chmod 0644 /home/user/dns_testset/expected_hosts.txt

chown -R 1000:1000 /home/user/dns_testset

rm -rf /home/user/audit || true

chmod 755 /home/user

export PATH="/home/user/.local/bin:${PATH}"
