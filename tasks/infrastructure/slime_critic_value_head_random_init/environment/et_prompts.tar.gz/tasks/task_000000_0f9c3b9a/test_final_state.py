# test_final_state.py
#
# Pytest suite that validates the operating-system state
# AFTER the student has completed the assignment.
#
# The checks enforce the exact deliverables described in the task
# specification and compare them against the authoritative ground-truth
# embedded below.  Any deviation—wrong byte counts, wrong ordering,
# superfluous whitespace/lines, missing/extra files, etc.—will cause a
# test failure with a clear explanation of what is still wrong.
#
# Only the Python standard library and pytest are used.

import difflib
import os
import stat

import pytest

HOME = "/home/user"

# ----------------------------------------------------------------------
#  Ground-truth for the three source HTML pages – they must remain
#  unmodified by the student’s solution.
# ----------------------------------------------------------------------
WEBPAGES_DIR = os.path.join(HOME, "webpages")
HTML_FILES = {
    "page1.html": 75,
    "page2.html": 74,
    "page3.html": 77,
}


# ----------------------------------------------------------------------
#  Expected artefacts produced by the student.
# ----------------------------------------------------------------------
PERF_DIR = os.path.join(HOME, "perf")
CSV_REPORT = os.path.join(PERF_DIR, "initial_load_metrics.csv")
LOG_REPORT = os.path.join(PERF_DIR, "content_length.log")

# Compose expected file contents precisely (with a final trailing LF).
_EXPECTED_CSV_LINES = [
    "url,response_time_ms,download_size_bytes",
    "file:///home/user/webpages/page1.html,N/A,75",
    "file:///home/user/webpages/page2.html,N/A,74",
    "file:///home/user/webpages/page3.html,N/A,77",
]
EXPECTED_CSV_CONTENT = "\n".join(_EXPECTED_CSV_LINES) + "\n"

_EXPECTED_LOG_LINES = [
    "/home/user/webpages/page1.html: 75",
    "/home/user/webpages/page2.html: 74",
    "/home/user/webpages/page3.html: 77",
]
EXPECTED_LOG_CONTENT = "\n".join(_EXPECTED_LOG_LINES) + "\n"


# ----------------------------------------------------------------------
#  Helper functions
# ----------------------------------------------------------------------
def _full_html_path(filename: str) -> str:
    return os.path.join(WEBPAGES_DIR, filename)


def _file_size(path: str) -> int:
    """Return the size in bytes of *path*, asserting that it is a regular file."""
    st = os.stat(path)
    if not stat.S_ISREG(st.st_mode):
        raise AssertionError(f"{path!r} exists but is not a regular file "
                             f"(mode={oct(st.st_mode)})")
    return st.st_size


def _compare_text_file(path: str, expected: str) -> None:
    """
    Compare the entire textual contents of *path* against *expected*.
    Fail with a unified diff if they differ.  Also reject CRLF endings.
    """
    if not os.path.isfile(path):
        pytest.fail(f"Expected file {path} to exist and be a regular file.")

    with open(path, "rb") as fh:
        raw = fh.read()

    # Reject any CR (Windows) line endings outright.
    if b"\r" in raw:
        pytest.fail(
            f"File {path} contains carriage-return (\\r) characters. "
            "Use Unix LF line endings only."
        )

    actual = raw.decode("utf-8")

    if actual != expected:
        diff = "\n".join(
            difflib.unified_diff(
                expected.splitlines(keepends=True),
                actual.splitlines(keepends=True),
                fromfile="expected",
                tofile="actual",
            )
        )
        pytest.fail(
            f"Contents of {path} do not match the required format:\n{diff}"
        )


# ----------------------------------------------------------------------
#  Tests
# ----------------------------------------------------------------------
def test_html_files_still_exist_and_unchanged():
    """
    The original HTML pages must still be present and byte-for-byte identical.
    Students should never modify or move these source files.
    """
    for filename, expected_size in HTML_FILES.items():
        full_path = _full_html_path(filename)

        assert os.path.exists(full_path), (
            f"Required HTML file {full_path} is missing."
        )

        size = _file_size(full_path)
        assert size == expected_size, (
            f"HTML file {full_path} was expected to be {expected_size} bytes "
            f"but is now {size} bytes. Do not modify the source pages."
        )


def test_perf_directory_created():
    assert os.path.isdir(PERF_DIR), (
        f"Directory {PERF_DIR} has not been created."
    )


def test_csv_report_exists_and_correct():
    _compare_text_file(CSV_REPORT, EXPECTED_CSV_CONTENT)


def test_log_report_exists_and_correct():
    _compare_text_file(LOG_REPORT, EXPECTED_LOG_CONTENT)


def test_no_extra_files_in_perf_directory():
    """
    Fail if the student created additional unexpected files in /home/user/perf.
    Only the two specified artefacts are allowed.
    """
    allowed = {CSV_REPORT, LOG_REPORT}
    for entry in os.listdir(PERF_DIR):
        path = os.path.join(PERF_DIR, entry)
        if path not in allowed:
            pytest.fail(f"Unexpected file or directory found: {path}")