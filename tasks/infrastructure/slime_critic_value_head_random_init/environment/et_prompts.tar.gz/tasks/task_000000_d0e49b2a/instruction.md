You are acting as a release-manager who must prepare a set of
service configuration files for the next production deployment.
All the material you need is already present in

    /home/user/deployment_configs/

Detailed objectives
-------------------
1.  Inside that directory there are exactly four “*.conf” files.
    Every file follows *precisely* this key-value format (1 value per
    line, no extra whitespace):

        ServiceName: <string>
        Version: <major>.<minor>.<patch>
        Environment: <string>
        Status: <string>

2.  A service that currently has

        Environment: staging
        Status: READY

    must be promoted to production:
    *   increment ONLY the patch component of Version by **+1**
        (e.g. 1.3.7  →  1.3.8)
    *   replace Environment with «production»
    *   replace Status      with «LIVE»

    Every other service must be left completely untouched.

3.  Produce the following two *new* artefacts in the same directory
    (exact filenames, exact spellings):

    a)  `/home/user/deployment_configs/release_summary.csv`
        CSV with **exactly three columns** in this order:
        `Environment,Status,Count`
        One header line plus one data line per
        Environment/Status combination that exists *after* your
        updates.  Sort rows first by Environment, then by Status,
        both ascending.  Do not add extra spaces.  Example pattern:

            Environment,Status,Count
            production,LIVE,3
            staging,IN_TEST,1

    b)  `/home/user/deployment_configs/release_notes.txt`
        Fixed-width notes that will be e-mailed:

            Line 1 : literal text  "Release Notes - 2023-10-15"
            Line 2 : exactly 26 ‘=’ characters
            Line 3 : blank
            Subsequent lines: one line per *promoted* service,
                            sorted alphabetically by ServiceName,
                            format  "<ServiceName> <Version>"
            Final file must end with a single trailing newline.

4.  Create a simple text log capturing each promotion:

        /home/user/deployment_configs/change_log.log

    One line per promoted service, format **exactly**:

        <ServiceName> bumped <oldVersion> -> <newVersion>

    Maintain alphabetical order by ServiceName.

5.  IMPORTANT CONSTRAINTS
    *   Use only standard CLI tools.
    *   Do NOT hard-code absolute version strings—derive them from
        the files you read.
    *   All paths, filenames and output formats must match this
        description byte-for-byte; the automated grader will fail on
        any deviation.
    *   Do your work exclusively inside `/home/user/deployment_configs/` ;
        you do not need elevated privileges.
    *   Display whatever console output you find helpful, but make sure
        the artefacts listed above exist with the required contents
        when you are done.