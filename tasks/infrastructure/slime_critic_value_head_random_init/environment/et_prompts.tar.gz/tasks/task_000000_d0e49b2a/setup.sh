#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


export PATH=/usr/local/bin:/usr/bin:/bin:$PATH

set -e && \
    echo "Updating package index and installing Python tooling..." && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3 \
        python3-pip && \
    echo "Installing pytest for the grading suite..." && \
    pip3 install --no-cache-dir pytest && \
    apt-get clean && \
    true

mkdir -p /home/user/deployment_configs && \
    chmod 755 /home/user/deployment_configs

cat > /home/user/deployment_configs/service_alpha.conf <<'EOF'
ServiceName: AlphaAPI
Version: 1.3.7
Environment: staging
Status: READY
EOF

cat > /home/user/deployment_configs/service_beta.conf <<'EOF'
ServiceName: BetaWorker
Version: 3.2.4
Environment: production
Status: LIVE
EOF

cat > /home/user/deployment_configs/service_gamma.conf <<'EOF'
ServiceName: GammaDB
Version: 0.9.12
Environment: staging
Status: READY
EOF

cat > /home/user/deployment_configs/service_delta.conf <<'EOF'
ServiceName: DeltaUI
Version: 2.1.0
Environment: staging
Status: IN_TEST
EOF

chmod 644 /home/user/deployment_configs/*.conf
