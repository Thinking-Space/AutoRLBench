# test_final_state.py
#
# Pytest suite that validates the *final* state of the filesystem
# *after* the student’s deployment-promotion script has run.
#
# The assertions are derived from the authoritative “Expected final
# state” section in the task description.  Any deviation, however
# small, will fail the tests with a clear, explanatory message.

import pathlib
import textwrap
import pytest

DEPLOY_DIR = pathlib.Path("/home/user/deployment_configs/")

# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------


def read_lines_no_nl(path: pathlib.Path):
    """
    Return the file’s logical lines *without* trailing newlines.
    We purposefully keep leading/trailing spaces inside the lines
    because the artefact formats must match exactly.
    """
    with path.open("r", encoding="utf-8") as f:
        return [ln.rstrip("\n") for ln in f.readlines()]


# ---------------------------------------------------------------------------
# Truth (“golden”) data for the FINAL state
# ---------------------------------------------------------------------------

EXPECTED_CONFIGS = {
    "service_alpha.conf": textwrap.dedent(
        """\
        ServiceName: AlphaAPI
        Version: 1.3.8
        Environment: production
        Status: LIVE"""
    ).splitlines(),
    "service_beta.conf": textwrap.dedent(
        """\
        ServiceName: BetaWorker
        Version: 3.2.4
        Environment: production
        Status: LIVE"""
    ).splitlines(),
    "service_gamma.conf": textwrap.dedent(
        """\
        ServiceName: GammaDB
        Version: 0.9.13
        Environment: production
        Status: LIVE"""
    ).splitlines(),
    "service_delta.conf": textwrap.dedent(
        """\
        ServiceName: DeltaUI
        Version: 2.1.0
        Environment: staging
        Status: IN_TEST"""
    ).splitlines(),
}

EXPECTED_RELEASE_SUMMARY = [
    "Environment,Status,Count",
    "production,LIVE,3",
    "staging,IN_TEST,1",
]

EXPECTED_RELEASE_NOTES = [
    "Release Notes - 2023-10-15",
    "=" * 26,
    "",  # mandatory blank line
    "AlphaAPI 1.3.8",
    "GammaDB 0.9.13",
]

EXPECTED_CHANGE_LOG = [
    "AlphaAPI bumped 1.3.7 -> 1.3.8",
    "GammaDB bumped 0.9.12 -> 0.9.13",
]

# ---------------------------------------------------------------------------
# Generic tests
# ---------------------------------------------------------------------------


def test_deploy_directory_still_exists():
    assert DEPLOY_DIR.is_dir(), (
        f"Directory {DEPLOY_DIR} is missing. The deployment folder must "
        "still be present after the promotion script has run."
    )


def test_exact_conf_file_set_final():
    """
    The directory must still contain *exactly* the four original .conf
    files—no more, no less.
    """
    conf_files = {p.name for p in DEPLOY_DIR.glob("*.conf")}
    expected_files = set(EXPECTED_CONFIGS)
    missing = expected_files - conf_files
    extra = conf_files - expected_files

    message_lines = []
    if missing:
        message_lines.append(
            f"Missing .conf file(s): {', '.join(sorted(missing))}"
        )
    if extra:
        message_lines.append(
            f"Unexpected new .conf file(s): {', '.join(sorted(extra))}"
        )

    assert not missing and not extra, "\n".join(message_lines) or (
        "Config file set does not match the expected final list."
    )


@pytest.mark.parametrize("filename,expected_lines", sorted(EXPECTED_CONFIGS.items()))
def test_conf_files_have_expected_contents(filename, expected_lines):
    """
    Validate every configuration file line-by-line.
    """
    path = DEPLOY_DIR / filename
    assert path.is_file(), f"Expected file {path} to exist in final state."

    actual_lines = read_lines_no_nl(path)

    # First guard the number of lines for clearer error output
    assert len(actual_lines) == len(expected_lines), (
        f"{filename} should have {len(expected_lines)} lines but has "
        f"{len(actual_lines)}."
    )

    for idx, (exp, act) in enumerate(zip(expected_lines, actual_lines), start=1):
        assert act == exp, (
            f"{filename}, line {idx} differs:\n"
            f"EXPECTED: '{exp}'\n"
            f"ACTUAL  : '{act}'"
        )


# ---------------------------------------------------------------------------
# release_summary.csv
# ---------------------------------------------------------------------------


def test_release_summary_csv_exists_and_is_correct():
    path = DEPLOY_DIR / "release_summary.csv"
    assert path.is_file(), (
        "release_summary.csv is missing.  The promotion script must "
        "generate this file."
    )
    actual_lines = read_lines_no_nl(path)

    assert actual_lines == EXPECTED_RELEASE_SUMMARY, (
        "release_summary.csv contents are incorrect.\n"
        f"EXPECTED ({len(EXPECTED_RELEASE_SUMMARY)} lines):\n"
        + "\n".join(EXPECTED_RELEASE_SUMMARY)
        + "\nACTUAL ({0} lines):\n".format(len(actual_lines))
        + "\n".join(actual_lines)
    )


# ---------------------------------------------------------------------------
# release_notes.txt
# ---------------------------------------------------------------------------


def test_release_notes_txt_exists_and_is_correct_and_has_trailing_newline():
    path = DEPLOY_DIR / "release_notes.txt"
    assert path.is_file(), (
        "release_notes.txt is missing. The promotion script must "
        "generate it."
    )

    # Read raw bytes to assert trailing newline precisely
    raw = path.read_bytes()
    assert raw.endswith(b"\n"), (
        "release_notes.txt must end with exactly one trailing newline."
    )

    # Now verify logical lines
    actual_lines = raw.decode("utf-8").rstrip("\n").split("\n")
    assert actual_lines == EXPECTED_RELEASE_NOTES, (
        "release_notes.txt contents are incorrect.\n"
        f"EXPECTED ({len(EXPECTED_RELEASE_NOTES)} lines):\n"
        + "\n".join(EXPECTED_RELEASE_NOTES)
        + "\nACTUAL ({0} lines):\n".format(len(actual_lines))
        + "\n".join(actual_lines)
    )


# ---------------------------------------------------------------------------
# change_log.log
# ---------------------------------------------------------------------------


def test_change_log_log_exists_and_is_correct():
    path = DEPLOY_DIR / "change_log.log"
    assert path.is_file(), (
        "change_log.log is missing.  The promotion script must create it."
    )
    actual_lines = read_lines_no_nl(path)

    assert actual_lines == EXPECTED_CHANGE_LOG, (
        "change_log.log contents are incorrect.\n"
        f"EXPECTED ({len(EXPECTED_CHANGE_LOG)} lines):\n"
        + "\n".join(EXPECTED_CHANGE_LOG)
        + "\nACTUAL ({0} lines):\n".format(len(actual_lines))
        + "\n".join(actual_lines)
    )