You are assisting a technical-writer who is preparing a “checksums” section
for the project documentation that lives under /home/user/docs.

A brand-new (empty) placeholder PDF called
/home/user/docs/manual_v1.2.pdf
has already been created, but the writer still needs its SHA-256 checksum
captured in a dedicated log file.

**Goal**

Calculate the SHA-256 checksum of the file `/home/user/docs/manual_v1.2.pdf` and append the result to a text file located at `/home/user/docs/checksums/sha256sum.txt`.

**Exact output format that will be verified**

*   The log file must be named exactly `/home/user/docs/checksums/sha256sum.txt` (all lower-case).
*   It must contain a single line **ending with a newline character**.
*   The line must have the exact format produced by the command “sha256sum manual\_v1.2.pdf”, i.e.

    `<64-character-hex-digest><two spaces><original-file-name>\n`

    Concretely, when written correctly the line will look like this (checksum followed by two spaces and then the file name):

    `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  manual_v1.2.pdf`

    The automated test will check:
    *   that the two spaces are present between the digest and the filename,
    *   that the filename is exactly “manual\_v1.2.pdf” (case-sensitive),
    *   and that the file ends with a single newline.