# test_final_state.py
#
# Pytest suite that validates the operating-system / filesystem
# AFTER the student has completed the “checksums” task.
#
# It checks that
#   1. /home/user/docs/checksums exists and is a directory.
#   2. /home/user/docs/checksums/sha256sum.txt exists and is a regular file.
#   3. The log file contains exactly ONE line whose format matches
#        <64-hex-chars><two spaces>manual_v1.2.pdf\n
#      i.e. the exact output of `sha256sum manual_v1.2.pdf`.
#   4. The digest in the log file is the correct SHA-256 of the
#      PDF placeholder, and the PDF is still present and empty.
#
# All assertions emit clear, actionable failure messages.

import hashlib
import os
import re
import stat
from pathlib import Path

import pytest

HOME = Path("/home/user")
DOCS_DIR = HOME / "docs"
PDF_FILE = DOCS_DIR / "manual_v1.2.pdf"
CHECKSUMS_DIR = DOCS_DIR / "checksums"
CHECKSUM_FILE = CHECKSUMS_DIR / "sha256sum.txt"

# Expected SHA-256 for an empty file (given in the task description)
EMPTY_FILE_SHA256 = (
    "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
)


# --------------------------------------------------------------------------- #
# Helper utilities                                                             #
# --------------------------------------------------------------------------- #
def _owner_has_permissions(path: Path, expected_bits: int) -> bool:
    """Return True if `path` has at least `expected_bits` for the owner."""
    st_mode = path.stat().st_mode
    return (st_mode & expected_bits) == expected_bits


def _compute_sha256(path: Path) -> str:
    """Return the hexadecimal SHA-256 digest of the file at *path*."""
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


# --------------------------------------------------------------------------- #
# Tests                                                                        #
# --------------------------------------------------------------------------- #
def test_checksums_directory_exists_and_is_directory():
    assert CHECKSUMS_DIR.exists(), (
        f"The directory {CHECKSUMS_DIR} does not exist. "
        "You must create it to store the checksum log."
    )
    assert CHECKSUMS_DIR.is_dir(), (
        f"{CHECKSUMS_DIR} exists but is not a directory."
    )
    # Directory should be at least rwx for owner
    assert _owner_has_permissions(
        CHECKSUMS_DIR, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR
    ), (
        f"Directory {CHECKSUMS_DIR} lacks required owner permissions "
        "(needs rwx --- ---)."
    )


def test_checksum_file_exists_and_is_regular_file():
    assert CHECKSUM_FILE.exists(), (
        f"The checksum log {CHECKSUM_FILE} was not found."
    )
    assert CHECKSUM_FILE.is_file(), (
        f"{CHECKSUM_FILE} exists but is not a regular file."
    )
    # File should be at least rw for owner
    assert _owner_has_permissions(
        CHECKSUM_FILE, stat.S_IRUSR | stat.S_IWUSR
    ), (
        f"File {CHECKSUM_FILE} lacks required owner permissions "
        "(needs rw- --- ---)."
    )


def test_checksum_log_content_exactness_and_correctness():
    # ---------- Read and basic structure ----------
    content = CHECKSUM_FILE.read_text(encoding="utf-8")
    assert content.endswith("\n"), (
        f"{CHECKSUM_FILE} must end with a single newline character."
    )

    # Splitlines without keeping newline to count logical lines
    lines = content.splitlines()
    assert len(lines) == 1, (
        f"{CHECKSUM_FILE} must contain exactly one line, "
        f"but {len(lines)} lines were found."
    )
    line = lines[0]

    # ---------- Format validation ----------
    pattern = r"^([0-9a-f]{64})  (manual_v1\.2\.pdf)$"
    m = re.match(pattern, line)
    assert m is not None, (
        f"The line in {CHECKSUM_FILE!s} is incorrectly formatted.\n"
        "Expected: <64-hex-chars><two spaces>manual_v1.2.pdf"
    )

    digest_in_file = m.group(1)

    # ---------- Digest correctness ----------
    # 1. It must equal the known digest for an empty file
    assert digest_in_file == EMPTY_FILE_SHA256, (
        "The SHA-256 digest recorded in the log is incorrect.\n"
        f"Expected : {EMPTY_FILE_SHA256}\n"
        f"Found    : {digest_in_file}"
    )

    # 2. It must equal the actual digest of the PDF *right now*
    assert PDF_FILE.exists() and PDF_FILE.is_file(), (
        f"The source PDF {PDF_FILE} is missing."
    )
    actual_digest = _compute_sha256(PDF_FILE)
    assert digest_in_file == actual_digest, (
        "The digest in the log does not match the current SHA-256 of "
        f"{PDF_FILE}.\n"
        f"Digest in log : {digest_in_file}\n"
        f"Actual digest : {actual_digest}"
    )


def test_pdf_placeholder_still_empty_and_intact():
    assert PDF_FILE.exists(), f"{PDF_FILE} has disappeared."
    assert PDF_FILE.is_file(), f"{PDF_FILE} is no longer a regular file."
    size = PDF_FILE.stat().st_size
    assert size == 0, (
        f"{PDF_FILE} was expected to remain empty (0 bytes) but is now {size} bytes."
    )
    # File should still be owner-read/write
    assert _owner_has_permissions(
        PDF_FILE, stat.S_IRUSR | stat.S_IWUSR
    ), (
        f"File {PDF_FILE} lacks required owner permissions "
        "(needs rw- --- ---)."
    )