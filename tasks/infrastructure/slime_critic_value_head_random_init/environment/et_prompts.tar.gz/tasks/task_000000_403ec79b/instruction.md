You are the on-call system administrator.

The inventory file **/home/user/servers/hosts.lst** already exists and contains one hostname per line.

Your manager wants a quick, machine-readable tally of how many hosts are in that file.

Produce that tally and write it to **/home/user/servers/hosts.count**.

VERY IMPORTANT – output format that will be automatically checked:
*   /home/user/servers/hosts.count must contain **only** the integer count, expressed in base-10 ASCII digits, followed by a single trailing newline (no additional spaces, words, or blank lines).
*   Example of the correct format if the count were 42:
    42⏎

No other files may be created or modified.
Do NOT display the count on the terminal; only write it to the file.
You do not need sudo privileges; simply operate as the regular user.