# test_final_state.py
#
# Pytest suite that validates the *final* operating-system / filesystem
# state after the student has completed the “host count” exercise.
#
# The requirements, recapped:
#   1. /home/user/servers/hosts.lst must remain unmodified.  It should still
#      contain exactly seven hostnames (one per line, LF terminated).
#   2. A new file /home/user/servers/hosts.count must have been created.
#      Its *only* contents must be the decimal count of hostnames followed
#      by a single newline (byte 0x0A).  For the canonical data set this is
#      the two-byte sequence b"7\n".
#   3. No other new files may have been created in /home/user/servers.
#
# Only the Python standard library and pytest are used.

import os
import re
import stat
import pytest

HOME = "/home/user"
SERVERS_DIR = os.path.join(HOME, "servers")
HOSTS_LST = os.path.join(SERVERS_DIR, "hosts.lst")
HOSTS_COUNT = os.path.join(SERVERS_DIR, "hosts.count")

EXPECTED_HOST_LINES = [
    "host-a",
    "host-b",
    "host-c",
    "host-d",
    "host-e",
    "host-f",
    "host-g",
]
EXPECTED_COUNT_STR = f"{len(EXPECTED_HOST_LINES)}\n"


# --------------------------------------------------------------------------- #
# Helper functions
# --------------------------------------------------------------------------- #
def read_file(path: str, mode: str = "r"):
    with open(path, mode) as f:
        return f.read()


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #
def test_servers_directory_contents():
    """
    1. /home/user/servers still exists and is writable.
    2. Exactly two regular files are present: hosts.lst (pre-existing) and
       hosts.count (the file the student had to create).
    """
    assert os.path.isdir(
        SERVERS_DIR
    ), f"Directory {SERVERS_DIR!r} is missing."

    assert os.access(
        SERVERS_DIR, os.W_OK
    ), f"Directory {SERVERS_DIR!r} is not writable by the current user."

    dir_entries = sorted(os.listdir(SERVERS_DIR))
    assert dir_entries == [
        "hosts.count",
        "hosts.lst",
    ], (
        f"Unexpected directory contents in {SERVERS_DIR!r}.\n"
        f"Expected exactly ['hosts.count', 'hosts.lst']\n"
        f"Found: {dir_entries}"
    )

    # Both entries must be regular files
    for fname in dir_entries:
        path = os.path.join(SERVERS_DIR, fname)
        st = os.stat(path)
        assert stat.S_ISREG(
            st.st_mode
        ), f"{path!r} is not a regular file (mode: {oct(st.st_mode)})"


def test_hosts_lst_unchanged():
    """
    /home/user/servers/hosts.lst must remain byte-for-byte identical
    to the truth data supplied to the student.
    """
    assert os.path.isfile(
        HOSTS_LST
    ), f"Required file {HOSTS_LST!r} no longer exists."

    content = read_file(HOSTS_LST, "r")
    expected_content = "\n".join(EXPECTED_HOST_LINES) + "\n"

    assert (
        content == expected_content
    ), (
        f"{HOSTS_LST!r} has been altered.\n"
        f"Expected exactly:\n{expected_content!r}\n\n"
        f"Found:\n{content!r}"
    )


def test_hosts_count_created_with_correct_contents():
    """
    Validate /home/user/servers/hosts.count:
        • Exists.
        • Is a regular file.
        • Contains only the decimal count followed by a single LF.
        • The numeric value matches the number of lines in hosts.lst.
    """
    assert os.path.isfile(
        HOSTS_COUNT
    ), f"Required tally file {HOSTS_COUNT!r} does not exist."

    # Must be regular file, not symlink or directory.
    st = os.stat(HOSTS_COUNT, follow_symlinks=False)
    assert stat.S_ISREG(
        st.st_mode
    ), f"{HOSTS_COUNT!r} is not a regular file (mode: {oct(st.st_mode)})"

    # Read as bytes so we can assert exact byte sequence.
    raw_bytes = read_file(HOSTS_COUNT, "rb")
    assert raw_bytes.endswith(
        b"\n"
    ), f"{HOSTS_COUNT!r} must end with a single newline (LF)."

    # Decode as UTF-8 for further checks
    content = raw_bytes.decode("utf-8", errors="strict")
    assert re.fullmatch(
        r"\d+\n", content
    ), (
        f"{HOSTS_COUNT!r} must contain ONLY decimal digits followed by a "
        "single newline.  Found: {!r}".format(content)
    )

    # Numeric value must match the number of hostnames in hosts.lst
    reported = int(content.strip())  # strip removes the single trailing LF
    actual = len(EXPECTED_HOST_LINES)
    assert (
        reported == actual
    ), (
        f"Count in {HOSTS_COUNT!r} is {reported}, but hosts.lst actually "
        f"contains {actual} hostnames."
    )

    # Also assert byte-for-byte equality with the expected string (7\n)
    assert (
        content == EXPECTED_COUNT_STR
    ), (
        f"Incorrect final byte sequence in {HOSTS_COUNT!r}.\n"
        f"Expected: {EXPECTED_COUNT_STR!r}\n"
        f"Found:    {content!r}"
    )