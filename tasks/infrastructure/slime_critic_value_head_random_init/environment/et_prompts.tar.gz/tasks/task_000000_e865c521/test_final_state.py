# test_final_state.py
#
# Pytest suite that validates the *final* operating-system / Git repository
# state after the “optimize_app” exercise has been completed.
#
# These tests **must pass** after the student has carried out every required
# step.  Any failure pin-points exactly what is still wrong.

import hashlib
import os
import subprocess
import textwrap

import pytest

# --------------------------------------------------------------------------- #
# Constant paths
# --------------------------------------------------------------------------- #
REPO_DIR = "/home/user/projects/optimize_app"
CFG_PATH = os.path.join(REPO_DIR, "solver_config.yaml")
BACKUP_PATH = os.path.join(
    REPO_DIR, "solver_config_2023-01-01T00:00:00Z.bak"
)
LOG_PATH = os.path.join(REPO_DIR, "config_changes.log")

# --------------------------------------------------------------------------- #
# Expected file contents (byte-for-byte, including the final newline)
# --------------------------------------------------------------------------- #
UPDATED_CONFIG_CONTENT = textwrap.dedent(
    """\
    solver:
      name: "cbc"
      tolerance: 1e-8
      max_iterations: 1000
      verbose: true
      time_limit: 300
    """
)
BACKUP_CONFIG_CONTENT = textwrap.dedent(
    """\
    solver:
      name: "glpk"
      tolerance: 1e-6
      max_iterations: 1000
      verbose: false
    """
)

# --------------------------------------------------------------------------- #
# Helper utilities
# --------------------------------------------------------------------------- #
def sha256_hex(path):
    """
    Return the lowercase hexadecimal SHA-256 digest of a file.
    """
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _run_git(cmd, cwd=REPO_DIR):
    """
    Run a git sub-command and return stdout (stripped).  Fail the test on
    non-zero exit status.
    """
    proc = subprocess.run(
        ["git"] + cmd,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    if proc.returncode != 0:
        pytest.fail(
            f"Git command {' '.join(cmd)} failed with exit code "
            f"{proc.returncode}.\nSTDERR:\n{proc.stderr}"
        )
    return proc.stdout.strip()


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #
def test_updated_solver_config_exists_and_is_correct():
    """
    The primary configuration must exist and match the required updated text.
    """
    assert os.path.isfile(
        CFG_PATH
    ), f"{CFG_PATH} is missing."
    with open(CFG_PATH, "r", encoding="utf-8") as fh:
        data = fh.read()
    assert (
        data == UPDATED_CONFIG_CONTENT
    ), f"{CFG_PATH} does not match the required updated contents."


def test_backup_file_is_correct_copy_of_original():
    """
    The backup file must exist and contain exactly the original configuration.
    """
    assert os.path.isfile(
        BACKUP_PATH
    ), f"Backup file {BACKUP_PATH} is missing."
    with open(BACKUP_PATH, "r", encoding="utf-8") as fh:
        data = fh.read()
    assert (
        data == BACKUP_CONFIG_CONTENT
    ), f"{BACKUP_PATH} does not contain the expected original configuration."


def test_change_log_format_and_hashes_are_correct():
    """
    The change-tracking log must exist, contain exactly one well-formed line,
    and reference correct SHA-256 digests for both files.
    """
    assert os.path.isfile(
        LOG_PATH
    ), f"Change log {LOG_PATH} is missing."

    with open(LOG_PATH, "r", encoding="utf-8") as fh:
        log_data = fh.read()

    # The file must end with a single newline so splitlines() works cleanly.
    assert log_data.endswith(
        "\n"
    ), f"{LOG_PATH} must end with exactly one newline character."

    lines = log_data.splitlines()
    assert (
        len(lines) == 1 and lines[0]
    ), f"{LOG_PATH} must contain exactly one non-empty line."

    fields = lines[0].split("|")
    assert (
        len(fields) == 5
    ), f"{LOG_PATH} must contain exactly five pipe-separated fields."

    timestamp, digest_old, digest_new, user_field, comment_field = fields

    # Field-level checks
    assert (
        timestamp == "2023-01-01T00:00:00Z"
    ), "Field 1 (timestamp) must be the literal '2023-01-01T00:00:00Z'."

    expected_old = sha256_hex(BACKUP_PATH)
    expected_new = sha256_hex(CFG_PATH)
    assert (
        digest_old == expected_old
    ), (
        f"Field 2 (old digest) is incorrect.\n"
        f"Expected {expected_old} (backup file), got {digest_old}."
    )
    assert (
        digest_new == expected_new
    ), (
        f"Field 3 (new digest) is incorrect.\n"
        f"Expected {expected_new} (updated config), got {digest_new}."
    )

    assert (
        user_field == "user:automation-bot"
    ), "Field 4 must be the literal 'user:automation-bot'."

    expected_comment = 'comment:"Upgrade solver to CBC with tighter tolerance and time limit"'
    assert (
        comment_field == expected_comment
    ), "Field 5 (comment) is not exactly as required."


def test_git_commit_contains_files_and_message_is_correct():
    """
    HEAD commit must include the three required files and have the exact
    commit message 'feat: switch to CBC solver'.
    """
    # Commit message
    commit_message = _run_git(["log", "-1", "--pretty=%s"])
    assert (
        commit_message == "feat: switch to CBC solver"
    ), "Last commit message is incorrect."

    # Ensure repository is clean (no uncommitted changes)
    status_porcelain = _run_git(["status", "--porcelain"])
    assert (
        status_porcelain == ""
    ), "Git working tree is dirty – all changes should be committed."

    # Files present in HEAD tree
    tree_files = set(
        _run_git(["ls-tree", "-r", "--name-only", "HEAD"]).splitlines()
    )

    expected_paths = {
        "solver_config.yaml",
        "solver_config_2023-01-01T00:00:00Z.bak",
        "config_changes.log",
    }

    missing = expected_paths - tree_files
    assert not missing, (
        "The following required files are missing from the last commit: "
        f"{', '.join(sorted(missing))}"
    )