You are the configuration manager for a small research project that benchmarks
different optimisation solvers.
A Git repository is already initialised in the directory
/home/user/projects/optimize_app

1) Inside that directory there is currently a single configuration file

      /home/user/projects/optimize_app/solver_config.yaml

   with the *exact* contents shown below (including all spaces and the
   trailing newline at the end of the last line):

        solver:
          name: "glpk"
          tolerance: 1e-6
          max_iterations: 1000
          verbose: false

2) There is **no** change–tracking log yet.
   Your task is to create one **and** to upgrade the solver settings.

3) Required end-state:

   a) The original configuration must be kept as a backup file named

        /home/user/projects/optimize_app/solver_config_2023-01-01T00:00:00Z.bak

      The backup file must be an *exact* byte-for-byte copy of the original
      solver_config.yaml shown above.

   b) Update /home/user/projects/optimize_app/solver_config.yaml
      so that it contains *exactly* (including spaces, indentation and the
      trailing newline) the following:

          solver:
            name: "cbc"
            tolerance: 1e-8
            max_iterations: 1000
            verbose: true
            time_limit: 300

   c) Create the new log file

        /home/user/projects/optimize_app/config_changes.log

      and append **one** single-line record that tracks the change.
      The line must have *precisely* five pipe-separated fields
      and must **not** contain any extra spaces.
      Use the fixed timestamp 2023-01-01T00:00:00Z (do NOT use the current
      time).  The required format is:

        YYYY-MM-DDThh:mm:ssZ|<sha256_old>|<sha256_new>|user:automation-bot|comment:"Upgrade solver to CBC with tighter tolerance and time limit"

      • Field 1  – literal        2023-01-01T00:00:00Z
      • Field 2  – the lowercase hexadecimal SHA-256 digest of the backup file
      • Field 3  – the lowercase hexadecimal SHA-256 digest of the **updated**
                   solver_config.yaml
      • Field 4  – literal        user:automation-bot
      • Field 5  – literal        comment:"Upgrade solver to CBC with tighter tolerance and time limit"

      Example of the *shape* (hashes will differ):

        2023-01-01T00:00:00Z|6f5902ac237024bdd0c176cb93063dc4|5feceb66ffc86f38d952786c6d696c79|user:automation-bot|comment:"Upgrade solver to CBC with tighter tolerance and time limit"

      The line must end with a single newline character.

   d) Stage and commit the three files
         solver_config.yaml
         solver_config_2023-01-01T00:00:00Z.bak
         config_changes.log
      with the commit message

         feat: switch to CBC solver

4) Verification notes (information for you, **not** part of the log):

   • The SHA-256 digests will be recomputed by the automated tests and must
     exactly match the contents of the second and third fields.
   • The only acceptable delimiter inside config_changes.log is the pipe
     character “|”.  No surrounding spaces are allowed.
   • The log file must contain exactly **one** line.
   • The three files *must* be present in the last commit.

IMPORTANT: do not use sudo – your account already owns all files.