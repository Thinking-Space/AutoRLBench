You are acting as the on-call backup engineer.  
Your goal is to verify that last night’s daily backup is not corrupt and to save an auditable proof of that verification.

Directory layout that already exists when you start:
* `/home/user/backups/daily/`  
    * `sample.db`           (a **zero-byte** SQLite backup file)  
    * `sample.db.md5`       (contains the MD5 checksum for the file above)

What you must accomplish:

*   Create a directory called `/home/user/integrity_checks` if it is not already present.
*   Use the information in `/home/user/backups/daily/sample.db.md5` to verify `sample.db`.
    *   The verification program’s normal output (stdout) must be captured in the file `/home/user/integrity_checks/daily_check.log`, overwriting the file if it exists.
    *   Do NOT add any extra text to the log; it should only contain the checksum program’s own output.
*   Set permissions so that:
    *   `/home/user/integrity_checks` is accessible only to the owner and the owner’s primary group (rwx for both, no rights for others → octal 770).
    *   `/home/user/integrity_checks/daily_check.log` is readable and writable by the owner and the owner’s primary group, and not accessible to others (octal 660).

Expected log file format (exactly one line, followed by a trailing newline):

sample.db: OK

Automated tests will check:
*   The directory `/home/user/integrity_checks` exists and has mode 770.
*   The file `/home/user/integrity_checks/daily_check.log` exists and has mode 660.
*   The log file’s *only* content is the single line shown above (with a terminating newline).