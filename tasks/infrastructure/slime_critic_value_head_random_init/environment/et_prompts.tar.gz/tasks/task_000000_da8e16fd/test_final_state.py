# test_final_state.py
#
# Pytest suite that validates the **FINAL** state of the operating-system /
# filesystem after the student has completed the “backup integrity check” task.
#
# The tests assert that:
#   • /home/user/integrity_checks exists and has permission mode 770.
#   • /home/user/integrity_checks/daily_check.log exists, has mode 660 and holds
#     exactly one line: "sample.db: OK\n".
#   • The original backup artefacts were NOT altered:
#       - /home/user/backups/daily/sample.db is still a zero-byte file.
#       - /home/user/backups/daily/sample.db.md5 still contains the expected
#         checksum line and the checksum matches the file’s current contents.
#
# Only the Python standard library and pytest are used.

import hashlib
from pathlib import Path
import stat

import pytest

ROOT = Path("/home/user")

# Paths created/checked by the student
INTEGRITY_DIR = ROOT / "integrity_checks"
LOG_FILE = INTEGRITY_DIR / "daily_check.log"

# Original backup artefacts – must remain untouched
BACKUP_DIR = ROOT / "backups" / "daily"
DB_FILE = BACKUP_DIR / "sample.db"
MD5_FILE = BACKUP_DIR / "sample.db.md5"

EXPECTED_MD5 = "d41d8cd98f00b204e9800998ecf8427e"
EXPECTED_MD5_LINE = f"{EXPECTED_MD5}  sample.db\n"
EXPECTED_LOG_LINE = "sample.db: OK\n"


# --------------------------------------------------------------------------- #
# Helper utilities
# --------------------------------------------------------------------------- #
def _mode(path: Path) -> int:
    """
    Return the octal permission bits (e.g. 0o770) for the given path.
    """
    return path.stat().st_mode & 0o777


# --------------------------------------------------------------------------- #
# Tests for the artefacts the student had to create/modify
# --------------------------------------------------------------------------- #
def test_integrity_directory_exists_and_has_correct_mode():
    assert INTEGRITY_DIR.exists(), (
        f"Directory {INTEGRITY_DIR} does not exist."
    )
    assert INTEGRITY_DIR.is_dir(), (
        f"{INTEGRITY_DIR} exists but is not a directory."
    )

    mode = _mode(INTEGRITY_DIR)
    expected_mode = 0o770
    assert mode == expected_mode, (
        f"{INTEGRITY_DIR} must have permissions 770, found {oct(mode)[2:]}."
    )


def test_log_file_exists_and_has_correct_mode():
    assert LOG_FILE.exists(), (
        f"Log file {LOG_FILE} does not exist."
    )
    assert LOG_FILE.is_file(), (
        f"{LOG_FILE} exists but is not a regular file."
    )

    mode = _mode(LOG_FILE)
    expected_mode = 0o660
    assert mode == expected_mode, (
        f"{LOG_FILE} must have permissions 660, found {oct(mode)[2:]}."
    )


def test_log_file_content_is_exact():
    content = LOG_FILE.read_text(encoding="utf-8")
    assert content == EXPECTED_LOG_LINE, (
        f"{LOG_FILE} has incorrect content.\n"
        f"Expected exactly: {EXPECTED_LOG_LINE!r}\n"
        f"Found:            {content!r}"
    )


# --------------------------------------------------------------------------- #
# Tests ensuring the original backup artefacts were *not* modified
# --------------------------------------------------------------------------- #
def test_backup_file_still_zero_bytes_and_same_md5():
    # Size check (must remain zero-byte)
    size = DB_FILE.stat().st_size
    assert size == 0, (
        f"{DB_FILE} should still be a zero-byte file, found {size} bytes."
    )

    # MD5 check
    md5_calculated = hashlib.md5(DB_FILE.read_bytes()).hexdigest()
    assert md5_calculated == EXPECTED_MD5, (
        f"MD5 of {DB_FILE} changed! Expected {EXPECTED_MD5}, "
        f"found {md5_calculated}."
    )


def test_md5_sidecar_file_unchanged_and_validates():
    assert MD5_FILE.exists(), (
        f"Checksum sidecar file {MD5_FILE} has disappeared."
    )
    assert MD5_FILE.is_file(), (
        f"{MD5_FILE} exists but is not a regular file."
    )

    content = MD5_FILE.read_text(encoding="utf-8")
    assert content == EXPECTED_MD5_LINE, (
        f"Content of {MD5_FILE} changed.\n"
        f"Expected: {EXPECTED_MD5_LINE!r}\n"
        f"Found:    {content!r}"
    )

    # Re-validate checksum correspondence
    # The line format is: "<md5>  filename\n"
    checksum_in_file = content.split()[0]
    md5_actual = hashlib.md5(DB_FILE.read_bytes()).hexdigest()
    assert checksum_in_file == md5_actual, (
        "Checksum in .md5 file no longer matches the current content of "
        f"{DB_FILE} (expected {checksum_in_file}, got {md5_actual})."
    )