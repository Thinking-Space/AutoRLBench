# test_final_state.py
#
# Pytest suite that validates the *final* state of the operating-system /
# container **after** the student has completed the “batch summary” task.
#
# The suite asserts that:
#   • /home/user/output/ exists and is 0755.
#   • Exactly two files exist inside that directory:
#         batch_summary.csv   (0644)
#         process.log         (0644)
#   • batch_summary.csv contains exactly the three expected summary lines
#     **in that order**, each terminated by a single LF, and nothing else.
#   • process.log contains exactly the three expected “Processed …” lines,
#     each terminated by a single LF, and nothing else.
#   • File permissions are as required.
#
# Failures provide clear, actionable feedback.
#
# Only Python stdlib + pytest are used.

import os
import stat
import pytest

HOME = "/home/user"
OUTPUT_DIR = os.path.join(HOME, "output")
SUMMARY_FILE = os.path.join(OUTPUT_DIR, "batch_summary.csv")
PROCESS_LOG  = os.path.join(OUTPUT_DIR, "process.log")

# Ground-truth lines (no trailing newline characters here; we will check those
# separately so that we can verify *exact* LF termination in the file bytes).
EXPECTED_SUMMARY_LINES = [
    "report_202301.csv,3,2,1",
    "report_202302.csv,3,3,0",
    "report_202303.csv,3,2,1",
]

EXPECTED_PROCESS_LOG_LINES = [
    "Processed report_202301.csv",
    "Processed report_202302.csv",
    "Processed report_202303.csv",
]

# -----------------------------------------------------------------------------
# Helper utilities
# -----------------------------------------------------------------------------
def _mode(path: str) -> int:
    """Return Unix permission bits (e.g. 0o755, 0o644) of a filesystem node."""
    return stat.S_IMODE(os.stat(path).st_mode)

def _read_file_bytes(path: str) -> bytes:
    with open(path, "rb") as fh:
        return fh.read()

def _read_text_lines(path: str):
    """Return a list of *text* lines **without** trailing newlines."""
    with open(path, "r", encoding="utf-8") as fh:
        return [ln.rstrip("\n") for ln in fh.readlines()]

# -----------------------------------------------------------------------------
# Tests
# -----------------------------------------------------------------------------
def test_output_directory_exists_and_is_world_readable():
    """Output directory must exist and have 0755 permissions."""
    assert os.path.isdir(OUTPUT_DIR), (
        f"Expected output directory {OUTPUT_DIR} to exist"
    )
    mode = _mode(OUTPUT_DIR)
    assert mode == 0o755, (
        f"Directory {OUTPUT_DIR} should have permissions 755 "
        f"(actual {oct(mode)})"
    )

def test_output_directory_contains_only_expected_files():
    """No extra or missing files inside /home/user/output/."""
    expected_files = {"batch_summary.csv", "process.log"}
    actual_files   = set(os.listdir(OUTPUT_DIR))
    missing = expected_files - actual_files
    extra   = actual_files   - expected_files
    assert not missing, f"Missing file(s) in {OUTPUT_DIR}: {sorted(missing)}"
    assert not extra,   f"Unexpected extra file(s) in {OUTPUT_DIR}: {sorted(extra)}"

@pytest.mark.parametrize(
    "path, expected_mode",
    [
        (SUMMARY_FILE, 0o644),
        (PROCESS_LOG,  0o644),
    ],
)
def test_file_permissions(path, expected_mode):
    """batch_summary.csv and process.log must each be 0644."""
    assert os.path.isfile(path), f"Expected file {path} was not found"
    mode = _mode(path)
    assert mode == expected_mode, (
        f"File {path} should have permissions {oct(expected_mode)} "
        f"(actual {oct(mode)})"
    )

def test_batch_summary_contents_and_newlines():
    """
    batch_summary.csv must contain the exact three expected lines, in order,
    newline-terminated, and nothing else.
    """
    file_bytes = _read_file_bytes(SUMMARY_FILE)

    # 1. File must end with a single LF.
    assert file_bytes.endswith(b"\n"), (
        "batch_summary.csv must end with a single LF (\\n) newline"
    )

    # 2. No extra blank newline at end (i.e. should not end with two LFs).
    assert not file_bytes.endswith(b"\n\n"), (
        "batch_summary.csv has an extra blank line at the end"
    )

    # 3. Split into text lines (drop the trailing final LF for splitlines()).
    lines = file_bytes.decode("utf-8").splitlines()
    assert lines == EXPECTED_SUMMARY_LINES, (
        "Contents of batch_summary.csv are incorrect.\n"
        f"Expected:\n{EXPECTED_SUMMARY_LINES}\n\nActual:\n{lines}"
    )

def test_process_log_contents_and_newlines():
    """
    process.log must contain the three 'Processed …' lines, in order,
    newline-terminated, and nothing else.
    """
    file_bytes = _read_file_bytes(PROCESS_LOG)

    # 1. Verify single LF at the very end.
    assert file_bytes.endswith(b"\n"), (
        "process.log must end with a single LF (\\n) newline"
    )
    assert not file_bytes.endswith(b"\n\n"), (
        "process.log has an extra blank line at the end"
    )

    lines = file_bytes.decode("utf-8").splitlines()
    assert lines == EXPECTED_PROCESS_LOG_LINES, (
        "Contents of process.log are incorrect.\n"
        f"Expected:\n{EXPECTED_PROCESS_LOG_LINES}\n\nActual:\n{lines}"
    )