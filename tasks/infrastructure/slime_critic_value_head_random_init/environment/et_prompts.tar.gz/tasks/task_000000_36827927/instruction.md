You are a junior data-analyst who has been given a directory full of monthly CSV “report” files and asked to build a batch summary.

1.  The input data are already present under
    /home/user/data/reports/  
    and each file to be processed follows this exact naming pattern:
        report_*.csv   (all lowercase; the * is a 6-character yyyymm or yyyymmdd block).

2.  Every report_*.csv has the same column layout:
        id,value,comment   (that is the single, first-row header).
    • “value” may be blank.  
    • There are **no embedded commas** in any field.

3.  Your task:  
    a.  Locate every file whose name begins with “report_” and ends in “.csv”  
        anywhere below /home/user/data/reports/ (there are no sub-directories
        today, but your solution must not assume that).  
    b.  For each such file, count:
        • total_rows                 = total data lines (exclude the header)  
        • non_empty_value_rows       = data lines whose “value” column is NOT empty  
        • rows_with_missing_value    = data lines whose “value” column IS empty
    c.  Collect those numbers in a single comma-separated summary file called
        /home/user/output/batch_summary.csv

       Exact required format of batch_summary.csv:
           Line-1:  report_YYYYMM.csv,3,2,1
           Line-2:  … (one line per source file)  
           Columns: filename,total_rows,non_empty_value_rows,rows_with_missing_value  
           • filename  = the basename only (no path).  
           • Lines must be sorted alphabetically by filename (C-locale order).  
           • Each line terminated by a single ASCII newline (LF, 0x0A).  
           • **NO header row** in the summary.

       With the data already provided to you, the file must end up containing
       exactly the following three lines (in this order):

           report_202301.csv,3,2,1
           report_202302.csv,3,3,0
           report_202303.csv,3,2,1

       (Trailing newline after the last line is required.)

    d.  Create a very simple process log at
        /home/user/output/process.log  
        containing one line per processed file, in the same sorted order, with
        the exact text:

           Processed report_202301.csv
           Processed report_202302.csv
           Processed report_202303.csv

        (Again, newline-terminated lines; no extra blank lines.)

    e.  When everything completes successfully, print the single line
        Batch summary generated
        to STDOUT so that the manager watching the CI run can see immediate
        feedback.

4.  Constraints:
    • Your solution must correctly handle filenames that may contain spaces or other special characters.
    • Do **not** hard-code the three sample filenames; use the naming pattern so that future months work automatically.
    • The directory /home/user/output/ may not yet exist; create it as needed without sudo. All generated files must be world-readable (chmod 644) to satisfy downstream tooling.
    • Avoid generating temporary files outside /tmp or the output directory. Clean up any temp files you create.

5.  Verification:
    Automated tests will:
    • Confirm that /home/user/output/batch_summary.csv exists and contains
      the exact three lines shown above in the correct order with correct
      newline endings, no extra spaces.  
    • Confirm that /home/user/output/process.log exists and contains exactly
      the three “Processed …” lines shown above.  
    • Capture your program’s final STDOUT and assert that it includes the
      phrase:
            Batch summary generated
      (exact spelling, case-sensitive).  
    • Inspect the summary file’s permissions to make sure they are 644 (rw-r--r--).

Execute all steps entirely from the terminal. The folder /home/user is your $HOME. You do NOT have root privileges, so rely only on standard user-level commands.