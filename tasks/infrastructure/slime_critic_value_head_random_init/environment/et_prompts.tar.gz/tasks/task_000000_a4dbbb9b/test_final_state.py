# test_final_state.py
#
# This pytest suite validates the **post-task** filesystem state after the
# student has performed the TLS-credential rotation assignment.
#
# Passing this test suite means:
#
# 1. The symbolic link /home/user/.secrets/active_key.pem exists and ultimately
#    resolves to /home/user/.secrets/new_key.pem.
# 2. The rotation log /home/user/rotation.log exists, has permissions 0644,
#    contains exactly one line, and that line (with a single trailing newline)
#    is the absolute canonical path /home/user/.secrets/new_key.pem.
#
# The checks are intentionally explicit so that any deviation will result in a
# clear, actionable failure message.

import os
import stat
import pytest

HOME_DIR      = "/home/user"
SECRETS_DIR   = os.path.join(HOME_DIR, ".secrets")

OLD_KEY       = os.path.join(SECRETS_DIR, "old_key.pem")
NEW_KEY       = os.path.join(SECRETS_DIR, "new_key.pem")
ACTIVE_LINK   = os.path.join(SECRETS_DIR, "active_key.pem")
ROTATION_LOG  = os.path.join(HOME_DIR, "rotation.log")


# --------------------------------------------------------------------------- #
# Helper assertions                                                           
# --------------------------------------------------------------------------- #
def _assert_regular_file(path: str, msg_prefix: str = "") -> None:
    assert os.path.exists(path), f"{msg_prefix}Expected file {path!r} to exist."
    assert os.path.isfile(path), f"{msg_prefix}{path!r} exists but is not a regular file."


def _assert_symlink(path: str, msg_prefix: str = "") -> None:
    assert os.path.lexists(path), f"{msg_prefix}Expected symlink {path!r} to exist."
    assert os.path.islink(path), f"{msg_prefix}{path!r} exists but is not a symbolic link."


# --------------------------------------------------------------------------- #
# Tests                                                                       
# --------------------------------------------------------------------------- #
def test_active_key_symlink_points_to_new_key():
    """
    Verify that /home/user/.secrets/active_key.pem is still a symlink and that
    it now resolves (via os.path.realpath, equivalent to `readlink -f`) to
    /home/user/.secrets/new_key.pem.
    """
    _assert_symlink(ACTIVE_LINK)

    resolved = os.path.realpath(ACTIVE_LINK)
    assert resolved == NEW_KEY, (
        f"{ACTIVE_LINK!r} should resolve to {NEW_KEY!r} after rotation, "
        f"but it currently resolves to {resolved!r}."
    )


def test_rotation_log_exists_and_is_correct():
    """
    Ensure /home/user/rotation.log exists, is a regular file with permissions
    0644, contains exactly one line, and that line is the canonical path to
    new_key.pem with a single trailing newline character.
    """
    _assert_regular_file(ROTATION_LOG)

    # --- Permissions ------------------------------------------------------- #
    stat_result = os.stat(ROTATION_LOG)
    perms = stat_result.st_mode & 0o777
    expected_perms = 0o644
    assert perms == expected_perms, (
        f"{ROTATION_LOG!r} permissions are {oct(perms)}, expected {oct(expected_perms)} "
        "(rw-r--r--)."
    )

    # --- Content ----------------------------------------------------------- #
    with open(ROTATION_LOG, "r", encoding="utf-8") as f:
        content = f.read()

    # (1) Must end with exactly one newline.
    assert content.endswith("\n"), (
        f"{ROTATION_LOG!r} must end with a single newline character."
    )

    # (2) After stripping the single trailing newline, nothing else should be
    #     left to strip (no spaces, no extra newlines).
    stripped_line = content.rstrip("\n")   # removes the *one* trailing newline
    assert "\n" not in stripped_line, (
        f"{ROTATION_LOG!r} must contain exactly one line; found multiple lines."
    )

    # (3) The sole line must be the canonical path to new_key.pem.
    assert stripped_line == NEW_KEY, (
        f"{ROTATION_LOG!r} content is {stripped_line!r}; expected {NEW_KEY!r}."
    )


def test_key_files_still_present():
    """
    The rotation process must not delete or corrupt the existing key files.
    """
    _assert_regular_file(OLD_KEY, msg_prefix="OLD_KEY: ")
    _assert_regular_file(NEW_KEY, msg_prefix="NEW_KEY: ")


def test_secrets_directory_still_exists():
    """
    Sanity check: the secrets directory should certainly still be present.
    """
    assert os.path.isdir(SECRETS_DIR), f"Directory {SECRETS_DIR!r} is missing."