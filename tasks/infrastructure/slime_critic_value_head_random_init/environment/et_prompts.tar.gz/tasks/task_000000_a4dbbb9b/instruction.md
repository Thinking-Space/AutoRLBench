You are acting as a security engineer who is rotating application-wide TLS credentials that live under the hidden directory 
/home/user/.secrets.  
The directory already contains the following three filesystem objects:

1. /home/user/.secrets/old_key.pem      – the previous private key file  
2. /home/user/.secrets/new_key.pem      – the freshly-generated private key file  
3. /home/user/.secrets/active_key.pem   – a symbolic link that **currently** points to old_key.pem

### Goal  
Replace the target of the symbolic link /home/user/.secrets/active_key.pem so that, after the change, it resolves to  
/home/user/.secrets/new_key.pem.

### Constraints  
* You do not have root privileges; keep everything inside /home/user.  

### Verification log (mandatory)  
After you have updated the link, capture proof in a text file called /home/user/rotation.log.  
The log file must contain exactly one line, **no extra spaces or newline characters before or after**.  
That line must be the absolute, canonical path that the symbolic link finally resolves to.  
Example format (do not include the square brackets):

```
/home/user/.secrets/new_key.pem
```

Nothing else should appear in rotation.log—no timestamps, no labels, no additional lines.

### Success criteria the grader will check  
1. /home/user/.secrets/active_key.pem exists and is a symbolic link.  
2. readlink -f /home/user/.secrets/active_key.pem returns /home/user/.secrets/new_key.pem.  
3. /home/user/rotation.log exists, is a regular text file, and its sole line is exactly  
   /home/user/.secrets/new_key.pem  

Carry out the rotation now.