# test_final_state.py
#
# Pytest suite that validates the FINAL state of the operating system
# after the “backup-and-restore” exercise has been completed.
#
# The checks below enforce EXACT compliance with the specification:
#
#   1. /home/user/backup_demo/backup/backup.tar.gz must exist and, when
#      decompressed, contain exactly one regular file
#          original/sample.txt
#      whose SHA-256 hash matches the canonical value.
#
#   2. /home/user/backup_demo/original/ must NOT exist anymore.
#
#   3. /home/user/backup_demo/restore/sample.txt must exist, be identical
#      to the original, and therefore have the same SHA-256 hash.
#
#   4. /home/user/backup_demo/restore_test.log must exist and consist of
#      EXACTLY the two mandated lines including the final newline.
#
# Only the Python standard library and pytest are used.

import hashlib
import os
import tarfile
from pathlib import Path

import pytest

# ---------------------------------------------------------------------- #
#  CONSTANTS                                                             #
# ---------------------------------------------------------------------- #

BASE_DIR = Path("/home/user/backup_demo")
ORIGINAL_DIR = BASE_DIR / "original"
BACKUP_DIR = BASE_DIR / "backup"
BACKUP_TAR = BACKUP_DIR / "backup.tar.gz"
RESTORE_DIR = BASE_DIR / "restore"
RESTORED_FILE = RESTORE_DIR / "sample.txt"
LOG_FILE = BASE_DIR / "restore_test.log"

EXPECTED_SHA256 = (
    "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824"
)

# Pre-computed reference log file content (must include final newline)
EXPECTED_LOG_BYTES = (
    f"FILE: sample.txt\n"
    f"SHA256: {EXPECTED_SHA256}\n"
).encode("utf-8")


# ---------------------------------------------------------------------- #
#  HELPER FUNCTIONS                                                      #
# ---------------------------------------------------------------------- #

def sha256_of_bytes(data: bytes) -> str:
    """Return hex-encoded SHA-256 of a bytes object."""
    return hashlib.sha256(data).hexdigest()


def sha256_of_file(path: Path) -> str:
    """Return hex-encoded SHA-256 of the given file."""
    hasher = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(8192), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


# ---------------------------------------------------------------------- #
#  TESTS                                                                 #
# ---------------------------------------------------------------------- #

def test_backup_tar_exists():
    assert BACKUP_TAR.is_file(), (
        f"Expected backup archive {BACKUP_TAR} to exist as a regular file, "
        "but it is missing."
    )


def test_backup_tar_structure_and_content():
    """
    1. The archive must be a valid gzip-compressed tar file.
    2. It must contain exactly one regular file: original/sample.txt
       (one directory entry for 'original/' is acceptable).
    3. The SHA-256 of that file inside the archive must match EXPECTED_SHA256.
    """
    with tarfile.open(BACKUP_TAR, mode="r:gz") as tar:
        members = tar.getmembers()

        # Separate regular files from directories/other entries
        regular_files = [m for m in members if m.isfile()]
        dirs_and_other  = [m for m in members if not m.isfile()]

        # --- Structure checks ------------------------------------------------
        assert len(regular_files) == 1, (
            f"{BACKUP_TAR} must contain exactly one regular file, but found "
            f"{len(regular_files)}: {[m.name for m in regular_files]}"
        )

        file_member = regular_files[0]
        file_name = file_member.name.lstrip("./")  # tar may prefix './'
        assert file_name == "original/sample.txt", (
            f"Incorrect file path in archive. Expected "
            "'original/sample.txt' but found '{file_member.name}'."
        )

        # No extra rubbish allowed (besides maybe the directory entry)
        allowed_dir_names = {"original", "original/"}
        unexpected = [
            m.name for m in dirs_and_other
            if not (m.isdir() and m.name.rstrip("/") in allowed_dir_names)
        ]
        assert not unexpected, (
            f"{BACKUP_TAR} contains unexpected members: {unexpected}"
        )

        # --- Content / hash check -------------------------------------------
        extracted = tar.extractfile(file_member)
        assert extracted is not None, (
            f"Could not extract {file_member.name} from {BACKUP_TAR}."
        )
        data = extracted.read()
        hash_inside_tar = sha256_of_bytes(data)
        assert hash_inside_tar == EXPECTED_SHA256, (
            "SHA-256 hash mismatch for the file stored INSIDE the archive.\n"
            f"Expected: {EXPECTED_SHA256}\n"
            f"Found:    {hash_inside_tar}"
        )


def test_original_directory_has_been_removed():
    assert not ORIGINAL_DIR.exists(), (
        f"Directory {ORIGINAL_DIR} should have been removed to simulate a "
        "disaster, but it still exists."
    )


def test_restore_directory_and_file():
    assert RESTORE_DIR.is_dir(), (
        f"Expected restoration directory {RESTORE_DIR} to exist, "
        "but it is missing."
    )
    assert RESTORED_FILE.is_file(), (
        f"Restored file {RESTORED_FILE} is missing or not a regular file."
    )

    restored_hash = sha256_of_file(RESTORED_FILE)
    assert restored_hash == EXPECTED_SHA256, (
        "Restored file content does not match the original.\n"
        f"Expected SHA-256: {EXPECTED_SHA256}\n"
        f"Found:            {restored_hash}"
    )


def test_log_file_exists_and_exact_content():
    assert LOG_FILE.is_file(), (
        f"Expected log file {LOG_FILE} to exist, but it is missing."
    )

    data = LOG_FILE.read_bytes()
    assert data == EXPECTED_LOG_BYTES, (
        f"Log file {LOG_FILE} has incorrect content.\n"
        "Expected EXACTLY (visible ▸ denotes end-of-line):\n"
        f"  FILE: sample.txt▸\\n\n"
        f"  SHA256: {EXPECTED_SHA256}▸\\n\n"
        "Found:\n"
        f"{data!r}"
    )