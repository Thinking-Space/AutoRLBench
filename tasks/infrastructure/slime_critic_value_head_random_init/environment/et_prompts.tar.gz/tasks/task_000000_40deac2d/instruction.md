You are a junior backup–operator who has just received a small sandbox on
/home/user.
A colleague has already placed a test folder on the system so you can
practise doing a very basic “backup-and-restore” cycle.

The directory tree CURRENTLY looks like this:

    /home/user/backup_demo/
    └── original/
        └── sample.txt

1.  The file `/home/user/backup_demo/original/sample.txt` already exists and is
    readable by you.  Do NOT modify its contents.

2.  Your assignment is to prove that you can:
    *   create a compressed backup archive,
    *   simulate a disaster (by deleting the live copy),
    *   restore the archive to a different location,
    *   and record the integrity hash of the restored file.

3.  VERY IMPORTANT:  When you finish, the system must comply with the
    following exact state so that the automated grader can verify your work.

    a) A compressed archive called
       `/home/user/backup_demo/backup/backup.tar.gz` must exist.
       – It must contain exactly one directory “original” with exactly one
         file “sample.txt” inside it.
       – The archive must be a standard GNU tar file compressed with gzip.

    b) A restoration directory called
       `/home/user/backup_demo/restore/` must exist and inside it the file
       `sample.txt` must have been extracted so that its content is identical
       to the original.

    c) The original directory at
       `/home/user/backup_demo/original/` must no longer exist (pretend it was
       lost in the “disaster”).

    d) A plain-text log file
       `/home/user/backup_demo/restore_test.log` must exist and contain EXACTLY
       the two lines below (no extra spaces, tabs, or blank lines):

       ```
       FILE: sample.txt
       SHA256: <64 lowercase hexadecimal characters>
       ```

       Substitute “<64 lowercase hexadecimal characters>” with the real
       SHA-256 hash of the restored `sample.txt` file.

       Example of correct formatting (obviously with a different hash):
       ```
       FILE: sample.txt
       SHA256: 0123456789abcdef…(total 64 chars)…abcdef
       ```

4.  No screen output or text besides what is required in
    `/home/user/backup_demo/restore_test.log` will be graded, but feel free to
    print progress messages to the console for your own debugging.

When everything matches the specification above, the exercise is complete.