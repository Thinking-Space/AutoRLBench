# test_final_state.py
#
# Pytest suite that validates the *final* filesystem state after the
# “backup-administrator” task has been completed.
#
# What we check here:
#   • /home/user/backup  and  /home/user/restore  exist with correct perms
#   • Two archive files exist, are readable via tar, and contain the
#     exact expected files (no more, no less, correct relative paths,
#     no absolute or “./” prefixes)
#   • /home/user/restore/hr is an *exact* byte-for-byte copy of
#     /home/user/data/hr
#   • /home/user/backup/backup_summary.log exists, has permission 0644,
#     and its contents match the required specification verbatim
#
# Only the Python standard library and pytest are used.

import os
import stat
import tarfile
import hashlib
import tempfile
import pytest


HOME = "/home/user"
DATA_DIR = os.path.join(HOME, "data")
FINANCE_DIR = os.path.join(DATA_DIR, "finance")
HR_DIR = os.path.join(DATA_DIR, "hr")

BACKUP_DIR = os.path.join(HOME, "backup")
RESTORE_DIR = os.path.join(HOME, "restore")
RESTORE_HR_DIR = os.path.join(RESTORE_DIR, "hr")

FIN_ARCHIVE = os.path.join(BACKUP_DIR, "finance_backup.tar.gz")
HR_ARCHIVE = os.path.join(BACKUP_DIR, "hr_backup.tar.bz2")
SUMMARY_FILE = os.path.join(BACKUP_DIR, "backup_summary.log")

DIR_PERMS = 0o755  # drwxr-xr-x expected for newly created directories
FILE_PERMS = 0o644  # -rw-r--r-- expected for the summary log

EXPECTED_FIN_FILES = sorted([
    "budget/2024_budget.xlsx",
    "accounts.txt",
])

EXPECTED_HR_FILES = sorted([
    "employees.csv",
    "policies/leave_policy.md",
])

EXPECTED_SUMMARY = (
    "==== BACKUP SUMMARY (2025-01-15) ====\n"
    "ARCHIVE: finance_backup.tar.gz\n"
    "FILE_COUNT: 2\n"
    "FILE_LIST_START\n"
    "budget/2024_budget.xlsx\n"
    "accounts.txt\n"
    "FILE_LIST_END\n"
    "ARCHIVE: hr_backup.tar.bz2\n"
    "FILE_COUNT: 2\n"
    "FILE_LIST_START\n"
    "employees.csv\n"
    "policies/leave_policy.md\n"
    "FILE_LIST_END\n"
    "==== END OF SUMMARY ===="
)

# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def _perm_bits(path):
    """Return the permission bits of a filesystem entry."""
    return stat.S_IMODE(os.stat(path).st_mode)


def _sha256_of_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _sha256_of_bytes(data):
    return hashlib.sha256(data).hexdigest()


def _open_tar(path):
    """
    Open a tar archive for reading regardless of compression
    (gzip/bzip2/none). Raises tarfile.ReadError if invalid.
    """
    return tarfile.open(path, mode="r:*")


def _file_members(tar):
    """Return a list of TarInfo objects that are *regular files*."""
    return [m for m in tar.getmembers() if m.isfile()]


def _names_of_files(tar):
    """Return a sorted list of file names for regular file members."""
    return sorted(m.name for m in _file_members(tar))

# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "dpath",
    [BACKUP_DIR, RESTORE_DIR, RESTORE_HR_DIR],
)
def test_directories_created_with_correct_permissions(dpath):
    assert os.path.exists(dpath), f"Directory missing: {dpath}"
    assert os.path.isdir(dpath), f"Expected directory but found something else: {dpath}"
    perms = _perm_bits(dpath)
    assert perms == DIR_PERMS, (
        f"Directory {dpath} permissions are {oct(perms)}, expected {oct(DIR_PERMS)}"
    )


def test_summary_log_exists_and_is_correct():
    assert os.path.exists(SUMMARY_FILE), f"Summary log file missing: {SUMMARY_FILE}"
    assert os.path.isfile(SUMMARY_FILE), f"Expected {SUMMARY_FILE} to be a file."

    perms = _perm_bits(SUMMARY_FILE)
    assert perms == FILE_PERMS, (
        f"{SUMMARY_FILE} permissions are {oct(perms)}, expected {oct(FILE_PERMS)}"
    )

    with open(SUMMARY_FILE, "r", encoding="utf-8") as fh:
        contents = fh.read()

    # Allow (optional) single trailing newline
    assert contents.rstrip("\n") == EXPECTED_SUMMARY, (
        "backup_summary.log does not match the required content exactly."
    )


@pytest.mark.parametrize(
    "archive_path, expected_files",
    [
        (FIN_ARCHIVE, EXPECTED_FIN_FILES),
        (HR_ARCHIVE, EXPECTED_HR_FILES),
    ],
)
def test_archives_exist_and_have_exact_contents(archive_path, expected_files):
    assert os.path.exists(archive_path), f"Expected archive missing: {archive_path}"
    assert os.path.isfile(archive_path), f"{archive_path} is not a regular file."

    # Validate that tarfile can open it
    try:
        with _open_tar(archive_path) as tf:
            names_in_tar = _names_of_files(tf)
    except tarfile.ReadError as exc:
        pytest.fail(f"{archive_path} is not a valid tar archive: {exc}")

    # Confirm correct file set
    assert names_in_tar == expected_files, (
        f"{archive_path} contains files {names_in_tar}, "
        f"but expected exactly {expected_files}"
    )

    # Ensure each file path is truly relative (no leading '/' or './')
    offending = [
        n for n in names_in_tar if n.startswith("/") or n.startswith("./")
    ]
    assert not offending, (
        f"The following paths inside {archive_path} are not purely relative: {offending}"
    )


def test_archive_contents_match_original_files():
    """
    For *each* file member in both archives, ensure its byte contents are an
    exact match to the original source file under /home/user/data.
    """
    for archive_path, base_dir in [
        (FIN_ARCHIVE, FINANCE_DIR),
        (HR_ARCHIVE, HR_DIR),
    ]:
        with _open_tar(archive_path) as tf:
            for member in _file_members(tf):
                rel_path = member.name
                original = os.path.join(base_dir, rel_path)
                assert os.path.exists(original), (
                    f"Original source file missing for {rel_path} referenced in {archive_path}"
                )
                original_hash = _sha256_of_file(original)
                extracted_bytes = tf.extractfile(member).read()
                extracted_hash = _sha256_of_bytes(extracted_bytes)
                assert extracted_hash == original_hash, (
                    f"File {rel_path} inside {archive_path} does not match its "
                    f"original counterpart {original}"
                )


def test_restore_hr_is_exact_copy_of_original():
    """
    Compare /home/user/restore/hr recursively with /home/user/data/hr.
    Every directory and regular file must exist in both locations,
    and all regular files must match byte-for-byte.
    """
    for root, dirs, files in os.walk(HR_DIR):
        rel_root = os.path.relpath(root, HR_DIR)  # '.' for top level
        restored_root = (
            RESTORE_HR_DIR if rel_root == "." else os.path.join(RESTORE_HR_DIR, rel_root)
        )

        # Directories -------------------------------------------------------
        assert os.path.exists(restored_root), (
            f"Directory missing in restored tree: {restored_root}"
        )
        assert os.path.isdir(restored_root), (
            f"Expected directory but found something else: {restored_root}"
        )

        # Compare directory permissions (optional but helpful)
        orig_perms = _perm_bits(root)
        rest_perms = _perm_bits(restored_root)
        assert rest_perms == orig_perms, (
            f"Directory permissions differ for {restored_root}: "
            f"{oct(rest_perms)} vs expected {oct(orig_perms)}"
        )

        # Files -------------------------------------------------------------
        for fname in files:
            orig_file = os.path.join(root, fname)
            rest_file = os.path.join(restored_root, fname)

            assert os.path.exists(rest_file), (
                f"File missing in restored tree: {rest_file}"
            )
            assert os.path.isfile(rest_file), (
                f"Expected regular file but found something else: {rest_file}"
            )

            # permissions
            orig_perms = _perm_bits(orig_file)
            rest_perms = _perm_bits(rest_file)
            assert rest_perms == orig_perms, (
                f"File permissions differ for {rest_file}: "
                f"{oct(rest_perms)} vs expected {oct(orig_perms)}"
            )

            # content
            assert _sha256_of_file(rest_file) == _sha256_of_file(orig_file), (
                f"File contents differ for restored file {rest_file}"
            )

    # Also ensure no *extra* files/dirs exist in restore/hr that are not in original
    with tempfile.TemporaryDirectory() as tmp:
        # Build sets of relative paths (files + dirs)
        orig_paths = set()
        for root, dirs, files in os.walk(HR_DIR):
            rel_root = os.path.relpath(root, HR_DIR)
            for d in dirs:
                orig_paths.add(os.path.join(rel_root, d) if rel_root != "." else d)
            for f in files:
                orig_paths.add(os.path.join(rel_root, f) if rel_root != "." else f)

        rest_paths = set()
        for root, dirs, files in os.walk(RESTORE_HR_DIR):
            rel_root = os.path.relpath(root, RESTORE_HR_DIR)
            for d in dirs:
                rest_paths.add(os.path.join(rel_root, d) if rel_root != "." else d)
            for f in files:
                rest_paths.add(os.path.join(rel_root, f) if rel_root != "." else f)

        extra = rest_paths - orig_paths
        assert not extra, (
            f"The restored hr directory contains unexpected extra paths: {sorted(extra)}"
        )