You are a newly-hired backup administrator.
Your first assignment is to archive the existing departmental data, verify that the archives can be restored, and leave a human-readable summary for auditors.

1.  **Directories that already exist**
    *   /home/user/data/finance
    *   /home/user/data/hr

2.  **What you must do**
    a.  Create the directory /home/user/backup if it does **not** yet exist (do NOT use sudo).
    b.  Compress the entire /home/user/data/finance tree into the file
        /home/user/backup/finance\_backup.tar.gz using *gzip* compression.
    c.  Compress the entire /home/user/data/hr tree into the file
        /home/user/backup/hr\_backup.tar.bz2 using *bzip2* compression.
    d.  Create the directory /home/user/restore (if missing) and fully extract the
        /home/user/backup/hr\_backup.tar.bz2 archive there, so that the path
        /home/user/restore/hr now contains an exact copy of the original
        /home/user/data/hr directory hierarchy.
    e.  Produce a plain-text summary file called /home/user/backup/backup\_summary.log
        with **exactly** the contents described in section 3.

3.  **Required format of /home/user/backup/backup\_summary.log**

The file must be an ordinary UTF-8 text file whose entire contents are **identical** to the block below **except** that the very last line may or may not have a trailing newline (either is acceptable).
All spelling, capitalisation, spacing and line-breaks are significant.

```text
==== BACKUP SUMMARY (2025-01-15) ====
ARCHIVE: finance_backup.tar.gz
FILE_COUNT: 2
FILE_LIST_START
accounts.txt
budget/2024_budget.xlsx
FILE_LIST_END
ARCHIVE: hr_backup.tar.bz2
FILE_COUNT: 2
FILE_LIST_START
employees.csv
policies/leave_policy.md
FILE_LIST_END
==== END OF SUMMARY ====
```

Explanations of each required line:
*   “FILE\_COUNT” is the **number of regular files** inside the corresponding archive, **not** the number of directories.
*   The list that begins with “FILE\_LIST\_START” must contain the **relative paths as they appear inside the archive**, one per line, sorted in strict ASCIIbetical order.
*   Do **not** include “./” prefixes.
*   No extra blank lines are allowed anywhere in the file.

4.  **Verification rules the automated grader will follow**
    *   It will check that /home/user/backup/finance\_backup.tar.gz and /home/user/backup/hr\_backup.tar.bz2 both exist and are valid archives that can be unpacked with tar.
    *   It will untar /home/user/backup/hr\_backup.tar.bz2 and verify that the directory /home/user/restore/hr has the same file/directory structure and file contents as the original /home/user/data/hr.
    *   It will read /home/user/backup/backup\_summary.log byte-for-byte and compare it with the exact block in section 3.
    *   It will confirm that the two archive files really contain exactly the files listed in the summary (no more, no less, correct names).

Important: you will **not** have root privileges. Stay entirely inside /home/user.
Do not move or rename any of the original files or directories.
Do not include absolute paths inside the archives—only relative paths as required.
When everything is finished, the grader must be able to reproduce the outcome by running the same commands on a clean copy of the initial file set.