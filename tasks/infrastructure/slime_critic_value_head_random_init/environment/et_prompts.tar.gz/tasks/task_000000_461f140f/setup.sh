#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        python3-pip \
        python3-setuptools \
        python3 && \
    pip3 install --no-cache-dir pytest

mkdir -p /home/user && \
    chmod 0777 /home/user && \
    mkdir -p /home/user/data/finance/budget && \
    mkdir -p /home/user/data/hr/policies && \
    find /home/user/data -type d -exec chmod 0755 {} \;

cat <<'EOF_ACCOUNTS' > /home/user/data/finance/accounts.txt
Quarterly accounts receivable: Q4 2024
Total: 123456
EOF_ACCOUNTS

cat <<'EOF_BUDGET' > /home/user/data/finance/budget/2024_budget.xlsx
dummy finance spreadsheet
EOF_BUDGET

cat <<'EOF_EMP' > /home/user/data/hr/employees.csv
id,name,department
1,Alice,HR
2,Bob,HR
EOF_EMP

cat <<'EOF_POLICY' > /home/user/data/hr/policies/leave_policy.md
# Leave Policy
All employees are entitled to 30 days of leave per year.
EOF_POLICY

find /home/user/data -type f -exec chmod 0644 {} \;

export HOME=/home/user
