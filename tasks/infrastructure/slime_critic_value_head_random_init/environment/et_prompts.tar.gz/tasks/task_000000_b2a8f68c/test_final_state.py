# test_final_state.py
#
# Pytest suite that validates the **final** state of the operating-system /
# container *after* the student has completed the “service-level network audit”
# exercise.
#
# It focusses exclusively on the artefact that should have been produced by the
# student:  /home/user/network_diagnostics/service_audit.log
#
# The tests do *not* re-parse the Kubernetes manifests – they rely solely on the
# ground-truth values provided by the exercise description and the exact, strict
# output format that the student must generate.
#
# Only the Python standard library + pytest are used.  No third-party packages.

import pathlib
import re
from typing import List, Dict, Tuple

LOG_DIR = pathlib.Path("/home/user/network_diagnostics")
LOG_FILE = LOG_DIR / "service_audit.log"

# ---------------------------------------------------------------------------
# Ground-truth data (taken from the exercise description)
# ---------------------------------------------------------------------------
TRUTH_SERVICES: Dict[str, Dict] = {
    "api-gateway": {
        "clusterIP": "10.96.0.20",
        "type": "NodePort",
        "ports": [
            {"port": 443, "targetPort": 8443, "protocol": "TCP", "nodePort": 40000}
        ],
    },
    "postgres": {
        "clusterIP": "10.96.0.30",
        "type": "ClusterIP",  # default, because omitted in manifest
        "ports": [
            # targetPort omitted in manifest -> should be treated as same as 'port'
            {"port": 5432, "targetPort": 5432, "protocol": "TCP", "nodePort": None}
        ],
    },
    "web-service": {
        "clusterIP": "10.96.0.10",
        "type": "NodePort",
        "ports": [
            {"port": 80, "targetPort": 8080, "protocol": "TCP", "nodePort": 30080}
        ],
    },
}


def _expected_nodeport_issue(svc: Dict) -> str:
    """
    Compute the expected NodePortIssues value for a Service, based on the
    exercise rules and the ground-truth data.
    """
    if svc["type"] != "NodePort":
        return "NOT_NODEPORT"

    node_ports = [
        p["nodePort"] for p in svc["ports"] if p.get("nodePort") is not None
    ]

    # A NodePort Service must always have at least one nodePort,
    # but we guard anyway.
    if all(30000 <= np <= 32767 for np in node_ports):
        return "OK"
    return "OUT_OF_RANGE"


# Pre-calculate truth status for quick look-ups
TRUTH_NODEPORT_STATUS = {
    name: _expected_nodeport_issue(data) for name, data in TRUTH_SERVICES.items()
}

TOTAL_SERVICES = len(TRUTH_SERVICES)
TOTAL_OUT_OF_RANGE = sum(
    1 for status in TRUTH_NODEPORT_STATUS.values() if status == "OUT_OF_RANGE"
)

# ---------------------------------------------------------------------------
# Helper – extremely small, *strict* parser for the audit log
# ---------------------------------------------------------------------------

_HEADER_LINES = 3  # '# Service Audit Report' + 'Generated: ...' + blank line

SERVICE_LINE_RE = re.compile(r"^Service: (\S+)$")
CLUSTER_IP_RE = re.compile(r"^ClusterIP: (\S+)$")
PORTS_HEADER_RE = re.compile(r"^Ports:$")
PORT_LINE_RE = re.compile(r"^  - (\d+)/(\S+) -> (\d+)$")  # two spaces, dash, space …
TYPE_LINE_RE = re.compile(r"^Type: (\S+)$")
NODEPORT_ISSUE_RE = re.compile(r"^NodePortIssues: (OK|OUT_OF_RANGE|NOT_NODEPORT)$")

GENERATED_TS_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$"
)  # very strict ISO-8601 UTC


class ParsedService:
    """
    Very small container object used only inside the test-suite.
    """

    def __init__(
        self,
        name: str,
        cluster_ip: str,
        ports: List[Tuple[int, str, int]],
        svc_type: str,
        nodeport_status: str,
    ):
        self.name = name
        self.cluster_ip = cluster_ip
        self.ports = ports  # list of tuples (port, protocol, targetPort)
        self.svc_type = svc_type
        self.nodeport_status = nodeport_status


def parse_audit_log(text: str) -> List[ParsedService]:
    """
    Parse the student's audit log strictly according to the required format.
    Returns a list of ParsedService objects *in the order they appear* in the
    file.  Raises AssertionError on the very first deviation from the spec –
    the calling test will surface the failure with a meaningful error message.
    """
    lines = text.splitlines()

    # ---------------- Header ----------------
    assert lines, "Audit log is empty."
    assert lines[0] == "# Service Audit Report", (
        "First line of audit log must be exactly '# Service Audit Report'."
    )

    assert len(lines) >= 2, "Audit log truncated – missing 'Generated:' line."
    assert lines[1].startswith("Generated: "), (
        "Second line must start with 'Generated: ' followed by an ISO-8601 UTC "
        "timestamp."
    )
    ts = lines[1][len("Generated: ") :]
    assert GENERATED_TS_RE.match(ts), (
        "Timestamp on 'Generated:' line is not in strict ISO-8601 UTC format "
        "(YYYY-MM-DDThh:mm:ssZ).  Found: " + ts
    )

    assert len(lines) >= 3, "Audit log truncated – missing blank line after header."
    assert lines[2] == "", "There must be one blank line after the header section."

    services: List[ParsedService] = []

    idx = _HEADER_LINES  # start reading after the mandatory blank line

    while idx < len(lines):
        # Summary detected → stop service parsing
        if lines[idx] == "Summary:":
            break

        # ---------------- Service block ----------------
        # 1) Service: <name>
        m = SERVICE_LINE_RE.match(lines[idx])
        assert m, (
            f"Expected 'Service: <name>' line at line {idx+1}, "
            f"but found: {lines[idx]!r}"
        )
        name = m.group(1)
        idx += 1

        # 2) ClusterIP: <ip>
        assert idx < len(lines), "Unexpected EOF while parsing service block."
        m = CLUSTER_IP_RE.match(lines[idx])
        assert m, (
            f"Expected 'ClusterIP: <ip>' line after service '{name}', "
            f"but found: {lines[idx]!r}"
        )
        cluster_ip = m.group(1)
        idx += 1

        # 3) Ports:
        assert idx < len(lines), "Unexpected EOF while parsing service block."
        assert PORTS_HEADER_RE.match(lines[idx]), (
            f"Expected 'Ports:' line after cluster IP in service '{name}', "
            f"but found: {lines[idx]!r}"
        )
        idx += 1

        # 3a) Parse one or more port lines (indented with exactly two spaces)
        port_tuples: List[Tuple[int, str, int]] = []
        while idx < len(lines):
            if PORT_LINE_RE.match(lines[idx]):
                m = PORT_LINE_RE.match(lines[idx])
                port = int(m.group(1))
                protocol = m.group(2)
                target_port = int(m.group(3))
                port_tuples.append((port, protocol, target_port))
                idx += 1
                continue
            break  # first non-port line terminates the port list

        assert port_tuples, (
            f"Service '{name}' contains a 'Ports:' header but no port lines."
        )

        # 4) Type: <type>
        assert idx < len(lines), "Unexpected EOF while parsing service block."
        m = TYPE_LINE_RE.match(lines[idx])
        assert m, (
            f"Expected 'Type: <type>' line after ports in service '{name}', "
            f"but found: {lines[idx]!r}"
        )
        svc_type = m.group(1)
        idx += 1

        # 5) NodePortIssues: <status>
        assert idx < len(lines), "Unexpected EOF while parsing service block."
        m = NODEPORT_ISSUE_RE.match(lines[idx])
        assert m, (
            f"Expected 'NodePortIssues: <value>' line after type in service "
            f"'{name}', but found: {lines[idx]!r}"
        )
        nodeport_status = m.group(1)
        idx += 1

        # 6) Exactly one blank line between blocks
        assert idx < len(lines), (
            "Unexpected EOF – missing blank line after service block."
        )
        assert lines[idx] == "", (
            f"There must be exactly one blank line after the service block for "
            f"'{name}'.  Found: {lines[idx]!r}"
        )
        idx += 1  # skip the blank line

        services.append(
            ParsedService(
                name=name,
                cluster_ip=cluster_ip,
                ports=port_tuples,
                svc_type=svc_type,
                nodeport_status=nodeport_status,
            )
        )

    # After loop we must see the Summary:
    assert idx < len(lines), "Audit log terminated before 'Summary:' section."
    assert lines[idx] == "Summary:", (
        f"Expected 'Summary:' line at line {idx+1}, but found: {lines[idx]!r}"
    )

    assert idx + 1 < len(lines), "Summary section incomplete – missing TotalServices."
    total_line = lines[idx + 1]
    m = re.match(r"^TotalServices: (\d+)$", total_line)
    assert m, (
        f"'TotalServices' line malformed. Expected 'TotalServices: <int>', "
        f"found: {total_line!r}"
    )
    total_services_reported = int(m.group(1))

    assert idx + 2 < len(lines), (
        "Summary section incomplete – missing NodePortOutOfRange line."
    )
    out_line = lines[idx + 2]
    m = re.match(r"^NodePortOutOfRange: (\d+)$", out_line)
    assert m, (
        f"'NodePortOutOfRange' line malformed. Expected "
        f"'NodePortOutOfRange: <int>', found: {out_line!r}"
    )
    nodeport_oor_reported = int(m.group(1))

    # Allow (optional) single trailing blank line (POSIX newline at EOF).
    assert idx + 3 == len(lines) or (
        idx + 3 == len(lines) - 1 and lines[-1] == ""
    ), (
        "Unexpected extra content after 'NodePortOutOfRange' line."
    )

    # Return parsed services plus summary values
    return services, total_services_reported, nodeport_oor_reported


# ---------------------------------------------------------------------------
#                              Pytest tests
# ---------------------------------------------------------------------------


def test_log_directory_and_file_exist():
    assert LOG_DIR.exists(), (
        f"Directory '{LOG_DIR}' was not created. The student's solution "
        "must create it to store the audit log."
    )
    assert LOG_DIR.is_dir(), f"'{LOG_DIR}' exists but is not a directory."

    assert LOG_FILE.exists(), (
        f"Expected audit log file '{LOG_FILE}' does not exist."
    )
    assert LOG_FILE.is_file(), f"'{LOG_FILE}' exists but is not a regular file."


def test_audit_log_format_and_content():
    content = LOG_FILE.read_text(encoding="utf-8", errors="replace")
    parsed_services, total_services_reported, nodeport_oor_reported = parse_audit_log(
        content
    )

    # ---------- 1) Correct number of services ----------
    assert (
        total_services_reported == TOTAL_SERVICES
    ), f"'TotalServices' in summary is {total_services_reported}, expected {TOTAL_SERVICES}."
    assert len(parsed_services) == TOTAL_SERVICES, (
        f"Number of service blocks is {len(parsed_services)}, but 'TotalServices' "
        f"reports {total_services_reported}."
    )

    # ---------- 2) Service order (alphabetical) ----------
    service_names = [svc.name for svc in parsed_services]
    assert service_names == sorted(service_names), (
        "Service blocks are not in ascending alphabetical order.\n"
        f"Found order: {service_names}"
    )

    # ---------- 3) Validate every service block ----------
    for svc in parsed_services:
        assert (
            svc.name in TRUTH_SERVICES
        ), f"Unexpected service '{svc.name}' present in audit log."
        truth = TRUTH_SERVICES[svc.name]

        # 3a) ClusterIP
        assert svc.cluster_ip == truth["clusterIP"], (
            f"Service '{svc.name}' has wrong ClusterIP.\n"
            f"Expected: {truth['clusterIP']}\n"
            f"Found   : {svc.cluster_ip}"
        )

        # 3b) Type
        assert svc.svc_type == truth["type"], (
            f"Service '{svc.name}' has wrong Type.\n"
            f"Expected: {truth['type']}\n"
            f"Found   : {svc.svc_type}"
        )

        # 3c) Ports list
        truth_ports = truth["ports"]
        assert len(svc.ports) == len(truth_ports), (
            f"Service '{svc.name}' has {len(svc.ports)} port line(s) but "
            f"{len(truth_ports)} expected."
        )
        for i, (obs_port, obs_proto, obs_tgt) in enumerate(svc.ports):
            exp = truth_ports[i]
            assert (
                obs_port == exp["port"]
                and obs_proto == exp["protocol"]
                and obs_tgt == exp["targetPort"]
            ), (
                f"Service '{svc.name}' port line {i+1} differs.\n"
                f"Expected: {exp['port']}/{exp['protocol']} -> {exp['targetPort']}\n"
                f"Found   : {obs_port}/{obs_proto} -> {obs_tgt}"
            )

        # 3d) NodePortIssues
        expected_issue = TRUTH_NODEPORT_STATUS[svc.name]
        assert svc.nodeport_status == expected_issue, (
            f"Service '{svc.name}' has NodePortIssues '{svc.nodeport_status}', "
            f"but expected '{expected_issue}'."
        )

    # ---------- 4) NodePortOutOfRange summary ----------
    assert (
        nodeport_oor_reported == TOTAL_OUT_OF_RANGE
    ), (
        f"'NodePortOutOfRange' summary value is {nodeport_oor_reported}, "
        f"expected {TOTAL_OUT_OF_RANGE}."
    )