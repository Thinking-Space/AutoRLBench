You are acting as the SRE on-call for a small Kubernetes-based web application.  
Your goal is to perform a **service-level network audit** of the existing
Kubernetes manifests that live in the directory  
/home/user/manifests.  
The audit must be written to the file  
/home/user/network_diagnostics/service_audit.log (create the directory
/home/user/network_diagnostics if it does not already exist).

What you have:
*   Three YAML manifest files are already present under
    /home/user/manifests:  
        *   web-deployment.yaml  
        *   api-gateway.yaml  
        *   db.yaml

*   Each manifest can contain one or more Kubernetes objects (Service,
    Deployment, StatefulSet, …).

What you must do (high level):
1.  Parse **every** Service object that appears anywhere inside those YAML
    files.  
2.  For each Service collect the following fields:
    *   metadata.name  
    *   spec.clusterIP  
    *   spec.type   (if omitted, treat as “ClusterIP”)  
    *   Every entry in spec.ports:
        *   port  
        *   targetPort  
        *   protocol (default “TCP” if omitted)  
        *   nodePort (may be absent)  
3.  Determine whether a Service has a NodePort that is **outside** the legal
    Kubernetes default range (30000–32767).  
    *   If spec.type is *NodePort* **and** every nodePort value is inside the
        30000-32767 range → mark **OK**.  
    *   If spec.type is *NodePort* **and** at least one nodePort value is
        < 30000 or > 32767 → mark **OUT_OF_RANGE**.  
    *   If spec.type is anything else (ClusterIP, LoadBalancer, …) →
        mark **NOT_NODEPORT**.
4.  Write a strictly formatted log file summarising your findings.

Required log-file format  
(the automated checker compares this **exactly**, so follow precisely):

    # Service Audit Report
    Generated: YYYY-MM-DDThh:mm:ssZ

    Service: <metadata.name>
    ClusterIP: <spec.clusterIP>
    Ports:
      - <port>/<protocol> -> <targetPort>
      - ...                             # one line per port
    Type: <spec.type|ClusterIP>
    NodePortIssues: <OK|OUT_OF_RANGE|NOT_NODEPORT>

    (blank line separates each service block)

    Summary:
    TotalServices: <integer>
    NodePortOutOfRange: <integer>

Additional rules:
*   List the individual service blocks **in ascending alphabetical order of
    metadata.name**.  
*   Inside each service block list the Ports lines in the same order they
    appear in the manifest.  
*   The timestamp on the “Generated:” line must be the current UTC time in
    ISO-8601 format (use the literal letter “Z” for UTC).  
*   All indentation must be made with two spaces (no tabs).  
*   There must be exactly one blank line between consecutive service blocks
    and exactly one blank line between the last service block and the
    “Summary:” section.

Remember:
*   Do **not** attempt to apply or modify the manifests in a running cluster;
    this task is static analysis only.  
*   You do **not** have root privileges. All work must happen inside the
    /home/user directory tree.  
*   All work must be done using the tools and scripting languages that are pre-installed in the environment. Do **not** install extra packages.

When the log file exactly matches the required format and correct values,
the task will be marked as complete.