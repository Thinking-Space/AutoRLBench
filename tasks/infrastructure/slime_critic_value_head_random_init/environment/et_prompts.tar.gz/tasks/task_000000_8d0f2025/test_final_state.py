# test_final_state.py
#
# Robust pytest suite that validates the **FINAL** state of the operating-system /
# filesystem **after** the emergency patch release for the “incident-tools” project
# has been fully carried out by the student.
#
# The assertions cover:
#   • version bumps in VERSION and package.json
#   • exact top-of-file section for CHANGELOG.md (date, headings, bullets, blank lines)
#   • existence and correctness of annotated / signed git tag v1.2.4
#   • release artefact .release_logs/release_1.2.4.json (order, content, permissions)
#   • .release_logs directory existence & permissions
#
# Only the Python standard library and pytest are used.

import json
import re
import stat
import subprocess
from collections import OrderedDict
from datetime import date
from pathlib import Path

import pytest

# --------------------------------------------------------------------------- #
# Constants                                                                   #
# --------------------------------------------------------------------------- #
REPO_PATH = Path("/home/user/incident-tools")
VERSION_FILE = REPO_PATH / "VERSION"
PACKAGE_JSON = REPO_PATH / "package.json"
CHANGELOG = REPO_PATH / "CHANGELOG.md"
RELEASE_LOGS_DIR = REPO_PATH / ".release_logs"
RELEASE_JSON = RELEASE_LOGS_DIR / "release_1.2.4.json"

OLD_VERSION = "1.2.3"
NEW_VERSION = "1.2.4"
GIT_TAG_NAME = f"v{NEW_VERSION}"
TAG_ANNOTATION = f"Release {NEW_VERSION}"

COMMITS_EXPECTED = [
    "fix(parser): handle null bytes in log stream",
    "chore(deps): bump lodash from 4.17.20 to 4.17.21",
    "docs: update contact escalation path",
]


# --------------------------------------------------------------------------- #
# Helper utilities                                                            #
# --------------------------------------------------------------------------- #
def _run_git(args):
    """
    Run a git command inside the repository and return stdout (str).

    Raises subprocess.CalledProcessError on non-zero return codes.
    """
    completed = subprocess.run(
        ["git"] + list(args),
        cwd=REPO_PATH,
        capture_output=True,
        text=True,
        check=True,
    )
    return completed.stdout.strip()


def _chmod_mask(path: Path) -> int:
    """
    Return the permission bits (mask) of a file/directory, similar to a literal
    used with chmod (e.g. 0o755).
    """
    return stat.S_IMODE(path.stat().st_mode)


# --------------------------------------------------------------------------- #
# Tests                                                                       #
# --------------------------------------------------------------------------- #
def test_version_file_updated():
    assert VERSION_FILE.is_file(), f"{VERSION_FILE} is missing."
    content = VERSION_FILE.read_text().strip()
    assert (
        content == NEW_VERSION
    ), f"VERSION file should contain '{NEW_VERSION}', found '{content}'."


def test_package_json_version_field_updated():
    assert PACKAGE_JSON.is_file(), f"{PACKAGE_JSON} is missing."
    try:
        data = json.loads(PACKAGE_JSON.read_text())
    except json.JSONDecodeError as exc:
        pytest.fail(f"package.json is not valid JSON: {exc}")

    version = data.get("version")
    assert (
        version == NEW_VERSION
    ), f"package.json version field should be '{NEW_VERSION}', found '{version}'."


def test_changelog_top_section_exact_block():
    """
    Verify that CHANGELOG.md was prepended with the exact block for 1.2.4,
    including correct ISO-8601 date, headings, bullets and blank lines.

    The test is strict because the automated release tooling downstream relies
    on byte-for-byte matching of this header.
    """
    assert CHANGELOG.is_file(), f"{CHANGELOG} does not exist."

    text = CHANGELOG.read_text()
    lines = text.splitlines()

    # --------------------------------------------------------------------- #
    # 1) Heading line — must be very first line                             #
    # --------------------------------------------------------------------- #
    assert lines, "CHANGELOG.md is empty – expected release notes."
    heading_regex = rf"^## \[{re.escape(NEW_VERSION)}] - (\d{{4}}-\d{{2}}-\d{{2}})$"
    match = re.match(heading_regex, lines[0])
    assert match, (
        "First line of CHANGELOG.md should match pattern "
        f"'## [{NEW_VERSION}] - YYYY-MM-DD' but found: {lines[0]!r}"
    )
    changelog_date = match.group(1)

    # Basic sanity: date is valid ISO-8601 and not in the future.
    try:
        date_obj = date.fromisoformat(changelog_date)
    except ValueError:
        pytest.fail(f"Date '{changelog_date}' in CHANGELOG.md is not valid ISO-8601.")
    assert date_obj <= date.today(), "Date in CHANGELOG.md is set in the future."

    # --------------------------------------------------------------------- #
    # 2) Exactly expected block follows (12 additional lines)               #
    # --------------------------------------------------------------------- #
    expected_block = [
        f"## [{NEW_VERSION}] - {changelog_date}",
        "### Added",
        "_Nothing_",
        "",
        "### Changed",
        "_Nothing_",
        "",
        "### Fixed",
        "- handle null bytes in log stream",
        "",
        "### Security",
        "_Nothing_",
        "",
    ]
    expected_joined = "\n".join(expected_block)
    actual_prefix = "\n".join(lines[: len(expected_block)])

    assert (
        actual_prefix == expected_joined
    ), (
        "Top section of CHANGELOG.md does not match expected block.\n"
        "---- Expected block ----\n"
        f"{expected_joined}\n"
        "---- Actual block   ----\n"
        f"{actual_prefix}\n"
    )


def test_git_tag_exists_and_is_annotated():
    # Tag existence
    tags = _run_git(["tag", "-l", GIT_TAG_NAME]).splitlines()
    assert (
        GIT_TAG_NAME in tags
    ), f"Expected git tag {GIT_TAG_NAME} to exist, but it was not found."

    # Tag object type should be 'tag' (annotated / signed, not lightweight)
    tag_type = _run_git(["cat-file", "-t", GIT_TAG_NAME])
    assert (
        tag_type == "tag"
    ), f"Git tag {GIT_TAG_NAME} is not annotated/signed (type={tag_type!r})."

    # Annotation message must be "Release 1.2.4" (single line)
    raw_tag = _run_git(["cat-file", "-p", GIT_TAG_NAME])
    # `git cat-file -p` output for a tag contains header lines (object, type, tagger, …)
    # followed by an empty line and then the body. We only care about the body.
    tag_body = raw_tag.split("\n\n", 1)[1] if "\n\n" in raw_tag else ""
    tag_body = tag_body.strip()
    assert (
        tag_body == TAG_ANNOTATION
    ), f"Annotation for git tag {GIT_TAG_NAME!r} should be {TAG_ANNOTATION!r}, found {tag_body!r}."

    # Tag must point to the current HEAD of main
    tag_commit = _run_git(["rev-list", "-n", "1", GIT_TAG_NAME])
    head_commit = _run_git(["rev-parse", "HEAD"])
    assert (
        tag_commit == head_commit
    ), f"Git tag {GIT_TAG_NAME} does not point at latest commit on main.\nTag commit:  {tag_commit}\nHEAD commit: {head_commit}"


def test_release_json_exists_and_is_correct():
    assert RELEASE_JSON.is_file(), f"{RELEASE_JSON} is missing."

    # --------------------------------------------------------------------- #
    # 1) Permissions                                                        #
    # --------------------------------------------------------------------- #
    file_perm = _chmod_mask(RELEASE_JSON)
    expected_perm = 0o644
    assert (
        file_perm == expected_perm
    ), f"{RELEASE_JSON} has permissions {oct(file_perm)}, expected {oct(expected_perm)} (rw-r--r--)."

    # --------------------------------------------------------------------- #
    # 2) Load JSON (preserving order)                                       #
    # --------------------------------------------------------------------- #
    try:
        ordered_pairs = json.loads(
            RELEASE_JSON.read_text(), object_pairs_hook=OrderedDict
        )
    except json.JSONDecodeError as exc:
        pytest.fail(f"{RELEASE_JSON} is not valid JSON: {exc}")

    # Validate key order
    expected_key_order = [
        "old_version",
        "new_version",
        "date",
        "commits_included",
        "git_tag",
    ]
    actual_order = list(ordered_pairs.keys())
    assert (
        actual_order == expected_key_order
    ), f"Key order in {RELEASE_JSON} is wrong.\nExpected: {expected_key_order}\nFound:    {actual_order}"

    # Content assertions
    assert (
        ordered_pairs["old_version"] == OLD_VERSION
    ), f"'old_version' should be {OLD_VERSION}."
    assert (
        ordered_pairs["new_version"] == NEW_VERSION
    ), f"'new_version' should be {NEW_VERSION}."

    # Date must match the one in CHANGELOG.md
    changelog_date_line = CHANGELOG.read_text().splitlines()[0]
    changelog_date = re.match(r".* - (\d{4}-\d{2}-\d{2})$", changelog_date_line).group(1)
    json_date = ordered_pairs["date"]
    assert (
        json_date == changelog_date
    ), f"'date' in {RELEASE_JSON} ({json_date}) does not match date in CHANGELOG.md ({changelog_date})."

    # Commits included list
    assert (
        ordered_pairs["commits_included"] == COMMITS_EXPECTED
    ), f"'commits_included' list incorrect.\nExpected: {COMMITS_EXPECTED}\nFound:    {ordered_pairs['commits_included']}"

    # git_tag field
    assert (
        ordered_pairs["git_tag"] == GIT_TAG_NAME
    ), f"'git_tag' should be {GIT_TAG_NAME}."


def test_release_logs_directory_permissions():
    """
    Directory must exist and be readable/executable for everyone, writable
    only by the owner (0755).
    """
    assert RELEASE_LOGS_DIR.is_dir(), f"{RELEASE_LOGS_DIR} directory is missing."

    perm = _chmod_mask(RELEASE_LOGS_DIR)
    expected_perm = 0o755
    assert (
        perm == expected_perm
    ), f"{RELEASE_LOGS_DIR} has permissions {oct(perm)}, expected {oct(expected_perm)} (rwxr-xr-x)."