Your role: You are an on-call incident-responder who must cut an emergency patch release for the internal tooling project located at
    /home/user/incident-tools

    Current situation
    -----------------
    1. /home/user/incident-tools is an existing **git** repository cloned in the working
       directory.  All recent hot-fixes were committed directly to the *main* branch, but
       no formal release has been made since version 1.2.3.
    2. The repository already contains these two version–tracking files:
         • /home/user/incident-tools/VERSION          (plain-text, one line: the current version)
         • /home/user/incident-tools/package.json     (JSON, has a top-level field called "version")
    3. A human left the last three git commit messages after v1.2.3 as:
         a.  fix(parser): handle null bytes in log stream
         b.  chore(deps): bump lodash from 4.17.20 to 4.17.21
         c.  docs: update contact escalation path
       None of these commits introduce breaking changes or new features, therefore the next
       semantic version bump must be **patch** → 1.2.4.

    Your tasks
    ----------
    1. Calculate the new version (1.2.4) and update **both** version-tracking files so
       that they contain exactly "1.2.4".
    2. Pre-pend a new release section to the top of /home/user/incident-tools/CHANGELOG.md. Do not delete the existing content of the file. The new section must have the following exact shape (respect the blank lines, hashes, and bullet characters):

       ## [1.2.4] - YYYY-MM-DD
       ### Added
       _Nothing_

       ### Changed
       _Nothing_

       ### Fixed
       - handle null bytes in log stream

       ### Security
       _Nothing_

       (Replace `YYYY-MM-DD` with today’s date in ISO-8601, for example 2024-03-30.)

    3. Create a **signed** git tag named v1.2.4 that points to the latest commit on
       main *after* your file edits. The tag annotation text must be the single line:
       “Release 1.2.4”. If the execution environment does not support GPG signing, create an *annotated* tag instead.
    4. Generate a machine-readable audit artefact at
       /home/user/incident-tools/.release_logs/release_1.2.4.json
       The file **must** satisfy ALL of the following:
         • valid JSON
         • exact key order (tests check order):
             ```json
             {
               "old_version": "1.2.3",
               "new_version": "1.2.4",
               "date": "YYYY-MM-DD",
               "commits_included": [
                 "fix(parser): handle null bytes in log stream",
                 "chore(deps): bump lodash from 4.17.20 to 4.17.21",
                 "docs: update contact escalation path"
               ],
               "git_tag": "v1.2.4"
             }
             ```
         • same ISO-8601 date you used in CHANGELOG.md.
    5. Ensure the directory /home/user/incident-tools/.release_logs already exists
       (create it if necessary) and set its permissions so that any regular user on
       the system may *read* but only you may *write* (octal 0755 on the directory
       and 0644 on the JSON file are acceptable).

    Verification the grader will perform
    ------------------------------------
    1. It will read /home/user/incident-tools/VERSION and package.json and expect the
       string 1.2.4.
    2. It will parse the top section of CHANGELOG.md and compare it byte-for-byte
       with the pattern shown above (allowing only the correct date substitution).
    3. It will run `git tag -l --format="%(refname:short)"` and expect **v1.2.4**
       to be present, and then check the annotation body for “Release 1.2.4”.
    4. It will load the JSON log file and validate every field as well as the key
       order.
    5. Permissions of .release_logs and its children will be stat-checked.