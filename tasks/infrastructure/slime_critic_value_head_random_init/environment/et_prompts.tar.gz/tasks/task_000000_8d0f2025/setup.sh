#!/bin/bash

set -euo pipefail



# --- pip has no index to talk to. Shell functions below cover `pip install`,
# --- but a task may also call a venv's pip by absolute path, which would then
# --- sit in pip's retry loop for minutes. Make any pip fail in under a second.
export PIP_NO_INDEX=1 PIP_RETRIES=0 PIP_TIMEOUT=1 PIP_NO_INPUT=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

# --- network/package commands are unavailable; make them no-ops -------------
apt-get() { :; }
apt() { :; }
apt-key() { :; }
dpkg() { :; }
dpkg-reconfigure() { :; }
pip() { :; }
pip3() { :; }
locale-gen() { :; }
update-locale() { :; }
curl() { echo "build-time network access is disabled" >&2; return 1; }
wget() { echo "build-time network access is disabled" >&2; return 1; }
# --- account management: the image already has a `user`, and the episode's
# --- home directory is created for us, so these would only ever fail --------
useradd() { :; }
adduser() { :; }
usermod() { :; }
groupadd() { :; }
chpasswd() { :; }
# Best-effort: `chown user:user` cannot work without that account, but every
# episode runs as a single uid in its own tree, so ownership is irrelevant.
chown() { command chown "$@" 2>/dev/null || true; }
chgrp() { command chgrp "$@" 2>/dev/null || true; }
export -f apt-get apt apt-key dpkg dpkg-reconfigure pip pip3 locale-gen update-locale curl wget
export -f useradd adduser usermod groupadd chpasswd chown chgrp


export LANG=C.UTF-8

export LC_ALL=C.UTF-8

set -e && \
    export DEBIAN_FRONTEND=noninteractive && \
    apt-get update && \
    apt-get install -y --no-install-recommends \
        git \
        python3 \
        python3-pip \
        jq \
        ca-certificates && \
    pip3 install --no-cache-dir pytest && \
    mkdir -p /home/user

cd /home/user && \
    git init incident-tools && \
    cd incident-tools && \
    git checkout -b main && \
    git config user.email "builder@example.com" && \
    git config user.name  "Builder Bot" && \
    echo "1.2.3" > VERSION

cd /home/user/incident-tools && \
    cat > CHANGELOG.md <<'EOF'
## [1.2.3] - 2023-10-02
### Added
- initial release of incident-tools

### Changed
- improved log parsing performance

### Fixed
- corrected typo in README

### Security
- none
EOF

cd /home/user/incident-tools && \
    cat > package.json <<'EOF'
{
  "name": "incident-tools",
  "version": "1.2.3",
  "description": "Internal utilities for incident responders",
  "main": "index.js",
  "license": "MIT"
}
EOF

cd /home/user/incident-tools && \
    git add VERSION CHANGELOG.md package.json && \
    git commit -m "chore: initial 1.2.3 release" && \
    git tag -a v1.2.3 -m "Release 1.2.3"

cd /home/user/incident-tools && \
    echo "// docs update placeholder" > internal.txt && \
    git add internal.txt && \
    git commit -m "docs: update contact escalation path" && \
    echo "// lodash bump" >> internal.txt && \
    git add internal.txt && \
    git commit -m "chore(deps): bump lodash from 4.17.20 to 4.17.21" && \
    echo "// fix null byte handling" >> internal.txt && \
    git add internal.txt && \
    git commit -m "fix(parser): handle null bytes in log stream"

chmod -R a+rwX /home/user/incident-tools && \
    chmod 755 /home/user
