# test_final_state.py
#
# Pytest suite that validates the *final* operating-system / filesystem
# state *after* the learner has completed the “Synchronize a Mock Remote
# Web Root and Produce a Transfer Log” task.
#
# This file MUST live at the project root and be named exactly as above.
#
# What we verify:
#   1. Destination mirror directory exists and is an exact byte-for-byte
#      copy of the source tree (no extra or missing files/directories).
#   2. Transfer-summary log file exists and contains exactly six
#      newline-terminated lines that match the required format and
#      values.
#
# Only the Python standard library and pytest are used.

import os
import pathlib
import filecmp
import pytest

# ---------------------------------------------------------------------
# Constants: Absolute paths and ground-truth data taken from
#            the privileged “truth” section of the exercise.
# ---------------------------------------------------------------------

SRC_ROOT = pathlib.Path("/home/user/mock_remote/var/www/html")
DST_ROOT = pathlib.Path("/home/user/pentest/mirror/web01")
LOG_FILE = pathlib.Path("/home/user/sync_logs/web01_sync.log")

# Expected files (relative paths) and their precise byte sizes
EXPECTED_FILES = {
    pathlib.Path("index.php"): 1254,
    pathlib.Path("admin/login.php"): 2048,
    pathlib.Path("css/style.css"): 512,
}

# Derived helpers
EXPECTED_DIRS = {
    pathlib.Path("."),               # root of mirror
    pathlib.Path("admin"),
    pathlib.Path("css"),
}

TOTAL_BYTES = sum(EXPECTED_FILES.values())
TOTAL_FILES = len(EXPECTED_FILES)
EXPECTED_LOG_LINES = [
    "SYNC SUMMARY\n",
    f"Source: {SRC_ROOT}\n",
    f"Destination: {DST_ROOT}\n",
    f"Files transferred: {TOTAL_FILES}\n",
    f"Bytes transferred: {TOTAL_BYTES}\n",
    "Command exit status: 0\n",
]


# ---------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------
@pytest.fixture(scope="module")
def _source_tree_sanity():
    """Sanity-check that the immutable source tree is still intact."""
    assert SRC_ROOT.is_dir(), (
        f"Source directory '{SRC_ROOT}' is missing — something tampered "
        "with the initial environment."
    )
    for rel_path, expected_size in EXPECTED_FILES.items():
        abs_path = SRC_ROOT / rel_path
        assert abs_path.is_file(), (
            f"Expected source file '{abs_path}' is missing."
        )
        actual_size = abs_path.stat().st_size
        assert actual_size == expected_size, (
            f"Source file '{abs_path}' expected size {expected_size} B, "
            f"found {actual_size} B."
        )
    return True  # simply to be able to depend on it in other tests


# ---------------------------------------------------------------------
# Tests for destination mirror
# ---------------------------------------------------------------------
def test_destination_directory_exists():
    assert DST_ROOT.is_dir(), (
        f"Destination directory '{DST_ROOT}' does not exist or is not a "
        "directory."
    )


def test_expected_files_present_and_identical(_source_tree_sanity):
    """
    Verify that every expected file exists in the destination and is
    byte-for-byte identical to the source counterpart.
    """
    for rel_path, expected_size in EXPECTED_FILES.items():
        src_file = SRC_ROOT / rel_path
        dst_file = DST_ROOT / rel_path

        assert dst_file.is_file(), (
            f"Missing file in destination mirror: '{dst_file}'."
        )

        dst_size = dst_file.stat().st_size
        assert dst_size == expected_size, (
            f"File '{dst_file}' size mismatch: expected {expected_size} B, "
            f"found {dst_size} B."
        )

        # Fast path: size equal & same mtime may indicate sameness, but we
        # demand byte-for-byte equality; use filecmp for efficiency.
        files_match = filecmp.cmp(src_file, dst_file, shallow=False)
        assert files_match, (
            f"File contents differ between source '{src_file}' "
            f"and destination '{dst_file}'."
        )


def test_no_extra_files_or_directories():
    """
    Ensure destination mirror contains *exactly* the expected files and
    directories — nothing more, nothing less.
    """
    # Walk destination and collect regular files/dirs as *relative* paths
    found_files = set()
    found_dirs = {pathlib.Path(".")}
    for root, dirs, files in os.walk(DST_ROOT):
        root_path = pathlib.Path(root)
        rel_root = root_path.relative_to(DST_ROOT)
        for d in dirs:
            found_dirs.add(rel_root / d)
        for f in files:
            found_files.add((rel_root / f))

    extra_files = found_files - set(EXPECTED_FILES.keys())
    missing_files = set(EXPECTED_FILES.keys()) - found_files
    extra_dirs = found_dirs - EXPECTED_DIRS
    missing_dirs = EXPECTED_DIRS - found_dirs

    assert not missing_dirs, (
        "The following required directories are missing from the "
        "destination mirror:\n"
        + "\n".join(sorted(map(str, missing_dirs)))
    )
    assert not extra_dirs, (
        "Found unexpected directories in the destination mirror:\n"
        + "\n".join(sorted(map(str, extra_dirs)))
    )
    assert not missing_files, (
        "The following required files are missing from the destination "
        "mirror:\n" + "\n".join(sorted(map(str, missing_files)))
    )
    assert not extra_files, (
        "Found unexpected files in the destination mirror:\n"
        + "\n".join(sorted(map(str, extra_files)))
    )


# ---------------------------------------------------------------------
# Tests for the transfer log
# ---------------------------------------------------------------------
def test_log_file_exists():
    assert LOG_FILE.is_file(), (
        f"Transfer log '{LOG_FILE}' does not exist or is not a regular file."
    )


def test_log_file_content_exact():
    """
    Validate that the log file contains exactly the six required lines,
    each newline-terminated, and that the numerical values are correct.
    """
    with LOG_FILE.open("r", encoding="utf-8", errors="replace") as fh:
        lines = fh.readlines()

    # Helpful diagnostics on count mismatch
    assert len(lines) == 6, (
        f"Log file should contain exactly 6 lines; found {len(lines)}."
    )

    # Ensure every line is newline-terminated
    for idx, line in enumerate(lines, start=1):
        assert line.endswith("\n"), (
            f"Line {idx} of log file is not newline-terminated."
        )

    # Compare verbatim
    for idx, (expected, actual) in enumerate(zip(EXPECTED_LOG_LINES, lines), start=1):
        assert actual == expected, (
            f"Log line {idx} mismatch:\n"
            f"  expected: {expected!r}\n"
            f"  found:    {actual!r}"
        )