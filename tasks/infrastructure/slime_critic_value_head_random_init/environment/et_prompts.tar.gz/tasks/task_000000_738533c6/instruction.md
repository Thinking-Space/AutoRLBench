<title>Synchronize a Mock Remote Web Root and Produce a Transfer Log</title>

    <description>
        You are performing an initial enumeration phase as part of a penetration-testing
        engagement.  
        A snapshot of the target web server’s document root has been mounted locally
        for offline analysis at:

            /home/user/mock_remote/var/www/html

        Your goal is to synchronize the entire contents of that *source* directory into a local
        working copy and create a log file summarizing the operation.

        **Synchronization Details:**

        The destination for the synchronized copy is:

            /home/user/pentest/mirror/web01

           • The destination directory may or may not exist yet.  
           • The synchronization must be a fast, bandwidth-efficient, recursive copy that preserves timestamps and permissions.
           • Overwrite existing files if the destination already exists.  
           • Delete any files in the destination that are *not* present in the source.  

        **Log File Details:**

        Create a plain-text log file summarizing the operation.
           • Path of the log file:  
                 /home/user/sync_logs/web01_sync.log  
           • If parent directories do not yet exist, create them with default
             user-level permissions.  

           The log file **must contain exactly six newline-terminated lines
           in the precise order shown below** (no extra whitespace):

                SYNC SUMMARY
                Source: /home/user/mock_remote/var/www/html
                Destination: /home/user/pentest/mirror/web01
                Files transferred: <INTEGER>
                Bytes transferred: <INTEGER>
                Command exit status: <INTEGER>

           Replace the three &lt;INTEGER&gt; placeholders with the actual numbers
           from the synchronization (the total count of regular files that were
           copied or updated, the total number of bytes transferred, and the
           exit status of the synchronization operation—usually 0 on success).  
           Do **not** add any additional text, headers, or blank lines.  

    Expected end-state that the automated checker will verify:
        • /home/user/pentest/mirror/web01/ exists and contains an exact
          mirror of /home/user/mock_remote/var/www/html (same files,
          directory layout, and byte-for-byte identical contents).  
        • /home/user/sync_logs/web01_sync.log exists, is readable, and
          matches the six-line format above with correct values.  
    Reminder:
        Run everything as the normal user; sudo is not available.
    </description>