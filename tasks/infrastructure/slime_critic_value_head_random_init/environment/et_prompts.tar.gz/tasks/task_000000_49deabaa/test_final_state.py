# test_final_state.py
#
# Robust pytest test-suite that validates the **final** filesystem
# state after the student has completed the “systemd user timer” task.
#
# The checks are purely file-level (no live systemd needed).
#
# A failure message should make it crystal-clear **what is still
# wrong** so the student can fix the issue quickly.

import os
import stat
import pytest

# ---------------------------------------------------------------------------
# Canonical (absolute) paths that must exist after the task is completed.
# ---------------------------------------------------------------------------
SERVICE_PATH = "/home/user/.config/systemd/user/hello-date.service"
TIMER_PATH   = "/home/user/.config/systemd/user/hello-date.timer"
VERIFY_LOG   = "/home/user/task_verification/created_files.log"

# ---------------------------------------------------------------------------
# Exact, byte-for-byte, expected file contents (each **must** end with
# exactly one UNIX LF '\n' and have no trailing spaces on any line).
# ---------------------------------------------------------------------------
EXPECTED_SERVICE_CONTENT = (
    "[Unit]\n"
    "Description=Write current date to /home/user/date_logs/hello.log\n"
    "\n"
    "[Service]\n"
    "Type=oneshot\n"
    "ExecStart=/usr/bin/env bash -c 'date \"+%F %T\" >> /home/user/date_logs/hello.log'\n"
)

EXPECTED_TIMER_CONTENT = (
    "[Unit]\n"
    "Description=Timer for hello-date.service (writes timestamp to log every 10 minutes)\n"
    "\n"
    "[Timer]\n"
    "OnCalendar=*:0/10\n"
    "Unit=hello-date.service\n"
    "Persistent=true\n"
    "\n"
    "[Install]\n"
    "WantedBy=timers.target\n"
)

EXPECTED_VERIFY_CONTENT = (
    "/home/user/.config/systemd/user/hello-date.service\n"
    "/home/user/.config/systemd/user/hello-date.timer\n"
)

# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------
def read_file(path):
    """Return the full *binary* contents of *path*; fail early if missing."""
    assert os.path.isfile(path), f"Expected file {path!r} does not exist or is not a regular file."
    with open(path, "rb") as fh:
        return fh.read()

def assert_exact_content(path, expected):
    """Assert that *path* exists and matches *expected* bytes exactly."""
    actual = read_file(path)
    exp_bytes = expected.encode("utf-8")
    assert actual == exp_bytes, (
        f"File {path} content mismatch.\n"
        f"--- expected ({len(exp_bytes)} bytes) ---\n{expected!r}\n"
        f"---   found ({len(actual)} bytes) ---\n{actual.decode('utf-8', 'replace')!r}"
    )

def assert_no_trailing_spaces(path, content_text):
    """Fail if any line (excluding its terminating LF) has trailing spaces."""
    for idx, line in enumerate(content_text.splitlines()):
        assert not line.endswith(" "), (
            f"Line {idx+1} in {path} has trailing spaces: {line!r}"
        )

def assert_single_trailing_newline(path, raw_bytes):
    """Every spec file must end with exactly **one** NL, not two or zero."""
    assert raw_bytes.endswith(b"\n"), f"{path} must end with a single '\\n'."
    assert not raw_bytes.endswith(b"\n\n"), (
        f"{path} must end with exactly one trailing newline (not multiple)."
    )

# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("path", [SERVICE_PATH, TIMER_PATH, VERIFY_LOG])
def test_file_exists(path):
    assert os.path.isfile(path), f"Required file {path!r} is missing."

def test_service_file_content_and_format():
    raw_bytes = read_file(SERVICE_PATH)
    content = raw_bytes.decode("utf-8")
    assert_exact_content(SERVICE_PATH, EXPECTED_SERVICE_CONTENT)
    assert_no_trailing_spaces(SERVICE_PATH, content)
    assert_single_trailing_newline(SERVICE_PATH, raw_bytes)

def test_timer_file_content_and_format():
    raw_bytes = read_file(TIMER_PATH)
    content = raw_bytes.decode("utf-8")
    assert_exact_content(TIMER_PATH, EXPECTED_TIMER_CONTENT)
    assert_no_trailing_spaces(TIMER_PATH, content)
    assert_single_trailing_newline(TIMER_PATH, raw_bytes)

def test_verification_log_content_and_format():
    raw_bytes = read_file(VERIFY_LOG)
    content = raw_bytes.decode("utf-8")
    assert_exact_content(VERIFY_LOG, EXPECTED_VERIFY_CONTENT)
    assert_single_trailing_newline(VERIFY_LOG, raw_bytes)

    # Additional semantic checks on the verification log:
    lines = content.strip("\n").split("\n")
    assert lines == sorted(lines), (
        f"The lines in {VERIFY_LOG} are not in ASCII sort order:\n{lines}"
    )

    # Must reference exactly *these* two absolute paths
    expected_lines = [
        "/home/user/.config/systemd/user/hello-date.service",
        "/home/user/.config/systemd/user/hello-date.timer",
    ]
    assert lines == expected_lines, (
        f"{VERIFY_LOG} must contain exactly the two required paths.\n"
        f"Expected lines:\n{expected_lines}\nFound lines:\n{lines}"
    )

def test_parent_directory_structure():
    # Existence and type checks for parent directories—helps pinpoint issues.
    expected_dirs = [
        "/home/user",
        "/home/user/.config",
        "/home/user/.config/systemd",
        "/home/user/.config/systemd/user",
        "/home/user/task_verification",
    ]
    for d in expected_dirs:
        assert os.path.isdir(d), f"Directory {d!r} is missing."

def test_files_are_not_executable():
    # Service + timer + log files should be regular files without the executable bit.
    for path in (SERVICE_PATH, TIMER_PATH, VERIFY_LOG):
        st_mode = os.stat(path).st_mode
        is_executable = bool(st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH))
        assert not is_executable, f"{path} should not have the executable bit set."