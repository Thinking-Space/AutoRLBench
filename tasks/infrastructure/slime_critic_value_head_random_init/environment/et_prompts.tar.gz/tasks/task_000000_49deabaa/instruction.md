You are an infrastructure engineer in the middle of automating a new provisioning workflow.
Management wants **user-level** timers (not system timers) so that every engineer can keep the
service inside their own `$HOME` without touching `/etc`.

Goal
────
1.  Author a **systemd user service** called **hello-date.service** and a matching
    **hello-date.timer** that runs the service every 10 minutes.
2.  Deliver a tiny “proof-of-creation” log so QA can non-interactively grade your work.

Functional requirements
───────────────────────
• Location of units: **/home/user/.config/systemd/user/**
  (Create the directory hierarchy if it does not already exist.)

• hello-date.service — exact file contents **must** be

    [Unit]
    Description=Write current date to /home/user/date_logs/hello.log

    [Service]
    Type=oneshot
    ExecStart=/usr/bin/env bash -c 'date "+%F %T" >> /home/user/date_logs/hello.log'

  The file **must end with a single UNIX newline** and contain **no trailing spaces** on any line.

• hello-date.timer — exact file contents **must** be

    [Unit]
    Description=Timer for hello-date.service (writes timestamp to log every 10 minutes)

    [Timer]
    OnCalendar=*:0/10
    Unit=hello-date.service
    Persistent=true

    [Install]
    WantedBy=timers.target

  This file must also end with a single UNIX newline and have no trailing spaces.

• Do not worry about enabling or starting the timer; unit authoring is enough.
  (There is no systemd in the grading container, only file-level checks.)

Verification artifact
─────────────────────
After creating the two unit files, write **/home/user/task_verification/created_files.log**
with **exactly two lines, in ASCII sort order, terminated by a single final newline**:

    /home/user/.config/systemd/user/hello-date.service
    /home/user/.config/systemd/user/hello-date.timer

QA’s automated tests will:
1.  Read the log file to discover which files you created.
2.  Compare the on-disk contents to the specifications above byte-for-byte.

Non-functional constraints
──────────────────────────
• You do NOT have root; work only under /home/user.
• Use standard GNU/Linux user-space tools available in a minimal Debian/Ubuntu environment.
• When you finish, ensure no additional output is printed to stdout/stderr other than what
  your commands naturally emit while creating the files. (The grader will ignore stdout,
  but please keep it tidy.)