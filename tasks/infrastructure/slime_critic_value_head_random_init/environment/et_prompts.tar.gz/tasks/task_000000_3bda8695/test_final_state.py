# test_final_state.py
#
# Pytest suite that validates the **FINAL** state of the operating-system /
# container after the student has carried out the “current_data” symlink task.
#
# What we check:
# 1. /home/user/data/current_data  is a *symbolic link* (not a file/dir).
# 2. os.path.realpath() of that symlink is exactly
#       /home/user/data/dataset_v3
# 3. /home/user/output/symlink_log.txt
#       • exists,
#       • is a regular file (not a symlink/dir),
#       • is world-readable,
#       • contains exactly one line which is the canonicalised absolute
#         destination of the symlink, terminated by a single newline.
# 4. The three dataset directories still exist and are real directories
#    (i.e. were not replaced by the symlink operation).

import os
import stat
import pytest

HOME = "/home/user"
DATA_DIR = os.path.join(HOME, "data")
OUTPUT_DIR = os.path.join(HOME, "output")

DATASET_V1 = os.path.join(DATA_DIR, "dataset_v1")
DATASET_V2 = os.path.join(DATA_DIR, "dataset_v2")
DATASET_V3 = os.path.join(DATA_DIR, "dataset_v3")

SYMLINK_PATH = os.path.join(DATA_DIR, "current_data")
LOG_FILE = os.path.join(OUTPUT_DIR, "symlink_log.txt")


# --------------------------------------------------------------------------- #
# Helpers                                                                     #
# --------------------------------------------------------------------------- #
def _assert_is_real_directory(path: str) -> None:
    """
    Assert that `path` exists and is a real directory (not a symlink).
    """
    assert os.path.exists(path), f"Directory {path!r} is missing."
    st = os.lstat(path)
    assert stat.S_ISDIR(st.st_mode), f"{path!r} should be a directory."
    assert not stat.S_ISLNK(
        st.st_mode
    ), f"{path!r} should be a real directory, not a symlink."


# --------------------------------------------------------------------------- #
# Tests                                                                       #
# --------------------------------------------------------------------------- #
def test_symlink_exists_and_is_symlink():
    """
    /home/user/data/current_data must exist and be a symbolic link
    (not a file or directory).
    """
    assert os.path.lexists(
        SYMLINK_PATH
    ), f"Expected symlink {SYMLINK_PATH!r} does not exist."

    st_mode = os.lstat(SYMLINK_PATH).st_mode
    assert stat.S_ISLNK(
        st_mode
    ), f"{SYMLINK_PATH!r} exists but is not a symbolic link."


def test_symlink_resolves_to_dataset_v3():
    """
    The symlink must ultimately resolve to /home/user/data/dataset_v3
    (the canonical absolute path, identical byte-for-byte).
    """
    resolved = os.path.realpath(SYMLINK_PATH)
    assert (
        resolved == DATASET_V3
    ), f"Symlink resolves to {resolved!r}, expected {DATASET_V3!r}."


def test_target_directory_still_exists_and_is_directory():
    """
    The destination directory (/home/user/data/dataset_v3/) must still
    exist and be a real directory (not replaced with something else).
    """
    _assert_is_real_directory(DATASET_V3)


@pytest.mark.parametrize(
    "dataset_dir",
    [DATASET_V1, DATASET_V2, DATASET_V3],
)
def test_other_dataset_directories_unchanged(dataset_dir):
    """
    Ensure all dataset_v* directories continue to exist as real directories.
    (This guards against accidental deletion or clobbering.)
    """
    _assert_is_real_directory(dataset_dir)


def test_log_file_exists_and_is_regular_world_readable():
    """
    /home/user/output/symlink_log.txt must exist, be a regular file
    (not a symlink/dir), and be world-readable.
    """
    assert os.path.exists(LOG_FILE), f"Log file {LOG_FILE!r} does not exist."

    st = os.lstat(LOG_FILE)

    # Must be a regular file
    assert stat.S_ISREG(
        st.st_mode
    ), f"{LOG_FILE!r} should be a regular file, not a directory or symlink."

    # Must be world-readable (owner/group/others – at least 'others')
    assert (
        st.st_mode & stat.S_IROTH
    ), f"{LOG_FILE!r} is not world-readable (others lack read permission)."


def test_log_file_contents_are_correct():
    """
    The log file must contain exactly one line:
        /home/user/data/dataset_v3\n
    with no extra whitespace or additional lines.
    """
    with open(LOG_FILE, "rb") as fh:
        content = fh.read()

    # Content must end with exactly one trailing newline and nothing else
    expected_bytes = (DATASET_V3 + "\n").encode()

    assert (
        content == expected_bytes
    ), (
        "Log file contents are incorrect.\n"
        f"Expected: {expected_bytes!r}\n"
        f"Got     : {content!r}"
    )

    # Extra defensive check: number of newline characters must be exactly 1
    newline_count = content.count(b"\n")
    assert (
        newline_count == 1
    ), f"Log file should contain exactly one newline, found {newline_count}."