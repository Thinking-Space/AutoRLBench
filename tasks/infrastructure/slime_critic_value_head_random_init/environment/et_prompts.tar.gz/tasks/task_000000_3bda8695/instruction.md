You are assisting a machine-learning engineer who keeps several versions of a training-data directory under:

/home/user/data/dataset_v1/  
/home/user/data/dataset_v2/  
/home/user/data/dataset_v3/

For downstream scripts to always pick up the newest data, the engineer wants a symbolic link called

/home/user/data/current_data

that points to the latest directory (/home/user/data/dataset_v3).

Your goal is to create (or replace, if it already exists) the symbolic link /home/user/data/current_data so that it resolves to /home/user/data/dataset_v3. You must also produce a verification log file at /home/user/output/symlink_log.txt that contains the fully-resolved absolute path of the link target.

**Required verification format**
*   The file /home/user/output/symlink_log.txt must exist when you finish.
*   It must contain exactly one line, ending with a single trailing newline.
*   That line must be the canonicalised absolute path of the symbolic link’s destination, i.e.

    `/home/user/data/dataset_v3`

    (no extra spaces, no additional lines).

Testing will confirm both that the symlink exists and that the log file matches the format above.